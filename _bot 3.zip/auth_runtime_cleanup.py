import os
import signal
import time
import logging
from contextlib import suppress


logger = logging.getLogger("auth_runtime_cleanup")
XRAY_CFG_DIR = "/root/ocr/zooma/bot/xray-sessions"
AUTH_SID_MARKER = "--zooma-auth-sid="


def _iter_proc_cmdline():
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        pid = int(name)
        cmdline_path = f"/proc/{pid}/cmdline"
        try:
            with open(cmdline_path, "rb") as f:
                raw = f.read()
            if not raw:
                continue
            parts = [p.decode("utf-8", errors="ignore") for p in raw.split(b"\x00") if p]
            if parts:
                yield pid, parts
        except Exception:
            continue


def _kill_pid(pid: int) -> None:
    with suppress(Exception):
        os.kill(pid, signal.SIGTERM)
    time.sleep(0.05)
    with suppress(Exception):
        os.kill(pid, 0)
        os.kill(pid, signal.SIGKILL)


def cleanup_orphan_auth_runtime() -> dict:
    killed_xray = 0
    killed_browser = 0
    removed_cfg = 0

    cfg_paths = []
    if os.path.isdir(XRAY_CFG_DIR):
        for fn in os.listdir(XRAY_CFG_DIR):
            if fn.endswith(".json"):
                cfg_paths.append(os.path.join(XRAY_CFG_DIR, fn))

    # Kill only xray processes started with our per-session configs.
    cfg_set = set(cfg_paths)
    for pid, args in _iter_proc_cmdline():
        cmd = " ".join(args)
        if "xray" in cmd and " run " in f" {cmd} " and "-config" in args:
            for p in cfg_set:
                if p in args or p in cmd:
                    _kill_pid(pid)
                    killed_xray += 1
                    break

    # Kill only browser processes that carry our explicit marker.
    for pid, args in _iter_proc_cmdline():
        cmd = " ".join(args)
        if AUTH_SID_MARKER in cmd:
            _kill_pid(pid)
            killed_browser += 1

    # Remove stale session config files.
    for p in cfg_paths:
        with suppress(Exception):
            os.remove(p)
            removed_cfg += 1

    logger.info(
        "auth runtime cleanup: killed_xray=%s killed_browser=%s removed_cfg=%s",
        killed_xray, killed_browser, removed_cfg,
    )
    return {"killed_xray": killed_xray, "killed_browser": killed_browser, "removed_cfg": removed_cfg}
