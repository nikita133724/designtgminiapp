import os


# Telegram Bot token
BOT_TOKEN = os.getenv("BOT_TOKEN", "8970987446:AAEpTb0vEAxs7TGwlSDtA7RCVoEyKBb362s").strip()
# Proxy for Telegram API only
PROXY_HOST = os.getenv("TG_PROXY_HOST", "127.0.0.1").strip()
PROXY_PORT = int(os.getenv("TG_PROXY_PORT", "1080").strip())
PROXY_SCHEME = os.getenv("PROXY_SCHEME", "socks5").strip()
USE_PROXY = os.getenv("ZOOMA_USE_PROXY", "1").strip().lower() in {"1", "true", "yes", "on"}
# Resolver URL for active casino domain
ZREF_URL = os.getenv("ZREF_URL", "https://zref.pro").strip()
# Optional forced casino domain (when set, zref resolver is fully bypassed)
FORCE_ACTIVE_DOMAIN = os.getenv("FORCE_ACTIVE_DOMAIN", "").strip()

# Internal FastAPI host/port (promo + billing webhook)
PROMO_API_HOST = os.getenv("PROMO_API_HOST", "127.0.0.1").strip()
PROMO_API_PORT = int(os.getenv("PROMO_API_PORT", "8789").strip())
# Public HTTPS base URL for Telegram Mini App links
PUBLIC_WEB_BASE_URL = os.getenv("PUBLIC_WEB_BASE_URL", "https://qidnm728nwjskkx.qzz.io").strip().rstrip("/")

# Browser extension WebSocket settings. On VPS you can expose ws://IP:PORT,
# on Render use the public Render domain because free web services expose one HTTP(S) port.
EXTENSION_WS_PUBLIC_URL = os.getenv("ZOOMA_EXTENSION_WS_PUBLIC_URL", "").strip().rstrip("/")
EXTENSION_WS_SECRET = os.getenv("ZOOMA_EXTENSION_WS_SECRET", "").strip()
EXTENSION_PROMO_TIMEOUT_SEC = float(os.getenv("ZOOMA_EXTENSION_PROMO_TIMEOUT_SEC", "30").strip() or "30")
# Detailed extension key/challenge/proof diagnostics. Change the default to "on" or set ZOOMA_EXTENSION_CRYPTO_DEBUG=on.
EXTENSION_CRYPTO_DEBUG = os.getenv("ZOOMA_EXTENSION_CRYPTO_DEBUG", "false").strip().lower() in {"1", "true", "yes", "on"}
TG_WATCHER_IN_MAIN_ENABLED = os.getenv("ZOOMA_TG_WATCHER_IN_MAIN", "1").strip().lower() in {"1", "true", "yes", "on"}

# Domain watcher intervals
DOMAIN_CHECK_INTERVAL_SEC = int(os.getenv("DOMAIN_CHECK_INTERVAL_SEC", "60").strip())
DOMAIN_RETRY_DELAY_SEC = int(os.getenv("DOMAIN_RETRY_DELAY_SEC", "2").strip())
# Session probe intervals
SESSION_PROBE_SLEEP_MIN_SEC = int(os.getenv("SESSION_PROBE_SLEEP_MIN_SEC", "60").strip())
SESSION_PROBE_SLEEP_MAX_SEC = int(os.getenv("SESSION_PROBE_SLEEP_MAX_SEC", "180").strip())
SESSION_PROBE_SCAN_IDLE_SEC = int(os.getenv("SESSION_PROBE_SCAN_IDLE_SEC", "60").strip())
DOMAIN_REFRESH_CONCURRENCY = int(os.getenv("DOMAIN_REFRESH_CONCURRENCY", "2").strip())
DOMAIN_REFRESH_ACCOUNT_GAP_SEC = float(os.getenv("DOMAIN_REFRESH_ACCOUNT_GAP_SEC", "1.0").strip())
STARTUP_RESTORE_CONCURRENCY = int(os.getenv("STARTUP_RESTORE_CONCURRENCY", "5").strip())
STARTUP_RESTORE_ACCOUNT_GAP_SEC = float(os.getenv("STARTUP_RESTORE_ACCOUNT_GAP_SEC", "0").strip())
# WS refresh interval range per user
WS_REFRESH_MIN_SEC = int(os.getenv("WS_REFRESH_MIN_SEC", str(60 * 60)).strip())
WS_REFRESH_MAX_SEC = int(os.getenv("WS_REFRESH_MAX_SEC", str(90 * 60)).strip())

# Chat AI (rain_runtime) settings. Account enable flags are stored inside casino_accounts_json.
CHAT_AI_BUFFER_SIZE = int(os.getenv("CHAT_AI_BUFFER_SIZE", "35").strip())
CHAT_AI_INTERVAL_MIN_SEC = int(os.getenv("CHAT_AI_INTERVAL_MIN_SEC", str(10 * 60)).strip())
CHAT_AI_INTERVAL_MAX_SEC = int(os.getenv("CHAT_AI_INTERVAL_MAX_SEC", str(25 * 60)).strip())
CHAT_AI_GROQ_API_KEY = os.getenv("GROQ_API_KEY", "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").strip()
CHAT_AI_GROQ_API_URL = os.getenv("GROQ_API_URL", "https://api.groq.com/openai/v1/chat/completions").strip()
CHAT_AI_GROQ_MODEL = os.getenv("GROQ_MODEL", "qwen/qwen3.6-27b").strip()
CHAT_AI_GROQ_PROXY_URL = (os.getenv("GROQ_PROXY_URL", "socks5://127.0.0.1:1080") if USE_PROXY else "").strip()
CPU_WATCHDOG_ENABLED = os.getenv("ZOOMA_CPU_WATCHDOG_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
CPU_WATCHDOG_THRESHOLD_PCT = float(os.getenv("ZOOMA_CPU_WATCHDOG_THRESHOLD_PCT", "60").strip())
CPU_WATCHDOG_DURATION_SEC = float(os.getenv("ZOOMA_CPU_WATCHDOG_DURATION_SEC", "420").strip())
CPU_WATCHDOG_INTERVAL_SEC = float(os.getenv("ZOOMA_CPU_WATCHDOG_INTERVAL_SEC", "15").strip())
CHAT_AI_MAX_RESPONSE_LENGTH = int(os.getenv("CHAT_AI_MAX_RESPONSE_LENGTH", "80").strip())
CHAT_AI_RAIN_MISS_MIN_DELAY_SEC = int(os.getenv("CHAT_AI_RAIN_MISS_MIN_DELAY_SEC", "5").strip())
CHAT_AI_RAIN_MISS_MAX_DELAY_SEC = int(os.getenv("CHAT_AI_RAIN_MISS_MAX_DELAY_SEC", "20").strip())

# Billing worker tick interval
BILLING_CHECK_INTERVAL_SEC = int(os.getenv("BILLING_CHECK_INTERVAL_SEC", "5").strip())
# Payment message countdown update period
INVOICE_COUNTDOWN_UPDATE_SEC = int(os.getenv("INVOICE_COUNTDOWN_UPDATE_SEC", "30").strip())
# Invoice lifetime (seconds)
INVOICE_TTL_SEC = int(os.getenv("INVOICE_TTL_SEC", "300").strip())

# CryptoBot API settings
CRYPTO_PAY_API_TOKEN = os.getenv("CRYPTO_PAY_API_TOKEN", "508410:AANih0tQdF6iD9qClit0e63EwX0QVDy1D0n").strip()
CRYPTO_PAY_API_BASE = os.getenv("CRYPTO_PAY_API_BASE", "https://pay.crypt.bot/api").strip().rstrip("/")
# Temporary webhook protection token (until crypto-pay-api-signature is enabled)
INTERNAL_WEBHOOK_TOKEN = os.getenv("INTERNAL_WEBHOOK_TOKEN", "change_me_long_random_token").strip()
# If true, billing webhook requires X-Internal-Token header match.
# For direct CryptoBot callbacks keep it false.
REQUIRE_INTERNAL_WEBHOOK_TOKEN = os.getenv("REQUIRE_INTERNAL_WEBHOOK_TOKEN", "0").strip().lower() in {"1", "true", "yes", "on"}
# Allowed relative difference for paid amount check (e.g. 0.01 => 1%)
PAYMENT_AMOUNT_REL_TOLERANCE = float(os.getenv("PAYMENT_AMOUNT_REL_TOLERANCE", "0.01").strip())
# Allowed absolute difference in USDT for amount check
PAYMENT_AMOUNT_ABS_TOLERANCE = float(os.getenv("PAYMENT_AMOUNT_ABS_TOLERANCE", "0.05").strip())
# RUB -> USD exchange rate source
RUB_USD_RATE_URL = os.getenv("RUB_USD_RATE_URL", "https://open.er-api.com/v6/latest/RUB").strip()

# Tariffs map (extend here later)
DEFAULT_TARIFFS = {
    "lite": {
        "title": "лайт",
        "days": 30,
        "price_rub": 700,
    }
}

# Steam auth start URL opened by headless browser flow
STEAM_AUTH_START_URL = os.getenv(
    "STEAM_AUTH_START_URL",
    "https://casiauth.com/go?from=zooma.casino&type=st",
).strip()
# Yandex auth start URL opened by browser flow
YANDEX_AUTH_START_URL = os.getenv(
    "YANDEX_AUTH_START_URL",
    "https://casiauth.com/go?from=zooma.casino&type=ya",
).strip()
# SOCKS5 proxy for Steam connect user and browser auth flow
STEAM_CONNECT_SOCKS5_PROXY = os.getenv(
    "STEAM_CONNECT_SOCKS5_PROXY",
    "socks5://B86tLg9C:m4EW7wQH@166.1.187.159:63135",
).strip()
# HTTP proxy for Playwright browser Steam auth flow
STEAM_BROWSER_HTTP_PROXY = os.getenv(
    "STEAM_BROWSER_HTTP_PROXY",
    "http://B86tLg9C:m4EW7wQH@166.1.187.159:63134",
).strip()
# Local Xray HTTP bridge for Playwright browser auth flows (TG/Yandex)
XRAY_HTTP_BRIDGE = os.getenv("XRAY_HTTP_BRIDGE", "http://127.0.0.1:8899").strip()
# Telegram chat id for Steam Mini App connect flow
STEAM_CONNECT_CHAT_ID = int(os.getenv("STEAM_CONNECT_CHAT_ID", "7670381241").strip())
ADMIN_CHAT_ID = int(os.getenv("ADMIN_CHAT_ID", "754274025").strip())
ADMIN_PANEL_TOKEN = os.getenv("ADMIN_PANEL_TOKEN", "change_admin_panel_token").strip()
RAIN_BOT_NAME = os.getenv("RAIN_BOT_NAME", "zooma").strip() or "zooma"
RAIN_TARGET_CHAT = os.getenv("RAIN_TARGET_CHAT", "@bonus_zooma").strip() or "@bonus_zooma"
PROXYLINE_API_TOKEN = os.getenv("PROXYLINE_API_TOKEN", "RFiTJVARG2cENcbS6E1Sw1KniN3Ebu7blBb9sedw").strip()
PROXYLINE_API_BASE = os.getenv("PROXYLINE_API_BASE", "https://panel.proxyline.net/api").strip().rstrip("/")
PROXYLINE_COUNTRY_POOL = [
    c.strip().lower()
    for c in os.getenv(
        "PROXYLINE_COUNTRY_POOL",
        "ru,de,us,nl,gb,ca,es,it,id,fr,ch,pt,ua,kz,cn,pl,in,jp,au,at,az,al,dz,ao,ad,ar,am,bd,bh,by,be,bg,bo,ba,br,hu,ve,vn,gt,hk,gl,gr,ge,dk,do,eg,il,jo,iq,ir,ie,is,kh,cm,qa,ke,cy,co,cr,cu,kg,lv,lr,ly,lt,lu,mg,my,mv,mt,ma,mx,md,mc,mn,np,ng,nz,no,ae,om,pk,pa,py,pe,pr,ro,sa,mk,sc,rs,sg,sk,si,tj,th,tw,tz,tn,tm,tr,uz,uy,ph,fi,hr,me,cz,cl,se,lk,ec,ee,et,za,kr,jm",
    ).split(",")
    if c.strip()
]
PROXYLINE_LOW_BALANCE_RUB = float(os.getenv("PROXYLINE_LOW_BALANCE_RUB", "1000").strip())
PROXYLINE_BALANCE_CACHE_TTL_SEC = int(os.getenv("PROXYLINE_BALANCE_CACHE_TTL_SEC", "45").strip())
PROXYLINE_LOW_BALANCE_ALERT_COOLDOWN_SEC = int(os.getenv("PROXYLINE_LOW_BALANCE_ALERT_COOLDOWN_SEC", str(6 * 60 * 60)).strip())
PROXYLINE_PRICE_BUFFER_PCT = float(os.getenv("PROXYLINE_PRICE_BUFFER_PCT", "1.1").strip())
PROXY_HEALTH_CHECK_INTERVAL_SEC = int(os.getenv("PROXY_HEALTH_CHECK_INTERVAL_SEC", "300").strip())
PROXY_HEALTH_BATCH_SIZE = int(os.getenv("PROXY_HEALTH_BATCH_SIZE", "5").strip())
PROXY_HEALTH_ALERT_COOLDOWN_SEC = int(os.getenv("PROXY_HEALTH_ALERT_COOLDOWN_SEC", "1800").strip())

PROXYLINE_COUNTRY_RU = {
    "ru": "Россия", "de": "Германия", "us": "США", "nl": "Нидерланды", "gb": "Великобритания", "ca": "Канада",
    "es": "Испания", "it": "Италия", "id": "Индонезия", "fr": "Франция", "ch": "Швейцария", "pt": "Португалия",
    "ua": "Украина", "kz": "Казахстан", "cn": "Китай", "pl": "Польша", "in": "Индия", "jp": "Япония", "au": "Австралия",
    "at": "Австрия", "az": "Азербайджан", "al": "Албания", "dz": "Алжир", "ao": "Ангола", "ad": "Андорра",
    "ar": "Аргентина", "am": "Армения", "bd": "Бангладеш", "bh": "Бахрейн", "by": "Беларусь", "be": "Бельгия",
    "bg": "Болгария", "bo": "Боливия", "ba": "Босния и Герцеговина", "br": "Бразилия", "hu": "Венгрия", "ve": "Венесуэла",
    "vn": "Вьетнам", "gt": "Гватемала", "hk": "Гонконг", "gl": "Гренландия", "gr": "Греция", "ge": "Грузия",
    "dk": "Дания", "do": "Доминиканская республика", "eg": "Египет", "il": "Израиль", "jo": "Иордания", "iq": "Ирак",
    "ir": "Иран", "ie": "Ирландия", "is": "Исландия", "kh": "Камбоджа", "cm": "Камерун", "qa": "Катар", "ke": "Кения",
    "cy": "Кипр", "co": "Колумбия", "cr": "Коста-Рика", "cu": "Куба", "kg": "Кыргызстан", "lv": "Латвия",
    "lr": "Либерия", "ly": "Ливия", "lt": "Литва", "lu": "Люксембург", "mg": "Мадагаскар", "my": "Малайзия",
    "mv": "Мальдивы", "mt": "Мальта", "ma": "Марокко", "mx": "Мексика", "md": "Молдова", "mc": "Монако",
    "mn": "Монголия", "np": "Непал", "ng": "Нигерия", "nz": "Новая Зеландия", "no": "Норвегия", "ae": "ОАЭ",
    "om": "Оман", "pk": "Пакистан", "pa": "Панама", "py": "Парагвай", "pe": "Перу", "pr": "Пуэрто-Рико",
    "ro": "Румыния", "sa": "Саудовская Аравия", "mk": "Северная Македония", "sc": "Сейшелы", "rs": "Сербия",
    "sg": "Сингапур", "sk": "Словакия", "si": "Словения", "tj": "Таджикистан", "th": "Таиланд", "tw": "Тайвань",
    "tz": "Танзания", "tn": "Тунис", "tm": "Туркменистан", "tr": "Турция", "uz": "Узбекистан", "uy": "Уругвай",
    "ph": "Филиппины", "fi": "Финляндия", "hr": "Хорватия", "me": "Черногория", "cz": "Чехия", "cl": "Чили",
    "se": "Швеция", "lk": "Шри-Ланка", "ec": "Эквадор", "ee": "Эстония", "et": "Эфиопия", "za": "ЮАР", "kr": "Южная Корея", "jm": "Ямайка",
}

# Default Centrifugo websocket endpoint for all users
DEFAULT_CENTRIFUGO_SOCKET = os.getenv(
    "DEFAULT_CENTRIFUGO_SOCKET",
    "wss://casisocket.com:9001/connection/websocket",
).strip()

# Supabase state backend
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://qzilosvjftximfduneuz.supabase.co").strip()
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF6aWxvc3ZqZnR4aW1mZHVuZXV6Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTc1NTQ5NiwiZXhwIjoyMDk1MzMxNDk2fQ.HhuIEi-gz4GinNKlw5p6d8HaeQHdYUFT3Lf1_XR7-GY").strip()
SUPABASE_USERS_TABLE = os.getenv("SUPABASE_USERS_TABLE", "users").strip() or "users"
SUPABASE_PENDING_ORDERS_TABLE = os.getenv("SUPABASE_PENDING_ORDERS_TABLE", "pending_orders").strip() or "pending_orders"

# Internal signature secret for invoice payload validation
PAYLOAD_SIGN_SECRET = os.getenv("PAYLOAD_SIGN_SECRET", "570e266d7cb17492d8242c572e198e78c3949f6037f020daeaa07c2c1bf6ae44").strip()
EXPIRED_ORDER_KEEP_DAYS = int(os.getenv("EXPIRED_ORDER_KEEP_DAYS", "7").strip())

# Xray bridge run command:
# xray run -config /root/ocr/zooma/bot/xray-bridge-8899.json
