import contextlib
import hashlib
import json
import logging
import os
import queue
import threading
import time
from typing import Any, Optional
from urllib.parse import quote, unquote, urlparse

import httpx
import store

logger = logging.getLogger("db_normalized")

ACCOUNT_TABLE = os.getenv("SUPABASE_CASINO_ACCOUNTS_TABLE", "casino_accounts").strip() or "casino_accounts"
PROXY_IMMEDIATE_PING_SAMPLES = max(1, int(os.getenv("PROXY_IMMEDIATE_PING_SAMPLES", "3").strip() or "3"))
PROXY_IMMEDIATE_PING_TIMEOUT = max(1.0, float(os.getenv("PROXY_IMMEDIATE_PING_TIMEOUT_SEC", "5").strip() or "5"))

ACCOUNT_WRITE_RETRY_MAX = max(0, int(os.getenv("DB_NORMALIZED_WRITE_RETRY_MAX", "3").strip() or "3"))
ACCOUNT_WRITE_RETRY_BASE_SEC = max(0.2, float(os.getenv("DB_NORMALIZED_WRITE_RETRY_BASE_SEC", "1.0").strip() or "1.0"))
ACCOUNT_WRITE_RETRY_MAX_SEC = max(1.0, float(os.getenv("DB_NORMALIZED_WRITE_RETRY_MAX_SEC", "8.0").strip() or "8.0"))
ACCOUNT_LOAD_RETRY_MAX = max(0, int(os.getenv("DB_NORMALIZED_LOAD_RETRY_MAX", "3").strip() or "3"))

USER_FIELDS = {
    "tg_username",
    "active_account_id",
    "last_profile_message_id",
    "last_ui_message_id",
    "stale_notified_at_ts",
    "timezone_name",
    "timezone_offset_min",
    "timezone_updated_at_ts",
    "timezone_source",
    "timezone_valid",
    "locale",
    "promo_activated_count",
    "promo_activated_total_amount",
    "promo_month_key",
    "promo_month_count",
    "promo_month_total_amount",
    "extension_bound_chat_id",
    "extension_bound_account_id",
    "extension_bound_at_ts",
}

ACCOUNT_FIELDS = {
    "port_user_id",
    "port_user_name",
    "centrifugo_socket",
    "centrifugo_secret",
    "zooma_top_session",
    "zooma_top_session_expires_at",
    "csrf_token",
    "fingerprint_now",
    "user_agent",
    "subscription_tier",
    "subscription_until_ts",
    "subscription_paused",
    "subscription_pause_started_ts",
    "subscription_frozen_left_sec",
    "subscription_warn_1d_for_ts",
    "promo_activation_paused",
    "promo_activation_mode",
    "extension_bound_device_id",
    "extension_public_key_jwk",
    "extension_key_id",
    "extension_binding_version",
    "extension_key_created_ts",
    "proxy_url",
    "proxy_country",
    "proxy_city",
    "proxy_order_id",
    "proxy_ip",
    "proxy_port_http",
    "proxy_port_socks5",
    "proxy_login",
    "proxy_password",
    "proxy_scheme",
    "train_jobs",
    "chat_ai_enabled",
    "chat_ai_api_key",
    "chat_ai_key_mode",
    "chat_ai_interval_min_sec",
    "chat_ai_interval_max_sec",
    "chat_ai_next_run_ts",
    "chat_ai_last_sent_ts",
    "chat_ai_last_error",
    "chat_ai_recent_messages",
    "chat_ai_pending_task",
    "chat_ai_rain_miss_messages",
    "chat_ai_cycle_started_ts",
    "chat_ai_rest_until_ts",
    "chat_ai_rate_limits",
    "server_session_state",
    "casino_accounts_json",
}

RUNTIME_ONLY_FIELDS = {
    "connected",
    "ws_live",
    "reconnecting",
    "proxy_ping_ms",
    "proxy_ping_last_ts",
    "proxy_ping_error",
    "proxy_ping_source",
    "effective_ping_ms",
    "effective_ping_source",
    "server_ping_ms",
}

ACCOUNT_WRITE_QUEUE: "queue.Queue[tuple[str, Any]]" = queue.Queue()
ACCOUNT_WRITER_STARTED = False
ACCOUNT_WRITER_LOCK = threading.Lock()
ACCOUNT_TABLE_AVAILABLE: Optional[bool] = None
LAST_ACCOUNT_HASH: dict[tuple[int, str], str] = {}
LAST_ACCOUNT_ROWS: dict[tuple[int, str], dict] = {}


def _now_ts() -> int:
    return int(time.time())


def _s(value: Any) -> str:
    return str(value or "").strip()


def _i(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except Exception:
        return default


def _b(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    s = str(value).strip().lower()
    if s in {"1", "true", "yes", "y", "on"}:
        return True
    if s in {"0", "false", "no", "n", "off"}:
        return False
    return default


def _json_object(value: Any) -> dict:
    """Return a detached JSON object, accepting native jsonb values or legacy strings."""
    if isinstance(value, dict):
        try:
            return json.loads(json.dumps(value, ensure_ascii=False, default=str))
        except Exception:
            return dict(value)
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}


def _json_list(value: Any) -> list:
    """Return a detached JSON list, accepting native jsonb values or strings."""
    if isinstance(value, list):
        try:
            return json.loads(json.dumps(value, ensure_ascii=False, default=str))
        except Exception:
            return list(value)
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except Exception:
            pass
    return []


def _build_proxy_url(*, scheme: str, host: str, port: Optional[int], login: str = "", password: str = "") -> str:
    if not host or not port:
        return ""
    sch = (scheme or "socks5").strip().lower() or "socks5"
    auth = ""
    if login or password:
        auth = f"{quote(login, safe='')}:{quote(password, safe='')}@"
    return f"{sch}://{auth}{host}:{int(port)}"


def normalize_proxy_fields(account: dict) -> dict:
    a = dict(account or {})
    proxy_url = _s(a.get("proxy_url"))
    scheme = _s(a.get("proxy_scheme")).lower()
    host = _s(a.get("proxy_ip"))
    port_http = _i(a.get("proxy_port_http"), 0) or None
    port_socks5 = _i(a.get("proxy_port_socks5"), 0) or None
    login = _s(a.get("proxy_login"))
    password = _s(a.get("proxy_password"))

    if proxy_url:
        raw_url = proxy_url if "://" in proxy_url else f"socks5://{proxy_url}"
        with contextlib.suppress(Exception):
            parsed = urlparse(raw_url)
            parsed_scheme = _s(parsed.scheme).lower()
            if parsed_scheme and not scheme:
                scheme = parsed_scheme
            if parsed.hostname and not host:
                host = parsed.hostname
            if parsed.username and not login:
                login = unquote(parsed.username)
            if parsed.password and not password:
                password = unquote(parsed.password)
            if parsed.port:
                if scheme in {"http", "https"}:
                    port_http = port_http or int(parsed.port)
                elif scheme in {"socks", "socks4", "socks5"}:
                    port_socks5 = port_socks5 or int(parsed.port)
                elif not port_http and not port_socks5:
                    port_socks5 = int(parsed.port)

    if not scheme:
        scheme = "socks5" if port_socks5 or not port_http else "http"

    if not proxy_url and host:
        primary_port = port_socks5 if scheme in {"socks", "socks4", "socks5"} else port_http
        primary_port = primary_port or port_socks5 or port_http
        proxy_url = _build_proxy_url(scheme=scheme, host=host, port=primary_port, login=login, password=password)

    if proxy_url:
        a["proxy_url"] = proxy_url
    if host:
        a["proxy_ip"] = host
    if port_http:
        a["proxy_port_http"] = int(port_http)
    if port_socks5:
        a["proxy_port_socks5"] = int(port_socks5)
    if login:
        a["proxy_login"] = login
    if password:
        a["proxy_password"] = password
    if scheme:
        a["proxy_scheme"] = scheme
    return a


def _short_ping_error(err: Exception | str) -> str:
    raw = str(err or "").strip()
    low = raw.lower()
    if not raw:
        return "unknown_error"
    if "407" in low or "proxy authentication" in low:
        return "proxy_auth_failed"
    if "timeout" in low or "timed out" in low:
        return "timeout"
    if "name resolution" in low or "temporary failure" in low:
        return "dns_error"
    if "connection" in low or "connecterror" in low or "connection refused" in low:
        return "connect_error"
    return raw[:120]


def _active_ping_target() -> str:
    with contextlib.suppress(Exception):
        active = str(store.get_active_domain() or "").strip().rstrip("/")
        if active:
            return active
    return str(os.getenv("PROXY_HEALTH_RESERVE_URL", "https://api.ipify.org?format=json")).strip()


def _measure_proxy_ping(proxy_url: str) -> tuple[Optional[float], str]:
    proxy_url = _s(proxy_url)
    target = _active_ping_target()
    if not proxy_url:
        return None, ""
    if not target:
        return None, "empty_target"

    ok_values: list[float] = []
    errors: list[str] = []
    headers = {"User-Agent": "Mozilla/5.0 (compatible; ZOOMA-ImmediatePing/1.0)"}
    try:
        with httpx.Client(
            timeout=httpx.Timeout(PROXY_IMMEDIATE_PING_TIMEOUT),
            proxy=proxy_url,
            follow_redirects=True,
            headers=headers,
        ) as client:
            for idx in range(PROXY_IMMEDIATE_PING_SAMPLES):
                t0 = time.perf_counter()
                try:
                    resp = client.get(target)
                    if int(resp.status_code) >= 500:
                        raise RuntimeError(f"HTTP {resp.status_code}")
                    ok_values.append((time.perf_counter() - t0) * 1000.0)
                except Exception as e:
                    errors.append(_short_ping_error(e))
                if idx + 1 < PROXY_IMMEDIATE_PING_SAMPLES:
                    time.sleep(0.1)
    except Exception as e:
        errors.append(_short_ping_error(e))

    if ok_values:
        return sum(ok_values) / len(ok_values), ""
    return None, (errors[-1] if errors else "failed_samples")


def _start_immediate_proxy_ping(chat_id: int, account_id: Optional[str], proxy_url: Optional[str]) -> None:
    aid = _s(account_id) or "acc_1"
    purl = _s(proxy_url)

    def worker() -> None:
        try:
            acc = store.get_user_account(int(chat_id), aid) or {}
            if bool(acc.get("subscription_paused")):
                store.patch_user_account(int(chat_id), aid, proxy_ping_last_ts=0, proxy_ping_ms=None, proxy_ping_error="")
                logger.info("immediate proxy ping skipped frozen | chat_id=%s account_id=%s", chat_id, aid)
                return
            if not purl:
                store.patch_user_account(int(chat_id), aid, proxy_ping_last_ts=0, proxy_ping_ms=None, proxy_ping_error="")
                return
            avg_ms, err = _measure_proxy_ping(purl)
            store.patch_user_account(
                int(chat_id),
                aid,
                proxy_ping_last_ts=int(time.time()),
                proxy_ping_ms=avg_ms,
                proxy_ping_error=err or "",
            )
            logger.info(
                "immediate proxy ping | chat_id=%s account_id=%s ok=%s avg_ms=%s err=%s",
                chat_id,
                aid,
                int(avg_ms is not None and not err),
                f"{avg_ms:.1f}" if avg_ms is not None else "-",
                err or "",
            )
        except Exception as e:
            logger.warning("immediate proxy ping failed chat_id=%s account_id=%s err=%s", chat_id, aid, e)

    threading.Thread(target=worker, name="proxy-immediate-ping", daemon=True).start()


def _account_status(until_ts: int, paused: bool = False) -> str:
    if paused:
        return "frozen"
    if until_ts <= 0:
        return "empty"
    return "active" if until_ts > _now_ts() else "expired"


def _active_account_snapshot(chat_id: int) -> Optional[dict]:
    user = store.get_user(int(chat_id))
    account = None
    with contextlib.suppress(Exception):
        account = store._select_account(user, getattr(user, "active_account_id", None))
    if not account:
        with contextlib.suppress(Exception):
            account = store._legacy_account_from_user(int(chat_id), user)
    if not account:
        return None

    acc = dict(account or {})
    for key, attr in (
        ("subscription_tier", "subscription_tier"),
        ("subscription_until_ts", "subscription_until_ts"),
        ("subscription_paused", "subscription_paused"),
        ("subscription_pause_started_ts", "subscription_pause_started_ts"),
        ("subscription_frozen_left_sec", "subscription_frozen_left_sec"),
        ("subscription_warn_1d_for_ts", "subscription_warn_1d_for_ts"),
        ("port_user_id", "port_user_id"),
        ("port_user_name", "port_user_name"),
        ("centrifugo_socket", "centrifugo_socket"),
        ("centrifugo_secret", "centrifugo_secret"),
        ("zooma_top_session", "zooma_top_session"),
        ("zooma_top_session_expires_at", "zooma_top_session_expires_at"),
        ("csrf_token", "csrf_token"),
        ("fingerprint_now", "fingerprint_now"),
        ("user_agent", "user_agent"),
        ("proxy_url", "user_proxy_url"),
        ("proxy_country", "user_proxy_country"),
        ("proxy_city", "user_proxy_city"),
        ("proxy_order_id", "user_proxy_order_id"),
        ("proxy_ip", "user_proxy_ip"),
        ("proxy_port_http", "user_proxy_port_http"),
        ("proxy_port_socks5", "user_proxy_port_socks5"),
        ("proxy_login", "user_proxy_login"),
        ("proxy_password", "user_proxy_password"),
        ("proxy_scheme", "user_proxy_scheme"),
    ):
        val = getattr(user, attr, None)
        if val not in (None, ""):
            acc[key] = val
    acc.setdefault("account_id", str(getattr(user, "active_account_id", None) or "acc_1"))
    acc.setdefault("slot", 1)
    acc.setdefault("billing_type", "main")
    acc.setdefault("owner_chat_id", int(chat_id))
    return normalize_proxy_fields(acc)


def _row_from_account(chat_id: int, account: dict) -> dict:
    a = normalize_proxy_fields(dict(account or {}))
    slot = _i(a.get("slot"), 1) or 1
    aid = _s(a.get("account_id")) or f"acc_{slot}"
    until_ts = _i(a.get("subscription_until_ts"), 0)
    created_at_ts = _i(a.get("created_at_ts"), _now_ts()) or _now_ts()
    updated_at_ts = _i(a.get("updated_at_ts"), _now_ts()) or _now_ts()
    billing_type = _s(a.get("billing_type")) or ("main" if slot == 1 else "addon")
    if billing_type not in {"main", "addon"}:
        billing_type = "main" if slot == 1 else "addon"

    extension_bound_chat_id = _i(a.get("extension_bound_chat_id"), 0)
    extension_bound_at_ts = _i(a.get("extension_bound_at_ts"), 0)
    extension_bound_status = _s(a.get("extension_bound_status")).lower()
    extension_bound_device_id = _s(a.get("extension_bound_device_id")).lower()
    if extension_bound_chat_id > 0:
        extension_bound_status = "bound"
    else:
        extension_bound_chat_id = 0
        extension_bound_at_ts = 0
        extension_bound_status = "unbound"
        extension_bound_device_id = ""

    return {
        "chat_id": int(chat_id),
        "account_id": aid,
        "slot": slot,
        "billing_type": billing_type,
        "status": _account_status(until_ts, _b(a.get("subscription_paused"), False)),
        "port_user_id": _s(a.get("port_user_id")) or None,
        "port_user_name": _s(a.get("port_user_name")) or None,
        "centrifugo_socket": _s(a.get("centrifugo_socket")) or getattr(store, "DEFAULT_CENTRIFUGO_SOCKET", None),
        "centrifugo_secret": _s(a.get("centrifugo_secret")) or None,
        "zooma_top_session": _s(a.get("zooma_top_session")) or None,
        "zooma_top_session_expires_at": a.get("zooma_top_session_expires_at") or None,
        "csrf_token": _s(a.get("csrf_token")) or None,
        "fingerprint_now": _s(a.get("fingerprint_now")) or None,
        "user_agent": _s(a.get("user_agent")) or None,
        "subscription_tier": _s(a.get("subscription_tier")) or None,
        "subscription_until_ts": until_ts,
        "subscription_paused": _b(a.get("subscription_paused"), False),
        "subscription_pause_started_ts": _i(a.get("subscription_pause_started_ts"), 0) or None,
        "subscription_frozen_left_sec": _i(a.get("subscription_frozen_left_sec"), 0) or None,
        "subscription_freeze_reason": _s(a.get("subscription_freeze_reason")) or None,
        "proxy_failure_notified_at_ts": _i(a.get("proxy_failure_notified_at_ts"), 0) or None,
        "subscription_warn_1d_for_ts": _i(a.get("subscription_warn_1d_for_ts"), 0) or 0,
        "promo_activation_paused": _b(a.get("promo_activation_paused"), False),
        "promo_activation_mode": (_s(a.get("promo_activation_mode")) or "server") if (_s(a.get("promo_activation_mode")) or "server") in {"server", "extension"} else "server",
        "extension_bound_chat_id": extension_bound_chat_id or None,
        "extension_bound_at_ts": extension_bound_at_ts or None,
        "extension_bound_status": extension_bound_status,
        "extension_bound_device_id": extension_bound_device_id or None,
        "extension_public_key_jwk": _json_object(a.get("extension_public_key_jwk")) or None,
        "extension_key_id": _s(a.get("extension_key_id")).lower() or None,
        "extension_binding_version": max(0, _i(a.get("extension_binding_version"), 0)),
        "extension_key_created_ts": _i(a.get("extension_key_created_ts"), 0) or None,
        "proxy_url": _s(a.get("proxy_url")) or None,
        "proxy_country": _s(a.get("proxy_country")) or None,
        "proxy_city": _s(a.get("proxy_city")) or None,
        "proxy_order_id": _s(a.get("proxy_order_id")) or None,
        "proxy_ip": _s(a.get("proxy_ip")) or None,
        "proxy_port_http": _i(a.get("proxy_port_http"), 0) or None,
        "proxy_port_socks5": _i(a.get("proxy_port_socks5"), 0) or None,
        "proxy_login": _s(a.get("proxy_login")) or None,
        "proxy_password": _s(a.get("proxy_password")) or None,
        "proxy_scheme": _s(a.get("proxy_scheme")) or None,
        "train_jobs": _json_object(a.get("train_jobs")),
        "chat_ai_enabled": _b(a.get("chat_ai_enabled"), False),
        "chat_ai_api_key": _s(a.get("chat_ai_api_key")),
        "chat_ai_key_mode": (
            (_s(a.get("chat_ai_key_mode")) or "user")
            if (_s(a.get("chat_ai_key_mode")) or "user") in {"user", "default"}
            else "user"
        ),
        "chat_ai_interval_min_sec": max(
            60,
            min(86400, _i(a.get("chat_ai_interval_min_sec"), 600) or 600),
        ),
        "chat_ai_interval_max_sec": max(
            max(
                60,
                min(86400, _i(a.get("chat_ai_interval_min_sec"), 600) or 600),
            ),
            min(86400, _i(a.get("chat_ai_interval_max_sec"), 1500) or 1500),
        ),
        "chat_ai_next_run_ts": max(0, _i(a.get("chat_ai_next_run_ts"), 0)),
        "chat_ai_last_sent_ts": max(0, _i(a.get("chat_ai_last_sent_ts"), 0)),
        "chat_ai_last_error": _s(a.get("chat_ai_last_error"))[:500],
        "chat_ai_recent_messages": _json_list(
            a.get("chat_ai_recent_messages")
        )[-3:],
        "chat_ai_pending_task": _json_object(a.get("chat_ai_pending_task")),
        "chat_ai_rain_miss_messages": store.normalize_chat_ai_rain_miss_messages(
            a.get("chat_ai_rain_miss_messages")
        ),
        "chat_ai_cycle_started_ts": max(0, _i(a.get("chat_ai_cycle_started_ts"), 0)),
        "chat_ai_rest_until_ts": max(0, _i(a.get("chat_ai_rest_until_ts"), 0)),
        "chat_ai_rate_limits": store.normalize_chat_ai_rate_limits(a.get("chat_ai_rate_limits")),
        "server_session_state": store.normalize_server_session_state(a.get("server_session_state")),
        "created_at_ts": created_at_ts,
        "updated_at_ts": updated_at_ts,
    }


def _account_from_row(row: dict) -> dict:
    r = dict(row or {})
    slot = _i(r.get("slot"), 1) or 1
    until_ts = _i(r.get("subscription_until_ts"), 0)
    account_id = _s(r.get("account_id")) or f"acc_{slot}"
    extension_bound_chat_id = _i(r.get("extension_bound_chat_id"), 0)
    extension_bound_at_ts = _i(r.get("extension_bound_at_ts"), 0)
    extension_bound_status = _s(r.get("extension_bound_status")).lower()
    extension_bound_device_id = _s(r.get("extension_bound_device_id")).lower()
    if extension_bound_chat_id > 0:
        extension_bound_status = "bound"
    else:
        extension_bound_chat_id = 0
        extension_bound_at_ts = 0
        extension_bound_status = "unbound"
        extension_bound_device_id = ""
    acc = {
        "account_id": account_id,
        "slot": slot,
        "billing_type": _s(r.get("billing_type")) or ("main" if slot == 1 else "addon"),
        "status": _account_status(until_ts, _b(r.get("subscription_paused"), False)),
        "owner_chat_id": _i(r.get("chat_id"), 0),
        "port_user_id": _s(r.get("port_user_id")),
        "port_user_name": _s(r.get("port_user_name")),
        "centrifugo_socket": _s(r.get("centrifugo_socket")) or getattr(store, "DEFAULT_CENTRIFUGO_SOCKET", ""),
        "centrifugo_secret": _s(r.get("centrifugo_secret")),
        "zooma_top_session": _s(r.get("zooma_top_session")),
        "zooma_top_session_expires_at": r.get("zooma_top_session_expires_at"),
        "csrf_token": _s(r.get("csrf_token")),
        "fingerprint_now": _s(r.get("fingerprint_now")),
        "user_agent": _s(r.get("user_agent")),
        "subscription_tier": _s(r.get("subscription_tier")),
        "subscription_until_ts": until_ts,
        "subscription_paused": _b(r.get("subscription_paused"), False),
        "subscription_pause_started_ts": _i(r.get("subscription_pause_started_ts"), 0) or None,
        "subscription_frozen_left_sec": _i(r.get("subscription_frozen_left_sec"), 0) or None,
        "subscription_freeze_reason": _s(r.get("subscription_freeze_reason")),
        "proxy_failure_notified_at_ts": _i(r.get("proxy_failure_notified_at_ts"), 0) or None,
        "subscription_warn_1d_for_ts": _i(r.get("subscription_warn_1d_for_ts"), 0),
        "promo_activation_paused": _b(r.get("promo_activation_paused"), False),
        "promo_activation_mode": (_s(r.get("promo_activation_mode")) or "server") if (_s(r.get("promo_activation_mode")) or "server") in {"server", "extension"} else "server",
        "extension_bound_chat_id": extension_bound_chat_id,
        "extension_bound_account_id": account_id if extension_bound_chat_id else "",
        "extension_bound_at_ts": extension_bound_at_ts,
        "extension_bound_status": extension_bound_status,
        "extension_bound_device_id": extension_bound_device_id,
        "extension_public_key_jwk": _json_object(r.get("extension_public_key_jwk")),
        "extension_key_id": _s(r.get("extension_key_id")).lower(),
        "extension_binding_version": max(0, _i(r.get("extension_binding_version"), 0)),
        "extension_key_created_ts": _i(r.get("extension_key_created_ts"), 0),
        "proxy_url": _s(r.get("proxy_url")),
        "proxy_country": _s(r.get("proxy_country")),
        "proxy_city": _s(r.get("proxy_city")),
        "proxy_order_id": _s(r.get("proxy_order_id")),
        "proxy_ip": _s(r.get("proxy_ip")),
        "proxy_port_http": _i(r.get("proxy_port_http"), 0) or None,
        "proxy_port_socks5": _i(r.get("proxy_port_socks5"), 0) or None,
        "proxy_login": _s(r.get("proxy_login")),
        "proxy_password": _s(r.get("proxy_password")),
        "proxy_scheme": _s(r.get("proxy_scheme")) or "socks5",
        "train_jobs": _json_object(r.get("train_jobs")),
        "chat_ai_enabled": _b(r.get("chat_ai_enabled"), False),
        "chat_ai_api_key": _s(r.get("chat_ai_api_key")),
        "chat_ai_key_mode": (
            (_s(r.get("chat_ai_key_mode")) or "user")
            if (_s(r.get("chat_ai_key_mode")) or "user") in {"user", "default"}
            else "user"
        ),
        "chat_ai_interval_min_sec": max(
            60,
            min(86400, _i(r.get("chat_ai_interval_min_sec"), 600) or 600),
        ),
        "chat_ai_interval_max_sec": max(
            max(
                60,
                min(86400, _i(r.get("chat_ai_interval_min_sec"), 600) or 600),
            ),
            min(86400, _i(r.get("chat_ai_interval_max_sec"), 1500) or 1500),
        ),
        "chat_ai_next_run_ts": max(0, _i(r.get("chat_ai_next_run_ts"), 0)),
        "chat_ai_last_sent_ts": max(0, _i(r.get("chat_ai_last_sent_ts"), 0)),
        "chat_ai_last_error": _s(r.get("chat_ai_last_error"))[:500],
        "chat_ai_recent_messages": _json_list(
            r.get("chat_ai_recent_messages")
        )[-3:],
        "chat_ai_pending_task": _json_object(r.get("chat_ai_pending_task")),
        "chat_ai_rain_miss_messages": store.normalize_chat_ai_rain_miss_messages(
            r.get("chat_ai_rain_miss_messages")
        ),
        "chat_ai_cycle_started_ts": max(0, _i(r.get("chat_ai_cycle_started_ts"), 0)),
        "chat_ai_rest_until_ts": max(0, _i(r.get("chat_ai_rest_until_ts"), 0)),
        "chat_ai_rate_limits": store.normalize_chat_ai_rate_limits(r.get("chat_ai_rate_limits")),
        "server_session_state": store.normalize_server_session_state(r.get("server_session_state")),
        "connected": False,
        "proxy_ping_ms": None,
        "proxy_ping_last_ts": 0,
        "proxy_ping_error": "",
        "created_at_ts": _i(r.get("created_at_ts"), _now_ts()),
        "updated_at_ts": _i(r.get("updated_at_ts"), _now_ts()),
    }
    return normalize_proxy_fields(acc)


def _hash_row(row: dict) -> str:
    comparable = {k: v for k, v in row.items() if k != "updated_at_ts"}
    raw = json.dumps(comparable, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _same_db_value(left: Any, right: Any) -> bool:
    return json.dumps(left, ensure_ascii=False, sort_keys=True, default=str) == json.dumps(
        right,
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    )


def _account_row_delta(previous: dict, current: dict) -> dict:
    return {
        key: value
        for key, value in current.items()
        if key not in {"chat_id", "account_id"}
        and not _same_db_value(previous.get(key), value)
    }


def _write_account_row(client, row: dict) -> None:
    key = (int(row["chat_id"]), str(row["account_id"]))
    previous = LAST_ACCOUNT_ROWS.get(key)
    if previous is None:
        client.table(ACCOUNT_TABLE).upsert(row, on_conflict="chat_id,account_id").execute()
    else:
        patch = _account_row_delta(previous, row)
        if patch:
            (
                client.table(ACCOUNT_TABLE)
                .update(patch)
                .eq("chat_id", key[0])
                .eq("account_id", key[1])
                .execute()
            )
    LAST_ACCOUNT_ROWS[key] = dict(row)
    LAST_ACCOUNT_HASH[key] = _hash_row(row)


def _client():
    with contextlib.suppress(Exception):
        return store._sb_client()
    return None


def _retry_delay(attempt: int) -> float:
    return min(ACCOUNT_WRITE_RETRY_MAX_SEC, ACCOUNT_WRITE_RETRY_BASE_SEC * (2 ** max(0, int(attempt))))


def _is_fatal_account_table_error(err: Exception | str) -> bool:
    raw = str(err or "").lower()
    table = str(ACCOUNT_TABLE or "").lower()
    if "42p01" in raw:
        return True
    if "does not exist" in raw and (table in raw or "relation" in raw):
        return True
    if "could not find the table" in raw and table in raw:
        return True
    return False


def _ensure_writer_started() -> None:
    global ACCOUNT_WRITER_STARTED
    with ACCOUNT_WRITER_LOCK:
        if ACCOUNT_WRITER_STARTED:
            return
        threading.Thread(target=_account_writer_loop, name="sb-account-writer", daemon=True).start()
        ACCOUNT_WRITER_STARTED = True


def _enqueue_replace_accounts(chat_id: int, accounts: list[dict]) -> None:
    if ACCOUNT_TABLE_AVAILABLE is False:
        return
    _ensure_writer_started()
    rows = [_row_from_account(int(chat_id), a) for a in (accounts or []) if isinstance(a, dict)]
    ACCOUNT_WRITE_QUEUE.put(("replace", int(chat_id), rows, 0))


def _enqueue_upsert_account(chat_id: int, account: dict) -> None:
    if ACCOUNT_TABLE_AVAILABLE is False:
        return
    _ensure_writer_started()
    ACCOUNT_WRITE_QUEUE.put(("upsert", _row_from_account(int(chat_id), account), 0))


def _account_writer_loop() -> None:
    global ACCOUNT_TABLE_AVAILABLE
    while True:
        item = ACCOUNT_WRITE_QUEUE.get()
        try:
            client = _client()
            if not client:
                raise RuntimeError("supabase_client_unavailable")

            op = item[0]

            if op == "upsert":
                row = item[1]
                attempt = _i(item[2] if len(item) > 2 else 0, 0)
                _write_account_row(client, row)
                ACCOUNT_TABLE_AVAILABLE = True

            elif op == "replace":
                chat_id = int(item[1])
                rows = list(item[2] or [])
                attempt = _i(item[3] if len(item) > 3 else 0, 0)
                keep_ids = {str(r.get("account_id") or "") for r in rows if r.get("account_id")}

                for row in rows:
                    _write_account_row(client, row)

                existing_ids = {
                    aid
                    for (cid, aid) in list(LAST_ACCOUNT_ROWS.keys())
                    if int(cid) == chat_id
                }
                for aid in sorted(existing_ids - keep_ids):
                    client.table(ACCOUNT_TABLE).delete().eq("chat_id", chat_id).eq("account_id", aid).execute()
                    LAST_ACCOUNT_ROWS.pop((chat_id, aid), None)
                    LAST_ACCOUNT_HASH.pop((chat_id, aid), None)

                ACCOUNT_TABLE_AVAILABLE = True

        except Exception as e:
            if _is_fatal_account_table_error(e):
                ACCOUNT_TABLE_AVAILABLE = False
                logger.warning("DB normalized accounts disabled fatal: table=%s error=%s", ACCOUNT_TABLE, e)
            else:
                ACCOUNT_TABLE_AVAILABLE = None
                op = item[0] if item else "-"
                if op == "upsert":
                    attempt = _i(item[2] if len(item) > 2 else 0, 0)
                    retry_item = ("upsert", item[1], attempt + 1)
                elif op == "replace":
                    attempt = _i(item[3] if len(item) > 3 else 0, 0)
                    retry_item = ("replace", item[1], item[2], attempt + 1)
                else:
                    attempt = ACCOUNT_WRITE_RETRY_MAX
                    retry_item = None

                if retry_item is not None and attempt < ACCOUNT_WRITE_RETRY_MAX:
                    delay = _retry_delay(attempt)
                    logger.debug(
                        "DB normalized accounts write retry scheduled: table=%s op=%s attempt=%s/%s delay=%.1fs error=%s",
                        ACCOUNT_TABLE,
                        op,
                        attempt + 1,
                        ACCOUNT_WRITE_RETRY_MAX,
                        delay,
                        e,
                    )
                    threading.Timer(delay, lambda item=retry_item: ACCOUNT_WRITE_QUEUE.put(item)).start()
                else:
                    logger.warning(
                        "DB normalized accounts write failed after retries, keep layer enabled: table=%s op=%s error=%s",
                        ACCOUNT_TABLE,
                        op,
                        e,
                    )
        finally:
            ACCOUNT_WRITE_QUEUE.task_done()


def _load_normalized_accounts() -> int:
    global ACCOUNT_TABLE_AVAILABLE

    rows = []
    last_error: Exception | None = None

    for attempt in range(ACCOUNT_LOAD_RETRY_MAX + 1):
        try:
            client = _client()
            if not client:
                raise RuntimeError("supabase_client_unavailable")
            resp = client.table(ACCOUNT_TABLE).select("*").execute()
            rows = getattr(resp, "data", None) or []
            ACCOUNT_TABLE_AVAILABLE = True
            break
        except Exception as e:
            last_error = e
            if _is_fatal_account_table_error(e):
                ACCOUNT_TABLE_AVAILABLE = False
                logger.warning("DB normalized accounts load disabled fatal: table=%s error=%s", ACCOUNT_TABLE, e)
                return 0

            ACCOUNT_TABLE_AVAILABLE = None
            if attempt < ACCOUNT_LOAD_RETRY_MAX:
                delay = _retry_delay(attempt)
                logger.debug(
                    "DB normalized accounts load retry: table=%s attempt=%s/%s delay=%.1fs error=%s",
                    ACCOUNT_TABLE,
                    attempt + 1,
                    ACCOUNT_LOAD_RETRY_MAX,
                    delay,
                    e,
                )
                time.sleep(delay)
                continue

            logger.warning(
                "DB normalized accounts load failed after retries, fallback to users only: table=%s error=%s",
                ACCOUNT_TABLE,
                last_error,
            )
            return 0

    grouped: dict[int, list[dict]] = {}
    LAST_ACCOUNT_HASH.clear()
    LAST_ACCOUNT_ROWS.clear()
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        chat_id = _i(row.get("chat_id"), 0)
        if not chat_id:
            continue
        acc = _account_from_row(row)
        grouped.setdefault(chat_id, []).append(acc)
        with contextlib.suppress(Exception):
            normalized_row = _row_from_account(chat_id, acc)
            key = (chat_id, str(acc.get("account_id")))
            LAST_ACCOUNT_ROWS[key] = dict(normalized_row)
            LAST_ACCOUNT_HASH[key] = _hash_row(normalized_row)

    for chat_id, accounts in grouped.items():
        user = store.get_user(chat_id)
        accounts.sort(key=lambda a: (_i(a.get("slot"), 999), str(a.get("account_id") or "")))
        with contextlib.suppress(Exception):
            accounts = store._normalize_accounts_for_user(chat_id, user, accounts)
        accounts = [normalize_proxy_fields(a) for a in accounts]
        user.casino_accounts_json = accounts
        if not _s(getattr(user, "active_account_id", None)):
            user.active_account_id = str(accounts[0].get("account_id") or "acc_1") if accounts else "acc_1"
        with contextlib.suppress(Exception):
            store._mirror_account_to_user(user, store._select_account(user))
        user.connected = False
        with contextlib.suppress(Exception):
            with store._SB_LAST_ROWS_LOCK:
                store._SB_LAST_ROWS[chat_id] = store._to_db_row(chat_id, user)

    ACCOUNT_TABLE_AVAILABLE = True
    if grouped:
        logger.info("DB restore normalized accounts: rows=%s users=%s", len(rows), len(grouped))
    return len(rows)


def _filter_user_patch(chat_id: int, patch: dict) -> dict:
    if int(chat_id) < 0:
        filtered = dict(patch or {})
    else:
        filtered = {k: v for k, v in (patch or {}).items() if k in USER_FIELDS}
    if "timezone_valid" in filtered:
        # Defense in depth for every user upsert, including old state files.
        filtered["timezone_valid"] = bool(filtered.get("timezone_valid"))
    return filtered


def persist_user_state_now_normalized(chat_id: int) -> bool:
    # Synchronously persist one user and all normalized casino accounts.
    global ACCOUNT_TABLE_AVAILABLE

    cid = int(chat_id)
    client = _client()
    if not client:
        raise RuntimeError("supabase_client_unavailable")

    user = store.get_user(cid)
    full_user_row = store._to_db_row(cid, user)

    # public.users stores only user-level data. Account-specific state belongs
    # to public.casino_accounts and must never leak unsupported legacy columns
    # such as accounts_schema_version into the users upsert.
    user_payload = {"chat_id": cid}
    user_payload.update(_filter_user_patch(cid, full_user_row))
    client.table(store.SUPABASE_USERS_TABLE).upsert(
        user_payload,
        on_conflict="chat_id",
    ).execute()

    accounts = store._normalize_accounts_for_user(cid, user)
    account_rows = [
        _row_from_account(cid, account)
        for account in accounts
        if isinstance(account, dict)
    ]
    keep_ids = {
        str(row.get("account_id") or "")
        for row in account_rows
        if row.get("account_id")
    }

    for row in account_rows:
        _write_account_row(client, row)

    existing = (
        client.table(ACCOUNT_TABLE)
        .select("account_id")
        .eq("chat_id", cid)
        .execute()
    )
    for raw in (getattr(existing, "data", None) or []):
        account_id = str((raw or {}).get("account_id") or "")
        if account_id and account_id not in keep_ids:
            (
                client.table(ACCOUNT_TABLE)
                .delete()
                .eq("chat_id", cid)
                .eq("account_id", account_id)
                .execute()
            )
            LAST_ACCOUNT_ROWS.pop((cid, account_id), None)
            LAST_ACCOUNT_HASH.pop((cid, account_id), None)

    for row in account_rows:
        key = (cid, str(row.get("account_id") or ""))
        LAST_ACCOUNT_ROWS[key] = dict(row)
        LAST_ACCOUNT_HASH[key] = _hash_row(row)

    with store._SB_LAST_ROWS_LOCK:
        previous = dict(store._SB_LAST_ROWS.get(cid, {}))
        previous.update(user_payload)
        store._SB_LAST_ROWS[cid] = previous

    ACCOUNT_TABLE_AVAILABLE = True
    return True


def _maybe_write_accounts_from_patch(chat_id: int, patch: dict) -> None:
    if int(chat_id) <= 0 or not isinstance(patch, dict):
        return
    if "casino_accounts_json" in patch:
        accounts = patch.get("casino_accounts_json")
        if isinstance(accounts, list):
            _enqueue_replace_accounts(int(chat_id), [normalize_proxy_fields(a) for a in accounts])
        return
    changed_keys = set(patch.keys())
    if changed_keys and changed_keys <= RUNTIME_ONLY_FIELDS:
        return
    if changed_keys & ACCOUNT_FIELDS:
        acc = _active_account_snapshot(int(chat_id))
        if acc:
            _enqueue_upsert_account(int(chat_id), acc)


def _patch_proxy_normalization() -> None:
    if getattr(store, "_zooma_proxy_normalizer_patched", False):
        return
    original_normalize_account = store._normalize_account
    original_set_account_proxy = getattr(store, "set_account_proxy", None)
    original_set_user_proxy = getattr(store, "set_user_proxy", None)

    def patched_normalize_account(chat_id: int, acc: dict, slot: int) -> dict:
        normalized = original_normalize_account(chat_id, normalize_proxy_fields(acc), slot)
        return normalize_proxy_fields(normalized)

    store._normalize_account = patched_normalize_account

    if callable(original_set_account_proxy):
        def patched_set_account_proxy(
            chat_id: int,
            account_id: str,
            proxy_url: Optional[str],
            country: Optional[str] = None,
            city: Optional[str] = None,
            order_id: Optional[str] = None,
            ip: Optional[str] = None,
            port_http: Optional[int] = None,
            port_socks5: Optional[int] = None,
            login: Optional[str] = None,
            password: Optional[str] = None,
            scheme: Optional[str] = None,
        ) -> None:
            data = normalize_proxy_fields({
                "proxy_url": proxy_url,
                "proxy_country": country,
                "proxy_city": city,
                "proxy_order_id": order_id,
                "proxy_ip": ip,
                "proxy_port_http": port_http,
                "proxy_port_socks5": port_socks5,
                "proxy_login": login,
                "proxy_password": password,
                "proxy_scheme": scheme,
            })
            result = original_set_account_proxy(
                chat_id,
                account_id,
                data.get("proxy_url"),
                country=data.get("proxy_country") or country,
                city=data.get("proxy_city") or city,
                order_id=data.get("proxy_order_id") or order_id,
                ip=data.get("proxy_ip"),
                port_http=data.get("proxy_port_http"),
                port_socks5=data.get("proxy_port_socks5"),
                login=data.get("proxy_login"),
                password=data.get("proxy_password"),
                scheme=data.get("proxy_scheme"),
            )
            _start_immediate_proxy_ping(int(chat_id), str(account_id or "acc_1"), data.get("proxy_url"))
            return result
        store.set_account_proxy = patched_set_account_proxy

    if callable(original_set_user_proxy):
        def patched_set_user_proxy(
            chat_id: int,
            proxy_url: Optional[str],
            country: Optional[str] = None,
            city: Optional[str] = None,
            order_id: Optional[str] = None,
            ip: Optional[str] = None,
            port_http: Optional[int] = None,
            port_socks5: Optional[int] = None,
            login: Optional[str] = None,
            password: Optional[str] = None,
            scheme: Optional[str] = None,
        ) -> None:
            data = normalize_proxy_fields({
                "proxy_url": proxy_url,
                "proxy_country": country,
                "proxy_city": city,
                "proxy_order_id": order_id,
                "proxy_ip": ip,
                "proxy_port_http": port_http,
                "proxy_port_socks5": port_socks5,
                "proxy_login": login,
                "proxy_password": password,
                "proxy_scheme": scheme,
            })
            result = original_set_user_proxy(
                chat_id,
                data.get("proxy_url"),
                country=data.get("proxy_country") or country,
                city=data.get("proxy_city") or city,
                order_id=data.get("proxy_order_id") or order_id,
                ip=data.get("proxy_ip"),
                port_http=data.get("proxy_port_http"),
                port_socks5=data.get("proxy_port_socks5"),
                login=data.get("proxy_login"),
                password=data.get("proxy_password"),
                scheme=data.get("proxy_scheme"),
            )
            aid = _s(getattr(store.get_user(int(chat_id)), "active_account_id", None)) or "acc_1"
            _start_immediate_proxy_ping(int(chat_id), aid, data.get("proxy_url"))
            return result
        store.set_user_proxy = patched_set_user_proxy

    store._zooma_proxy_normalizer_patched = True


def install_db_normalization_patches() -> None:
    if getattr(store, "_zooma_db_normalized_patched", False):
        return

    _patch_proxy_normalization()

    original_upsert_patch = store._sb_upsert_patch
    original_load_all = store._sb_load_all

    def normalized_sb_upsert_patch(chat_id: int, patch: dict) -> None:
        if not patch:
            return None
        try:
            _maybe_write_accounts_from_patch(int(chat_id), dict(patch))
        except Exception as e:
            logger.warning("normalized account write schedule failed chat_id=%s err=%s", chat_id, e)
        filtered = _filter_user_patch(int(chat_id), dict(patch))
        if filtered:
            return original_upsert_patch(chat_id, filtered)
        return None

    def normalized_sb_load_all() -> int:
        count = original_load_all()
        _load_normalized_accounts()
        return count

    store._sb_upsert_patch = normalized_sb_upsert_patch
    store._sb_load_all = normalized_sb_load_all
    store._PERSIST_USER_STATE_NOW_HANDLER = persist_user_state_now_normalized
    store._zooma_db_normalized_patched = True
    logger.info("DB normalization patches installed account_table=%s", ACCOUNT_TABLE)
