#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

LOG="${ZOOMA_LOG_FILE:-zooma1.log}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
TG_SESSION_PATH="${TG_SESSION_PATH:-./saxarokchatzooma}"

TERM_WAIT_SEC="${ZOOMA_STOP_TERM_WAIT_SEC:-3}"
KILL_WAIT_SEC="${ZOOMA_STOP_KILL_WAIT_SEC:-2}"
START_DELAY_SEC="${ZOOMA_START_DELAY_SEC:-2}"

wait_gone() {
  local pids="$1"
  local timeout="$2"
  local waited="0"

  if [ -z "$pids" ]; then
    return 0
  fi

  while awk "BEGIN { exit !($waited < $timeout) }"; do
    local alive=""
    for pid in $pids; do
      if kill -0 "$pid" 2>/dev/null; then
        alive="$alive $pid"
      fi
    done

    if [ -z "$alive" ]; then
      return 0
    fi

    sleep 0.2
    waited="$(awk "BEGIN { printf \"%.1f\", $waited + 0.2 }")"
  done

  return 1
}

stop_group() {
  local name="$1"
  local pattern="$2"
  local pids

  pids="$(pgrep -f "$pattern" || true)"
  if [ -z "$pids" ]; then
    echo "No old $name processes"
    return 0
  fi

  echo "Stopping old $name pids:$pids"
  kill -TERM $pids 2>/dev/null || true

  if wait_gone "$pids" "$TERM_WAIT_SEC"; then
    echo "Stopped old $name"
    return 0
  fi

  pids="$(pgrep -f "$pattern" || true)"
  if [ -n "$pids" ]; then
    echo "Killing old $name pids:$pids"
    kill -KILL $pids 2>/dev/null || true

    if ! wait_gone "$pids" "$KILL_WAIT_SEC"; then
      pids="$(pgrep -f "$pattern" || true)"
      if [ -n "$pids" ]; then
        echo "ERROR: old $name still alive after KILL:$pids" >&2
        exit 1
      fi
    fi
  fi

  echo "Stopped old $name"
}

stop_group "process_watchdog.py" "python.*process_watchdog\.py"
stop_group "main.py" "python.*main\.py"
stop_group "tg_watcher.py" "python.*tg_watcher\.py"

echo "Old processes stopped. Waiting ${START_DELAY_SEC}s before start..."
sleep "$START_DELAY_SEC"

: > "$LOG"

# ============================================================
# ВЫБОР РЕЖИМА ПРОКСИ
#
# local  — локальный SOCKS5 127.0.0.1:1080
# remote — купленный SOCKS5
# off    — полностью без прокси
#
# Для переключения меняй только следующую строку.
# ============================================================
PROXY_MODE="local"

export PROXY_SCHEME="socks5"

case "$PROXY_MODE" in
  local)
    export ZOOMA_USE_PROXY=1

    # Основной Telegram-бот.
    export TG_PROXY_HOST="127.0.0.1"
    export TG_PROXY_PORT="1080"

    # Telethon-клиент tg_watcher.py.
    export TG_WATCHER_PROXY_HOST="127.0.0.1"
    export TG_WATCHER_PROXY_PORT="1080"
    export TG_WATCHER_PROXY_USERNAME=""
    export TG_WATCHER_PROXY_PASSWORD=""

    # Groq / Chat AI.
    export GROQ_PROXY_URL="socks5://127.0.0.1:1080"
    ;;

  remote)
    export ZOOMA_USE_PROXY=1

    # Основной Telegram-бот.
    export TG_PROXY_HOST=B86tLg9C:m4EW7wQH@136.234.170.240
    export TG_PROXY_PORT=64797

    # Telethon-клиент tg_watcher.py.
    export TG_WATCHER_PROXY_HOST=136.234.170.240
    export TG_WATCHER_PROXY_PORT=64797
    export TG_WATCHER_PROXY_USERNAME=B86tLg9C
    export TG_WATCHER_PROXY_PASSWORD=m4EW7wQH

    # Groq / Chat AI.
    export GROQ_PROXY_URL=socks5://B86tLg9C:m4EW7wQH@136.234.170.240:64797
    ;;

  off)
    export ZOOMA_USE_PROXY=0

    export TG_PROXY_HOST=""
    export TG_PROXY_PORT="0"

    export TG_WATCHER_PROXY_HOST=""
    export TG_WATCHER_PROXY_PORT="0"
    export TG_WATCHER_PROXY_USERNAME=""
    export TG_WATCHER_PROXY_PASSWORD=""

    export GROQ_PROXY_URL=""
    ;;

  *)
    echo "ERROR: неизвестный PROXY_MODE=$PROXY_MODE" >&2
    echo "Допустимые значения: local, remote, off" >&2
    exit 1
    ;;
esac

echo "Proxy mode: $PROXY_MODE"

export ZOOMA_TG_FOLDER_SYNC_HTTP_ENABLED="${ZOOMA_TG_FOLDER_SYNC_HTTP_ENABLED:-0}"
export ZOOMA_TG_WATCHER_INTERNAL_URL="${ZOOMA_TG_WATCHER_INTERNAL_URL:-http://127.0.0.1:8789/internal/promo/enqueue}"
export TG_SESSION="$TG_SESSION_PATH"
export ZOOMA_ADMIN_LOGIN_PATH="${ZOOMA_ADMIN_LOGIN_PATH:-/wk7kru/iwmKna}"
export ZOOMA_ADMIN_PANEL_PATH="${ZOOMA_ADMIN_PANEL_PATH:-/iqpdm/pwmY81}"
export ZOOMA_ADMIN_API_PREFIX="${ZOOMA_ADMIN_API_PREFIX:-/g5nqz/a7T2v9/api}"


nohup "$PYTHON_BIN" ./main.py >> "$LOG" 2>&1 &
MAIN_PID="$!"

echo "Started main.py pid=$MAIN_PID log=$PWD/$LOG"
