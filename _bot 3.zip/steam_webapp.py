import asyncio
import os
import time
import json
import shutil
import subprocess
import tempfile
from contextlib import suppress
from fastapi import FastAPI, Form, BackgroundTasks, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from fastapi.templating import Jinja2Templates
import base64
from urllib.parse import urlparse

from config import STEAM_AUTH_START_URL, STEAM_BROWSER_HTTP_PROXY, ADMIN_CHAT_ID
from store import get_user
from xray_bridge import ensure_xray_bridge, stop_xray_bridge


app = FastAPI(
    openapi_url=None,
    docs_url=None,
    redoc_url=None,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")

sessions = {}
_recent_closures: dict[str, dict] = {}
SESSION_TTL = 300
_ttl_task = None
_ON_ZOOMA_SESSION = None
_STEAM_FRONTEND_FAIL: set[str] = set()


async def close_sessions_for_chat(chat_id: int, exclude_sid: str | None = None):
    if chat_id is None:
        return
    for sid in list(sessions.keys()):
        if exclude_sid and sid == exclude_sid:
            continue
        if _chat_id_from_sid(sid) == int(chat_id):
            await _close_session(sid, reason="superseded_by_other_auth")


async def close_session_by_sid(sid: str, reason: str = "admin_stop") -> bool:
    if sid not in sessions:
        return False
    await _close_session(sid, reason=reason)
    return True


def _display_locks_exist(display_num: int) -> bool:
    lock1 = f"/tmp/.X{display_num}-lock"
    lock2 = f"/tmp/.X11-unix/X{display_num}"
    return os.path.exists(lock1) or os.path.exists(lock2)


def _start_xvfb_dynamic() -> tuple[subprocess.Popen, str]:
    xvfb_bin = shutil.which("Xvfb")
    if not xvfb_bin:
        raise RuntimeError("Xvfb не установлен на сервере")
    for n in range(99, 140):
        if _display_locks_exist(n):
            continue
        display = f":{n}"
        err_log = tempfile.NamedTemporaryFile(prefix=f"xvfb-{n}-", suffix=".log", delete=False)
        err_path = err_log.name
        err_log.close()
        proc = subprocess.Popen(
            [xvfb_bin, display, "-screen", "0", "1280x720x24", "-nolisten", "tcp"],
            stdout=subprocess.DEVNULL,
            stderr=open(err_path, "ab"),
        )
        time.sleep(0.25)
        if proc.poll() is None:
            return proc, display
        with suppress(Exception):
            os.remove(err_path)
    raise RuntimeError("Не удалось запустить Xvfb: нет свободного DISPLAY")


def set_zooma_session_handler(handler):
    global _ON_ZOOMA_SESSION
    _ON_ZOOMA_SESSION = handler


def _chat_id_from_sid(sid: str) -> int | None:
    if not sid:
        return None
    parts = sid.split("_")
    if not parts:
        return None
    last = parts[-1].strip()
    if not last.isdigit():
        return None
    return int(last)


def _make_session_state(init_token: int | None = None):
    return {
        "ready": False,
        "is_processing": False,
        "done": False,
        "stage": "login",
        "init_error": "",
        "created_at": int(time.time()),
        "last_seen": int(time.time()),
        "init_token": init_token or time.time_ns(),
        "qr_active": False,
        "qr_requested": False,
        "qr_ready": False,
        "qr_error": "",
        "qr_wait_started": 0,
        "code_submit_inflight": False,
        "last_code_submit": 0.0,
        "last_code_value": "",
    }


def _get_page_if_ready(sid: str):
    sess = sessions.get(sid)
    if not sess or not sess.get("ready"):
        return None

    page = sess.get("page")
    if not page:
        return None

    try:
        if page.is_closed():
            return None
    except Exception:
        return None

    return page


async def _wait_for_ready_page(sid: str, attempts: int = 20, delay: float = 0.5):
    for _ in range(attempts):
        page = _get_page_if_ready(sid)
        if page:
            return page
        await asyncio.sleep(delay)
    return None


async def _wait_for_qr_button(page, attempts: int = 14, delay: float = 0.35):
    selectors = [
        "text=/Показать QR-код/i",
        ".login_qr_code_button",
        "button:has-text('QR')",
    ]
    for _ in range(attempts):
        for selector in selectors:
            try:
                loc = page.locator(selector).first
                if await loc.count() > 0 and await loc.is_visible():
                    return selector
            except Exception:
                continue
        await asyncio.sleep(delay)
    return None


async def _is_qr_present_on_page(page) -> bool:
    try:
        return await page.evaluate("""() => {
            return Boolean(
                document.querySelector('.login_qr_code_img img') ||
                document.querySelector('img[src^="blob:"]') ||
                document.querySelector('canvas')
            );
        }""")
    except Exception:
        return False


async def _ensure_qr_capture_injected(page):
    await page.evaluate("""() => {
        window.lastQR = window.lastQR || "";
        window.last_src = window.last_src || "";
        if (window.__qrScanInstalled) return;
        const scan = () => {
            const el = document.querySelector('img[src*="blob:"]') ||
                       document.querySelector('canvas') ||
                       document.querySelector('.login_qr_code_img img');
            if (!el) return;
            const src = el.tagName === 'CANVAS' ? el.toDataURL() : (el.src || '');
            if (!src || src === window.last_src) return;
            window.last_src = src;
            const size = 1024;
            const padding = 80;
            const canvas = document.createElement('canvas');
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            ctx.imageSmoothingEnabled = false;
            const img = new Image();
            img.src = src;
            img.onload = () => {
                ctx.fillStyle = "white";
                ctx.fillRect(0, 0, size, size);
                ctx.drawImage(img, padding, padding, size - (padding * 2), size - (padding * 2));
                window.lastQR = canvas.toDataURL("image/png");
            };
        };
        window.__qrScanInstalled = true;
        setInterval(scan, 200);
        scan();
    }""")


async def _activate_qr_mode(sid: str, page):
    sess = sessions.get(sid)
    if not sess:
        return False, "session_closed"

    try:
        await page.wait_for_load_state("domcontentloaded", timeout=3500)
    except Exception:
        # Не блокируемся на этом — Steam иногда держит сеть "живой".
        pass

    if await _is_qr_present_on_page(page):
        await _ensure_qr_capture_injected(page)
        sess["qr_ready"] = True
        sess["qr_error"] = ""
        return True, ""

    selector = await _wait_for_qr_button(page)
    if not selector:
        # Кнопка может исчезать после первого переключения в QR,
        # поэтому повторно проверяем уже открытый QR-блок.
        if await _is_qr_present_on_page(page):
            await _ensure_qr_capture_injected(page)
            sess["qr_ready"] = True
            sess["qr_error"] = ""
            return True, ""
        return False, "qr_button_not_found"

    try:
        await page.click(selector, timeout=2500)
        print(f"[{sid}] Кнопка QR нажата ({selector})")
    except Exception as e:
        return False, f"qr_click_failed: {e}"

    await asyncio.sleep(0.6)
    await _ensure_qr_capture_injected(page)
    sess["qr_ready"] = True
    sess["qr_error"] = ""
    return True, ""


def _humanize_qr_error(code: str) -> str:
    if not code:
        return ""

    if "qr_button_not_found" in code:
        return "Кнопка QR не найдена"
    if "qr_not_appeared" in code:
        return "QR не появился"
    if "qr_click_failed" in code:
        return "Не удалось нажать кнопку QR"
    if "session_closed" in code:
        return "Сессия Steam закрыта"
    return "Задержка Steam, пробуем снова"


def _proxy_snapshot() -> str:
    parts = []
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY"):
        value = os.getenv(key) or os.getenv(key.lower())
        if value:
            parts.append(f"{key}={value}")
    return ", ".join(parts) if parts else "proxy_env=off"


async def _save_goto_timeout_screenshot(page, sid: str, attempt: int) -> None:
    ts = int(time.time())
    out_dir = os.path.join(os.path.dirname(__file__), "steam_debug")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{sid}-goto-timeout-attempt{attempt}-{ts}.png")
    try:
        await page.screenshot(path=path, full_page=True, timeout=5000)
        print(f"[{sid}] 📸 Steam timeout screenshot saved: {path}", flush=True)
    except Exception as e:
        print(f"[{sid}] ⚠️ Steam timeout screenshot failed: {e}", flush=True)


def _has_required_user_proxy(chat_id: int | None) -> bool:
    if chat_id is None:
        return False
    if chat_id == ADMIN_CHAT_ID:
        return True
    user = get_user(chat_id)
    return bool((user.user_proxy_url or "").strip())


async def _goto_steam_login(page, sid: str):
    page.set_default_navigation_timeout(60000)
    page.set_default_timeout(20000)

    last_error = None
    init_route_handler = None
    try:
        async def _init_route(route):
            req = route.request
            rtype = req.resource_type
            if rtype in {"image", "font", "media"}:
                await route.abort()
                return
            await route.continue_()

        init_route_handler = _init_route
        await page.route("**/*", init_route_handler)
    except Exception:
        init_route_handler = None

    for attempt in range(1, 4):
        try:
            _STEAM_FRONTEND_FAIL.discard(sid)
            response = await page.goto(STEAM_LOGIN_URL, wait_until="commit", timeout=45000)
            status = response.status if response else "no_response"
            print(f"[{sid}] 🌐 Steam OpenID commit ok (attempt={attempt}, status={status}, url={page.url})", flush=True)

            try:
                await page.wait_for_load_state("domcontentloaded", timeout=15000)
                print(f"[{sid}] 📄 Steam DOMContentLoaded reached", flush=True)
            except PlaywrightTimeoutError:
                print(f"[{sid}] ⏳ Steam DOMContentLoaded delayed, продолжаю по селекторам", flush=True)

            # Steam cookie consent may block the login form; try to dismiss it.
            with suppress(Exception):
                consent_btn = page.locator(
                    "button:has-text('Принять все'), button:has-text('Отклонить все'), "
                    "button:has-text('Accept All'), button:has-text('Reject All')"
                ).first
                if await consent_btn.count() > 0 and await consent_btn.is_visible():
                    await consent_btn.click(timeout=2000)
                    print(f"[{sid}] 🍪 Cookie banner dismissed", flush=True)
                    await asyncio.sleep(0.4)

            await page.wait_for_selector(
                "input[type='text'], input[type='password'], #imageLogin, .login_qr_code_button, button:has-text('Sign in'), button:has-text('Войти')",
                timeout=15000,
            )
            if init_route_handler:
                with suppress(Exception):
                    await page.unroute("**/*", init_route_handler)
            return
        except PlaywrightTimeoutError as e:
            last_error = e
            print(f"[{sid}] ⚠️ Steam goto timeout (attempt={attempt}): {e}", flush=True)
            await _save_goto_timeout_screenshot(page, sid, attempt)
        except Exception as e:
            last_error = e
            print(f"[{sid}] ⚠️ Steam goto error (attempt={attempt}): {e}", flush=True)

        with suppress(Exception):
            await page.goto("about:blank", wait_until="load", timeout=5000)
        await asyncio.sleep(min(attempt, 3))

    raise last_error or RuntimeError("Steam login page did not open")


async def _close_browser_resources(sess: dict):
    browser = sess.get("browser")
    if browser:
        with suppress(Exception):
            await browser.close()

    pw = sess.get("pw")
    if pw:
        with suppress(Exception):
            await pw.stop()


async def _close_session(sid: str, reason: str = "unknown"):
    sess = sessions.pop(sid, None)
    if not sess:
        print(f"[{sid}] ℹ️ Сессия уже закрыта (reason={reason})", flush=True)
        return
    try:
        xvfb_proc = sess.get("xvfb_proc")
        if xvfb_proc and xvfb_proc.poll() is None:
            with suppress(Exception):
                xvfb_proc.terminate()
            with suppress(Exception):
                xvfb_proc.wait(timeout=2)
            if xvfb_proc.poll() is None:
                with suppress(Exception):
                    xvfb_proc.kill()
        await _close_browser_resources(sess)
        print(f"[{sid}] 🧹 Браузер закрыт (reason={reason})", flush=True)
    except Exception as e:
        print(f"[{sid}] ⚠️ Ошибка при закрытии браузера (reason={reason}): {e}", flush=True)
    finally:
        _recent_closures[sid] = {"reason": reason, "ts": int(time.time())}
        stop_xray_bridge(sid)

def _touch(sid: str):
    if sid in sessions:
        sessions[sid]["last_seen"] = int(time.time())

async def _cleanup_expired():
    now = int(time.time())
    for sid, meta in list(_recent_closures.items()):
        if now - int(meta.get("ts") or now) > 900:
            _recent_closures.pop(sid, None)
    for sid, sess in list(sessions.items()):
        if now - int(sess.get("last_seen", now)) > SESSION_TTL:
            await _close_session(sid, reason="ttl_expired")


async def _ttl_loop():
    while True:
        await _cleanup_expired()
        await asyncio.sleep(5)


def _ensure_ttl_cleaner_started():
    global _ttl_task
    if _ttl_task is None or _ttl_task.done():
        _ttl_task = asyncio.create_task(_ttl_loop())
        print("[steam] ✅ TTL cleaner started", flush=True)

STEAM_LOGIN_URL = STEAM_AUTH_START_URL
_p = urlparse(STEAM_BROWSER_HTTP_PROXY)
STEAM_PROXY_CFG = {
    "server": f"{_p.scheme}://{_p.hostname}:{_p.port}",
    "username": _p.username or "",
    "password": _p.password or "",
}

async def init_browser(sid, init_token: int, chat_id: int | None = None):
    print(f"[{sid}] 🚀 Запуск браузера... {_proxy_snapshot()}", flush=True)
    if chat_id is None:
        chat_id = _chat_id_from_sid(sid)
    if not _has_required_user_proxy(chat_id):
        if sid in sessions:
            sessions[sid]["init_error"] = "proxy_required"
            sessions[sid]["stage"] = "init_error"
        print(f"[{sid}] ⛔ Steam init blocked: proxy_required chat_id={chat_id}", flush=True)
        return
    if sid not in sessions:
        sessions[sid] = _make_session_state(init_token)

    if sessions[sid].get("init_token") != init_token:
        print(f"[{sid}] ℹ️ Пропускаю устаревший init до запуска браузера", flush=True)
        return

    pw = None
    browser = None
    xvfb_proc = None
    xvfb_display = None
    try:
        bridge_url = ensure_xray_bridge(sid, int(chat_id))
        xvfb_proc, xvfb_display = _start_xvfb_dynamic()
        pw = await async_playwright().start()
        launch_kwargs = {
            "headless": False,
            "env": {**os.environ, "DISPLAY": xvfb_display},
            "args": [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--disable-extensions",
                "--disable-background-timer-throttling",
                "--disable-renderer-backgrounding",
                "--disable-backgrounding-occluded-windows",
                "--disable-features=Translate,BackForwardCache",
                "--disable-blink-features=AutomationControlled",
                "--no-first-run",
                "--no-zygote",
                f"--zooma-auth-sid={sid}",
            ],
        }
        if bridge_url:
            launch_kwargs["proxy"] = {"server": bridge_url}
            print(f"[{sid}] 🔌 Steam proxy bridge enabled: {bridge_url}", flush=True)
        else:
            print(f"[{sid}] 🔌 Steam proxy bypass for admin", flush=True)
        browser = await pw.chromium.launch(**launch_kwargs)
        context = await browser.new_context(
            viewport={"width": 412, "height": 915},
            screen={"width": 412, "height": 915},
            device_scale_factor=3,
            locale='ru-RU',
            extra_http_headers={"Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8"},
            user_agent="Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            is_mobile=True,
            has_touch=True,
            timezone_id="Europe/Moscow",
        )
        page = await context.new_page()
        page.on("requestfailed", lambda req: print(
            f"[{sid}] ❌ request failed: {req.method} {req.url} | {req.failure}",
            flush=True,
        ))
        def _mark_front_fail(req):
            try:
                url = (req.url or "").lower()
                fail = str(req.failure or "")
                if "steamstatic.com" in url and "login.js" in url:
                    _STEAM_FRONTEND_FAIL.add(sid)
                    print(f"[{sid}] ⚠️ Steam frontend asset failed: {url} {fail}", flush=True)
            except Exception:
                pass
        page.on("requestfailed", _mark_front_fail)
        page.on(
            "response",
            lambda res: print(f"[{sid}] ↩️ response: {res.status} {res.url}", flush=True)
            if "steamcommunity.com" in res.url else None,
        )
        await page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        await _goto_steam_login(page, sid)
        if sid in _STEAM_FRONTEND_FAIL:
            raise RuntimeError("steam_frontend_incomplete")

        current_session = sessions.get(sid)
        if not current_session or current_session.get("init_token") != init_token:
            print(f"[{sid}] ℹ️ Устаревший init завершился после отмены/перезапуска", flush=True)
            await _close_browser_resources({"browser": browser, "pw": pw})
            return

        current_session.update({"page": page, "browser": browser, "pw": pw, "ready": True, "last_seen": int(time.time())})
        current_session["xvfb_proc"] = xvfb_proc
        current_session["xvfb_display"] = xvfb_display
        print(f"[{sid}] ✅ Steam готов")
    except Exception as e:
        if sid in sessions:
            sessions[sid]["init_error"] = str(e)
            sessions[sid]["stage"] = "init_error"
        if xvfb_proc and xvfb_proc.poll() is None:
            with suppress(Exception):
                xvfb_proc.terminate()
            with suppress(Exception):
                xvfb_proc.wait(timeout=2)
        if browser or pw:
            await _close_browser_resources({"browser": browser, "pw": pw})
        # Auto-restart once on incomplete Steam frontend (new xray bridge/port, same user proxy).
        if sid in sessions and str(e) == "steam_frontend_incomplete":
            sess = sessions.get(sid, {})
            if not sess.get("steam_retry_once_done"):
                sess["steam_retry_once_done"] = True
                sessions[sid] = sess
                print(f"[{sid}] 🔁 Перезапуск Steam init из-за неполной загрузки фронта", flush=True)
                stop_xray_bridge(sid)
                await asyncio.sleep(0.5)
                await init_browser(sid, init_token, chat_id)
                return
        print(f"[{sid}] ❌ Ошибка инита: {e}", flush=True)

@app.get("/api/init")
async def api_init(sid: str, bg: BackgroundTasks, chat_id: int | None = None):
    _recent_closures.pop(sid, None)
    _ensure_ttl_cleaner_started()
    await _cleanup_expired()
    if sid in sessions and _get_page_if_ready(sid) and not sessions[sid].get("done"):
        _touch(sid)
        return {"status": "ok", "reused": True}
    if chat_id is None:
        chat_id = _chat_id_from_sid(sid)
    if chat_id is not None:
        # If user switched auth provider, close previous auth sessions for this user.
        with suppress(Exception):
            from tg_webapp import close_sessions_for_chat as close_tg_sessions_for_chat
            await close_tg_sessions_for_chat(int(chat_id))
        with suppress(Exception):
            from yandex_webapp import close_sessions_for_chat as close_ya_sessions_for_chat
            await close_ya_sessions_for_chat(int(chat_id))
        await close_sessions_for_chat(int(chat_id), exclude_sid=sid)
    if not _has_required_user_proxy(chat_id):
        sessions[sid] = _make_session_state()
        sessions[sid]["init_error"] = "proxy_required"
        sessions[sid]["stage"] = "init_error"
        return {
            "status": "error",
            "msg": "Для прохождения авторизации требуется прокси.\nАдмин оповещен @saxarok322",
        }
    # Prestart xray bridge in init request to reduce browser-start latency.
    if chat_id is not None:
        with suppress(Exception):
            ensure_xray_bridge(sid, int(chat_id))
    sessions[sid] = _make_session_state()
    bg.add_task(init_browser, sid, sessions[sid]["init_token"], chat_id)
    return {"status": "pending"}

@app.post("/api/show_qr")
async def api_show_qr(sid: str = Form(...)):
    if sid not in sessions: return {"status": "error"}
    _touch(sid)
    sessions[sid]["qr_active"] = True
    sessions[sid]["qr_requested"] = True
    sessions[sid]["qr_error"] = ""
    sessions[sid]["qr_wait_started"] = int(time.time())

    page = await _wait_for_ready_page(sid, attempts=8, delay=0.35)
    if not page:
        print(f"[{sid}] show_qr отложен: страница ещё не готова")
        return {"status": "waiting", "msg": "Steam еще загружается, команда show_qr сохранена"}

    try:
        print(f"[{sid}] Режим QR: Включен. Ищу кнопку...")
        ok, qr_error = await _activate_qr_mode(sid, page)
        if not ok:
            sessions[sid]["qr_error"] = qr_error
            msg = _humanize_qr_error(qr_error)
            print(f"[{sid}] Ошибка в show_qr: {qr_error} ({msg})")
            if "not_found" in qr_error:
                return {"status": "waiting", "msg": msg or "Кнопка QR не найдена"}
            return {"status": "retry", "msg": msg or "Задержка Steam, пробуем снова"}
        return {"status": "ok", "msg": "QR режим активирован"}
    except Exception as e:
        sessions[sid]["qr_error"] = str(e)
        print(f"[{sid}] Ошибка в show_qr: {e}")
        return {"status": "retry", "msg": "Временная ошибка show_qr"}


@app.post("/api/hide_qr")
async def api_hide_qr(sid: str = Form(...)):
    """Выключает режим QR, если пользователь нажал 'Скрыть'"""
    if sid in sessions:
        sessions[sid]["qr_active"] = False
        sessions[sid]["qr_requested"] = False
        sessions[sid]["qr_ready"] = False
        sessions[sid]["qr_error"] = ""
        sessions[sid]["qr_wait_started"] = 0
        print(f"[{sid}] Режим QR: Выключен")
    return {"status": "ok"}


@app.get("/api/get_qr")
async def api_get_qr(sid: str):
    if sid not in sessions: return {"status": "error"}
    _touch(sid)
    page = _get_page_if_ready(sid)
    if not page:
        return {"status": "waiting"}
    try:
        sess = sessions.get(sid)
        if sess and sess.get("qr_active") and sess.get("qr_requested") and not sess.get("qr_ready"):
            ok, qr_error = await _activate_qr_mode(sid, page)
            if not ok:
                if qr_error:
                    sess["qr_error"] = qr_error
                return {"status": "waiting", "msg": _humanize_qr_error(qr_error)}

        base64_img = await page.evaluate("window.lastQR || ''")
        if base64_img:
            return {"status": "ok", "image": base64_img}

        if sess:
            wait_started = int(sess.get("qr_wait_started") or 0)
            if wait_started and int(time.time()) - wait_started >= 10:
                sess["qr_error"] = "qr_not_appeared"
                return {"status": "waiting", "msg": _humanize_qr_error("qr_not_appeared")}

            if sess.get("qr_error"):
                return {"status": "waiting", "msg": _humanize_qr_error(sess["qr_error"])}

        return {"status": "waiting", "msg": "Задержка Steam, пробуем снова"}
    except Exception as e:
        if sid in sessions:
            sessions[sid]["qr_error"] = str(e)
        return {"status": "error"}


@app.post("/api/login")
async def api_login(sid: str = Form(...), u: str = Form(...), p: str = Form(...)):
    if sid not in sessions: return {"status": "error", "msg": "Сессия не найдена"}
    _touch(sid)
    page = await _wait_for_ready_page(sid)
    if not page:
        return {"status": "error", "msg": "Браузер Steam еще запускается. Попробуйте снова через секунду."}
    
    try:
        # 1. Ввод данных
        await page.fill("input[type='text']", u)
        await page.fill("input[type='password']", p)

        # 2. Очистка старых ошибок
        await page.evaluate("""() => {
            const err = document.querySelector('.error_display, #error_display, [class*="error"]');
            if (err) err.style.display = 'none';
        }""")
        
        # 3. Клик по кнопке входа
        login_btn = page.locator("button:has-text('Войти'), #imageLogin, .DjSvCZoKKfoNSmarsEcTS")
        await login_btn.first.click()

        print(f"[{sid}] Попытка входа (Логин: {u}). Жду результат...")
        await asyncio.sleep(1.5)

        # 4. Цикл анализа страницы
        for i in range(15):
            # Проверка на ошибку пароля/логина
            error_el = page.locator("text=Пожалуйста, проверьте свой пароль")
            if await error_el.count() > 0 and await error_el.first.is_visible():
                msg = (await error_el.first.text_content()).strip()
                print(f"[{sid}] ❌ Ошибка: {msg}")
                return {"status": "error", "msg": msg}

            # ПРОВЕРКА 1: Прямой ввод кода (твой случай 8.txt)
            # Ищем текст "Введите код, полученный" или наличие инпутов для кода при отсутствии мобильного текста
            direct_code_check = await page.evaluate("""() => {
                const text = (document.body && document.body.innerText) ? document.body.innerText : "";
                return text.includes("Введите код, полученный") || text.includes("на вашу почту");
            }""")
            
            if direct_code_check:
                print(f"[{sid}] 🔐 Обнаружен экран прямого ввода кода (Email/Classic)")
                sessions[sid]["stage"] = "two_factor"
                return {"status": "wait_code"}

            # ПРОВЕРКА 2: Подтверждение в приложении (Push)
            mobile_push_check = await page.evaluate("""() => {
                const text = (document.body && document.body.innerText) ? document.body.innerText : "";
                return text.includes("Используйте мобильное приложение") || text.includes("подтвердите вход");
            }""")
            
            # Также проверяем наличие инпута как запасной вариант для входа
            code_input = page.locator("input[maxlength='1'][type='text'], input#authcode, input#twofactorcode_entry")
            
            if mobile_push_check:
                print(f"[{sid}] 📱 Требуется подтверждение в мобильном приложении")
                sessions[sid]["stage"] = "two_factor"
                return {"status": "need_2fa"}

            # ПРОВЕРКА 3: Успешный вход или наличие инпутов (общий случай)
            if await code_input.count() > 0 or await page.locator(f"text=Аккаунт: {u}").count() > 0:
                print(f"[{sid}] 🔐 Переход на стадию 2FA (общий случай)")
                sessions[sid]["stage"] = "two_factor"
                return {"status": "need_2fa"}

            await asyncio.sleep(0.5)

        return {"status": "error", "msg": "Steam не ответил вовремя. Попробуйте еще раз."}
    
    except Exception as e:
        print(f"[{sid}] ❌ Ошибка в api_login: {str(e)}")
        return {"status": "error", "msg": "Ошибка соединения"}


@app.post("/api/click_code_button")
async def api_click_code_button(sid: str = Form(...)):
    if sid not in sessions: return {"status": "error"}
    _touch(sid)
    page = _get_page_if_ready(sid)
    if not page:
        return {"status": "waiting"}
    try:
        # Пытаемся нажать, только если кнопка есть (для режима Push)
        target = page.locator("text=введите код, .login_verify_mobile_code_link")
        if await target.count() > 0:
            await target.click()
        return {"status": "ok"}
    except:
        return {"status": "ok"}


@app.post("/api/submit_code")
async def api_submit_code(sid: str = Form(...), code: str = Form(...)):
    if sid not in sessions: return {"status": "error"}
    _touch(sid)
    page = _get_page_if_ready(sid)
    if not page:
        return {"status": "waiting"}
    sess = sessions.get(sid)
    if not sess:
        return {"status": "error"}

    now_ts = time.time()
    clean_code = code.strip().upper()
    if sess.get("code_submit_inflight"):
        return {"status": "processing"}
    if (
        sess.get("last_code_value") == clean_code
        and (now_ts - float(sess.get("last_code_submit") or 0.0)) < 4.0
    ):
        return {"status": "duplicate"}

    sess["code_submit_inflight"] = True
    sess["last_code_submit"] = now_ts
    sess["last_code_value"] = clean_code
    try:
        print(f"[{sid}] ⌨️ Попытка ввода кода: {clean_code}")

        # 1. Проверяем, какой тип поля на странице прямо сейчас
        # Ищем 5 раздельных полей
        inputs_5 = page.locator('input[maxlength="1"][type="text"]')
        # Ищем одно целое поле (Email или Classic)
        input_single = page.locator('input#authcode, input#twofactorcode_entry, input[type="text"]')

        if await inputs_5.count() >= 5:
            print(f"[{sid}] Использую ввод в 5 ячеек")
            for i in range(5):
                await inputs_5.nth(i).fill(clean_code[i])
                # Небольшая пауза имитирует ручной ввод
                await asyncio.sleep(0.1) 
        else:
            print(f"[{sid}] Использую ввод в одно поле")
            # Пытаемся найти наиболее подходящее поле и заполнить его целиком
            target_input = input_single.first
            await target_input.fill(clean_code)

        await asyncio.sleep(0.5)

        # 2. Нажатие Enter — это самый надежный способ отправить форму в Steam
        await page.keyboard.press("Enter")
        print(f"[{sid}] Нажат Enter")
        

        # 3. Запасной клик по кнопке, если Enter не сработал (используем твои селекторы)
        await asyncio.sleep(1)
        confirm_btn = page.locator("text=Войти, text=Продолжить, #auth_buttonset_confirm, .DjSvCZoKKfoNSmarsEcTS")
        if await confirm_btn.count() > 0 and await confirm_btn.first.is_visible():
            await confirm_btn.first.click()
            print(f"[{sid}] Нажата кнопка подтверждения (запасной вариант)")

        # ВАЖНО: Не меняй stage на "polling" здесь, если логика check_status сама справляется
        return {"status": "ok"}
    except Exception as e:
        print(f"[{sid}] ❌ Ошибка ввода кода: {e}")
        return {"status": "error", "msg": str(e)}
    finally:
        sess["code_submit_inflight"] = False



@app.get("/api/check_status")
async def api_check_status(sid: str):
    await _cleanup_expired()
    if sid not in sessions:
        meta = _recent_closures.get(sid) or {}
        if str(meta.get("reason") or "") == "admin_stop":
            return {"status": "admin_stopped"}
        return {"status": "waiting"}
    if sid not in sessions or sessions[sid]["done"]:
        return {"status": "waiting"}
    _touch(sid)
    
    s = sessions[sid]
    # Если процесс уже идет, не запускаем второй параллельно
    if s.get("is_processing"): 
        return {"status": "processing"}

    page = _get_page_if_ready(sid)
    if not page:
        return {"status": "waiting"}

    s["is_processing"] = True
    try:
        # Твой рабочий цикл на 10 итераций
        for _ in range(10): 
            current_url = page.url
           
            # 1. ПРОВЕРКА НА УСПЕХ (zooma_top_session HttpOnly + localStorage snapshot)
            cookies = await page.context.cookies()
            zooma_session = None
            for c in cookies:
                if c.get("name") == "zooma_top_session" and c.get("value"):
                    zooma_session = str(c["value"]).strip()
                    break

            if zooma_session:
                local_storage_dump = await page.evaluate("""() => {
                    const out = {};
                    try {
                        for (let i = 0; i < localStorage.length; i++) {
                            const k = localStorage.key(i);
                            out[k] = localStorage.getItem(k);
                        }
                    } catch (e) {}
                    return out;
                }""")
                local_storage_dump = dict(local_storage_dump or {})
                local_storage_dump["auth_method"] = "steam_webapp"
                chat_id = _chat_id_from_sid(sid)
                if _ON_ZOOMA_SESSION and chat_id is not None:
                    ok, msg = await _ON_ZOOMA_SESSION(chat_id, zooma_session, local_storage_dump)
                    if ok:
                        s["done"] = True
                        s["stage"] = "done"
                        await _close_session(sid, reason="zooma_session_connected")
                        print(f"[{sid}] ✅ Сессия завершена после zooma_top_session")
                        return {"status": "done", "message": msg or "ok"}
                    # Если токен есть, но verify не прошел — продолжаем ждать/действовать.
                    print(f"[{sid}] zooma_top_session found but not connected: {msg}", flush=True)

            # 2. ПРОВЕРКА НА КНОПКУ "ВОЙТИ" С ТВОИМИ СЕЛЕКТОРАМИ + МАРКЕР
            # Добавляем условие: нажимаем только если видим маркер OpenID ("Это не вы?" или "не имеют отношения к")
            is_openid = await page.evaluate("""() => {
                const text = (document.body && document.body.innerText) ? document.body.innerText : "";
                return text.includes("Это не вы?") || text.includes("не имеют отношения к") || text.includes("Sign in to");
            }""")

            if is_openid:
                # Твои старые рабочие селекторы + универсальный текст
                login_btn = page.locator("#imageLogin, input[type='submit'][value='Войти'], button:has-text('Войти'), .DjSvCZoKKfoNSmarsEcTS")
                
                if await login_btn.count() > 0:
                    # Проверяем видимость первого найденного элемента
                    target = login_btn.first
                    if await target.is_visible():
                        print(f"[{sid}] 🎯 Маркер 'Это не вы?' найден. Жму 'Войти'...")
                        await target.click(force=True)
                        await asyncio.sleep(3) # Ждем загрузки после клика
                        continue # Сразу переходим к следующей итерации цикла для проверки токенов

            # Если ничего не нашли, ждем секунду и пробуем снова (внутри цикла)
            await asyncio.sleep(1)
            
        return {"status": "waiting"}
    except Exception as e:
        print(f"[{sid}] Ошибка в check_status: {e}")
        return {"status": "waiting"}
    finally:
        s["is_processing"] = False


@app.get("/api/state")
async def api_state(sid: str):
    await _cleanup_expired()
    if sid not in sessions:
        meta = _recent_closures.get(sid) or {}
        if str(meta.get("reason") or "") == "admin_stop":
            return {"status": "admin_stopped", "stage": "stopped", "ready": False, "init_error": ""}
        return {"status": "missing", "stage": "login"}
    _touch(sid)
    return {
        "status": "ok",
        "stage": sessions[sid].get("stage", "login"),
        "ready": sessions[sid].get("ready", False),
        "init_error": sessions[sid].get("init_error", ""),
    }

@app.post("/api/ping")
async def api_ping(sid: str = Form(...)):
    await _cleanup_expired()
    if sid not in sessions or sessions[sid].get("done"):
        return {"status": "missing"}
    _touch(sid)
    return {"status": "ok"}

@app.post("/api/cancel")
async def api_cancel(sid: str = Form(...)):
    await _close_session(sid, reason="manual_cancel")
    return {"status": "ok"}

# Папка, где лежит index.html
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "steam.html")
    
@app.on_event("startup")
async def start_ttl_cleaner():
    _ensure_ttl_cleaner_started()
