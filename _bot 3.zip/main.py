import asyncio
import contextlib
import html
import logging
import os
import random
import re
import time
from urllib.parse import urlparse

import httpx
from datetime import datetime, timezone, timedelta

import uvicorn
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, Update, WebAppInfo, MenuButtonWebApp, LinkPreviewOptions
from telegram.error import BadRequest, NetworkError, RetryAfter, TimedOut
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from store import (
    USERS,
    get_user,
    save_connected_account,
    set_active_domain,
    get_active_domain,
    load_state,
    get_all_chat_ids,
    has_active_subscription,
    has_active_account_subscription,
    update_user_fields,
    get_user_accounts,
    get_user_account,
    patch_user_account,
    clear_account_casino_data,
    account_server_session_is_stale,
    mark_account_server_session_stale,
    mark_account_server_session_notified,
    clear_account_server_session_state,
    flush_promo_stats_now,
)
from config import (
    BOT_TOKEN,
    PROXY_HOST,
    PROXY_PORT,
    PROXY_SCHEME,
    ZREF_URL,
    PROMO_API_HOST,
    PROMO_API_PORT,
    DOMAIN_CHECK_INTERVAL_SEC,
    DOMAIN_RETRY_DELAY_SEC,
    SESSION_PROBE_SLEEP_MIN_SEC,
    SESSION_PROBE_SLEEP_MAX_SEC,
    SESSION_PROBE_SCAN_IDLE_SEC,
    DOMAIN_REFRESH_CONCURRENCY,
    DOMAIN_REFRESH_ACCOUNT_GAP_SEC,
    STARTUP_RESTORE_CONCURRENCY,
    STARTUP_RESTORE_ACCOUNT_GAP_SEC,
    WS_REFRESH_MIN_SEC,
    WS_REFRESH_MAX_SEC,
    PUBLIC_WEB_BASE_URL,
    FORCE_ACTIVE_DOMAIN,
    STEAM_CONNECT_CHAT_ID,
    ADMIN_CHAT_ID,
    USE_PROXY,
    RAIN_TARGET_CHAT,
    TG_WATCHER_IN_MAIN_ENABLED,
)
from zooma import (
    proxy_url,
    resolve_active_domain,
    verify_token,
    is_domain_alive,
    get_user_proxy_url,
)
from ws_manager import UserWsManager
from promo_engine import PromoEngine
from promo_api import build_promo_app
from billing import BillingService
from rain_runtime import start_rain_runtime, stop_rain_runtime
from steam_webapp import set_zooma_session_handler
from tg_webapp import set_zooma_session_handler as set_tg_session_handler
from yandex_webapp import set_zooma_session_handler as set_yandex_session_handler
from auth_runtime_cleanup import cleanup_orphan_auth_runtime


def _omsk_logging_converter(timestamp: float):
    return datetime.fromtimestamp(timestamp, tz=timezone(timedelta(hours=6))).timetuple()

logging.Formatter.converter = staticmethod(_omsk_logging_converter)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)


def _install_db_normalization() -> None:
    if os.getenv("ZOOMA_DISABLE_DB_NORMALIZATION", "").strip().lower() in {"1", "true", "yes", "on"}:
        logging.info("DB normalization disabled by env")
        return
    try:
        from db_normalized import install_db_normalization_patches
        install_db_normalization_patches()
    except Exception as e:
        logging.exception("DB normalization install failed: %s", e)


_install_db_normalization()


class _TgPollingNoiseFilter(logging.Filter):
    def __init__(self) -> None:
        super().__init__()
        self.had_remote_disconnect = False
        self._last_warn_ts = 0.0
        self._streak = 0
        self._warned_for_streak = False

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        if "httpx.RemoteProtocolError: Server disconnected without sending a response." in msg:
            self._streak += 1
            now = time.monotonic()
            if self._streak >= 3 and (not self._warned_for_streak or now - self._last_warn_ts >= 5.0):
                logging.warning("TG polling: %s consecutive disconnects, retry in 1s", self._streak)
                self._last_warn_ts = now
                self._warned_for_streak = True
            self.had_remote_disconnect = True
            return False
        return True


_tg_polling_noise_filter = _TgPollingNoiseFilter()
logging.getLogger("telegram.ext._utils.networkloop").addFilter(_tg_polling_noise_filter)

ws_manager = UserWsManager()
promo_engine = PromoEngine(ws_manager)
billing = BillingService(ws_manager)
promo_server: uvicorn.Server | None = None
promo_server_task: asyncio.Task | None = None
domain_watchdog_task: asyncio.Task | None = None
session_probe_task: asyncio.Task | None = None
_SESSION_STALE_ALERT_LOCK: set[str] = set()
ws_refresh_task: asyncio.Task | None = None
rain_runtime_task: asyncio.Task | None = None
tg_watcher_task: asyncio.Task | None = None
startup_restore_task: asyncio.Task | None = None
MSK_TZ = timezone(timedelta(hours=3))
_LAST_USER_DELETE_ATTEMPT: dict[int, int] = {}
_LAST_CONNECTED_NOTIFY: dict[str, tuple[str, float]] = {}
_LAST_PROFILE_SHOW_TS: dict[int, float] = {}
_TG_ERROR_LAST_LOG_TS: dict[str, float] = {}
_TG_ERROR_SUPPRESSED: dict[str, int] = {}




async def _telegram_call_with_retry(func, *args, attempts: int = 30, delay: float = 1.0, **kwargs):
    last_exc = None
    for attempt in range(1, max(1, int(attempts)) + 1):
        try:
            return await func(*args, **kwargs)
        except RetryAfter as e:
            last_exc = e
            await asyncio.sleep(max(delay, float(getattr(e, "retry_after", delay) or delay)))
        except Exception as e:
            last_exc = e
            if attempt >= attempts:
                raise
            await asyncio.sleep(delay)
    if last_exc:
        raise last_exc


def _install_telegram_retries(app: Application) -> None:
    # telegram.ExtBot objects are immutable TelegramObject instances, so assigning
    # wrappers to app.bot.send_message raises AttributeError. Patch methods on the
    # concrete bot class once; Python will bind `self` normally for this app.
    bot_cls = type(app.bot)
    for name in (
        "send_message",
        "send_photo",
        "send_document",
        "send_video",
        "send_animation",
        "copy_message",
        "forward_message",
        "edit_message_text",
        "delete_message",
    ):
        orig = getattr(bot_cls, name, None)
        if not callable(orig) or getattr(orig, "_zooma_retry_wrapped", False):
            continue

        async def wrapped(self, *args, __orig=orig, __method_name=name, **kwargs):
            if __method_name in {"send_message", "edit_message_text"}:
                if "link_preview_options" not in kwargs and "disable_web_page_preview" not in kwargs:
                    kwargs["link_preview_options"] = LinkPreviewOptions(is_disabled=True)
            return await _telegram_call_with_retry(__orig, self, *args, **kwargs)

        wrapped._zooma_retry_wrapped = True
        setattr(bot_cls, name, wrapped)

def _user_app_url() -> str:
    return f"{PUBLIC_WEB_BASE_URL}/app"


async def _set_menu_button_default(app: Application) -> None:
    with contextlib.suppress(Exception):
        await app.bot.set_chat_menu_button(
            menu_button=MenuButtonWebApp(text="Открыть", web_app=WebAppInfo(url=_user_app_url()))
        )


async def _set_menu_button_for_chat(app: Application, chat_id: int) -> None:
    with contextlib.suppress(Exception):
        await app.bot.set_chat_menu_button(
            chat_id=int(chat_id),
            menu_button=MenuButtonWebApp(text="Открыть", web_app=WebAppInfo(url=_user_app_url())),
        )



def _user_log_ref(chat_id: int) -> str:
    with contextlib.suppress(Exception):
        u = get_user(int(chat_id))
        username = str(getattr(u, "tg_username", "") or "").strip()
        if username:
            return username
    return str(chat_id)


def _log_personal_promo_source(chat_id: int, promo: str) -> None:
    stamp = datetime.now(timezone(timedelta(hours=6))).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    print(f"[{stamp}] {_user_log_ref(chat_id)} / {str(promo or '').strip().upper()}", flush=True)


def _is_admin_runtime_chat(chat_id: int) -> bool:
    try:
        return bool(ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID))
    except Exception:
        return False


def _account_has_casino_runtime_data(acc: dict | None) -> bool:
    a = acc or {}
    for key in (
        "port_user_id",
        "port_user_name",
        "zooma_top_session",
        "zooma_top_session_expires_at",
        "csrf_token",
        "centrifugo_secret",
        "fingerprint_now",
        "user_agent",
        "proxy_url",
        "proxy_ip",
        "proxy_order_id",
        "proxy_login",
        "proxy_password",
    ):
        if str(a.get(key) or "").strip():
            return True
    return False


def _account_proxy_allowed_for_runtime(chat_id: int, account_id: str | None = None, acc: dict | None = None) -> bool:
    # chat_id=ADMIN_CHAT_ID may run without proxy. Everyone else needs the proxy
    # bound to this exact casino account. Never fall back to another account.
    if _is_admin_runtime_chat(chat_id):
        return True

    if account_id:
        a = acc or get_user_account(int(chat_id), account_id) or {}
        if account_server_session_is_stale(a):
            return False
        runtime_status = str(a.get("proxy_runtime_status") or "healthy").strip().lower()
        if runtime_status in {"unavailable", "site_unreachable", "recovering"}:
            return False
        return bool(str(a.get("proxy_url") or "").strip())

    user = get_user(int(chat_id))
    active_id = str(getattr(user, "active_account_id", None) or "acc_1")
    a = get_user_account(int(chat_id), active_id) or {}
    runtime_status = str(a.get("proxy_runtime_status") or "healthy").strip().lower()
    if runtime_status in {"unavailable", "site_unreachable", "recovering"}:
        return False
    return bool(str(a.get("proxy_url") or "").strip())


def _account_in_extension_mode(chat_id: int, account_id: str | None = None) -> bool:
    try:
        aid = str(account_id or getattr(get_user(int(chat_id)), "active_account_id", None) or "acc_1")
        acc = get_user_account(int(chat_id), aid) or {}
        return str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension"
    except Exception:
        return False


def _looks_like_proxy_connect_failure(text: str | None) -> bool:
    low = str(text or "").lower()
    return (
        "couldn't connect to proxy" in low
        or "connect call failed" in low
        or "connection refused" in low
        or "errno 111" in low
        or "all connection attempts failed" in low
        or "connect_error" in low
    )


def _connected_notify_key(chat_id: int, account_id: str | None) -> str:
    return f"{int(chat_id)}:{str(account_id or 'acc_1')}"


def _session_stale_key(chat_id: int, account_id: str) -> str:
    return f"{int(chat_id)}:{str(account_id or 'acc_1')}"


def _clear_stale_alert_lock(chat_id: int, account_id: str) -> None:
    _SESSION_STALE_ALERT_LOCK.discard(_session_stale_key(chat_id, account_id))


def _session_stale_message(chat_id: int, account_id: str) -> tuple[str, str]:
    acc = get_user_account(int(chat_id), str(account_id)) or {}
    slot = int(acc.get("slot") or 1)
    name = str(acc.get("port_user_name") or "-").strip() or "-"
    casino_id = str(acc.get("port_user_id") or "-").strip() or "-"
    user = get_user(int(chat_id))
    username = str(getattr(user, "tg_username", "") or "-")
    account_line = f"Аккаунт: #{slot} · {name} | ID {casino_id}"
    user_text = "⚠️ Сессия протухла\n\nТребуется повторно подключить аккаунт казино.\n" + account_line
    admin_text = f"⚠️ Сессия пользователя протухла\nchat_id: {chat_id}\nuser: {username}\n{account_line}"
    return user_text, admin_text


async def _resolve_active_domain_fast() -> str:
    forced_domain = str(FORCE_ACTIVE_DOMAIN or "").strip()
    if forced_domain:
        return forced_domain
    return str(
        await resolve_active_domain(
            zref_url=ZREF_URL,
            proxy_scheme=PROXY_SCHEME,
            proxy_host=PROXY_HOST,
            proxy_port=PROXY_PORT,
        )
        or ""
    ).strip()



async def _notify_extension_domain_change(app: Application, old_domain: str | None, new_domain: str) -> None:
    """Notify users who activate promos via a bound extension about domain rotation."""
    now_ts = int(time.time())
    text = f"Смена домена: {old_domain or '-'} -> {new_domain}\nРасширение автоматически перейдёт на новый домен."
    sent: set[int] = set()
    for cid in get_all_chat_ids():
        try:
            chat_id = int(cid)
        except Exception:
            continue
        if chat_id in sent:
            continue
        for acc in get_user_accounts(chat_id, include_empty=True):
            if str(acc.get("promo_activation_mode") or "server").strip().lower() != "extension":
                continue
            if int(acc.get("extension_bound_chat_id") or 0) != chat_id:
                continue
            if not has_active_account_subscription(chat_id, str(acc.get("account_id") or "acc_1"), now_ts):
                continue
            with contextlib.suppress(Exception):
                await app.bot.send_message(chat_id=chat_id, text=text)
                sent.add(chat_id)
            break

async def _notify_admin_auth_success(
    app: Application,
    *,
    chat_id: int,
    tg_username: str | None,
    method: str,
    status: str = "успешно",
) -> None:
    if not ADMIN_CHAT_ID:
        return
    uname = (str(tg_username or "").strip() or "-")
    text = (
        "✅ Авторизация пользователя\n"
        f"chat_id: {int(chat_id)}\n"
        f"юзернейм: {uname}\n"
        f"статус: {status}\n"
        f"метод: {method}"
    )
    with contextlib.suppress(Exception):
        await app.bot.send_message(chat_id=ADMIN_CHAT_ID, text=text)


def _connected_account_text(chat_id: int, account_id: str | None, port_user_name: str | None, port_user_id: str | None) -> str:
    acc = get_user_account(chat_id, account_id) if account_id else None
    slot = int((acc or {}).get("slot") or 1)
    title = "Аккаунт" if slot <= 1 else f"Аккаунт #{slot}"

    name = str(port_user_name or (acc or {}).get("port_user_name") or "").strip()
    casino_id = str(port_user_id or (acc or {}).get("port_user_id") or "").strip()
    casino = f"{name or '-'} | {casino_id or '-'}"

    return f"✅ {title} подключен\n{casino}"

def _connected_notify_marker(result, fallback_token: str | None = None) -> str:
    return str(
        getattr(result, "port_user_id", None)
        or getattr(result, "zooma_top_session", None)
        or fallback_token
        or ""
    )


def _reserve_connected_notify(chat_id: int, account_id: str | None, marker: str, now: float, ttl_sec: float = 600.0) -> tuple[bool, str]:
    key = _connected_notify_key(chat_id, account_id)
    marker = str(marker or "")
    prev = _LAST_CONNECTED_NOTIFY.get(key)
    if prev and prev[0] == marker and (now - float(prev[1] or 0.0)) <= ttl_sec:
        return False, key
    _LAST_CONNECTED_NOTIFY[key] = (marker, now)
    return True, key

def _mark_tg_poll_recovered() -> None:
    if _tg_polling_noise_filter.had_remote_disconnect:
        _tg_polling_noise_filter.had_remote_disconnect = False
        _tg_polling_noise_filter._streak = 0
        _tg_polling_noise_filter._warned_for_streak = False
        logging.info("TG polling: retry successful, connection restored")

def reply_keyboard(chat_id: int | None = None):
    rows = [["Тарифы", "Профиль"]]
    if chat_id is not None and _is_admin_runtime_chat(int(chat_id)):
        rows = [["Тарифы", "Профиль", "уведа"]]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)


async def _refresh_reply_keyboard(
    app: Application,
    chat_id: int,
    *,
    text: str = "Клавиатура обновлена. Используйте кнопки ниже.",
) -> None:
    """Force Telegram clients to replace the persistent reply keyboard.

    Inline keyboards are attached to a single message and do not update the
    bottom reply keyboard. Sending a tiny service message with ReplyKeyboardMarkup
    makes /start refresh the user keyboard for both regular users and admin.
    """
    await app.bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=reply_keyboard(chat_id),
    )



def _is_visible_account_for_profile(acc: dict) -> bool:
    # Hide unpaid empty addon slots created by invoice reservation.
    # Paid-but-not-bound addon accounts stay visible because subscription_until_ts > now.
    until_ts = int(acc.get("subscription_until_ts") or 0)
    if until_ts > int(time.time()):
        return True
    if bool(acc.get("connected")):
        return True
    if str(acc.get("port_user_id") or "").strip() or str(acc.get("port_user_name") or "").strip():
        return True
    if str(acc.get("proxy_url") or "").strip() or str(acc.get("proxy_ip") or "").strip():
        return True
    return False


def profile_keyboard(chat_id: int):
    accounts = get_user_accounts(chat_id)
    visible_accounts = [a for a in accounts if _is_visible_account_for_profile(a)]
    now_ts = int(time.time())

    if len(visible_accounts) > 1:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🎰 Мои аккаунты", callback_data="accounts:p=0")],
        ])

    acc = visible_accounts[0] if visible_accounts else {}
    until_ts = int(acc.get("subscription_until_ts") or 0)
    connected = bool(acc.get("connected") and str(acc.get("port_user_name") or "").strip())
    rows = [[
        InlineKeyboardButton(
            "Переподключить аккаунт" if connected else "Подключить аккаунт",
            callback_data="connect",
        )
    ]]
    if until_ts > now_ts:
        rows.append([InlineKeyboardButton("Доп акк", callback_data="addon_account")])
    return InlineKeyboardMarkup(rows)


def back_keyboard():
    return InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data="back")]])


def steam_connect_keyboard(chat_id: int):
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("Войти через Steam", web_app=WebAppInfo(url=f"{PUBLIC_WEB_BASE_URL}/auth/webapp/steam/?chat_id={chat_id}"))],
            [InlineKeyboardButton("Войти через Telegram", web_app=WebAppInfo(url=f"{PUBLIC_WEB_BASE_URL}/auth/webapp/tg/?chat_id={chat_id}"))],
            [InlineKeyboardButton("Войти через Яндекс", web_app=WebAppInfo(url=f"{PUBLIC_WEB_BASE_URL}/auth/webapp/yandex/?chat_id={chat_id}"))],
            [InlineKeyboardButton("Вписать zooma_top_session", callback_data="manual_token")],
            [InlineKeyboardButton("Назад", callback_data="back")],
        ]
    )


def username(update: Update):
    user = update.effective_user
    if not user:
        return "без username"
    if user.username:
        return f"@{user.username}"
    return "без username"


def username_from_callback(update: Update) -> str:
    user = update.callback_query.from_user if update.callback_query else None
    if not user:
        return "без username"
    if user.username:
        return f"@{user.username}"
    return "без username"


async def _answer_callback_safe(query) -> None:
    try:
        await query.answer()
    except Exception as e:
        msg = str(e)
        if (
            "Query is too old" not in msg
            and "query id is invalid" not in msg
            and "response timeout expired" not in msg
        ):
            logging.warning("callback answer failed: %s", e)



def _compact_update_for_log(update) -> str:
    try:
        if isinstance(update, Update):
            user = update.effective_user
            chat = update.effective_chat
            parts = []
            if chat:
                parts.append(f"chat_id={chat.id}")
            if user:
                uname = f"@{user.username}" if user.username else "no_username"
                parts.append(f"user={uname}/{user.id}")
            if update.callback_query:
                parts.append(f"callback={str(update.callback_query.data or '')[:80]}")
            if update.message:
                message_text = str(update.message.text or "")
                parts.append(f"message_len={len(message_text)}")
            return " ".join(parts) or "Update"
        return update.__class__.__name__ if update is not None else "None"
    except Exception:
        return "unknown_update"


def _tg_error_should_log(key: str, interval_sec: float = 60.0) -> tuple[bool, int]:
    now = time.monotonic()
    last = _TG_ERROR_LAST_LOG_TS.get(key, 0.0)
    if now - last >= interval_sec:
        suppressed = _TG_ERROR_SUPPRESSED.pop(key, 0)
        _TG_ERROR_LAST_LOG_TS[key] = now
        return True, suppressed
    _TG_ERROR_SUPPRESSED[key] = _TG_ERROR_SUPPRESSED.get(key, 0) + 1
    return False, 0


async def telegram_error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    err = context.error
    if err is None:
        return

    err_name = err.__class__.__name__
    err_text = str(err)

    # Старые callback query и просроченные клики не являются проблемой.
    if isinstance(err, BadRequest):
        low = err_text.lower()
        if (
            "query is too old" in low
            or "query id is invalid" in low
            or "response timeout expired" in low
            or "message is not modified" in low
            or "message to delete not found" in low
        ):
            return

    is_network_noise = (
        isinstance(err, (NetworkError, TimedOut, RetryAfter))
        or "httpx." in err_text
        or "server disconnected without sending a response" in err_text.lower()
        or "connecterror" in err_text.lower()
        or "remoteprotocolerror" in err_text.lower()
        or "pooltimeout" in err_text.lower()
    )

    if is_network_noise:
        key = f"tg_network:{err_name}:{err_text[:160]}"
        should_log, suppressed = _tg_error_should_log(key, interval_sec=60.0)
        if should_log:
            extra = f" suppressed={suppressed}" if suppressed else ""
            logging.warning(
                "TG network error: %s: %s%s update=%s",
                err_name,
                err_text[:500],
                extra,
                _compact_update_for_log(update),
            )
        return

    logging.error(
        "Telegram update error: %s: %s update=%s",
        err_name,
        err_text,
        _compact_update_for_log(update),
        exc_info=(type(err), err, err.__traceback__),
    )


def _clean_tier_view(value: str | None) -> str:
    tier_raw = str(value or "lite").strip()
    tier_view = tier_raw.split(":", 1)[1] if ":" in tier_raw else tier_raw
    return tier_view or "lite"


def _fmt_msk_ts(ts: int | None) -> str:
    if not ts:
        return "-"
    return datetime.fromtimestamp(int(ts), tz=MSK_TZ).strftime("%H:%M %d.%m.%Y")


def _fmt_msk_short(ts: int | None) -> str:
    if not ts:
        return "-"
    return datetime.fromtimestamp(int(ts), tz=MSK_TZ).strftime("%H:%M %d.%m")


def _account_display_name(acc: dict) -> str:
    name = str(acc.get("port_user_name") or "").strip()
    uid = str(acc.get("port_user_id") or "").strip()
    if name and uid:
        return f"{name} | {uid}"
    if name:
        return name
    if uid:
        return f"id {uid}"
    return f"Аккаунт {int(acc.get('slot') or 1)}"


def _account_number_emoji(slot: int) -> str:
    return {
        1: "1️⃣",
        2: "2️⃣",
        3: "3️⃣",
        4: "4️⃣",
        5: "5️⃣",
        6: "6️⃣",
        7: "7️⃣",
        8: "8️⃣",
        9: "9️⃣",
        10: "🔟",
    }.get(int(slot or 0), f"{slot}.")


def _mask_proxy_ip(value: str | None) -> str:
    ip = str(value or "").strip()
    if not ip:
        return "-"
    parts = ip.split(".")
    if len(parts) >= 2:
        return f"{parts[0]}.{parts[1]}.*.*"
    return ip[:5] + "***"


def _country_flag(cc: str | None) -> str:
    code = str(cc or "").strip().upper()
    if len(code) != 2 or not code.isalpha():
        return ""
    return "".join(chr(127397 + ord(ch)) for ch in code)


def _sorted_accounts_for_view(chat_id: int, include_empty: bool = True) -> list[dict]:
    accounts = get_user_accounts(chat_id, include_empty=include_empty)
    now_ts = int(time.time())

    def key(acc: dict):
        until = int(acc.get("subscription_until_ts") or 0)
        active = until > now_ts
        return (0 if active else 1, until if active else 10**18, int(acc.get("slot") or 999))

    return sorted(accounts, key=key)


def _account_html_link(acc: dict) -> str:
    name = html.escape(str(acc.get("port_user_name") or "").strip() or f"Аккаунт {int(acc.get('slot') or 1)}")
    uid = str(acc.get("port_user_id") or "").strip()
    if not uid:
        return name
    active_domain = (get_active_domain() or "").rstrip("/")
    if active_domain:
        return f'{name} <a href="{active_domain}/user/{html.escape(uid)}">{html.escape(uid)}</a>'
    return f"{name} {html.escape(uid)}"


def profile_text(chat_id: int, tg_username: str):
    accounts = _sorted_accounts_for_view(chat_id, include_empty=True)
    non_empty = [a for a in accounts if _is_visible_account_for_profile(a)]
    visible = non_empty

    text = (
        "ZOOMA client\n\n"
        "Профиль\n"
        f"{html.escape(tg_username)}\n\n"
    )

    if not visible:
        text += "Активных подписок нет"
        return text

    if len(visible) > 1:
        now_ts = int(time.time())
        active_until = [
            int(a.get("subscription_until_ts") or 0)
            for a in visible
            if int(a.get("subscription_until_ts") or 0) > now_ts
        ]
        nearest = min(active_until) if active_until else 0
        text += (
            f"Аккаунтов {len(visible)}\n"
            f"Наиближайшие окончание: {_fmt_msk_ts(nearest) + ' МСК' if nearest else '-'}"
        )
        return text

    acc = visible[0] if visible else {}
    until_ts = int(acc.get("subscription_until_ts") or 0)
    if until_ts:
        text += (
            f"Тариф: {html.escape(_clean_tier_view(acc.get('subscription_tier')))}\n"
            f"Действует до {_fmt_msk_ts(until_ts)} МСК"
        )
    else:
        text += "Тариф: не активный"

    if acc.get("connected") and str(acc.get("port_user_name") or "").strip():
        text += f"\n\nАккаунт: {_account_html_link(acc)}"

    return text


def accounts_list_text(chat_id: int, page: int = 0) -> str:
    accounts = [a for a in _sorted_accounts_for_view(chat_id, include_empty=True) if _is_visible_account_for_profile(a)]
    if not accounts:
        return "🎰 Ваши аккаунты ZOOMA\n\nАктивных аккаунтов нет"
    return "🎰 Ваши аккаунты ZOOMA"


def accounts_list_keyboard(chat_id: int, page: int = 0) -> InlineKeyboardMarkup:
    accounts = [a for a in _sorted_accounts_for_view(chat_id, include_empty=True) if _is_visible_account_for_profile(a)]
    if not accounts:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("Подключить аккаунт", callback_data="connect")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="back")],
        ])
    total = len(accounts)
    page_size = 5
    max_page = max(0, (total - 1) // page_size)
    page = max(0, min(int(page or 0), max_page))
    chunk = accounts[page * page_size:(page + 1) * page_size]

    rows = []
    for acc in chunk:
        aid = str(acc.get("account_id") or "")
        slot = int(acc.get("slot") or 1)
        title = _account_display_name(acc)
        rows.append([InlineKeyboardButton(f"{_account_number_emoji(slot)} {title}", callback_data=f"account:{aid}:p={page}")])

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⏮", callback_data="accounts:p=0"))
        nav.append(InlineKeyboardButton("◀️", callback_data=f"accounts:p={page - 1}"))
    if page < max_page:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"accounts:p={page + 1}"))
        nav.append(InlineKeyboardButton("⏭", callback_data=f"accounts:p={max_page}"))
    if nav:
        rows.append(nav)

    rows.append([InlineKeyboardButton("➕ Доп акк", callback_data="addon_account")])
    rows.append([InlineKeyboardButton("⬅️ Назад", callback_data="back")])
    return InlineKeyboardMarkup(rows)


def account_detail_text(chat_id: int, account_id: str) -> str:
    acc = get_user_account(chat_id, account_id) or {}
    slot = int(acc.get("slot") or 1)
    proxy_ip = str(acc.get("proxy_ip") or "").strip()
    proxy_country = str(acc.get("proxy_country") or "").strip()
    proxy_view = _mask_proxy_ip(proxy_ip)
    flag = _country_flag(proxy_country)
    if flag:
        proxy_view = f"{proxy_view} {flag}"
    until_ts = int(acc.get("subscription_until_ts") or 0)

    return (
        f"{_account_number_emoji(slot)}аккаунт\n"
        f"Ник: {html.escape(str(acc.get('port_user_name') or '-'))}\n"
        f"ID: {html.escape(str(acc.get('port_user_id') or '-'))}\n"
        f"Прокси: {html.escape(proxy_view)}\n"
        f"До: {_fmt_msk_ts(until_ts)} МСК"
    )


def account_detail_keyboard(account_id: str, page: int = 0) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Продлить подписку", callback_data=f"account_renew:{account_id}:p={int(page or 0)}")],
        [InlineKeyboardButton("🔄 Перелогиниться", callback_data=f"relogin:{account_id}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=f"accounts:p={int(page or 0)}")],
    ])


async def _set_active_account_for_auth(chat_id: int, account_id: str) -> None:
    user = get_user(chat_id)
    user.active_account_id = str(account_id or "acc_1")
    try:
        patch_user_account(chat_id, user.active_account_id)
    except Exception:
        pass


async def _show_profile_after_connect_later(app: Application, chat_id: int, account_id: str | None, token_marker: str, connect_ts: float) -> None:
    await asyncio.sleep(7)

    notify_key = _connected_notify_key(chat_id, account_id)
    prev = _LAST_CONNECTED_NOTIFY.get(notify_key)
    if not prev:
        return

    # If another auth/connect happened after this task was scheduled, this task is stale.
    if str(prev[0] or "") != str(token_marker or "") or abs(float(prev[1] or 0.0) - float(connect_ts or 0.0)) > 0.001:
        return

    # Set before sending to avoid multiple delayed profile tasks.
    if _LAST_PROFILE_SHOW_TS.get(chat_id, 0.0) >= connect_ts:
        return
    _LAST_PROFILE_SHOW_TS[chat_id] = asyncio.get_running_loop().time()

    user = get_user(chat_id)
    await _show_profile_message(app, chat_id, user.tg_username or "без username")

async def _delete_message_safe(app: Application, chat_id: int, message_id: int | None) -> None:
    if not message_id:
        return
    try:
        await app.bot.delete_message(chat_id=chat_id, message_id=int(message_id))
    except Exception:
        pass


async def _delete_user_command_message(app: Application, chat_id: int, message_id: int | None) -> None:
    if not message_id:
        return
    mid = int(message_id)
    if _LAST_USER_DELETE_ATTEMPT.get(chat_id) == mid:
        return
    _LAST_USER_DELETE_ATTEMPT[chat_id] = mid
    await _delete_message_safe(app, chat_id, mid)


async def _show_profile_message(
    app: Application,
    chat_id: int,
    tg_user: str,
    *,
    user_message_id_to_delete: int | None = None,
) -> None:
    user = get_user(chat_id)
    await _delete_message_safe(app, chat_id, user.last_ui_message_id)
    if user_message_id_to_delete:
        await _delete_user_command_message(app, chat_id, user_message_id_to_delete)
    msg = await app.bot.send_message(
        chat_id=chat_id,
        text=profile_text(chat_id, tg_user),
        parse_mode="HTML",
        reply_markup=profile_keyboard(chat_id),
    )
    _LAST_PROFILE_SHOW_TS[chat_id] = asyncio.get_running_loop().time()
    update_user_fields(chat_id, last_profile_message_id=msg.message_id, last_ui_message_id=msg.message_id)


async def _show_tariffs_message(
    app: Application,
    chat_id: int,
    *,
    user_message_id_to_delete: int | None = None,
) -> None:
    items = billing.tariffs('main')
    lines = ["Актуальные тарифы", ""]
    for i, t in enumerate(items, start=1):
        lines.append(f'{i}) <i>{t.title}</i> - срок {t.days} дней за {int(t.price_rub)}руб')
        lines.append("")
    lines.append(
        "<b>Все тарифы включают в себя весь функционал бота.\n"
        "Всегда только качественные прокси. Их стоимость уже включена в подписку.</b>"
    )
    tariffs_text = "\n".join(lines)

    user = get_user(chat_id)
    await _delete_message_safe(app, chat_id, user.last_ui_message_id)
    if user_message_id_to_delete:
        await _delete_user_command_message(app, chat_id, user_message_id_to_delete)
    msg = await app.bot.send_message(
        chat_id=chat_id,
        text=tariffs_text,
        parse_mode="HTML",
        reply_markup=billing.tariffs_menu_keyboard(),
    )
    update_user_fields(chat_id, last_ui_message_id=msg.message_id)


def _extension_auth_base_url() -> str:
    parsed = urlparse(PUBLIC_WEB_BASE_URL)
    host = parsed.netloc or parsed.path
    scheme = parsed.scheme or "https"
    if host.lower().startswith("tg."):
        return f"{scheme}://{host}"
    return f"{scheme}://tg.{host}"


async def _try_register_extension_code(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> bool:
    code = str(code or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{7}", code):
        return False
    chat_id = int(update.effective_user.id if update.effective_user else update.effective_chat.id)
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{_extension_auth_base_url()}/auth-api/register-code", params={"code": code, "chat_id": chat_id})
            data = resp.json()
    except Exception as e:
        logging.warning("extension code register failed chat_id=%s code=%s err=%s", chat_id, code, e)
        await update.message.reply_text("❌ Ошибка связи с сервером авторизации расширения.")
        return True
    if data.get("status") == "ok":
        await update.message.reply_text("✅ Расширение привязано. Вернитесь в браузер.")
    else:
        msg = str(data.get("message") or "Код не найден или истек.")
        if msg == "subscription_required":
            msg = "Нужна активная подписка для доступа к расширению."
        elif msg == "already_bound":
            msg = "Этот аккаунт уже привязан к расширению. Сначала выполните отвязку."
        await update.message.reply_text(f"❌ {msg}")
    return True


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    chat_id = update.effective_chat.id
    if context.args and await _try_register_extension_code(update, context, context.args[0]):
        return
    is_new_user = chat_id not in USERS
    if is_new_user:
        if ADMIN_CHAT_ID and int(chat_id) != int(ADMIN_CHAT_ID):
            ref = (f"@{update.effective_user.username}" if update.effective_user and update.effective_user.username else str(chat_id))
            with contextlib.suppress(Exception):
                await context.application.bot.send_message(chat_id=ADMIN_CHAT_ID, text=f"{ref} зашел в бота")
        await update.message.reply_text(
            "Добро пожаловать в логово\n<i>Zooma Client</i>",
            parse_mode="HTML",
        )
        await asyncio.sleep(2)
    user = get_user(chat_id)
    await _set_menu_button_for_chat(context.application, chat_id)
    tg_user = username(update)
    if user.tg_username != tg_user:
        update_user_fields(chat_id, tg_username=tg_user)
    await _refresh_reply_keyboard(context.application, chat_id)
    await _show_profile_message(
        context.application,
        chat_id,
        tg_user,
        user_message_id_to_delete=update.message.message_id if update.message else None,
    )


async def send_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    chat_id = update.effective_chat.id
    user = get_user(chat_id)
    tg_user = username(update)
    if user.tg_username != tg_user:
        update_user_fields(chat_id, tg_username=tg_user)

    await _show_profile_message(
        context.application,
        chat_id,
        tg_user,
        user_message_id_to_delete=update.message.message_id if update.message else None,
    )


async def connect_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)

    chat_id = query.message.chat_id
    data = query.data or ""
    user_state = get_user(chat_id)
    if data.startswith("relogin:"):
        account_id = data.split(":", 1)[1].strip()
        await _set_active_account_for_auth(chat_id, account_id)
        user_state = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user_state.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    if not billing.can_use_account(chat_id, getattr(user_state, "active_account_id", None)):
        await query.edit_message_text(
            "необходимо купить подписку\nкнопка тарифы👇",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("Тарифы", callback_data="tariff_menu")]]
            ),
        )
        return
    # For all non-admin users proxy is mandatory before opening auth webapps.
    active_account_id = getattr(user_state, "active_account_id", None)
    active_proxy_url = get_user_proxy_url(chat_id, active_account_id)
    if chat_id != ADMIN_CHAT_ID and not (active_proxy_url or "").strip():
        await query.edit_message_text(
            "Для прохождения авторизации требуется прокси.\nАдмин оповещен @saxarok322",
            reply_markup=back_keyboard(),
        )
        return
    update_user_fields(chat_id, waiting_token=False)
    await query.edit_message_text(
        "Выберите способ авторизации",
        reply_markup=steam_connect_keyboard(chat_id),
    )
    return


async def back_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)

    chat_id = query.message.chat_id
    user = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    update_user_fields(chat_id, waiting_token=False)

    await _show_profile_message(context.application, chat_id, user.tg_username or "без username")
    try:
        await query.delete_message()
    except Exception:
        pass


async def manual_token_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)

    chat_id = query.message.chat_id
    user = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    update_user_fields(chat_id, waiting_token=True)

    await query.edit_message_text(
        "Впишите zooma_top_session",
        reply_markup=back_keyboard(),
    )


async def tariffs_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    user = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    items = billing.tariffs('main')
    lines = ["Актуальные тарифы", ""]
    for i, t in enumerate(items, start=1):
        lines.append(f'{i}) <i>{t.title}</i> - срок {t.days} дней за {int(t.price_rub)}руб')
        lines.append("")
    lines.append(
        "<b>Все тарифы включают в себя весь функционал бота.\n"
        "Всегда только качественные прокси. Их стоимость уже включена в подписку.</b>"
    )
    tariffs_text = "\n".join(lines)

    await query.edit_message_text(
        tariffs_text,
        parse_mode="HTML",
        reply_markup=billing.tariffs_menu_keyboard(),
    )
    update_user_fields(chat_id, last_ui_message_id=query.message.message_id)


async def tariff_buy_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    user = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    tariff_key = (query.data or "").split(":", 1)[-1]
    tariff = billing.find_tariff(tariff_key, 'main')
    if not tariff:
        await query.edit_message_text("Тариф не найден", reply_markup=billing.tariffs_menu_keyboard())
        return
    await query.edit_message_text(
        f"Вы уверены, что хотите приобрести подписку «<i>{tariff.title}</i>» на {tariff.days} дней?\n\n"
        f"💰 Стоимость подписки: {tariff.price_rub} ₽",
        parse_mode="HTML",
        reply_markup=billing.confirm_keyboard(tariff.key),
    )


async def tariff_confirm_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    user = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    tariff_key = (query.data or "").split(":", 1)[-1]
    tariff = billing.find_tariff(tariff_key, 'main')
    if not tariff:
        await query.edit_message_text("Тариф не найден", reply_markup=billing.tariffs_menu_keyboard())
        return
    try:
        invoice = await billing.create_invoice(chat_id, tariff)
    except Exception as e:
        await query.edit_message_text(f"Не удалось создать счет: {e}")
        return
    await query.delete_message()
    await billing.send_invoice_message(chat_id, invoice)


async def accounts_menu_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    page = 0
    m = re.search(r"p=(\d+)", query.data or "")
    if m:
        page = int(m.group(1))
    user = get_user(chat_id)
    cb_username = username_from_callback(update)
    if user.tg_username != cb_username:
        update_user_fields(chat_id, tg_username=cb_username)
    visible_accounts = [a for a in get_user_accounts(chat_id, include_empty=True) if _is_visible_account_for_profile(a)]
    if not visible_accounts:
        await query.edit_message_text(
            profile_text(chat_id, user.tg_username or "без username"),
            parse_mode="HTML",
            reply_markup=profile_keyboard(chat_id),
        )
        update_user_fields(chat_id, last_ui_message_id=query.message.message_id)
        return
    await query.edit_message_text(
        accounts_list_text(chat_id, page),
        parse_mode="HTML",
        reply_markup=accounts_list_keyboard(chat_id, page),
    )
    update_user_fields(chat_id, last_ui_message_id=query.message.message_id)


async def account_detail_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    data = query.data or ""
    m = re.match(r"^account:([^:]+)(?::p=(\d+))?$", data)
    if not m:
        return
    account_id = m.group(1)
    page = int(m.group(2) or 0)
    await query.edit_message_text(
        account_detail_text(chat_id, account_id),
        parse_mode="HTML",
        reply_markup=account_detail_keyboard(account_id, page),
    )
    update_user_fields(chat_id, last_ui_message_id=query.message.message_id)


async def account_renew_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    data = query.data or ""
    m = re.match(r"^account_renew:([^:]+)(?::p=(\d+))?$", data)
    if not m:
        return
    account_id = m.group(1)
    page = int(m.group(2) or 0)
    acc = get_user_account(chat_id, account_id) or {}
    if not acc:
        await query.edit_message_text("Аккаунт не найден", reply_markup=back_keyboard())
        return

    tariff_type = str(acc.get("billing_type") or "main").strip() or "main"
    items = billing.tariffs(tariff_type)
    if not items:
        await query.edit_message_text(
            f"Тарифы типа {tariff_type} пока не настроены.",
            reply_markup=account_detail_keyboard(account_id, page),
        )
        return

    slot = int(acc.get("slot") or 1)
    name = html.escape(str(acc.get("port_user_name") or f"Аккаунт {slot}"))
    uid = html.escape(str(acc.get("port_user_id") or "-"))

    lines = [
        f"Продление аккаунта #{slot}",
        f"{name} | {uid}",
        "",
        "Выбери тариф:",
    ]

    rows = []
    for t in items:
        rows.append([
            InlineKeyboardButton(
                f"{t.title} - {int(t.price_rub)}руб / {int(t.days)}д",
                callback_data=f"account_renew_confirm:{account_id}:{t.key}:p={page}",
            )
        ])
    rows.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"account:{account_id}:p={page}")])

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(rows),
    )


async def account_renew_confirm_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    data = query.data or ""
    m = re.match(r"^account_renew_confirm:([^:]+):(.+?)(?::p=(\d+))?$", data)
    if not m:
        return
    account_id = m.group(1)
    tariff_key = m.group(2)
    page = int(m.group(3) or 0)

    acc = get_user_account(chat_id, account_id) or {}
    if not acc:
        await query.edit_message_text("Аккаунт не найден", reply_markup=back_keyboard())
        return

    tariff_type = str(acc.get("billing_type") or "main").strip() or "main"
    tariff = billing.find_tariff(tariff_key, tariff_type)
    if not tariff:
        await query.edit_message_text("Тариф не найден", reply_markup=account_detail_keyboard(account_id, page))
        return

    slot = int(acc.get("slot") or 0)
    kind = "account_renew" if int(acc.get("subscription_until_ts") or 0) > int(time.time()) else "account_add"

    try:
        invoice = await billing.create_invoice(
            chat_id,
            tariff,
            kind=kind,
            account_id=account_id,
            account_slot=slot,
            account_label=f"акк #{slot}",
            is_addon=True,
        )
    except Exception as e:
        await query.edit_message_text(f"Не удалось создать счет: {e}", reply_markup=account_detail_keyboard(account_id, page))
        return

    with contextlib.suppress(Exception):
        await query.delete_message()
    await billing.send_invoice_message(chat_id, invoice)


async def addon_account_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    accounts = get_user_accounts(chat_id, include_empty=True)
    if len(accounts) >= 10:
        await query.edit_message_text(
            "Лимит аккаунтов: 10",
            reply_markup=back_keyboard(),
        )
        return
    items = billing.tariffs("addon")
    if not items:
        await query.edit_message_text(
            "Тарифы для доп аккаунтов пока не настроены.\nАдмин должен добавить тарифы с типом addon.",
            reply_markup=back_keyboard(),
        )
        return
    lines = ["Тарифы для доп аккаунта", ""]
    for i, t in enumerate(items, start=1):
        lines.append(f'{i}) <i>{t.title}</i> - срок {t.days} дней за {int(t.price_rub)}руб')
        lines.append("")
    lines.append("<b>После оплаты бот купит отдельный прокси и даст кнопку привязки доп аккаунта.</b>")
    await query.edit_message_text(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=billing.tariffs_menu_keyboard("addon", callback_prefix="addon_tariff_buy"),
    )
    update_user_fields(chat_id, last_ui_message_id=query.message.message_id)


async def addon_tariff_buy_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    tariff_key = (query.data or "").split(":", 1)[-1]
    tariff = billing.find_tariff(tariff_key, "addon")
    if not tariff:
        await query.edit_message_text("Тариф доп аккаунта не найден", reply_markup=back_keyboard())
        return
    await query.edit_message_text(
        f"Вы уверены, что хотите приобрести <b>доп аккаунт</b> «<i>{tariff.title}</i>» на {tariff.days} дней?\n\n"
        f"💰 Стоимость: {tariff.price_rub} ₽",
        parse_mode="HTML",
        reply_markup=billing.confirm_keyboard(
            tariff.key,
            callback_prefix="addon_tariff_confirm",
            back_callback="addon_account",
        ),
    )


async def addon_tariff_confirm_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    tariff_key = (query.data or "").split(":", 1)[-1]
    tariff = billing.find_tariff(tariff_key, "addon")
    if not tariff:
        await query.edit_message_text("Тариф доп аккаунта не найден", reply_markup=back_keyboard())
        return
    try:
        invoice = await billing.create_addon_invoice(chat_id, tariff)
    except Exception as e:
        await query.edit_message_text(f"Не удалось создать счет для доп аккаунта: {e}", reply_markup=back_keyboard())
        return
    await query.delete_message()
    await billing.send_invoice_message(chat_id, invoice)


async def proxy_choice_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    data = query.data or ""
    m = re.match(r"^proxy_choice:(buy|manual):([^:]+):([^:]+):(\d+):([01]):(.+)$", data)
    if not m:
        with contextlib.suppress(Exception):
            await query.answer("Неверный формат выбора", show_alert=False)
        return
    action = m.group(1)
    choice_id = m.group(2)
    account_id = m.group(3)
    period_days = int(m.group(4) or 30)
    renew_hint = (m.group(5) == "1")
    order_id = m.group(6)
    ok, text, reply_markup = await billing.handle_proxy_choice_callback(
        chat_id=chat_id,
        action=action,
        choice_id=choice_id,
        account_id=account_id,
        period_days=period_days,
        renew_hint=renew_hint,
        order_id=order_id,
    )
    with contextlib.suppress(Exception):
        await query.edit_message_text(text=text, reply_markup=reply_markup)
        if action == "manual" and ok and query.message:
            billing.set_manual_proxy_wait_prompt_message_id(chat_id, query.message.message_id)
    if not ok:
        with contextlib.suppress(Exception):
            await query.answer(text[:180], show_alert=False)


async def proxy_choice_clear_manual_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    data = query.data or ""
    m = re.match(r"^proxy_choice_clear_manual:([^:]+):([^:]+):(\d+):([01]):(.+)$", data)
    if not m:
        with contextlib.suppress(Exception):
            await query.answer("Неверный формат очистки", show_alert=False)
        return

    choice_id = m.group(1)
    account_id = m.group(2)
    period_days = int(m.group(3) or 30)
    renew_hint = (m.group(4) == "1")
    order_id = m.group(5)

    ok_clear, clear_text = billing.clear_manual_proxy_for_account(chat_id, account_id)
    if not ok_clear:
        with contextlib.suppress(Exception):
            await query.edit_message_text(text=clear_text)
            await query.answer(clear_text[:180], show_alert=False)
        return

    ok, text, reply_markup = await billing.handle_proxy_choice_callback(
        chat_id=chat_id,
        action="buy",
        choice_id=choice_id,
        account_id=account_id,
        period_days=period_days,
        renew_hint=renew_hint,
        order_id=order_id,
    )
    final_text = text if ok else f"{clear_text}\n\n{text}"
    with contextlib.suppress(Exception):
        await query.edit_message_text(text=final_text, reply_markup=reply_markup)
    if not ok:
        with contextlib.suppress(Exception):
            await query.answer(text[:180], show_alert=False)


async def proxy_choice_manual_cancel_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    data = query.data or ""
    m = re.match(r"^proxy_choice_manual_cancel:([^:]+):([^:]+):(\d+):([01]):(.+)$", data)
    if not m:
        with contextlib.suppress(Exception):
            await query.answer("Неверный формат отмены", show_alert=False)
        return
    billing.cancel_manual_proxy_wait(chat_id)
    with contextlib.suppress(Exception):
        await query.delete_message()
    user = get_user(chat_id)
    await _show_profile_message(context.application, chat_id, user.tg_username or "без username")





def _broadcast_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("Отмена", callback_data="broadcast_cancel")]])


async def broadcast_cancel_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await _answer_callback_safe(query)
    chat_id = query.message.chat_id
    if not _is_admin_runtime_chat(chat_id):
        return
    context.user_data["awaiting_broadcast"] = False
    await query.edit_message_text("Рассылка отменена")


async def _admin_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message or not _is_admin_runtime_chat(update.effective_chat.id):
        return
    if not context.user_data.get("awaiting_broadcast"):
        return
    context.user_data["awaiting_broadcast"] = False
    targets = [cid for cid in get_all_chat_ids() if int(cid) != int(ADMIN_CHAT_ID) and has_active_subscription(int(cid), int(time.time()))]
    ok = 0
    fail = 0
    for cid in targets:
        try:
            await context.application.bot.copy_message(chat_id=int(cid), from_chat_id=update.effective_chat.id, message_id=update.message.message_id)
            ok += 1
            await asyncio.sleep(0.03)
        except Exception:
            fail += 1
    await update.message.reply_text(f"Рассылка завершена: отправлено {ok}, ошибок {fail}")

_PROMO_TEXT_RE = re.compile(r"(?i)\bzm_[a-z0-9]+\b")


def _extract_promos_from_bot_text(text: str) -> list[str]:
    seen: set[str] = set()
    promos: list[str] = []
    for m in _PROMO_TEXT_RE.finditer(str(text or "")):
        promo = m.group(0).upper()
        if promo in seen:
            continue
        seen.add(promo)
        promos.append(promo)
    return promos


def _has_any_promo_subscription(chat_id: int) -> bool:
    now_ts = int(time.time())
    try:
        for acc in get_user_accounts(int(chat_id), include_empty=False):
            aid = str(acc.get("account_id") or "").strip()
            if aid and has_active_account_subscription(int(chat_id), aid, now_ts):
                return True
    except Exception:
        return False
    return False


async def _activate_bot_text_promo_later(bot, chat_id: int, promo: str) -> None:
    try:
        _log_personal_promo_source(chat_id, promo)
        await promo_engine.activate_for_all(promo, requester_chat_id=chat_id)
    except Exception as e:
        logging.exception("bot text promo activation failed | chat_id=%s promo=%s error=%s", chat_id, promo, e)
        with contextlib.suppress(Exception):
            await bot.send_message(chat_id=chat_id, text=f"Промо «{promo}»\nошибка обработки")


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _mark_tg_poll_recovered()
    if not update.message or update.message.text is None:
        return
    text = (update.message.text or "").strip()
    chat_id = update.effective_chat.id
    if _is_admin_runtime_chat(chat_id) and context.user_data.get("awaiting_broadcast"):
        await _admin_broadcast_message(update, context)
        return
    if await _try_register_extension_code(update, context, text):
        return
    user = get_user(chat_id)
    tg_user = username(update)
    if user.tg_username != tg_user:
        update_user_fields(chat_id, tg_username=tg_user)

    # В режиме ожидания ручного прокси любые команды/текст блокируются,
    # пока пользователь не отправит валидный SOCKS5 или не нажмет "Отмена".
    if billing.has_active_manual_proxy_wait(chat_id):
        if billing.is_likely_manual_proxy_input(text):
            prev_prompt_mid = billing.get_manual_proxy_wait_prompt_message_id(chat_id)
            manual_proxy_handled, manual_proxy_text = await billing.consume_manual_proxy_input(chat_id, text)
            if manual_proxy_handled:
                if str(manual_proxy_text or "").startswith("✅"):
                    await _delete_message_safe(context.application, chat_id, prev_prompt_mid)
                await update.message.reply_text(manual_proxy_text)
                return
        await _delete_user_command_message(context.application, chat_id, update.message.message_id if update.message else None)
        prev_mid = billing.get_manual_proxy_wait_prompt_message_id(chat_id)
        await _delete_message_safe(context.application, chat_id, prev_mid)
        await context.application.bot.send_message(chat_id=chat_id, text="Сначала необходимо выбрать прокси.")
        await asyncio.sleep(3)
        aid, acc, _expired = billing.get_manual_proxy_wait_context(chat_id)
        if aid and acc and billing.has_active_manual_proxy_wait(chat_id):
            p_choice_id = str(acc.get("proxy_manual_wait_choice_id") or "manual")
            p_order_id = str(acc.get("proxy_manual_wait_order_id") or "-")
            p_days = int(acc.get("proxy_manual_wait_period_days") or 30)
            p_renew = bool(int(acc.get("proxy_manual_wait_renew_hint") or 0))
            prompt_text, prompt_kb = billing.get_manual_proxy_wait_prompt(
                chat_id=chat_id,
                choice_id=p_choice_id,
                account_id=aid,
                period_days=p_days,
                renew_hint=p_renew,
                order_id=p_order_id,
            )
            prompt_msg = await context.application.bot.send_message(chat_id=chat_id, text=prompt_text, reply_markup=prompt_kb)
            billing.set_manual_proxy_wait_prompt_message_id(chat_id, prompt_msg.message_id)
        return

    if text == "Тарифы":
        await _show_tariffs_message(
            context.application,
            chat_id,
            user_message_id_to_delete=update.message.message_id if update.message else None,
        )
        return

    if text == "Профиль":
        await send_profile(update, context)
        return

    if _is_admin_runtime_chat(chat_id) and text.lower() == "уведа":
        context.user_data["awaiting_broadcast"] = True
        await update.message.reply_text("Введите сообщение", reply_markup=_broadcast_cancel_keyboard())
        return

    promos_from_text = _extract_promos_from_bot_text(text)
    if promos_from_text:
        if not _has_any_promo_subscription(chat_id):
            await update.message.reply_text("Промо могут отправлять только пользователи с активной подпиской.")
            return
        for promo in promos_from_text:
            await update.message.reply_text(f"промо «{promo}»\nпринято в обработку")
            asyncio.create_task(_activate_bot_text_promo_later(context.application.bot, chat_id, promo), name=f"bot-text-promo:{chat_id}:{promo}")
        return

    if user.waiting_token:
        status_message = await update.message.reply_text("Проверяю аккаунт...")
        waiting_account_id = getattr(user, "active_account_id", None)
        if _account_in_extension_mode(chat_id, waiting_account_id):
            await status_message.edit_text(
                "Этот аккаунт работает через расширение. Серверная проверка токена отключена; "
                "подключите аккаунт через расширение или переключите режим на сервер."
            )
            return

        result = await verify_token(
            token=text,
            base_url=get_active_domain(),
            chat_id=chat_id,
            account_id=waiting_account_id,
        )

        if not result.ok:
            await status_message.edit_text(result.error or "Не верный токен")
            return

        save_connected_account(
            chat_id=chat_id,
            tg_username=username(update),
            port_user_id=result.port_user_id or "",
            port_user_name=result.port_user_name or "",
            centrifugo_socket=result.centrifugo_socket or "",
            centrifugo_secret=result.centrifugo_secret or "",
            zooma_top_session=result.zooma_top_session or text,
            zooma_top_session_expires_at=result.zooma_top_session_expires_at,
            csrf_token=result.csrf_token,
            fingerprint_now=result.fingerprint_now,
            user_agent=result.user_agent,
        )
        await _notify_admin_auth_success(
            context.application,
            chat_id=chat_id,
            tg_username=username(update),
            method="manual_token",
            status="успешно",
        )

        active_domain = get_active_domain()
        connected_account_id = getattr(get_user(chat_id), "active_account_id", None)
        ws_ok = False
        if active_domain:
            if _account_proxy_allowed_for_runtime(chat_id, connected_account_id):
                ws_ok = await ws_manager.reconnect_for_user(chat_id, active_domain, account_id=connected_account_id, attempts=3, attempt_timeout=5.0)
            else:
                logging.info("WS start skipped no_proxy | user=%s account_id=%s", _user_log_ref(chat_id), connected_account_id or "-")
        if ws_ok:
            await status_message.edit_text(_connected_account_text(chat_id, connected_account_id, result.port_user_name, result.port_user_id))
            _clear_stale_alert_lock(chat_id, str(connected_account_id or "acc_1"))
            connect_ts = asyncio.get_running_loop().time()
            notify_marker = _connected_notify_marker(result, text)
            should_profile, _notify_key = _reserve_connected_notify(chat_id, connected_account_id, notify_marker, connect_ts)
            if should_profile:
                asyncio.create_task(_show_profile_after_connect_later(context.application, chat_id, connected_account_id, notify_marker, connect_ts))
        else:
            await status_message.edit_text("Токен валиден, но WebSocket не подключился.")
        return

    await update.message.reply_text(
        "Используйте кнопки ниже.",
        reply_markup=reply_keyboard(chat_id),
    )


async def post_init(app: Application):
    cleanup_orphan_auth_runtime()
    await _set_menu_button_default(app)
    load_state()
    promo_engine.set_telegram_bot(app.bot)

    async def _tg_watcher_enqueue(payload: dict):
        return await promo_engine.enqueue_promo(
            str((payload or {}).get("promo") or ""),
            channel_key=str((payload or {}).get("channel_key") or ""),
            msg_id=(payload or {}).get("msg_id"),
        )

    if TG_WATCHER_IN_MAIN_ENABLED:
        try:
            from tg_watcher import run_tg_watcher, set_in_memory_promo_handler
            set_in_memory_promo_handler(_tg_watcher_enqueue)
            global tg_watcher_task
            tg_watcher_task = asyncio.create_task(run_tg_watcher([""], parent_pid=0), name="tg-watcher")
            logging.info("TG watcher запущен внутри main.py")
        except Exception as e:
            logging.exception("TG watcher in-main start failed: %s", e)
    async def _on_zooma_session(chat_id: int, zooma_top_session: str, local_storage_dump: dict):
        base_url = get_active_domain()
        if not base_url:
            return False, "Актуальный домен не получен"
        result = await verify_token(
            token=zooma_top_session,
            base_url=base_url,
            chat_id=chat_id,
            account_id=getattr(get_user(chat_id), "active_account_id", None),
        )
        if not result.ok:
            return False, result.error or "Не верный токен"
        user = get_user(chat_id)
        save_connected_account(
            chat_id=chat_id,
            tg_username=user.tg_username,
            port_user_id=result.port_user_id or "",
            port_user_name=result.port_user_name or "",
            centrifugo_socket=result.centrifugo_socket or "",
            centrifugo_secret=result.centrifugo_secret or "",
            zooma_top_session=result.zooma_top_session or zooma_top_session,
            zooma_top_session_expires_at=result.zooma_top_session_expires_at,
            csrf_token=result.csrf_token,
            fingerprint_now=result.fingerprint_now,
            user_agent=result.user_agent or user.user_agent,
        )
        auth_method = str((local_storage_dump or {}).get("auth_method") or "webapp").strip()
        await _notify_admin_auth_success(
            app,
            chat_id=chat_id,
            tg_username=user.tg_username,
            method=auth_method,
            status="успешно",
        )
        connected_account_id = getattr(get_user(chat_id), "active_account_id", None)
        ws_ok = False
        if _account_proxy_allowed_for_runtime(chat_id, connected_account_id):
            ws_ok = await ws_manager.reconnect_for_user(chat_id, base_url, account_id=connected_account_id, attempts=3, attempt_timeout=5.0)
        else:
            logging.info("WS start skipped no_proxy | user=%s account_id=%s", _user_log_ref(chat_id), connected_account_id or "-")
        if ws_ok:
            _clear_stale_alert_lock(chat_id)
        if app.bot and ws_ok:
            now = asyncio.get_running_loop().time()
            marker = _connected_notify_marker(result, zooma_top_session)
            should_notify, notify_key = _reserve_connected_notify(chat_id, connected_account_id, marker, now)
            # Suppress repeated "account connected" notifications caused by parallel status polling/auth callbacks.
            if should_notify:
                await app.bot.send_message(
                    chat_id=chat_id,
                    text=_connected_account_text(chat_id, connected_account_id, result.port_user_name, result.port_user_id),
                )
                asyncio.create_task(_show_profile_after_connect_later(app, chat_id, connected_account_id, marker, now))
            else:
                logging.info("connected notify suppressed duplicate | user=%s account_id=%s key=%s", _user_log_ref(chat_id), connected_account_id or "-", notify_key)
        return True, "ok"

    set_zooma_session_handler(_on_zooma_session)
    set_tg_session_handler(_on_zooma_session)
    set_yandex_session_handler(_on_zooma_session)
    now_ts = int(asyncio.get_running_loop().time() + 0)  # monotonic fallback overwritten below
    try:
        import time as _time
        now_ts = int(_time.time())
    except Exception:
        pass

    forced_domain = (FORCE_ACTIVE_DOMAIN or "").strip()
    if forced_domain:
        set_active_domain(forced_domain)
        domain = forced_domain
        logging.info("Актуальный домен (FORCE_ACTIVE_DOMAIN): %s", forced_domain)
    else:
        domain = await _resolve_active_domain_fast()

    if domain:
        set_active_domain(domain)
        logging.info("Актуальный домен: %s", domain)
    else:
        logging.warning("Актуальный домен не получен на старте через zref.pro. Бот всё равно запущен.")

    active_domain = get_active_domain()
    restored = 0
    connected = 0
    if active_domain:
        startup_sem = asyncio.Semaphore(max(1, int(STARTUP_RESTORE_CONCURRENCY)))

        async def _restore_startup_user(chat_id: int) -> tuple[int, int]:
            async with startup_sem:
                restored_count = 0
                connected_count = 0
                try:
                    user = get_user(chat_id)
                    accounts = get_user_accounts(chat_id, include_empty=True)
                    for acc in accounts:
                        account_id = str(acc.get("account_id") or "")
                        if not account_id:
                            continue
                        if bool(acc.get("subscription_paused")):
                            patch_user_account(chat_id, account_id, connected=False)
                            logging.info("Startup restore skip user=%s account_id=%s reason=frozen", _user_log_ref(chat_id), account_id)
                            continue

                        until_ts = int(acc.get("subscription_until_ts") or 0)
                        if until_ts <= now_ts:
                            if _account_has_casino_runtime_data(acc):
                                with contextlib.suppress(Exception):
                                    await ws_manager.stop_for_user(chat_id, account_id=account_id)
                                clear_account_casino_data(chat_id, account_id)
                                logging.info("Startup restore cleared expired/stale account | user=%s account_id=%s", _user_log_ref(chat_id), account_id)
                            continue

                        restore_mode = str(
                            acc.get("promo_activation_mode")
                            or getattr(user, "promo_activation_mode", "server")
                            or "server"
                        ).strip().lower()

                        if restore_mode == "extension":
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_ping_ms=None,
                                proxy_ping_last_ts=0,
                                proxy_ping_error="",
                            )
                            with contextlib.suppress(Exception):
                                await ws_manager.stop_for_user(
                                    chat_id,
                                    account_id=account_id,
                                )
                            logging.info(
                                "Startup restore extension runtime user=%s account_id=%s",
                                _user_log_ref(chat_id),
                                account_id,
                            )
                            continue

                        startup_gate_pending = (
                            str(acc.get("proxy_runtime_status") or "").strip().lower()
                            == "recovering"
                            and str(acc.get("proxy_runtime_source") or "").strip()
                            == "startup_gate"
                        )
                        if (
                            not _account_proxy_allowed_for_runtime(
                                chat_id,
                                account_id,
                                acc,
                            )
                            and not startup_gate_pending
                        ):
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                            )
                            logging.info(
                                "Startup restore skip user=%s account_id=%s reason=no_proxy_or_runtime_block",
                                _user_log_ref(chat_id),
                                account_id,
                            )
                            continue

                        token = str(acc.get("zooma_top_session") or "").strip()
                        if not token:
                            logging.warning("Startup restore skip chat_id=%s account_id=%s reason=no_zooma_top_session", chat_id, account_id)
                            continue

                        if STARTUP_RESTORE_ACCOUNT_GAP_SEC > 0:
                            await asyncio.sleep(float(STARTUP_RESTORE_ACCOUNT_GAP_SEC))
                        if _account_in_extension_mode(chat_id, account_id):
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_ping_ms=None,
                                proxy_ping_last_ts=0,
                                proxy_ping_error="",
                            )
                            with contextlib.suppress(Exception):
                                await ws_manager.stop_for_user(chat_id, account_id=account_id)
                            logging.info("Startup restore verify skipped extension mode user=%s account_id=%s", _user_log_ref(chat_id), account_id)
                            continue
                        try:
                            result = await asyncio.wait_for(
                                verify_token(
                                    token=token,
                                    base_url=active_domain,
                                    chat_id=chat_id,
                                    account_id=account_id,
                                ),
                                timeout=30.0,
                            )
                        except asyncio.TimeoutError:
                            proxy_timeout_ts = int(time.time())
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_runtime_status="unavailable",
                                proxy_runtime_reason="startup_verify_timeout",
                                proxy_runtime_source="startup_verify",
                                proxy_runtime_domain=active_domain,
                                proxy_unavailable_since_ts=(
                                    int(
                                        acc.get(
                                            "proxy_unavailable_since_ts"
                                        )
                                        or 0
                                    )
                                    or proxy_timeout_ts
                                ),
                                proxy_recovery_successes=0,
                                proxy_ping_last_ts=proxy_timeout_ts,
                                proxy_ping_ms=None,
                                proxy_ping_error="startup_verify_timeout",
                            )
                            logging.warning(
                                "Startup restore verify timeout user=%s chat_id=%s account_id=%s domain=%s timeout=30s runtime=unavailable",
                                _user_log_ref(chat_id),
                                chat_id,
                                account_id,
                                active_domain,
                            )
                            restored_count += 1
                            continue
                        if not result.ok:
                            patch_user_account(chat_id, account_id, connected=False)
                            reason_text = str(result.error or "unknown")
                            logging.warning(
                                "Startup restore verify failed chat_id=%s account_id=%s reason=%s domain=%s",
                                chat_id, account_id, reason_text, active_domain,
                            )
                            if _looks_like_proxy_connect_failure(reason_text):
                                with contextlib.suppress(Exception):
                                    await billing.auto_freeze_proxy_unavailable(
                                        chat_id,
                                        account_id,
                                        reason_text,
                                        source="startup_verify",
                                    )
                            restored_count += 1
                            continue

                        patch_user_account(
                            chat_id,
                            account_id,
                            connected=False,
                            port_user_id=result.port_user_id or "",
                            port_user_name=result.port_user_name or "",
                            centrifugo_socket=result.centrifugo_socket or "",
                            centrifugo_secret=result.centrifugo_secret or "",
                            zooma_top_session=result.zooma_top_session or token,
                            zooma_top_session_expires_at=result.zooma_top_session_expires_at,
                            csrf_token=result.csrf_token,
                            fingerprint_now=result.fingerprint_now,
                            user_agent=result.user_agent or acc.get("user_agent"),
                        )

                        restored_count += 1
                        try:
                            ws_ok = await asyncio.wait_for(
                                ws_manager.reconnect_for_user(
                                    chat_id,
                                    active_domain,
                                    account_id=account_id,
                                    attempts=3,
                                    attempt_timeout=5.0,
                                ),
                                timeout=30.0,
                            )
                        except asyncio.TimeoutError:
                            ws_ok = False
                            logging.warning(
                                "Startup restore WS reconnect timeout user=%s chat_id=%s account_id=%s timeout=30s",
                                _user_log_ref(chat_id),
                                chat_id,
                                account_id,
                            )
                        if ws_ok:
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=True,
                                proxy_runtime_status="healthy",
                                proxy_runtime_reason="",
                                proxy_runtime_source="startup_restore",
                                proxy_runtime_domain=active_domain,
                                proxy_unavailable_since_ts=0,
                                proxy_recovery_successes=0,
                                proxy_ping_error="",
                            )
                            connected_count += 1
                            continue

                        patch_user_account(chat_id, account_id, connected=False)
                        logging.warning("Startup restore WS reconnect failed chat_id=%s account_id=%s domain=%s", chat_id, account_id, active_domain)
                        try:
                            label = user.tg_username or f"chat_id={chat_id}"
                            slot = int(acc.get("slot") or 0)
                            if ADMIN_CHAT_ID:
                                await app.bot.send_message(
                                    chat_id=ADMIN_CHAT_ID,
                                    text=f"⚠️ Startup WS не подключился за 3 попытки\nЮзер: {label}\nchat_id: {chat_id}\nаккаунт: #{slot}",
                                )
                        except Exception as e:
                            logging.warning("Startup WS admin notify failed chat_id=%s account_id=%s err=%s", chat_id, account_id, e)
                    return restored_count, connected_count

                except Exception as e:
                    logging.warning("Startup restore user error chat_id=%s err=%s: %s", chat_id, e.__class__.__name__, e)
                    return restored_count, connected_count

    async def _restore_startup_all() -> None:
        if not active_domain:
            logging.info(
                "Startup restore complete | users=0 | ws=0 | concurrency=%s",
                max(1, int(STARTUP_RESTORE_CONCURRENCY)),
            )
            return

        results = await asyncio.gather(
            *(_restore_startup_user(cid) for cid in get_all_chat_ids())
        )
        restored = sum(item[0] for item in results)
        connected = sum(item[1] for item in results)

        logging.info(
            "Startup restore complete | users=%s | ws=%s | concurrency=%s",
            restored,
            connected,
            max(1, int(STARTUP_RESTORE_CONCURRENCY)),
        )

    async def _refresh_all_users_for_domain() -> tuple[int, int]:
        active_domain = get_active_domain()
        if not active_domain:
            return 0, 0

        import time as _time
        now_ts = int(_time.time())
        refresh_sem = asyncio.Semaphore(max(1, int(DOMAIN_REFRESH_CONCURRENCY)))

        async def _guard_mass_invalid_session_refresh() -> bool:
            """Return True when refresh should continue.

            If 70%+ eligible accounts suddenly report `Не верный zooma_top_session`,
            treat it like a broken domain/verify wave and do up to 3 soft restart
            attempts instead of marking accounts offline.
            """
            targets: list[tuple[int, str, str]] = []
            for cid in get_all_chat_ids():
                for acc in get_user_accounts(cid, include_empty=True):
                    account_id = str(acc.get("account_id") or "").strip()
                    if not account_id:
                        continue
                    if bool(acc.get("subscription_paused")):
                        continue
                    if int(acc.get("subscription_until_ts") or 0) <= now_ts:
                        continue

                    mode = str(
                        acc.get("promo_activation_mode") or "server"
                    ).strip().lower()
                    if mode == "extension":
                        continue

                    if not _account_proxy_allowed_for_runtime(cid, account_id, acc):
                        continue
                    token = str(acc.get("zooma_top_session") or "").strip()
                    if not token:
                        continue
                    targets.append((int(cid), account_id, token))

            if len(targets) < 2:
                return True

            async def _verify_wave(domain: str) -> tuple[int, int]:
                sem = asyncio.Semaphore(max(1, int(DOMAIN_REFRESH_CONCURRENCY)))

                async def _one(cid: int, aid: str, token: str) -> str:
                    async with sem:
                        try:
                            if DOMAIN_REFRESH_ACCOUNT_GAP_SEC > 0:
                                await asyncio.sleep(float(DOMAIN_REFRESH_ACCOUNT_GAP_SEC))
                            if _account_in_extension_mode(cid, aid):
                                return "extension_mode"
                            result = await verify_token(token=token, base_url=domain, chat_id=cid, account_id=aid)
                            if result.ok:
                                return "ok"
                            return str(result.error or "unknown")
                        except Exception as e:
                            return f"exception:{e.__class__.__name__}:{e}"

                statuses = await asyncio.gather(*(_one(cid, aid, token) for cid, aid, token in targets))
                invalid = sum(1 for st in statuses if "Не верный zooma_top_session" in st)
                return invalid, len(statuses)

            domain = active_domain
            for attempt in range(1, 4):
                invalid, total = await _verify_wave(domain)
                ratio = invalid / max(1, total)
                if ratio < 0.70:
                    if attempt > 1:
                        logging.info(
                            "Domain refresh mass invalid recovered | attempt=%s domain=%s invalid=%s/%s",
                            attempt, domain, invalid, total,
                        )
                    return True

                logging.warning(
                    "Domain refresh mass invalid session wave | attempt=%s/3 domain=%s invalid=%s/%s ratio=%.2f",
                    attempt, domain, invalid, total, ratio,
                )
                if attempt < 3:
                    new_domain = await _resolve_active_domain_fast()
                    if new_domain:
                        domain = new_domain
                        if get_active_domain() != new_domain:
                            set_active_domain(new_domain)
                    await asyncio.sleep(random.randint(3, 8))

            logging.error(
                "Domain refresh skipped after 3 mass invalid session waves | domain=%s accounts=%s threshold=70%%",
                domain, len(targets),
            )
            return False

        if not await _guard_mass_invalid_session_refresh():
            return 0, 0
        active_domain = get_active_domain() or active_domain

        async def _refresh_domain_user(chat_id: int) -> tuple[int, int]:
            async with refresh_sem:
                refreshed_count = 0
                ws_count = 0
                try:
                    user = get_user(chat_id)
                    accounts = get_user_accounts(chat_id, include_empty=True)
                    for acc in accounts:
                        account_id = str(acc.get("account_id") or "")
                        if not account_id:
                            continue
                        if bool(acc.get("subscription_paused")):
                            patch_user_account(chat_id, account_id, connected=False)
                            logging.info("Domain refresh skip user=%s account_id=%s reason=frozen", _user_log_ref(chat_id), account_id)
                            continue

                        until_ts = int(acc.get("subscription_until_ts") or 0)
                        if until_ts <= now_ts:
                            if _account_has_casino_runtime_data(acc):
                                with contextlib.suppress(Exception):
                                    await ws_manager.stop_for_user(chat_id, account_id=account_id)
                                clear_account_casino_data(chat_id, account_id)
                                logging.info("Domain refresh cleared expired/stale account | user=%s account_id=%s", _user_log_ref(chat_id), account_id)
                            continue

                        refresh_mode = str(
                            acc.get("promo_activation_mode") or "server"
                        ).strip().lower()

                        if refresh_mode == "extension":
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_ping_ms=None,
                                proxy_ping_last_ts=0,
                                proxy_ping_error="",
                            )
                            with contextlib.suppress(Exception):
                                await ws_manager.stop_for_user(
                                    chat_id,
                                    account_id=account_id,
                                )
                            logging.info(
                                "Domain refresh extension runtime user=%s account_id=%s",
                                _user_log_ref(chat_id),
                                account_id,
                            )
                            continue

                        if not _account_proxy_allowed_for_runtime(chat_id, account_id, acc):
                            patch_user_account(chat_id, account_id, connected=False)
                            logging.info("Domain refresh skip user=%s account_id=%s reason=no_proxy", _user_log_ref(chat_id), account_id)
                            continue

                        token = str(acc.get("zooma_top_session") or "").strip()
                        if not token:
                            logging.warning("Domain refresh skip chat_id=%s account_id=%s reason=no_zooma_top_session", chat_id, account_id)
                            continue

                        if DOMAIN_REFRESH_ACCOUNT_GAP_SEC > 0:
                            await asyncio.sleep(float(DOMAIN_REFRESH_ACCOUNT_GAP_SEC))
                        if _account_in_extension_mode(chat_id, account_id):
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_ping_ms=None,
                                proxy_ping_last_ts=0,
                                proxy_ping_error="",
                            )
                            with contextlib.suppress(Exception):
                                await ws_manager.stop_for_user(chat_id, account_id=account_id)
                            logging.info("Domain refresh verify skipped extension mode user=%s account_id=%s", _user_log_ref(chat_id), account_id)
                            continue
                        result = await verify_token(token=token, base_url=active_domain, chat_id=chat_id, account_id=account_id)
                        if not result.ok:
                            patch_user_account(chat_id, account_id, connected=False)
                            reason_text = str(result.error or "unknown")
                            logging.warning(
                                "Domain refresh verify failed chat_id=%s account_id=%s reason=%s domain=%s",
                                chat_id, account_id, reason_text, active_domain,
                            )
                            if _looks_like_proxy_connect_failure(reason_text):
                                with contextlib.suppress(Exception):
                                    await billing.auto_freeze_proxy_unavailable(
                                        chat_id,
                                        account_id,
                                        reason_text,
                                        source="domain_refresh_verify",
                                    )
                            refreshed_count += 1
                            continue

                        patch_user_account(
                            chat_id,
                            account_id,
                            connected=False,
                            port_user_id=result.port_user_id or "",
                            port_user_name=result.port_user_name or "",
                            centrifugo_socket=result.centrifugo_socket or "",
                            centrifugo_secret=result.centrifugo_secret or "",
                            zooma_top_session=result.zooma_top_session or token,
                            zooma_top_session_expires_at=result.zooma_top_session_expires_at,
                            csrf_token=result.csrf_token,
                            fingerprint_now=result.fingerprint_now,
                            user_agent=result.user_agent or acc.get("user_agent"),
                        )
                        await ws_manager.start_for_user(chat_id, active_domain, account_id=account_id)
                        if ws_manager.is_connected(chat_id, account_id=account_id):
                            patch_user_account(chat_id, account_id, connected=True)
                        else:
                            patch_user_account(chat_id, account_id, connected=False)
                        refreshed_count += 1
                        if ws_manager.is_connected(chat_id, account_id=account_id):
                            ws_count += 1

                    return refreshed_count, ws_count

                except Exception as e:
                    logging.warning("Domain refresh user error chat_id=%s err=%s: %s", chat_id, e.__class__.__name__, e)
                    return refreshed_count, ws_count

        results = await asyncio.gather(*(_refresh_domain_user(cid) for cid in get_all_chat_ids()))
        refreshed = sum(x[0] for x in results)
        ws_started = sum(x[1] for x in results)
        return refreshed, ws_started

    async def _domain_watchdog_loop() -> None:
        forced_domain = (FORCE_ACTIVE_DOMAIN or "").strip()
        if forced_domain:
            logging.info("Domain watchdog: zref.pro bypass enabled (FORCE_ACTIVE_DOMAIN=%s)", forced_domain)
            while True:
                try:
                    await asyncio.sleep(DOMAIN_CHECK_INTERVAL_SEC)
                    if get_active_domain() != forced_domain:
                        set_active_domain(forced_domain)
                except asyncio.CancelledError:
                    return
                except Exception:
                    await asyncio.sleep(DOMAIN_RETRY_DELAY_SEC)
            return

        domain_was_unhealthy = False
        retry_sleep = max(1.0, min(2.0, float(DOMAIN_RETRY_DELAY_SEC or 2)))
        while True:
            try:
                await asyncio.sleep(DOMAIN_CHECK_INTERVAL_SEC)
                active_domain = get_active_domain()
                alive_now = bool(active_domain) and await is_domain_alive(active_domain)
                if not active_domain or not alive_now:
                    domain_was_unhealthy = True
                    logging.warning("Domain watchdog: current domain dead, resolving via zref.pro | domain=%s", active_domain or "-")
                    while True:
                        new_domain = await _resolve_active_domain_fast()
                        if new_domain:
                            set_active_domain(new_domain)
                            refreshed, ws_started = await _refresh_all_users_for_domain()
                            logging.info("Domain watchdog recovered | domain=%s refreshed=%s ws=%s", new_domain, refreshed, ws_started)
                            domain_was_unhealthy = False
                            break
                        await asyncio.sleep(retry_sleep)
                    continue

                # Even while current domain looks alive, keep zref.pro as source of truth:
                # stale domains can redirect and mask a rotation.
                new_domain = await _resolve_active_domain_fast()
                if not new_domain:
                    logging.warning("zref.pro unavailable, keeping current live domain: %s", active_domain)
                    await asyncio.sleep(retry_sleep)
                    continue

                should_refresh_users = False
                if new_domain != active_domain:
                    logging.info("Смена домена: %s -> %s", active_domain, new_domain)
                    notify_text = f"Смена домена: {active_domain} -> {new_domain}"
                    for _chat in (ADMIN_CHAT_ID, RAIN_TARGET_CHAT):
                        if _chat:
                            with contextlib.suppress(Exception):
                                await app.bot.send_message(chat_id=_chat, text=notify_text)
                    await _notify_extension_domain_change(app, active_domain, new_domain)
                    set_active_domain(new_domain)
                    should_refresh_users = True
                    domain_was_unhealthy = False
                elif not alive_now:
                    # Старый домен мог быть недоступен; проверим, что текущий реально ожил.
                    if await is_domain_alive(new_domain):
                        logging.info("Домен восстановлен: %s", new_domain)
                        should_refresh_users = True
                        domain_was_unhealthy = False
                    else:
                        domain_was_unhealthy = True
                        logging.warning("Домен все еще недоступен: %s", new_domain)
                elif domain_was_unhealthy:
                    logging.info("Домен снова стабилен: %s", new_domain)
                    should_refresh_users = True
                    domain_was_unhealthy = False

                if should_refresh_users:
                    refreshed, ws_started = await _refresh_all_users_for_domain()
                    logging.info("Обновление юзеров после домена: refreshed=%s ws=%s", refreshed, ws_started)
            except asyncio.CancelledError:
                return
            except Exception as e:
                logging.warning("Ошибка domain watchdog: %s", e)
                domain_was_unhealthy = True
                await asyncio.sleep(retry_sleep)

    async def _session_probe_loop() -> None:
        while True:
            try:
                now_ts = int(time.time())
                eligible_accounts: list[tuple[int, str]] = []
                for chat_id in get_all_chat_ids():
                    for acc in get_user_accounts(int(chat_id), include_empty=False):
                        account_id = str(acc.get("account_id") or "").strip()
                        if not account_id:
                            continue
                        if not has_active_account_subscription(int(chat_id), account_id, now_ts):
                            continue
                        if bool(acc.get("subscription_paused")):
                            continue
                        if str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension":
                            continue
                        if account_server_session_is_stale(acc):
                            continue
                        if not bool(acc.get("connected")):
                            continue
                        if not _account_proxy_allowed_for_runtime(int(chat_id), account_id, acc):
                            continue
                        eligible_accounts.append((int(chat_id), account_id))

                random.shuffle(eligible_accounts)
                if not eligible_accounts:
                    await asyncio.sleep(max(10, int(SESSION_PROBE_SCAN_IDLE_SEC)))
                    continue

                logging.debug("Session probe cycle eligible=%s", len(eligible_accounts))
                for chat_id, account_id in eligible_accounts:
                    try:
                        detail = await promo_engine.probe_user_session_detail(chat_id, account_id=account_id)
                        status = str(detail.get("status") or "")
                        if status == "ok" and bool(detail.get("valid")):
                            _clear_stale_alert_lock(chat_id, account_id)
                        elif status == "session_stale":
                            acc = mark_account_server_session_stale(
                                chat_id,
                                account_id,
                                reason="periodic_session_probe",
                                http_status=int(detail.get("http_status") or 0),
                                response=str(detail.get("body") or ""),
                            )
                            await ws_manager.stop_for_user(chat_id, account_id=account_id)
                            state = dict(acc.get("server_session_state") or {})
                            key = _session_stale_key(chat_id, account_id)
                            if not int(state.get("notified_at_ts") or 0) and key not in _SESSION_STALE_ALERT_LOCK:
                                _SESSION_STALE_ALERT_LOCK.add(key)
                                user_text, admin_text = _session_stale_message(chat_id, account_id)
                                await app.bot.send_message(chat_id=chat_id, text=user_text)
                                if ADMIN_CHAT_ID:
                                    with contextlib.suppress(Exception):
                                        await app.bot.send_message(chat_id=ADMIN_CHAT_ID, text=admin_text)
                                mark_account_server_session_notified(chat_id, account_id)
                            logging.warning(
                                "Session stale chat_id=%s account_id=%s http=%s body=%s",
                                chat_id,
                                account_id,
                                detail.get("http_status") or 0,
                                str(detail.get("body") or "")[:600],
                            )
                        elif status in {"http_419_unknown", "request_error", "site_transient_error", "empty_response", "http_error"}:
                            logging.warning(
                                "Session probe inconclusive chat_id=%s account_id=%s status=%s http=%s body=%s",
                                chat_id,
                                account_id,
                                status,
                                detail.get("http_status") or 0,
                                str(detail.get("body") or "")[:600],
                            )
                    except Exception as e:
                        domain = get_active_domain() or "-"
                        has_proxy = 1 if (get_user_proxy_url(chat_id, account_id=account_id) or "").strip() else 0
                        logging.warning(
                            "Session probe user error chat_id=%s account_id=%s domain=%s proxy=%s err=%s: %s",
                            chat_id,
                            account_id,
                            domain,
                            has_proxy,
                            e.__class__.__name__,
                            e,
                        )
                    finally:
                        await asyncio.sleep(random.randint(SESSION_PROBE_SLEEP_MIN_SEC, SESSION_PROBE_SLEEP_MAX_SEC))
            except asyncio.CancelledError:
                return
            except Exception as e:
                logging.exception("Ошибка session probe loop: %s", e)
                await asyncio.sleep(30)

    async def _ws_refresh_loop() -> None:
        next_run: dict[str, float] = {}

        def _schedule_after() -> float:
            # 60-90 minutes
            return asyncio.get_running_loop().time() + random.randint(WS_REFRESH_MIN_SEC, WS_REFRESH_MAX_SEC)

        def _ws_refresh_key(chat_id: int, account_id: str) -> str:
            return f"{int(chat_id)}:{str(account_id or 'acc_1')}"

        while True:
            try:
                now = asyncio.get_running_loop().time()
                now_ts = int(time.time())
                base_url = get_active_domain()
                chat_ids = get_all_chat_ids()
                live_keys: set[str] = set()

                for chat_id in chat_ids:
                    accounts = get_user_accounts(chat_id, include_empty=True)
                    for acc in accounts:
                        account_id = str(acc.get("account_id") or "").strip()
                        if not account_id:
                            continue
                        key = _ws_refresh_key(chat_id, account_id)
                        live_keys.add(key)
                        if key not in next_run:
                            next_run[key] = _schedule_after()

                for stale_key in list(next_run.keys()):
                    if stale_key not in live_keys:
                        next_run.pop(stale_key, None)

                for chat_id in chat_ids:
                    if promo_engine.is_user_promo_active(chat_id):
                        # Не мешаем активной промо-сессии; мягко переносим refresh всех аккаунтов юзера.
                        for key in live_keys:
                            if key.startswith(f"{int(chat_id)}:"):
                                next_run[key] = asyncio.get_running_loop().time() + 60
                        continue

                    user = get_user(chat_id)
                    accounts = get_user_accounts(chat_id, include_empty=True)
                    active_runtime_accounts = 0

                    for acc in accounts:
                        account_id = str(acc.get("account_id") or "").strip()
                        if not account_id:
                            continue
                        has_active_account = has_active_account_subscription(chat_id, account_id, now_ts)
                        if has_active_account:
                            active_runtime_accounts += 1

                        key = _ws_refresh_key(chat_id, account_id)
                        due = next_run.get(key, 0)
                        if now < due:
                            continue

                        if not has_active_account:
                            patch_user_account(chat_id, account_id, connected=False)
                            await ws_manager.stop_for_user(chat_id, account_id=account_id)
                            next_run[key] = _schedule_after()
                            continue

                        refresh_mode = str(
                            acc.get("promo_activation_mode") or "server"
                        ).strip().lower()

                        if refresh_mode == "extension":
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_ping_ms=None,
                                proxy_ping_last_ts=0,
                                proxy_ping_error="",
                            )
                            with contextlib.suppress(Exception):
                                await ws_manager.stop_for_user(
                                    chat_id,
                                    account_id=account_id,
                                )
                            next_run[key] = _schedule_after()
                            continue

                        token = str(acc.get("zooma_top_session") or "").strip()
                        if not token or not base_url:
                            next_run[key] = _schedule_after()
                            continue

                        if not _account_proxy_allowed_for_runtime(chat_id, account_id, acc):
                            patch_user_account(chat_id, account_id, connected=False)
                            await ws_manager.stop_for_user(chat_id, account_id=account_id)
                            logging.info("WS refresh skipped no_proxy user=%s account_id=%s", _user_log_ref(chat_id), account_id)
                            next_run[key] = _schedule_after()
                            continue

                        if _account_in_extension_mode(chat_id, account_id):
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                proxy_ping_ms=None,
                                proxy_ping_last_ts=0,
                                proxy_ping_error="",
                            )
                            await ws_manager.stop_for_user(chat_id, account_id=account_id)
                            next_run[key] = _schedule_after()
                            continue
                        result = await verify_token(token=token, base_url=base_url, chat_id=chat_id, account_id=account_id)
                        if result.ok:
                            patch_user_account(
                                chat_id,
                                account_id,
                                connected=False,
                                server_session_state={},
                                port_user_id=result.port_user_id or "",
                                port_user_name=result.port_user_name or "",
                                centrifugo_socket=result.centrifugo_socket or "",
                                centrifugo_secret=result.centrifugo_secret or "",
                                zooma_top_session=result.zooma_top_session or token,
                                zooma_top_session_expires_at=result.zooma_top_session_expires_at,
                                csrf_token=result.csrf_token,
                                fingerprint_now=result.fingerprint_now,
                                user_agent=result.user_agent or acc.get("user_agent") or user.user_agent,
                            )
                            # Переподключаем WS на свежих данных конкретного аккаунта.
                            await ws_manager.start_for_user(chat_id, base_url, account_id=account_id)
                            logging.debug("WS refresh ok chat_id=%s account_id=%s", chat_id, account_id)
                        else:
                            patch_user_account(chat_id, account_id, connected=False)
                            logging.warning("WS refresh failed chat_id=%s account_id=%s error=%s", chat_id, account_id, result.error)

                        next_run[key] = _schedule_after()

                    if active_runtime_accounts <= 0:
                        update_user_fields(chat_id, connected=False)

                await asyncio.sleep(15)
            except asyncio.CancelledError:
                return
            except Exception as e:
                logging.warning("Ошибка ws refresh loop: %s", e)
                await asyncio.sleep(30)

    def _gate_startup_server_accounts() -> tuple[int, int]:
        """Block account actions until startup verification finishes."""
        gated = 0
        already_blocked = 0

        if not active_domain:
            return gated, already_blocked

        for raw_chat_id in get_all_chat_ids():
            chat_id = int(raw_chat_id)

            # Администратор может работать напрямую без пользовательского прокси.
            if _is_admin_runtime_chat(chat_id):
                continue

            try:
                user = get_user(chat_id)

                for acc in get_user_accounts(
                    chat_id,
                    include_empty=True,
                ):
                    account_id = str(
                        acc.get("account_id") or ""
                    ).strip()

                    if not account_id:
                        continue
                    if bool(acc.get("subscription_paused")):
                        continue
                    if int(acc.get("subscription_until_ts") or 0) <= now_ts:
                        continue

                    mode = str(
                        acc.get("promo_activation_mode")
                        or getattr(
                            user,
                            "promo_activation_mode",
                            "server",
                        )
                        or "server"
                    ).strip().lower()

                    if mode == "extension":
                        continue
                    if not str(acc.get("proxy_url") or "").strip():
                        continue
                    if not str(
                        acc.get("zooma_top_session") or ""
                    ).strip():
                        continue

                    runtime_status = str(
                        acc.get("proxy_runtime_status") or "healthy"
                    ).strip().lower()

                    if runtime_status in {
                        "unavailable",
                        "site_unreachable",
                        "recovering",
                    }:
                        patch_user_account(
                            chat_id,
                            account_id,
                            connected=False,
                        )
                        already_blocked += 1
                        continue

                    patch_user_account(
                        chat_id,
                        account_id,
                        connected=False,
                        proxy_runtime_status="recovering",
                        proxy_runtime_reason=(
                            "startup_verification_pending"
                        ),
                        proxy_runtime_source="startup_gate",
                        proxy_runtime_domain=active_domain,
                        proxy_recovery_successes=0,
                    )
                    gated += 1

            except Exception as exc:
                logging.warning(
                    "Startup account gate failed chat_id=%s err=%s: %s",
                    chat_id,
                    type(exc).__name__,
                    exc,
                )

        return gated, already_blocked

    async def _startup_restore_then_account_loops() -> None:
        global domain_watchdog_task, session_probe_task, ws_refresh_task

        try:
            await asyncio.wait_for(
                _restore_startup_all(),
                timeout=300.0,
            )
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError:
            logging.error(
                "Startup restore global timeout | timeout=300s; continuing startup"
            )
        except Exception:
            logging.exception(
                "Startup restore background task failed; continuing startup"
            )

        domain_watchdog_task = asyncio.create_task(
            _domain_watchdog_loop(),
            name="domain-watchdog",
        )
        session_probe_task = asyncio.create_task(
            _session_probe_loop(),
            name="session-probe",
        )
        ws_refresh_task = asyncio.create_task(
            _ws_refresh_loop(),
            name="ws-refresh",
        )
        logging.info("Account runtime loops started after startup restore")

    global promo_server, promo_server_task
    startup_gated, startup_already_blocked = (
        _gate_startup_server_accounts()
    )
    logging.info(
        "Startup account action gate installed | recovering=%s | already_blocked=%s",
        startup_gated,
        startup_already_blocked,
    )
    billing.bind_app(app)
    billing.start()
    promo_app = build_promo_app(promo_engine, billing)
    promo_config = uvicorn.Config(
        promo_app,
        host=PROMO_API_HOST,
        port=PROMO_API_PORT,
        log_level="warning",
        loop="asyncio",
        access_log=False,
    )
    promo_server = uvicorn.Server(promo_config)
    promo_server_task = asyncio.create_task(promo_server.serve(), name="promo-api-server")
    logging.info("Promo API запущен: http://%s:%s", PROMO_API_HOST, PROMO_API_PORT)
    global rain_runtime_task
    rain_runtime_task = start_rain_runtime(
        app.bot,
        extension_ws_manager=promo_engine.extension_ws_manager,
        server_ws_manager=ws_manager,
    )

    global startup_restore_task
    startup_restore_task = asyncio.create_task(
        _startup_restore_then_account_loops(),
        name="startup-account-restore",
    )
    logging.info("Startup restore scheduled in background | timeout=300s")


async def post_shutdown(app: Application):
    global startup_restore_task
    if startup_restore_task and not startup_restore_task.done():
        startup_restore_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await asyncio.wait_for(startup_restore_task, timeout=5)
    startup_restore_task = None

    await ws_manager.stop_all()
    await billing.stop()
    global promo_server, promo_server_task
    if promo_server:
        promo_server.should_exit = True
    if promo_server_task and not promo_server_task.done():
        try:
            await asyncio.wait_for(promo_server_task, timeout=5)
        except Exception:
            promo_server_task.cancel()
    global domain_watchdog_task
    if domain_watchdog_task and not domain_watchdog_task.done():
        domain_watchdog_task.cancel()
        try:
            await asyncio.wait_for(domain_watchdog_task, timeout=3)
        except Exception:
            pass
    global session_probe_task
    if session_probe_task and not session_probe_task.done():
        session_probe_task.cancel()
        try:
            await asyncio.wait_for(session_probe_task, timeout=3)
        except Exception:
            pass
    global ws_refresh_task
    if ws_refresh_task and not ws_refresh_task.done():
        ws_refresh_task.cancel()
        try:
            await asyncio.wait_for(ws_refresh_task, timeout=3)
        except Exception:
            pass
    global tg_watcher_task
    if tg_watcher_task and not tg_watcher_task.done():
        tg_watcher_task.cancel()
        try:
            await asyncio.wait_for(tg_watcher_task, timeout=5)
        except Exception:
            pass
        tg_watcher_task = None
    global rain_runtime_task
    if rain_runtime_task and not rain_runtime_task.done():
        await stop_rain_runtime()
        rain_runtime_task = None
    with contextlib.suppress(Exception):
        flush_promo_stats_now()


def _build_application(purl: str | None) -> Application:
    builder = Application.builder().token(BOT_TOKEN)
    if purl:
        builder = builder.proxy(purl).get_updates_proxy(purl)
    app = (
        builder
        # Telegram API pool. Bigger pool helps when the bot sends/deletes/edits
        # messages while polling is also using Telegram API through the proxy.
        .connection_pool_size(96)
        .pool_timeout(45.0)
        .connect_timeout(30.0)
        .read_timeout(45.0)
        .write_timeout(45.0)
        # Separate pool for getUpdates long-polling.
        # This reduces PoolTimeout during restarts/cleanup/proxy stalls.
        .get_updates_connection_pool_size(16)
        .get_updates_pool_timeout(45.0)
        .get_updates_connect_timeout(30.0)
        .get_updates_read_timeout(45.0)
        .get_updates_write_timeout(45.0)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )
    _install_telegram_retries(app)

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(connect_click, pattern=r"^(connect|relogin:.+)$"))
    app.add_handler(CallbackQueryHandler(accounts_menu_click, pattern=r"^accounts(?::p=\d+)?$"))
    app.add_handler(CallbackQueryHandler(account_detail_click, pattern=r"^account:[^:]+(?::p=\d+)?$"))
    app.add_handler(CallbackQueryHandler(account_renew_click, pattern=r"^account_renew:[^:]+(?::p=\d+)?$"))
    app.add_handler(CallbackQueryHandler(account_renew_confirm_click, pattern=r"^account_renew_confirm:[^:]+:.+(?::p=\d+)?$"))
    app.add_handler(CallbackQueryHandler(addon_account_click, pattern=r"^addon_account$"))
    app.add_handler(CallbackQueryHandler(addon_tariff_buy_click, pattern=r"^addon_tariff_buy:.+$"))
    app.add_handler(CallbackQueryHandler(addon_tariff_confirm_click, pattern=r"^addon_tariff_confirm:.+$"))
    app.add_handler(CallbackQueryHandler(proxy_choice_clear_manual_click, pattern=r"^proxy_choice_clear_manual:[^:]+:[^:]+:\d+:[01]:.+$"))
    app.add_handler(CallbackQueryHandler(proxy_choice_manual_cancel_click, pattern=r"^proxy_choice_manual_cancel:[^:]+:[^:]+:\d+:[01]:.+$"))
    app.add_handler(CallbackQueryHandler(proxy_choice_click, pattern=r"^proxy_choice:(buy|manual):.+$"))
    app.add_handler(CallbackQueryHandler(manual_token_click, pattern=r"^manual_token$"))
    app.add_handler(CallbackQueryHandler(back_click, pattern=r"^back$"))
    app.add_handler(CallbackQueryHandler(broadcast_cancel_click, pattern=r"^broadcast_cancel$"))
    app.add_handler(CallbackQueryHandler(tariffs_click, pattern=r"^tariff_menu$"))
    app.add_handler(CallbackQueryHandler(tariff_buy_click, pattern=r"^tariff_buy:.+$"))
    app.add_handler(CallbackQueryHandler(tariff_confirm_click, pattern=r"^tariff_confirm:.+$"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(~filters.COMMAND, _admin_broadcast_message))
    app.add_error_handler(telegram_error_handler)
    return app


def main():
    if not BOT_TOKEN or BOT_TOKEN == "PASTE_BOT_TOKEN_HERE":
        raise RuntimeError("Задай BOT_TOKEN через переменную окружения")

    purl = proxy_url(PROXY_SCHEME, PROXY_HOST, PROXY_PORT) if USE_PROXY else None
    max_start_attempts = 5

    for attempt in range(1, max_start_attempts + 1):
        app = _build_application(purl)
        try:
            logging.info("Бот запускается... attempt=%s/%s proxy=%s", attempt, max_start_attempts, purl or "off")
            app.run_polling(allowed_updates=Update.ALL_TYPES, poll_interval=1.0)
            return
        except Exception:
            logging.exception("run_polling упал attempt=%s/%s", attempt, max_start_attempts)
            if attempt >= max_start_attempts:
                logging.error("run_polling не запустился после %s попыток", max_start_attempts)
                raise
            time.sleep(5)


if __name__ == "__main__":
    main()
