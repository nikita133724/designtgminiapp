import asyncio
import contextlib
import json
import os
import random
import logging
import sys
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

import aiohttp
from aiohttp_socks import ProxyConnector

from store import get_user, get_user_account, patch_user_account
from zooma import CheckResult, verify_token, get_user_proxy_url


def _ws_user_label(chat_id: int) -> str:
    with contextlib.suppress(Exception):
        username = str(getattr(get_user(int(chat_id)), "tg_username", "") or "").strip().lstrip("@")
        if username:
            return f"@{username}"
    return str(chat_id)


@dataclass
class _WsRuntime:
    chat_id: int
    account_id: str = "acc_1"
    task: Optional[asyncio.Task] = None
    ws: Optional[aiohttp.ClientWebSocketResponse] = None
    session: Optional[aiohttp.ClientSession] = None
    pinger: Optional[asyncio.Task] = None
    listener: Optional[asyncio.Task] = None
    reconnecting: bool = False
    stopped: bool = False
    last_event_type: Optional[str] = None
    last_event_ts: float = 0.0
    last_connected_ts: float = 0.0
    events: Optional[asyncio.Queue] = None
    reconnect_task: Optional[asyncio.Task] = None
    connect_retry_sec: int = 3
    connect_failures: int = 0


class UserWsManager:
    def __init__(self) -> None:
        self._reconnect_min_sec = max(1.0, float(os.getenv("ZOOMA_WS_RECONNECT_MIN_SEC", "3") or "3"))
        self._reconnect_max_sec = max(self._reconnect_min_sec, float(os.getenv("ZOOMA_WS_RECONNECT_MAX_SEC", "120") or "120"))
        self._reconnect_jitter_sec = max(0.0, float(os.getenv("ZOOMA_WS_RECONNECT_JITTER_SEC", "3") or "3"))
        self._items: dict[str, _WsRuntime] = {}
        self._pending_admin_auth_notify: dict[str, asyncio.Task] = {}
        self._proxy_failure_handler: Optional[Callable[[int, str, str], Awaitable[Any]]] = None
        # UI/admin status should not flip to offline just because the casino briefly
        # closes/reopens the socket right after sending userNotify/updateBalance.
        self._recent_event_live_sec = 300.0
        # promo_api historically reads a module-level `ws_manager` while the real
        # manager is passed through PromoEngine. Register this instance so admin
        # panel / Telegram mini app can calculate ws_live from the actual runtime.
        with contextlib.suppress(Exception):
            import promo_api as _promo_api
            setattr(_promo_api, "ws_manager", self)
            self._patch_promo_api_connect_keyboard(_promo_api)
        with contextlib.suppress(Exception):
            from timezone_utils import install_timezone_patches
            install_timezone_patches(self)
        self._patch_main_admin_auth_notify()

    @staticmethod
    def _patch_promo_api_connect_keyboard(_promo_api) -> None:
        """
        The Telegram mini app asks promo_api to send the auth-method message.
        That keyboard was missing the manual zooma_top_session option that exists
        in main.py's inline auth keyboard. Patch only that 3-button auth keyboard.
        """
        if getattr(_promo_api, "_zooma_manual_token_button_patched", False):
            return

        real_markup = getattr(_promo_api, "InlineKeyboardMarkup")
        button_cls = getattr(_promo_api, "InlineKeyboardButton")

        def patched_markup(inline_keyboard, *args, **kwargs):
            rows = inline_keyboard
            try:
                texts = [
                    str(getattr(row[0], "text", "") or "")
                    for row in rows
                    if isinstance(row, list) and len(row) == 1
                ]
                is_auth_keyboard = texts == [
                    "Войти через Steam",
                    "Войти через Telegram",
                    "Войти через Яндекс",
                ]
                has_manual = any(
                    str(getattr(btn, "callback_data", "") or "") == "manual_token"
                    for row in rows
                    if isinstance(row, list)
                    for btn in row
                )
                if is_auth_keyboard and not has_manual:
                    rows = list(rows) + [[button_cls("Вписать zooma_top_session", callback_data="manual_token")]]
            except Exception:
                rows = inline_keyboard
            return real_markup(rows, *args, **kwargs)

        setattr(_promo_api, "InlineKeyboardMarkup", patched_markup)
        setattr(_promo_api, "_zooma_manual_token_button_patched", True)

    def _patch_main_admin_auth_notify(self) -> None:
        """
        Admin "auth success" should mean the same as the user's "account connected":
        token/session data is valid AND VIP WebSocket is connected.

        main.py calls _notify_admin_auth_success before reconnect_for_user for every
        auth method (manual token and webapp Steam/TG/Yandex). If we waited inline,
        it would deadlock before reconnect starts. So replace it with a tiny deferred
        notifier: return immediately, then send the original admin message once this
        manager reports the account online.
        """
        for module_name in ("__main__", "main"):
            module = sys.modules.get(module_name)
            if not module or getattr(module, "_zooma_admin_auth_notify_patched", False):
                continue
            original = getattr(module, "_notify_admin_auth_success", None)
            if not callable(original):
                continue

            manager = self

            async def patched_notify_admin_auth_success(
                app,
                *,
                chat_id: int,
                tg_username: str | None,
                method: str,
                status: str = "успешно",
            ) -> None:
                try:
                    cid = int(chat_id)
                except Exception:
                    await original(app, chat_id=chat_id, tg_username=tg_username, method=method, status=status)
                    return

                try:
                    account_id = str(getattr(get_user(cid), "active_account_id", None) or "acc_1")
                except Exception:
                    account_id = "acc_1"

                key = f"{cid}:{account_id}:{method}"
                old_task = manager._pending_admin_auth_notify.pop(key, None)
                if old_task and not old_task.done():
                    old_task.cancel()

                async def wait_ws_then_notify() -> None:
                    try:
                        deadline = asyncio.get_running_loop().time() + 30.0
                        while asyncio.get_running_loop().time() < deadline:
                            if manager.is_connected(cid, account_id=account_id):
                                await original(app, chat_id=cid, tg_username=tg_username, method=method, status=status)
                                return
                            await asyncio.sleep(0.25)
                        logging.warning(
                            "admin auth notify skipped: WS not connected after auth | chat_id=%s account_id=%s method=%s",
                            cid,
                            account_id,
                            method,
                        )
                    except asyncio.CancelledError:
                        return
                    except Exception as e:
                        logging.warning("admin auth notify delayed task failed chat_id=%s method=%s err=%s", cid, method, e)
                    finally:
                        cur = manager._pending_admin_auth_notify.get(key)
                        if cur is asyncio.current_task():
                            manager._pending_admin_auth_notify.pop(key, None)

                task = asyncio.create_task(wait_ws_then_notify(), name=f"admin-auth-notify-{cid}-{account_id}")
                manager._pending_admin_auth_notify[key] = task

            setattr(module, "_notify_admin_auth_success", patched_notify_admin_auth_success)
            setattr(module, "_zooma_admin_auth_notify_patched", True)

    def set_proxy_failure_handler(self, handler: Callable[[int, str, str], Awaitable[Any]]) -> None:
        self._proxy_failure_handler = handler

    @staticmethod
    def _is_proxy_connect_error(exc: Exception) -> bool:
        txt = f"{type(exc).__name__}: {exc}".lower()
        return (
            "proxy" in txt
            and (
                "couldn't connect" in txt
                or "connect call failed" in txt
                or "connection refused" in txt
                or "errno 111" in txt
                or "connecterror" in txt
            )
        )

    def _account_id(self, chat_id: int, account_id: Optional[str] = None) -> str:
        if account_id:
            return str(account_id)
        try:
            user = get_user(int(chat_id))
            return str(getattr(user, "active_account_id", None) or "acc_1")
        except Exception:
            return "acc_1"

    def _key(self, chat_id: int, account_id: Optional[str] = None) -> str:
        return f"{int(chat_id)}:{self._account_id(chat_id, account_id)}"

    def _is_current_runtime(self, runtime: _WsRuntime) -> bool:
        return self._items.get(self._key(runtime.chat_id, runtime.account_id)) is runtime

    @staticmethod
    def _socket_open(runtime: _WsRuntime | None) -> bool:
        return bool(runtime and runtime.ws is not None and not runtime.ws.closed)

    @staticmethod
    def _is_account_frozen(chat_id: int, account_id: str) -> bool:
        with contextlib.suppress(Exception):
            acc = get_user_account(int(chat_id), str(account_id)) or {}
            runtime_status = str(acc.get("proxy_runtime_status") or "healthy").strip().lower()
            return bool(
                acc.get("subscription_paused")
                or runtime_status in {"unavailable", "site_unreachable"}
            )
        return False

    @staticmethod
    def _is_extension_mode(chat_id: int, account_id: str) -> bool:
        with contextlib.suppress(Exception):
            acc = get_user_account(int(chat_id), str(account_id)) or {}
            return str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension"
        return False

    def _recent_ws_activity(self, runtime: _WsRuntime | None) -> bool:
        if not runtime or not runtime.last_event_ts:
            return False
        return (time.time() - float(runtime.last_event_ts or 0.0)) <= self._recent_event_live_sec

    async def start_for_user(self, chat_id: int, base_url: str, account_id: Optional[str] = None) -> None:
        aid = self._account_id(chat_id, account_id)
        account = get_user_account(int(chat_id), aid) or {}
        if str(account.get("promo_activation_mode") or "server").strip().lower() == "extension":
            logging.info("WS[%s]: start skipped extension mode account_id=%s", chat_id, aid)
            patch_user_account(int(chat_id), aid, connected=False)
            await self.stop_for_user(chat_id, account_id=aid)
            return
        if self._is_account_frozen(int(chat_id), aid):
            logging.info("WS[%s]: start skipped frozen account_id=%s", chat_id, aid)
            patch_user_account(int(chat_id), aid, connected=False)
            await self.stop_for_user(chat_id, account_id=aid)
            return
        await self.stop_for_user(chat_id, account_id=aid)
        runtime = _WsRuntime(chat_id=chat_id, account_id=aid)
        runtime.events = asyncio.Queue(maxsize=200)
        self._items[self._key(chat_id, aid)] = runtime
        runtime.task = asyncio.create_task(self._run(runtime, base_url))

    async def stop_for_user(self, chat_id: int, account_id: Optional[str] = None) -> None:
        if account_id is None:
            keys = [k for k in list(self._items.keys()) if k.startswith(f"{int(chat_id)}:")]
            for key in keys:
                runtime = self._items.pop(key, None)
                if runtime:
                    runtime.stopped = True
                    await self._shutdown(runtime, mark_disconnected=True)
            return

        runtime = self._items.pop(self._key(chat_id, account_id), None)
        if not runtime:
            return
        runtime.stopped = True
        await self._shutdown(runtime, mark_disconnected=True)

    async def stop_all(self) -> None:
        keys = list(self._items.keys())
        for key in keys:
            runtime = self._items.pop(key, None)
            if runtime:
                runtime.stopped = True
                await self._shutdown(runtime, mark_disconnected=True)

    def is_connected(self, chat_id: int, account_id: Optional[str] = None) -> bool:
        """
        Factual UI status for a user's VIP socket.

        Open socket is online. A very recent VIP event is also treated as online,
        because promo status can arrive through the socket and then the connection
        may briefly recycle before the reconnect loop finishes. This prevents the
        admin panel / Telegram mini app from showing offline while the VIP socket
        is demonstrably delivering userNotify/updateBalance events.
        """
        if account_id is None:
            return any(
                (self._socket_open(rt) or self._recent_ws_activity(rt))
                for key, rt in self._items.items()
                if key.startswith(f"{int(chat_id)}:")
            )
        runtime = self._items.get(self._key(int(chat_id), account_id))
        return bool(self._socket_open(runtime) or self._recent_ws_activity(runtime))

    async def reconnect_for_user(
        self,
        chat_id: int,
        base_url: str,
        *,
        account_id: Optional[str] = None,
        attempts: int = 3,
        attempt_timeout: float = 5.0,
        stable_sec: float = 1.2,
    ) -> bool:
        chat_id = int(chat_id)
        aid = self._account_id(chat_id, account_id)
        account = get_user_account(chat_id, aid) or {}
        if str(account.get("promo_activation_mode") or "server").strip().lower() == "extension":
            logging.info("WS[%s]: reconnect skipped extension mode account_id=%s", chat_id, aid)
            patch_user_account(chat_id, aid, connected=False)
            await self.stop_for_user(chat_id, account_id=aid)
            return False
        if self._is_account_frozen(chat_id, aid):
            logging.info("WS[%s]: reconnect skipped frozen account_id=%s", chat_id, aid)
            patch_user_account(chat_id, aid, connected=False)
            await self.stop_for_user(chat_id, account_id=aid)
            return False
        attempts = max(1, int(attempts or 1))
        attempt_timeout = max(1.0, float(attempt_timeout or 5.0))

        for attempt in range(1, attempts + 1):
            await self.start_for_user(chat_id, base_url, account_id=aid)
            deadline = asyncio.get_running_loop().time() + attempt_timeout

            while asyncio.get_running_loop().time() < deadline:
                runtime = self._items.get(self._key(chat_id, aid))
                if self._socket_open(runtime):
                    # Guard against "flash connect": socket opened then dropped
                    # right after subscribe/auth. For explicit reconnect we check
                    # the real socket, not the recent-event UI fallback.
                    if stable_sec > 0:
                        await asyncio.sleep(stable_sec)
                        if self._is_extension_mode(chat_id, aid):
                            await self.stop_for_user(chat_id, account_id=aid)
                            patch_user_account(chat_id, aid, connected=False)
                            return False
                        runtime = self._items.get(self._key(chat_id, aid))
                        if not self._socket_open(runtime):
                            logging.warning(
                                "WS[%s/%s]: reconnect unstable | stable=%.1fs | try=%s/%s",
                                _ws_user_label(chat_id), aid, stable_sec, attempt, attempts,
                            )
                            break
                    logging.info(
                        "WS[%s/%s]: reconnect ok | try=%s/%s",
                        _ws_user_label(chat_id),
                        aid,
                        attempt,
                        attempts,
                    )
                    return True
                await asyncio.sleep(0.25)

            await self.stop_for_user(chat_id, account_id=aid)

            if attempt < attempts:
                await asyncio.sleep(0.5)

        return False

    async def _run(self, runtime: _WsRuntime, base_url: str) -> None:
        while not runtime.stopped:
            user = get_user(runtime.chat_id)
            account = get_user_account(runtime.chat_id, runtime.account_id) or {}
            if self._is_extension_mode(runtime.chat_id, runtime.account_id):
                logging.info("WS[%s]: run stopped extension mode account_id=%s", runtime.chat_id, runtime.account_id)
                runtime.stopped = True
                patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
                break
            if self._is_account_frozen(runtime.chat_id, runtime.account_id):
                logging.info("WS[%s]: run stopped blocked account_id=%s", runtime.chat_id, runtime.account_id)
                runtime.stopped = True
                patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
                break
            session_cookie = str(account.get("zooma_top_session") or user.zooma_top_session or "").strip()
            if not session_cookie:
                await asyncio.sleep(5)
                continue

            if self._is_extension_mode(runtime.chat_id, runtime.account_id):
                logging.info("WS[%s]: verify skipped extension mode account_id=%s", runtime.chat_id, runtime.account_id)
                runtime.stopped = True
                patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
                break
            result = await verify_token(session_cookie, base_url, chat_id=runtime.chat_id, account_id=runtime.account_id)
            if not result.ok:
                logging.warning(
                    "WS[%s]: verify failed reason=%s base_url=%s has_session=%s",
                    runtime.chat_id, result.error or "unknown", base_url, int(bool(session_cookie)),
                )
                await asyncio.sleep(10)
                continue

            self._apply_refresh(runtime.chat_id, result, runtime.account_id)

            ok = await self._connect(runtime)
            if not ok:
                await asyncio.sleep(runtime.connect_retry_sec)
                continue

            # Просто держим сокет живым.
            # Никаких периодических HTTP refresh: токен обновляется только на реальных запросах.
            while not runtime.stopped:
                if runtime.reconnect_task and not runtime.reconnect_task.done():
                    await asyncio.sleep(0.5)
                    continue
                if runtime.ws is None or runtime.ws.closed:
                    await self._ensure_reconnect(runtime)
                    await asyncio.sleep(0.5)
                    continue
                await asyncio.sleep(1.0)

            await self._shutdown_ws_only(runtime, mark_disconnected=False)

        await self._shutdown(runtime, mark_disconnected=False)

    async def _connect(self, runtime: _WsRuntime) -> bool:
        user = get_user(runtime.chat_id)
        account = get_user_account(runtime.chat_id, runtime.account_id) or {}
        if self._is_extension_mode(runtime.chat_id, runtime.account_id):
            logging.info("WS[%s]: connect skipped extension mode account_id=%s", runtime.chat_id, runtime.account_id)
            runtime.stopped = True
            patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
            return False
        if self._is_account_frozen(runtime.chat_id, runtime.account_id):
            logging.info("WS[%s]: connect skipped blocked account_id=%s", runtime.chat_id, runtime.account_id)
            runtime.stopped = True
            patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
            return False
        centrifugo_socket = str(account.get("centrifugo_socket") or user.centrifugo_socket or "")
        centrifugo_secret = str(account.get("centrifugo_secret") or user.centrifugo_secret or "")
        port_user_id = str(account.get("port_user_id") or user.port_user_id or "")
        if not centrifugo_socket or not centrifugo_secret or not port_user_id:
            logging.warning(
                "WS[%s]: connect precheck failed has_socket=%s has_secret=%s has_port_user_id=%s",
                runtime.chat_id,
                int(bool(centrifugo_socket)),
                int(bool(centrifugo_secret)),
                int(bool(port_user_id)),
            )
            return False
        try:
            proxy_url = get_user_proxy_url(runtime.chat_id, account_id=runtime.account_id)
            connector = ProxyConnector.from_url(proxy_url) if proxy_url else None
            runtime.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30, connect=10),
                connector=connector,
            )
            runtime.ws = await runtime.session.ws_connect(centrifugo_socket)
            await runtime.ws.send_json({"id": 1, "method": 0, "params": {"token": centrifugo_secret}})
            auth_resp = await runtime.ws.receive_json()
            if isinstance(auth_resp, dict) and auth_resp.get("error"):
                raise RuntimeError(f"ws_auth_error: {auth_resp.get('error')}")
            await runtime.ws.send_json(
                {"id": 2, "method": 1, "params": {"channel": f"usr#{port_user_id}"}}
            )
            sub_resp = await runtime.ws.receive_json()
            if isinstance(sub_resp, dict) and sub_resp.get("error"):
                raise RuntimeError(f"ws_subscribe_error: {sub_resp.get('error')}")
            runtime.last_connected_ts = time.time()
            runtime.pinger = asyncio.create_task(self._pinger(runtime))
            runtime.listener = asyncio.create_task(self._listener(runtime))
            runtime.connect_failures = 0
            runtime.connect_retry_sec = int(self._reconnect_min_sec)
            if self._is_current_runtime(runtime):
                patch_user_account(runtime.chat_id, runtime.account_id, connected=True)
            return True
        except Exception as e:
            if self._is_proxy_connect_error(e):
                runtime.connect_retry_sec = 60
                logging.warning(
                    "WS[%s]: proxy unavailable, account runtime will be paused account_id=%s error=%s",
                    runtime.chat_id,
                    runtime.account_id,
                    e,
                )
                if self._proxy_failure_handler:
                    with contextlib.suppress(Exception):
                        await self._proxy_failure_handler(runtime.chat_id, runtime.account_id, str(e))
                runtime.stopped = True
                await self._shutdown_ws_only(runtime, mark_disconnected=self._is_current_runtime(runtime))
                return False

            runtime.connect_failures += 1
            retry = min(self._reconnect_max_sec, self._reconnect_min_sec * (2 ** min(runtime.connect_failures - 1, 8)))
            retry += random.uniform(0, self._reconnect_jitter_sec)
            runtime.connect_retry_sec = int(max(1, retry))
            if runtime.connect_failures in {1, 3, 5, 10} or runtime.connect_failures % 20 == 0:
                logging.warning(
                    "WS[%s]: connect error failures=%s retry_sec=%s error=%s",
                    runtime.chat_id, runtime.connect_failures, runtime.connect_retry_sec, e,
                )
            await self._shutdown_ws_only(runtime, mark_disconnected=self._is_current_runtime(runtime))
            return False

    async def _pinger(self, runtime: _WsRuntime) -> None:
        try:
            while runtime.ws and not runtime.ws.closed and not runtime.stopped:
                await asyncio.sleep(25)
                pong = runtime.ws.ping()
                await asyncio.wait_for(pong, timeout=12)
        except Exception:
            await self._ensure_reconnect(runtime)

    async def _listener(self, runtime: _WsRuntime) -> None:
        def _extract_event(payload: dict) -> tuple[Optional[str], Optional[dict]]:
            chain_candidates = [
                ("push", "pub", "data"),
                ("result", "data", "data"),
                ("result", "data"),
                ("data",),
            ]
            for chain in chain_candidates:
                node = payload
                ok = True
                for key in chain:
                    if isinstance(node, dict) and key in node:
                        node = node.get(key)
                    else:
                        ok = False
                        break
                if ok and isinstance(node, dict):
                    event_type = str(node.get("type") or "").strip()
                    if event_type:
                        event_payload = node.get("data", {})
                        if not isinstance(event_payload, dict):
                            event_payload = {}
                        return event_type, event_payload
            return None, None

        try:
            while runtime.ws and not runtime.ws.closed and not runtime.stopped:
                msg = await runtime.ws.receive()
                if msg.type == aiohttp.WSMsgType.TEXT:
                    try:
                        payload = json.loads(msg.data)
                        event_type, event_payload = _extract_event(payload)
                        if event_type:
                            runtime.last_event_type = event_type
                            runtime.last_event_ts = time.time()
                            if self._is_current_runtime(runtime):
                                with contextlib.suppress(Exception):
                                    patch_user_account(runtime.chat_id, runtime.account_id, connected=True)
                            if runtime.events is not None:
                                with contextlib.suppress(asyncio.QueueFull):
                                    runtime.events.put_nowait({"type": event_type, "data": event_payload or {}})
                            if event_type in {"userNotify", "updateBalance"}:
                                logging.debug("WS[%s]: event=%s", runtime.chat_id, event_type)
                    except Exception:
                        pass
                if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                    break
        except Exception:
            pass
        await self._ensure_reconnect(runtime)

    async def _ensure_reconnect(self, runtime: _WsRuntime) -> None:
        if runtime.stopped:
            return
        if self._is_extension_mode(runtime.chat_id, runtime.account_id):
            runtime.stopped = True
            patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
            return
        if self._is_account_frozen(runtime.chat_id, runtime.account_id):
            runtime.stopped = True
            patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
            return
        if runtime.reconnect_task and not runtime.reconnect_task.done():
            return
        runtime.reconnect_task = asyncio.create_task(
            self._reconnect_loop(runtime),
            name=f"ws-reconnect-{runtime.chat_id}-{runtime.account_id}",
        )

    async def _reconnect_loop(self, runtime: _WsRuntime) -> None:
        runtime.reconnecting = True
        try:
            for attempt in range(1, 100):
                if runtime.stopped:
                    return
                await asyncio.sleep(max(1, runtime.connect_retry_sec))
                if self._is_extension_mode(runtime.chat_id, runtime.account_id):
                    runtime.stopped = True
                    patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
                    return
                await self._shutdown_ws_only(runtime, mark_disconnected=False)
                if await self._connect(runtime):
                    runtime.connect_retry_sec = int(self._reconnect_min_sec)
                    runtime.connect_failures = 0
                    return
            logging.warning("WS[%s]: reconnect exhausted attempts", runtime.chat_id)
            if self._is_current_runtime(runtime):
                with contextlib.suppress(Exception):
                    patch_user_account(runtime.chat_id, runtime.account_id, connected=False)
        finally:
            runtime.reconnecting = False
            runtime.reconnect_task = None

    async def wait_event(self, chat_id: int, timeout: float = 8.0, account_id: Optional[str] = None) -> Optional[dict]:
        runtime = self._items.get(self._key(int(chat_id), account_id))
        if not runtime or runtime.events is None:
            # Defensive throttle: callers must never enter a hot loop after the
            # account runtime was removed because its proxy went offline.
            await asyncio.sleep(max(0.05, min(float(timeout or 0.1), 0.25)))
            return None
        try:
            return await asyncio.wait_for(runtime.events.get(), timeout=timeout)
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError:
            return None
        except Exception:
            return None

    def drain_events(self, chat_id: int, account_id: Optional[str] = None) -> int:
        runtime = self._items.get(self._key(int(chat_id), account_id))
        if not runtime or runtime.events is None:
            return 0
        drained = 0
        while True:
            try:
                runtime.events.get_nowait()
                drained += 1
            except Exception:
                break
        return drained

    async def _shutdown_ws_only(self, runtime: _WsRuntime, *, mark_disconnected: bool = True) -> None:
        for task in (runtime.pinger, runtime.listener):
            if task and not task.done():
                task.cancel()
        runtime.pinger = None
        runtime.listener = None
        try:
            if runtime.ws and not runtime.ws.closed:
                await runtime.ws.close()
        except Exception:
            pass
        runtime.ws = None
        try:
            if runtime.session:
                await runtime.session.close()
        except Exception:
            pass
        runtime.session = None
        if mark_disconnected:
            with contextlib.suppress(Exception):
                patch_user_account(runtime.chat_id, runtime.account_id, connected=False)

    async def _shutdown(self, runtime: _WsRuntime, *, mark_disconnected: bool = True) -> None:
        await self._shutdown_ws_only(runtime, mark_disconnected=mark_disconnected)
        if runtime.reconnect_task and runtime.reconnect_task is not asyncio.current_task() and not runtime.reconnect_task.done():
            runtime.reconnect_task.cancel()
        if runtime.task and runtime.task is not asyncio.current_task() and not runtime.task.done():
            runtime.task.cancel()

    @staticmethod
    def _apply_refresh(chat_id: int, result: CheckResult, account_id: Optional[str] = None) -> None:
        if account_id:
            patch_user_account(
                chat_id,
                account_id,
                port_user_id=result.port_user_id or "",
                port_user_name=result.port_user_name or "",
                centrifugo_socket=result.centrifugo_socket or "",
                centrifugo_secret=result.centrifugo_secret or "",
                zooma_top_session=result.zooma_top_session or "",
                zooma_top_session_expires_at=result.zooma_top_session_expires_at,
                csrf_token=result.csrf_token,
                fingerprint_now=result.fingerprint_now,
                user_agent=result.user_agent,
            )
            return
        user = get_user(chat_id)
        user.waiting_token = False
        user.port_user_id = result.port_user_id or user.port_user_id
        user.port_user_name = result.port_user_name or user.port_user_name
        user.centrifugo_socket = result.centrifugo_socket or user.centrifugo_socket
        user.centrifugo_secret = result.centrifugo_secret or user.centrifugo_secret
        user.zooma_top_session = result.zooma_top_session or user.zooma_top_session
        user.zooma_top_session_expires_at = (
            result.zooma_top_session_expires_at or user.zooma_top_session_expires_at
        )
