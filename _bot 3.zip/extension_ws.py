from __future__ import annotations

import asyncio
import contextlib
import logging
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from fastapi import WebSocket

from store import (
    get_user,
    get_user_account,
    has_active_account_subscription,
    has_active_subscription,
    hash_extension_installation_id,
    patch_user_account,
)

logger = logging.getLogger(__name__)


@dataclass
class ExtensionConnection:
    ws: WebSocket
    chat_id: int
    username: str = ""
    account_id: str = "acc_1"
    fingerprint: str = ""
    installation_id: str = ""
    connection_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    connected_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    # Approximate one-way server -> extension response latency.
    # Derived from server-observed heartbeat RTT / 2 to avoid browser clock skew.
    last_ping_ms: float | None = None
    last_ping_rtt_ms: float | None = None
    probe_id: str = ""
    probe_nonce: str = ""
    probe_sent_at: float = 0.0
    probe_deadline_at: float = 0.0
    probe_failures: int = 0
    probe_waiter: Any | None = None
    last_probe_ok_at: float = 0.0
    last_probe_state: str = ""
    last_probe_buffered_amount: int = 0
    train_task_ids: set[str] = field(default_factory=set)
    promo_task_ids: set[str] = field(default_factory=set)
    chat_ai_task_ids: set[str] = field(default_factory=set)


def get_extension_entitlement(
    chat_id: int,
    account_id: str | None = None,
    now_ts: int | None = None,
    *,
    installation_id: str | None = None,
) -> dict[str, Any]:
    now = int(now_ts or time.time())
    aid = str(account_id or "acc_1")
    acc = get_user_account(int(chat_id), aid) or {}
    user = get_user(int(chat_id))
    account_until = int(acc.get("subscription_until_ts") or 0)
    user_until = int(getattr(user, "subscription_until_ts", 0) or 0)
    user_active = has_active_subscription(int(chat_id), now)
    account_active = has_active_account_subscription(int(chat_id), aid, now)
    active = bool(account_active or user_active)
    until_ts = account_until if account_active else (user_until if user_active else max(account_until, user_until, 0))

    bound_chat_id = int(acc.get("extension_bound_chat_id") or 0)
    bound_status = str(acc.get("extension_bound_status") or "").strip().lower()
    account_bound = bound_chat_id == int(chat_id) and bound_status != "unbound"
    stored_device_hash = str(acc.get("extension_bound_device_id") or "").strip().lower()
    stored_key_id = str(acc.get("extension_key_id") or "").strip().lower()
    stored_public_key = acc.get("extension_public_key_jwk")
    binding_version = max(0, int(acc.get("extension_binding_version") or 0))
    provided_installation = str(installation_id or "").strip()
    candidate_hash = ""
    if provided_installation:
        with contextlib.suppress(ValueError):
            candidate_hash = hash_extension_installation_id(provided_installation)
    device_matches = bool(
        account_bound
        and stored_device_hash
        and candidate_hash
        and secrets.compare_digest(stored_device_hash, candidate_hash)
    )
    bound_elsewhere = bool(account_bound and provided_installation and not device_matches)
    telegram_bound = device_matches if provided_installation else account_bound

    return {
        "active": active,
        "subscription_active": active,
        "subscription_until_ts": until_ts,
        "account_id": aid,
        "chat_id": int(chat_id),
        "telegram_bound": telegram_bound,
        "account_bound": account_bound,
        "device_matches": device_matches,
        "bound_elsewhere": bound_elsewhere,
        "extension_bound_chat_id": bound_chat_id or None,
        "extension_bound_at_ts": int(acc.get("extension_bound_at_ts") or 0) or None,
        "extension_bound_status": "bound" if account_bound else "unbound",
        "extension_key_registered": bool(device_matches and stored_key_id and isinstance(stored_public_key, dict)),
        "extension_key_id": stored_key_id if device_matches else None,
        "extension_binding_version": binding_version if device_matches else 0,
        "server_ts": now,
    }


class ExtensionWsManager:
    """WebSocket runtime for browser-extension promo activation."""


    def __init__(self, *, promo_timeout_sec: float = 30.0) -> None:
        self.promo_timeout_sec = max(60.0, float(promo_timeout_sec or 60.0))
        self._connections: dict[str, ExtensionConnection] = {}
        self._by_key: dict[str, str] = {}
        self._pending: dict[str, asyncio.Future] = {}
        self._lock = asyncio.Lock()
        self._train_task_provider: Any | None = None
        self._train_event_handler: Any | None = None
        self._seen_promo_result_ids: dict[str, float] = {}
        self._state_pusher: Any | None = None
        self._control_pending: dict[str, asyncio.Future] = {}
        self._chat_ai_pending: dict[str, asyncio.Future] = {}
        self._connection_event_handler: Any | None = None


    @staticmethod
    def _key(chat_id: int, account_id: str | None = None, fingerprint: str | None = None) -> str:
        fp = str(fingerprint or "").strip()
        return f"{int(chat_id)}:{str(account_id or 'acc_1')}:{fp}"


    def set_state_pusher(self, fn: Any | None) -> None:
        self._state_pusher = fn

    def set_connection_event_handler(self, fn: Any | None) -> None:
        self._connection_event_handler = fn

    async def _emit_connection_event(self, event_type: str, conn: ExtensionConnection) -> None:
        fn = self._connection_event_handler
        if fn is None:
            return
        try:
            result = fn(str(event_type), int(conn.chat_id), str(conn.account_id))
            if asyncio.iscoroutine(result):
                await result
        except Exception as exc:
            logger.warning(
                "extension connection event handler failed | event=%s chat_id=%s account_id=%s error=%s",
                event_type,
                conn.chat_id,
                conn.account_id,
                exc,
            )

    async def _push_state(self, chat_id: int) -> None:
        fn = self._state_pusher
        if fn is None:
            return
        try:
            result = fn(int(chat_id))
            if asyncio.iscoroutine(result):
                await result
        except Exception as exc:
            logger.warning("extension state push failed chat_id=%s error=%s", chat_id, exc)

    def status_snapshot(self, chat_id: int, account_id: str | None = None) -> dict[str, Any]:
        conn = self._connection_for(int(chat_id), str(account_id or "acc_1"))
        now = time.time()
        live = bool(
            conn
            and self._ws_transport_open(conn)
            and (now - float(conn.last_seen or 0.0)) <= 45.0
        )
        return {
            "extension_ws_live": live,
            "extension_ws_ping_ms": (round(float(conn.last_ping_ms), 1) if conn and conn.last_ping_ms is not None else None),
            "extension_ws_ping_rtt_ms": (round(float(conn.last_ping_rtt_ms), 1) if conn and conn.last_ping_rtt_ms is not None else None),
            "extension_ws_last_seen_ts": (int(conn.last_seen) if conn else 0),
            "extension_ws_connected_at_ts": (int(conn.connected_at) if conn else 0),
            "extension_ws_probe_ok_ts": (int(conn.last_probe_ok_at) if conn else 0),
            "extension_ws_probe_state": (str(conn.last_probe_state or "") if conn else ""),
            "extension_ws_probe_failures": (int(conn.probe_failures) if conn else 0),
            "extension_ws_buffered_amount": (int(conn.last_probe_buffered_amount) if conn else 0),
        }

    async def reload_managed_tab(self, chat_id: int, account_id: str, *, timeout_sec: float = 25.0) -> dict[str, Any]:
        cid = int(chat_id)
        aid = str(account_id or "acc_1")
        entitlement = get_extension_entitlement(cid, aid)
        if not entitlement.get("account_bound"):
            return {"ok": False, "status": "extension_not_bound", "message": "Расширение не привязано"}
        conn = self._connection_for(cid, aid)
        if not conn:
            return {"ok": False, "status": "extension_offline", "message": "Расширение не подключено"}
        request_id = uuid.uuid4().hex
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self._control_pending[request_id] = fut
        try:
            await conn.ws.send_json({
                "type": "managed_tab_reload",
                "request_id": request_id,
                "chat_id": cid,
                "account_id": aid,
                "server_ts_ms": int(time.time() * 1000),
            })
            result = await asyncio.wait_for(fut, timeout=max(5.0, float(timeout_sec or 25.0)))
            return dict(result or {})
        except asyncio.TimeoutError:
            return {"ok": False, "status": "extension_timeout", "message": "Расширение не подтвердило обновление вкладки вовремя"}
        except Exception as exc:
            return {"ok": False, "status": "extension_send_error", "message": f"{type(exc).__name__}: {exc}"}
        finally:
            self._control_pending.pop(request_id, None)

    def set_train_handlers(self, *, task_provider: Any, event_handler: Any) -> None:
        self._train_task_provider = task_provider
        self._train_event_handler = event_handler
        with contextlib.suppress(RuntimeError):
            loop = asyncio.get_running_loop()
            for conn in list(self._connections.values()):
                loop.create_task(
                    self.send_pending_train_tasks(conn),
                    name=f"extension-train-sync-{conn.chat_id}-{conn.account_id}",
                )

    async def _emit_train_event(self, conn: ExtensionConnection, msg: dict[str, Any]) -> dict[str, Any]:
        handler = self._train_event_handler
        if handler is None:
            return {"accepted": False, "status": "train_handler_unavailable"}
        try:
            result = await handler(conn, dict(msg))
            return result if isinstance(result, dict) else {"accepted": bool(result)}
        except Exception as exc:
            logger.exception(
                "extension train event failed chat_id=%s account_id=%s type=%s",
                conn.chat_id,
                conn.account_id,
                msg.get("type"),
            )
            return {"accepted": False, "status": "train_handler_error", "message": f"{type(exc).__name__}: {exc}"}

    def _connection_for(self, chat_id: int, account_id: str) -> ExtensionConnection | None:
        cid = self._by_key.get(self._key(int(chat_id), str(account_id), ""))
        return self._connections.get(cid or "")


    def _account_label(self, chat_id: int, account_id: str) -> str:
        try:
            username = str(get_user(int(chat_id)).tg_username or "").strip().lstrip("@")
        except Exception:
            username = ""
        base = f"@{username}" if username else f"chat_id={int(chat_id)}"
        try:
            acc = get_user_account(int(chat_id), str(account_id)) or {}
        except Exception:
            acc = {}
        name = str(acc.get("port_user_name") or "").strip()
        uid = str(acc.get("port_user_id") or "").strip()
        tail = f"{name or str(account_id)}|{uid or '-'}"
        return f"{base}/{tail}"

    @staticmethod
    def _ws_transport_open(conn: ExtensionConnection | None) -> bool:
        if conn is None:
            return False
        ws = conn.ws
        for attr in ("client_state", "application_state"):
            state = getattr(ws, attr, None)
            if state is None:
                continue
            state_name = str(getattr(state, "name", state)).upper()
            if state_name != "CONNECTED":
                return False
        return True

    async def _close_failed_transport(self, conn: ExtensionConnection, *, reason: str) -> None:
        with contextlib.suppress(Exception):
            await conn.ws.close(code=4001, reason=str(reason or "transport send failed")[:120])

    async def _probe_connection(self, conn: ExtensionConnection, *, timeout_sec: float = 12.0, max_age_sec: float = 30.0) -> bool:
        now = time.time()
        if (
            conn.last_probe_ok_at
            and now - float(conn.last_probe_ok_at or 0.0) <= max(1.0, float(max_age_sec or 30.0))
            and int(conn.probe_failures or 0) == 0
        ):
            return True
        if conn.probe_waiter and not conn.probe_waiter.done():
            try:
                return bool(await asyncio.wait_for(asyncio.shield(conn.probe_waiter), timeout=max(1.0, float(timeout_sec or 12.0))))
            except Exception:
                return False

        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        probe_id = uuid.uuid4().hex
        probe_nonce = secrets.token_hex(16)
        conn.probe_id = probe_id
        conn.probe_nonce = probe_nonce
        conn.probe_sent_at = time.time()
        conn.probe_deadline_at = conn.probe_sent_at + max(1.0, float(timeout_sec or 12.0))
        conn.probe_waiter = fut
        try:
            await conn.ws.send_json({
                "type": "probe",
                "id": probe_id,
                "nonce": probe_nonce,
                "sent_at": int(conn.probe_sent_at * 1000),
                "server_ts_ms": int(conn.probe_sent_at * 1000),
            })
            ok = bool(await asyncio.wait_for(fut, timeout=max(1.0, float(timeout_sec or 12.0))))
            return ok
        except asyncio.TimeoutError:
            conn.probe_failures += 1
            logger.warning(
                "extension probe timeout | %s failures=%s",
                self._account_label(conn.chat_id, conn.account_id),
                conn.probe_failures,
            )
            return False
        except Exception as exc:
            conn.probe_failures += 1
            logger.warning(
                "extension probe send failed | %s err=%s failures=%s",
                self._account_label(conn.chat_id, conn.account_id),
                exc,
                conn.probe_failures,
            )
            await self._close_failed_transport(conn, reason="probe send failed")
            return False
        finally:
            if conn.probe_id == probe_id:
                conn.probe_id = ""
                conn.probe_nonce = ""
                conn.probe_sent_at = 0.0
                conn.probe_deadline_at = 0.0
            if conn.probe_waiter is fut:
                conn.probe_waiter = None


    async def runtime_ready(
        self,
        chat_id: int,
        account_id: str,
        *,
        timeout_sec: float = 7.0,
        max_age_sec: float = 20.0,
    ) -> tuple[bool, str]:
        conn = self._connection_for(int(chat_id), str(account_id or "acc_1"))
        if not conn or not self._ws_transport_open(conn):
            return False, "extension_offline"
        ok = await self._probe_connection(
            conn,
            timeout_sec=max(1.0, float(timeout_sec or 7.0)),
            max_age_sec=max(0.0, float(max_age_sec or 20.0)),
        )
        if ok:
            return True, "ready"
        state = str(conn.last_probe_state or "").strip().lower()
        if state in {"managed_tab_not_ready", "tab_unavailable", "tab_not_found"}:
            return False, "managed_tab_not_ready"
        return False, "extension_offline"


    async def send_chat_ai_task(
        self,
        *,
        chat_id: int,
        account_id: str,
        task_id: str,
        message: str,
        source: str,
        attempt: int,
        mode_epoch: int = 0,
        timeout_sec: float = 35.0,
    ) -> dict[str, Any]:
        cid = int(chat_id)
        aid = str(account_id or "acc_1")
        account = get_user_account(cid, aid) or {}
        current_mode = str(account.get("promo_activation_mode") or "server").strip().lower()
        current_epoch = max(0, int(account.get("runtime_mode_epoch") or 0))
        requested_epoch = max(0, int(mode_epoch or 0))
        if current_mode != "extension":
            return {"ok": False, "status": "wrong_activation_mode", "message": "Аккаунт работает через сервер"}
        if requested_epoch != current_epoch:
            return {"ok": False, "status": "activation_mode_changed", "message": "Режим аккаунта уже изменён"}
        entitlement = get_extension_entitlement(cid, aid)
        if not entitlement.get("active"):
            return {"ok": False, "status": "extension_subscription_inactive", "message": "Подписка неактивна"}
        if not entitlement.get("account_bound"):
            return {"ok": False, "status": "extension_not_bound", "message": "Расширение не привязано"}
        conn = self._connection_for(cid, aid)
        if not conn:
            return {"ok": False, "status": "extension_offline", "message": "Расширение не подключено"}
        if not self._ws_transport_open(conn):
            return {"ok": False, "status": "extension_offline", "message": "WebSocket расширения закрыт"}
        runtime_ok, runtime_status = await self.runtime_ready(
            cid,
            aid,
            timeout_sec=7.0,
            max_age_sec=20.0,
        )
        if not runtime_ok:
            if runtime_status == "managed_tab_not_ready":
                return {"ok": False, "status": "managed_tab_not_ready", "message": "Вкладка казино недоступна"}
            return {"ok": False, "status": "extension_offline", "message": "Расширение не подключено"}
        tid = str(task_id or "").strip()
        if not tid:
            return {"ok": False, "status": "missing_task_id", "message": "Не указан task_id"}
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        pending_key = f"{tid}:{max(1, int(attempt or 1))}"
        self._chat_ai_pending[pending_key] = fut
        conn.chat_ai_task_ids.add(pending_key)
        payload = {
            "type": "chat_ai_task",
            "task_id": tid,
            "chat_id": cid,
            "account_id": aid,
            "message": str(message or ""),
            "source": str(source or "regular"),
            "attempt": max(1, int(attempt or 1)),
            "mode_epoch": current_epoch,
            "server_ts_ms": int(time.time() * 1000),
        }
        try:
            await conn.ws.send_json(payload)
            result = await asyncio.wait_for(fut, timeout=max(5.0, float(timeout_sec or 35.0)))
            data = dict(result or {})
            return data
        except asyncio.TimeoutError:
            return {"ok": False, "status": "extension_timeout", "message": "Расширение не подтвердило отправку сообщения"}
        except Exception as exc:
            await self._close_failed_transport(conn, reason="chat ai send failed")
            return {"ok": False, "status": "extension_send_error", "message": f"{type(exc).__name__}: {exc}"}
        finally:
            self._chat_ai_pending.pop(pending_key, None)
            conn.chat_ai_task_ids.discard(pending_key)

    async def send_chat_ai_cancel(
        self,
        *,
        chat_id: int,
        account_id: str,
        task_id: str,
        attempt: int,
        mode_epoch: int,
        reason: str,
    ) -> bool:
        tid = str(task_id or "").strip()
        if not tid:
            return False
        pending_key = f"{tid}:{max(1, int(attempt or 1))}"
        sent = False
        conn = self._connection_for(int(chat_id), str(account_id or "acc_1"))
        if conn is not None and self._ws_transport_open(conn):
            try:
                await conn.ws.send_json({
                    "type": "chat_ai_cancel",
                    "chat_id": int(chat_id),
                    "account_id": str(account_id or "acc_1"),
                    "task_id": tid,
                    "attempt": max(1, int(attempt or 1)),
                    "mode_epoch": max(0, int(mode_epoch or 0)),
                    "reason": str(reason or "activation_mode_changed")[:200],
                    "server_ts_ms": int(time.time() * 1000),
                })
                sent = True
            except Exception:
                sent = False
        fut = self._chat_ai_pending.get(pending_key)
        if fut and not fut.done():
            fut.set_result({
                "ok": False,
                "status": "activation_mode_changed",
                "message": "Режим аккаунта изменён",
                "mode_epoch": max(0, int(mode_epoch or 0)),
            })
        return sent

    async def send_train_task(self, *, chat_id: int, account_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        entitlement = get_extension_entitlement(int(chat_id), str(account_id))
        if not entitlement["active"]:
            return {"sent": False, "status": "extension_subscription_inactive"}
        if not entitlement.get("account_bound"):
            return {"sent": False, "status": "extension_not_bound"}
        conn = self._connection_for(int(chat_id), str(account_id))
        if not conn:
            return {"sent": False, "status": "extension_offline"}
        if not self._ws_transport_open(conn):
            return {"sent": False, "status": "extension_offline"}
        body = dict(payload)
        body["type"] = "train_task"
        body["chat_id"] = int(chat_id)
        body["account_id"] = str(account_id)
        body["server_ts_ms"] = int(time.time() * 1000)
        task_id = str(body.get("task_id") or "").strip()
        if task_id and task_id in conn.train_task_ids:
            return {"sent": True, "status": "stored"}
        try:
            await conn.ws.send_json(body)
            await self._emit_train_event(conn, {**body, "type": "train_delivered"})
            return {"sent": True, "status": "delivered"}
        except Exception as exc:
            await self._close_failed_transport(conn, reason="train send failed")
            return {"sent": False, "status": "extension_send_error", "message": f"{type(exc).__name__}: {exc}"}


    async def send_train_cancel(
        self,
        *,
        chat_id: int,
        account_id: str,
        join_id: str,
        task_id: str,
        reason: str,
    ) -> bool:
        conn = self._connection_for(int(chat_id), str(account_id))
        if not conn:
            return False
        try:
            await conn.ws.send_json({
                "type": "train_cancel",
                "chat_id": int(chat_id),
                "account_id": str(account_id),
                "join_id": str(join_id),
                "task_id": str(task_id),
                "reason": str(reason or "cancelled")[:200],
                "server_ts_ms": int(time.time() * 1000),
            })
            conn.train_task_ids.discard(str(task_id))
            return True
        except Exception:
            return False

    async def send_pending_train_tasks(self, conn: ExtensionConnection) -> int:
        provider = self._train_task_provider
        if provider is None:
            return 0
        try:
            payloads = await provider(conn.chat_id, conn.account_id)
        except Exception:
            logger.exception("extension pending train provider failed chat_id=%s account_id=%s", conn.chat_id, conn.account_id)
            return 0
        sent = 0
        for payload in payloads or []:
            result = await self.send_train_task(chat_id=conn.chat_id, account_id=conn.account_id, payload=dict(payload))
            if result.get("sent"):
                sent += 1
        return sent

    async def add(self, ws: WebSocket, hello: dict[str, Any]) -> ExtensionConnection:
        chat_id = int(hello.get("chat_id") or 0)
        if chat_id <= 0:
            raise ValueError("bad_chat_id")
        account_id = str(hello.get("account_id") or "acc_1").strip() or "acc_1"
        # Existing fingerprint is casino/runtime routing data. Do not use it as the license binding key.
        fingerprint = str(hello.get("fingerprint") or "").strip()
        installation_id = str(hello.get("installation_id") or "").strip().lower()
        if len(installation_id) != 64 or any(ch not in "0123456789abcdef" for ch in installation_id):
            raise ValueError("bad_extension_installation_id")
        entitlement = get_extension_entitlement(
            chat_id,
            account_id,
            int(time.time()),
            installation_id=installation_id,
        )
        if not entitlement["active"]:
            logger.warning("extension ws rejected no_subscription chat_id=%s account_id=%s", chat_id, account_id)
            raise ValueError("subscription_required")
        if entitlement.get("bound_elsewhere"):
            logger.warning("extension ws rejected another_device chat_id=%s account_id=%s", chat_id, account_id)
            raise ValueError("extension_bound_to_another_device")
        if not entitlement.get("device_matches"):
            logger.warning("extension ws rejected not_bound chat_id=%s account_id=%s", chat_id, account_id)
            raise ValueError("extension_not_bound")
        conn = ExtensionConnection(
            ws=ws,
            chat_id=chat_id,
            username=str(hello.get("username") or "").strip(),
            account_id=account_id,
            fingerprint=fingerprint,
            installation_id=installation_id,
        )
        async with self._lock:
            old_id = self._by_key.get(self._key(conn.chat_id, conn.account_id, conn.fingerprint))
            if old_id and old_id in self._connections:
                old = self._connections.pop(old_id, None)
                if old:
                    with contextlib.suppress(Exception):
                        await old.ws.close(code=4002)
                    for key, cid in list(self._by_key.items()):
                        if cid == old_id:
                            self._by_key.pop(key, None)
                    logger.info("extension ws replaced old connection chat_id=%s account_id=%s", conn.chat_id, conn.account_id)
            self._connections[conn.connection_id] = conn
            self._by_key[self._key(conn.chat_id, conn.account_id, conn.fingerprint)] = conn.connection_id
            self._by_key[self._key(conn.chat_id, conn.account_id, "")] = conn.connection_id
        hello_patch: dict[str, Any] = {}
        current_acc = get_user_account(conn.chat_id, conn.account_id) or {}
        port_user_id = str(hello.get("port_user_id") or "").strip()
        port_user_name = str(hello.get("port_user_name") or "").strip()[:255]
        if (
            port_user_id.isdigit()
            and int(port_user_id) > 1000
            and port_user_id != str(current_acc.get("port_user_id") or "").strip()
        ):
            hello_patch["port_user_id"] = port_user_id
        if port_user_name and port_user_name != str(current_acc.get("port_user_name") or "").strip():
            hello_patch["port_user_name"] = port_user_name
        if hello_patch:
            with contextlib.suppress(Exception):
                patch_user_account(conn.chat_id, conn.account_id, **hello_patch)
        logger.info("extension ws connected | %s fp=%s", self._account_label(conn.chat_id, conn.account_id), conn.fingerprint[:8])
        await self._push_state(conn.chat_id)
        asyncio.create_task(
            self._emit_connection_event("connected", conn),
            name=f"extension-connected-event-{conn.chat_id}-{conn.account_id}",
        )
        return conn

    async def remove(self, conn: ExtensionConnection | None) -> None:
        if not conn:
            return
        async with self._lock:
            self._connections.pop(conn.connection_id, None)
            for key, cid in list(self._by_key.items()):
                if cid == conn.connection_id:
                    self._by_key.pop(key, None)
        logger.info("extension ws disconnected | %s", self._account_label(conn.chat_id, conn.account_id))
        for pending_key in list(conn.chat_ai_task_ids):
            fut = self._chat_ai_pending.get(pending_key)
            if fut and not fut.done():
                fut.set_result({
                    "ok": False,
                    "status": "extension_offline",
                    "message": "Расширение отключилось",
                })
        await self._push_state(conn.chat_id)
        asyncio.create_task(
            self._emit_connection_event("disconnected", conn),
            name=f"extension-disconnected-event-{conn.chat_id}-{conn.account_id}",
        )

    async def disconnect(self, chat_id: int, account_id: str | None = None, *, code: int = 4004) -> bool:
        cid = self._by_key.get(self._key(int(chat_id), account_id, ""))
        conn = self._connections.get(cid or "")
        if not conn:
            return False
        with contextlib.suppress(Exception):
            await conn.ws.close(code=code)
        return True


    async def handle_message(self, conn: ExtensionConnection, msg: dict[str, Any]) -> None:
        conn.last_seen = time.time()
        typ = str(msg.get("type") or "").strip().lower()
        if typ == "probe_ack":
            probe_id = str(msg.get("id") or "").strip()
            nonce = str(msg.get("nonce") or "").strip()
            now = time.time()
            state = str(msg.get("state") or "").strip().lower()
            try:
                buffered_amount = max(0, int(msg.get("buffered_amount") or 0))
            except Exception:
                buffered_amount = 0
            healthy = False
            conn.last_probe_state = state or "unknown"
            conn.last_probe_buffered_amount = buffered_amount
            if probe_id != conn.probe_id or nonce != conn.probe_nonce:
                if state == "ready" and buffered_amount < 512 * 1024:
                    healthy = True
                    conn.probe_failures = 0
                    conn.last_probe_ok_at = now
                    logger.info(
                        "extension probe late ready ack accepted as transport proof | %s buffered=%s failures=%s",
                        self._account_label(conn.chat_id, conn.account_id),
                        buffered_amount,
                        conn.probe_failures,
                    )
                    await self._push_state(conn.chat_id)
                else:
                    conn.probe_failures += 1
                    logger.warning(
                        "extension probe bad ack | %s state=%s failures=%s",
                        self._account_label(conn.chat_id, conn.account_id),
                        conn.last_probe_state,
                        conn.probe_failures,
                    )
            else:
                rtt_ms = max(0.0, (now - float(conn.probe_sent_at or now)) * 1000.0)
                healthy = state == "ready" and buffered_amount < 512 * 1024
                conn.last_ping_rtt_ms = rtt_ms
                conn.last_ping_ms = max(0.0, rtt_ms / 2.0)
                conn.probe_id = ""
                conn.probe_nonce = ""
                conn.probe_sent_at = 0.0
                conn.probe_deadline_at = 0.0
                if healthy:
                    conn.probe_failures = 0
                    conn.last_probe_ok_at = now
                else:
                    conn.probe_failures += 1
                    logger.warning(
                        "extension probe degraded | %s state=%s buffered=%s failures=%s",
                        self._account_label(conn.chat_id, conn.account_id),
                        state or "-",
                        buffered_amount,
                        conn.probe_failures,
                    )
                await self._push_state(conn.chat_id)
            waiter = conn.probe_waiter
            if waiter and not waiter.done():
                waiter.set_result(bool(healthy))
            return
        if typ == "client_ping":
            await conn.ws.send_json({
                "type": "client_pong",
                "ping_id": msg.get("ping_id"),
                "server_ts_ms": int(time.time() * 1000),
                "client_ts_ms": msg.get("client_ts_ms"),
            })
            return
        if typ == "account_info":
            current_acc = get_user_account(conn.chat_id, conn.account_id) or {}
            port_user_id = str(msg.get("port_user_id") or "").strip()
            port_user_name = str(msg.get("port_user_name") or "").strip()[:255]
            current_domain = str(msg.get("current_domain") or "").strip().rstrip("/")
            patch: dict[str, Any] = {}
            if (
                port_user_id.isdigit()
                and int(port_user_id) > 1000
                and port_user_id != str(current_acc.get("port_user_id") or "").strip()
            ):
                patch["port_user_id"] = port_user_id
            if port_user_name and port_user_name != str(current_acc.get("port_user_name") or "").strip():
                patch["port_user_name"] = port_user_name
            if (
                current_domain.startswith("https://")
                and current_domain != str(current_acc.get("extension_current_domain") or "").strip().rstrip("/")
            ):
                patch["extension_current_domain"] = current_domain[:255]
                patch["extension_current_domain_ts"] = int(time.time())
            if patch:
                patch_user_account(conn.chat_id, conn.account_id, **patch)
                await self._push_state(conn.chat_id)
            return
        if typ == "subscription_check":
            await conn.ws.send_json({
                "type": "subscription_update",
                **get_extension_entitlement(conn.chat_id, conn.account_id, installation_id=conn.installation_id),
            })
            return
        if typ == "pong":
            sent = float(msg.get("server_ts_ms") or 0) / 1000.0
            if sent > 0:
                rtt_ms = max(0.0, (time.time() - sent) * 1000.0)
                conn.last_ping_rtt_ms = rtt_ms
                conn.last_ping_ms = max(0.0, rtt_ms / 2.0)
                await self._push_state(conn.chat_id)
            return
        if typ == "managed_tab_reload_result":
            request_id = str(msg.get("request_id") or "").strip()
            fut = self._control_pending.get(request_id)
            if fut and not fut.done():
                fut.set_result(dict(msg))
            return
        if typ == "chat_ai_result":
            task_id = str(msg.get("task_id") or "").strip()
            attempt = max(1, int(msg.get("attempt") or 1))
            result_epoch = max(0, int(msg.get("mode_epoch") or 0))
            pending_key = f"{task_id}:{attempt}"
            fut = self._chat_ai_pending.get(pending_key)
            account = get_user_account(int(conn.chat_id), str(conn.account_id)) or {}
            current_mode = str(account.get("promo_activation_mode") or "server").strip().lower()
            current_epoch = max(0, int(account.get("runtime_mode_epoch") or 0))
            accepted = bool(
                fut
                and not fut.done()
                and current_mode == "extension"
                and result_epoch == current_epoch
            )
            if accepted:
                fut.set_result(dict(msg))
            with contextlib.suppress(Exception):
                await conn.ws.send_json({
                    "type": "chat_ai_result_ack",
                    "task_id": task_id,
                    "attempt": attempt,
                    "mode_epoch": result_epoch,
                    "server_ts_ms": int(time.time() * 1000),
                    "accepted": accepted,
                    "terminal": not accepted,
                    "status": "accepted" if accepted else "wrong_activation_mode",
                })
            return
        if typ in {"train_task_ack", "train_progress", "train_result"}:
            if typ == "train_task_ack":
                task_id = str(msg.get("task_id") or "").strip()
                if task_id:
                    conn.train_task_ids.add(task_id)
            result = await self._emit_train_event(conn, msg)
            if typ == "train_result":
                await conn.ws.send_json({
                    "type": "train_result_ack",
                    "task_id": msg.get("task_id"),
                    "join_id": msg.get("join_id"),
                    "server_ts_ms": int(time.time() * 1000),
                    **result,
                })
            return
        if typ == "promo_notify":
            task_id = str(msg.get("task_id") or "").strip()
            promo = str(msg.get("promo") or "-").strip().upper()
            status = str(msg.get("status") or "").strip().lower()
            message = " ".join(str(msg.get("message") or msg.get("reason") or "").split())[:300]
            source = str(msg.get("result_source") or "casino_ws_user_notify").strip() or "casino_ws_user_notify"

            if status == "queued":
                logger.info(
                    "[EXT_PROMO] %s userNotify: %s promo=%s task_id=%s source=%s",
                    self._account_label(conn.chat_id, conn.account_id),
                    message or "Отправлено в очередь...",
                    promo,
                    task_id or "-",
                    source,
                )
            else:
                logger.info(
                    "[EXT_PROMO] %s notify status=%s promo=%s task_id=%s message=%s source=%s",
                    self._account_label(conn.chat_id, conn.account_id),
                    status or "unknown",
                    promo,
                    task_id or "-",
                    message or "-",
                    source,
                )
            return

        if typ == "promo_task_ack":
            task_id = str(msg.get("task_id") or "").strip()
            is_new = bool(task_id and task_id not in conn.promo_task_ids)
            if task_id:
                conn.promo_task_ids.add(task_id)
            if is_new:
                logger.info(
                    "[EXTENSION_PROMO] %s promo=%s stored task_id=%s",
                    self._account_label(conn.chat_id, conn.account_id),
                    str(msg.get("promo") or "-").strip().upper(),
                    task_id,
                )
            return
        if typ != "promo_result":
            return

        task_id = str(msg.get("task_id") or "").strip()
        fut = self._pending.get(task_id)
        known = bool(fut)
        if fut and not fut.done():
            fut.set_result(msg)

        now = time.time()
        for old_id, seen_at in list(self._seen_promo_result_ids.items()):
            if now - float(seen_at or 0) > 2 * 60 * 60:
                self._seen_promo_result_ids.pop(old_id, None)
        first_seen = bool(task_id and task_id not in self._seen_promo_result_ids)
        if task_id:
            self._seen_promo_result_ids[task_id] = now

        if not known and task_id and first_seen:
            reason = " ".join(str(msg.get("reason") or msg.get("message") or "").split())[:300]
            logger.info(
                    "[EXTENSION_PROMO] %s promo=%s late_result status=%s source=%s amount=%s reason=%s task_id=%s latency_ms=%s",
                    self._account_label(conn.chat_id, conn.account_id),
                    str(msg.get("promo") or "-").strip().upper(),
                    str(msg.get("status") or "unknown").strip().lower(),
                    str(msg.get("result_source") or "extension"),
                    msg.get("amount"),
                    reason or "-",
                    task_id,
                    int(msg.get("latency_ms") or 0),
                )

        await conn.ws.send_json({
            "type": "promo_result_ack",
            "task_id": task_id,
            "server_ts_ms": int(time.time() * 1000),
            "accepted": True,
            "terminal": not known,
            "status": "accepted" if known else "late_or_already_finished",
        })



    def is_online(self, chat_id: int, account_id: str | None = None, fingerprint: str | None = None) -> bool:
        cid = self._by_key.get(self._key(chat_id, account_id, fingerprint)) or self._by_key.get(self._key(chat_id, account_id, ""))
        return bool(cid and cid in self._connections)


    async def send_promo_task(self, *, chat_id: int, account_id: str, username: str, fingerprint: str, promo: str) -> dict[str, Any]:
        entitlement = get_extension_entitlement(int(chat_id), account_id)
        if not entitlement["active"]:
            return {"ok": False, "status": "extension_subscription_inactive", "message": "Подписка неактивна", **entitlement}
        if not entitlement.get("account_bound"):
            return {"ok": False, "status": "extension_not_bound", "message": "Расширение отвязано", **entitlement}
        conn = self._connection_for(int(chat_id), str(account_id))
        if not conn:
            return {"ok": False, "status": "extension_offline", "message": "Расширение не подключено"}
        if not self._ws_transport_open(conn):
            return {"ok": False, "status": "extension_offline", "message": "WebSocket расширения закрыт", **entitlement}
        loop = asyncio.get_running_loop()
        task_id = uuid.uuid4().hex
        fut = loop.create_future()
        self._pending[task_id] = fut
        sent_ms = int(time.time() * 1000)
        promo_code = str(promo or "").upper()
        payload = {
            "type": "promo_task",
            "task_id": task_id,
            "promo": promo_code,
            "chat_id": int(chat_id),
            "username": username,
            "account_id": account_id,
            "fingerprint": fingerprint,
            "sent_at_ms": sent_ms,
            "subscription_active": entitlement["active"],
            "subscription_until_ts": entitlement["subscription_until_ts"],
        }
        deadline = loop.time() + self.promo_timeout_sec
        last_error = ""
        try:
            while True:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    return {
                        "ok": False,
                        "status": "extension_timeout",
                        "message": "Расширение не ответило вовремя",
                        "sent_at_ms": sent_ms,
                        "task_id": task_id,
                        "promo": promo_code,
                        "result_source": "server_timeout",
                        "server_wait_ms": max(0, int(time.time() * 1000) - sent_ms),
                    }
                conn = self._connection_for(int(chat_id), str(account_id))
                if conn and task_id not in conn.promo_task_ids:
                    try:
                        if self._ws_transport_open(conn):
                            await conn.ws.send_json(payload)
                    except Exception as exc:
                        last_error = f"{type(exc).__name__}: {exc}"
                        await self._close_failed_transport(conn, reason="promo send failed")
                try:
                    result = await asyncio.wait_for(asyncio.shield(fut), timeout=min(5.0, remaining))
                    result.setdefault("sent_at_ms", sent_ms)
                    result.setdefault("task_id", task_id)
                    result.setdefault("promo", promo_code)
                    result.setdefault("server_wait_ms", max(0, int(time.time() * 1000) - sent_ms))
                    return {"ok": str(result.get("status") or "").lower() == "success", **result}
                except asyncio.TimeoutError:
                    continue
        except Exception as exc:
            return {
                "ok": False,
                "status": "extension_error",
                "message": last_error or f"{type(exc).__name__}: {exc}",
                "sent_at_ms": sent_ms,
                "task_id": task_id,
                "promo": promo_code,
                "result_source": "server_error",
                "server_wait_ms": max(0, int(time.time() * 1000) - sent_ms),
            }
        finally:
            self._pending.pop(task_id, None)
            for conn in list(self._connections.values()):
                conn.promo_task_ids.discard(task_id)

    async def heartbeat(self, conn: ExtensionConnection, *, interval_sec: float = 15.0, stale_sec: float = 45.0) -> None:
        while True:
            await asyncio.sleep(interval_sec)
            now = time.time()
            if now - conn.last_seen > stale_sec:
                with contextlib.suppress(Exception):
                    await conn.ws.close(code=4001, reason="stale")
                return
            entitlement = get_extension_entitlement(
                conn.chat_id,
                conn.account_id,
                installation_id=conn.installation_id,
            )
            with contextlib.suppress(Exception):
                await conn.ws.send_json({
                    "type": "ping",
                    "server_ts_ms": int(time.time() * 1000),
                    "server_ping_ms": (round(float(conn.last_ping_ms), 1) if conn.last_ping_ms is not None else None),
                    "server_ping_rtt_ms": (round(float(conn.last_ping_rtt_ms), 1) if conn.last_ping_rtt_ms is not None else None),
                    **entitlement,
                })
            if entitlement["active"] and entitlement.get("device_matches"):
                if not self._ws_transport_open(conn):
                    return

                with contextlib.suppress(Exception):
                    await self.send_pending_train_tasks(conn)
                continue
            with contextlib.suppress(Exception):
                await conn.ws.send_json({"type": "subscription_update", **entitlement})
            code = 4003 if not entitlement["active"] else 4005 if entitlement.get("bound_elsewhere") else 4004
            with contextlib.suppress(Exception):
                await conn.ws.close(code=code)
            return
