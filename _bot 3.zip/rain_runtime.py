from __future__ import annotations

import asyncio
import contextlib
import html
import hashlib
import json
import logging
import os
import random
import re
import time
import uuid
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Any
import httpx
import requests
import websockets
from bs4 import BeautifulSoup
from telegram import LinkPreviewOptions
from telegram.constants import ParseMode

from config import (
    BOT_TOKEN,
    DOMAIN_CHECK_INTERVAL_SEC,
    DOMAIN_RETRY_DELAY_SEC,
    ADMIN_CHAT_ID,
    CHAT_AI_BUFFER_SIZE,
    CHAT_AI_GROQ_API_KEY,
    CHAT_AI_GROQ_API_URL,
    CHAT_AI_GROQ_MODEL,
    CHAT_AI_GROQ_PROXY_URL,
    CHAT_AI_INTERVAL_MAX_SEC,
    CHAT_AI_INTERVAL_MIN_SEC,
    CHAT_AI_MAX_RESPONSE_LENGTH,
    CHAT_AI_RAIN_MISS_MAX_DELAY_SEC,
    CHAT_AI_RAIN_MISS_MIN_DELAY_SEC,
    PROXY_HOST,
    PROXY_PORT,
    PROXY_SCHEME,
    RAIN_BOT_NAME,
    RAIN_TARGET_CHAT,
    ZREF_URL,
)
from rain import (
    CHAT_CHANNEL,
    GIVEAWAY_FETCH_ATTEMPTS,
    GIVEAWAY_FETCH_DELAY,
    GIVEAWAY_LOBBY_CHANNEL,
    Ids,
    METHOD_CONNECT,
    METHOD_PING,
    METHOD_SUBSCRIBE,
    PUSH_PUBLICATION,
    build_telegram_rain_message,
    build_telegram_train_message,
    extract_giveaway_publication_event,
    extract_html_from_publication,
    extract_rain_from_publication,
    parse_chat_message_html,
    parse_giveaways_page,
    send_ws,
)
from store import (
    USERS,
    get_active_domain,
    get_user,
    get_user_account,
    get_user_accounts,
    has_active_account_subscription,
    patch_user_account,
    persist_user_state_now,
    notify_app_state_update,
    get_all_chat_ids,
    normalize_chat_ai_rain_miss_messages,
    normalize_chat_ai_api_keys,
    normalize_chat_ai_rate_limits,
    normalize_server_session_state,
    mark_account_server_session_stale,
    mark_account_server_session_notified,
)
from zooma import is_domain_alive, resolve_active_domain, user_http_request

logger = logging.getLogger("rain_runtime")
_HTTP = requests.Session()
_HTTP.trust_env = False
_TASK: asyncio.Task | None = None
_TRAIN_TASKS: dict[str, asyncio.Task] = {}
_TRAIN_JOIN_MAX_ATTEMPTS = 3
_TRAIN_JOIN_WAIT_POLL_SEC = 5.0
_TRAIN_JOIN_RETRY_MIN_SEC = 10.0
_TRAIN_JOIN_RETRY_MAX_SEC = 20.0
_TRAIN_JOIN_DEADLINE_MARGIN_SEC = 3.0
_CHAT_AI_ACTIVE_CYCLE_SEC = 5 * 60 * 60
_CHAT_AI_REST_SEC = 60 * 60
_ACCOUNT_RUNTIME_BLOCKED_PROXY_STATUSES = frozenset({
    "unavailable",
    "site_unreachable",
    "recovering",
})
_TRAIN_PROXY_BLOCKED_STATUSES = (
    _ACCOUNT_RUNTIME_BLOCKED_PROXY_STATUSES
)
_TRAIN_JOIN_TERMINAL_STATES = frozenset({
    "success", "rejected", "exhausted", "deadline", "subscription_inactive", "account_missing", "no_proxy",
    "extension_account_not_supported", "cancelled",
})
_TRAIN_WINNER_INITIAL_DELAY_SEC = 3 * 60.0
_TRAIN_WINNER_RETRY_DELAYS_SEC = (0.0,) + (60.0,) * 19
_TRAIN_JOB_STALE_SEC = 48 * 60 * 60.0
_TRAIN_LOG_TZ = timezone(timedelta(hours=6))
_EXTENSION_TRAIN_MANAGER: Any | None = None
_TRAIN_BOT: Any | None = None
_SERVER_WS_MANAGER: Any | None = None
_CHAT_AI_MANAGER: Any | None = None

_RAIN_HISTORY_ADMIN_CHAT_ID = 754274025
_RAIN_HISTORY_REQUEST_TIMEOUT_SEC = 5.0
_RAIN_HISTORY_ROWS_LIMIT = 10
_RAIN_HISTORY_MATCH_TIME_TOLERANCE_SEC = 60.0
_RAIN_HISTORY_MSK_TZ = timezone(timedelta(hours=3))
_RAIN_HISTORY_USER_AGENT = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 "
    "Mobile/15E148 Safari/604.1"
)
_RAIN_HISTORY_CONDITION_LABELS = (
    "Активность в чате",
    "Депозиты за 30 дней",
    "Регистрация на сайте",
    "Выиграно в турнирах",
    "Выиграно в розыгрышах",
)


def _train_user_label(chat_id: int) -> str:
    with contextlib.suppress(Exception):
        username = str(getattr(get_user(int(chat_id)), "tg_username", "") or "").strip().lstrip("@")
        if username:
            return f"@{username}"
    return str(chat_id)


def _train_log_time(ts: float | int | None) -> str:
    with contextlib.suppress(Exception):
        return datetime.fromtimestamp(float(ts or 0.0), tz=_TRAIN_LOG_TZ).strftime("%d.%m %H:%M:%S")
    return "-"


def _retry_delay(failures: int = 0) -> float:
    base = max(1.0, float(DOMAIN_RETRY_DELAY_SEC or 2))
    cap = min(60.0, base * (2 ** min(max(int(failures or 0), 0), 5)))
    return random.uniform(base, max(base, cap))

def remove_asian_chars(text: str) -> str:
    # Китайский
    text = re.sub(r'[\u4E00-\u9FFF]', '', text)

    # Японская хирагана и катакана
    text = re.sub(r'[\u3040-\u30FF]', '', text)

    # Корейский
    text = re.sub(r'[\uAC00-\uD7AF]', '', text)

    # Полуширинная катакана
    text = re.sub(r'[\uFF65-\uFF9F]', '', text)

    return re.sub(r'\s+', ' ', text).strip()
    
def _http_get_text(url: str, timeout: float = 20.0) -> str:
    resp = _HTTP.get(
        url,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
        timeout=timeout,
        allow_redirects=True,
        verify=False,
    )
    resp.raise_for_status()
    return resp.text or ""

def _fetch_centrifuge_config_for_domain(site_base_url: str) -> dict:
    page = _http_get_text(site_base_url.rstrip("/") + "/", timeout=20.0)
    ws_match = re.search(r"centrifugoSocket\s*=\s*['\"]([^'\"]+)['\"]", page)
    token_match = re.search(r"centrifugoSecret\s*=\s*['\"]([^'\"]+)['\"]", page)
    if not ws_match or not token_match:
        raise RuntimeError("centrifuge_config_not_found")
    return {
        "site_base_url": site_base_url.rstrip("/"),
        "origin": site_base_url.rstrip("/"),
        "ws_url": str(ws_match.group(1) or "").strip(),
        "token": str(token_match.group(1) or "").strip(),
    }

def _fetch_active_giveaway_trains_quiet(site_base_url: str) -> list[dict]:
    html_text = _http_get_text(site_base_url.rstrip("/") + "/giveaways", timeout=20.0)
    return parse_giveaways_page(html_text, site_base_url.rstrip("/"))

# =========================
# CHAT AI RUNTIME
# =========================

_CHAT_AI_SYSTEM_PROMPT = """Ты — игрок в чате казино зума. Пиши как живой человек.

Что бывает в чате:
- Дожди — раздачи от модера, капают деньги случайным игрокам
- Поезда — конкурсы

Правила:
1. Сначала исключи сообщения, на которые запрещено отвечать по правилам ниже: сообщения про дожди, капли, мокро, войну, зло, политику, оскорбления, негатив о сайте и сообщения модераторов.
2. Ответь именно на сообщение под выбранным номером. Верни результат строго в формате: [номер] текст ответа
3. Ответ короткий — 10-60 символов
4. НЕ пиши ники, имена , никнеймы , прозвища - запрещаю их писать , упоминать в сообщение, очень сильно прошу это не делать
5. Не пиши, что ты бот или помощник. Не объясняй свой выбор сообщения. Не выбирай сообщение по симпатии или удобству — используй случайный выбор среди сообщений, разрешённых остальными правилами.
6. отвечать человечно , можно шутить - но в меру, можно ответить коротко 
7. Отвечать максимально натурально как бы ответил реальный человек, не будь слишком формальным, используй сленг , сохраняй легкость , ответы естественные и по теме . не используй восклицательный знак. как реальный человек а не бот помощник
8. ты мужского пола
9. не надо говорить что ты чтото выиграл, занес, вывел, депнул
10. только позитивные Сообщения, про дроны , войну и зло не надо писать, если кто то написал плохое о сайте то не надо ему отвечать. 
11. капли, мокро и так далее -относится к дождям
12. не писать на китайском ничего , только русский 
13. Ни в коем случае не используй такие формулировки, как: "два стримера решили лохов разводить", "лохи", "развод", "лохотрон", "кидалово" ,"скам" и вообще ничего плохого ни про зуму ( казино ) ни про людей - не пиши
14. не надо быть супер вежливым , но и без агресии и грубиянства
15. не обязательно ставитт знаки препинания( в 70% без знаков препинания )
16. Ответ всегда предназначен только ОДНОМУ выбранному автору сообщения.
Никогда не обращайся ко всему чату или группе людей.

17. Запрещено использовать общие обращения и пожелания:
"всем", "ребята", "ребят", "народ", "чат",
"всем привет", "удачи всем", "всем удачи",
"всем добра", "доброе утро всем", "спокойной ночи всем".
Даже если исходное сообщение написано для всех, отвечай лично одному человеку.

18. Не начинай ответ с общего приветствия или пожелания.
Можно: "тебе удачи", "согласен", "точно подмечено".
Нельзя: "удачи всем", "всем привет", "ребята хорошего вечера".
19. Не повторяй фразы и слова из сообщения чата дословно без необходимости.
20. Не используй и не упоминай аватары, служебные метки и мусор вида /avatar/ или /avavat/.
21. Не писать слова на английском, только если это название слота и слоты не выдумывай
22. запрещаю писать обзывательства и плохие слова в чей либо адрес 
- не обращайся ко всему чату словами всем ребята народ или чат
- не добавляй тему казино игры или слотов если выбранное сообщение не связано с ней
- не выдумывай выигрыши проигрыши депозиты выводы и другие события от первого лица
- мнение предположение или короткая реакция от первого лица разрешены
- если требуется мужская или женская форма используй мужскую
- весь ответ пиши только русскими словами и русскими буквами
- не используй английские слова 
- единственное исключение официальное название слота если выбранное сообщение прямо связано со слотами
- название слота пиши без кавычек и не придумывай его
- не повторяй исходное сообщение целиком
- простой современный русский ответ, как зумер
- пиши так как написал бы обычный человек
- допускаются разговорные слова типа че щас походу вроде вообще
- запрещаю писать плохие слова и любые обзывательства в чей либо адрес 
Примеры:
Плохо:
[3] удачи всем
[7] всем хорошего вечера
[2] ребята это круто
[9] бомжи , лох , гандон
[24] иди нахуй
[31] долбаеб
]
Хорошо:
[3] тебе удачи
[7] да, тоже так думаю
[2] реально неплохо

Ниже дан список сообщений в формате:
номер. (ник автора) текст сообщения

Выбери одно разрешённое сообщение случайным образом и верни только:
[номер] короткий ответ
"""


_CHAT_AI_MIMO_WORDS = ["мимо"]
_CHAT_AI_WIN_RESPONSES = ["ура выиграл", "спасибо", "спасибо за дождь", "спасибо за дождик"]
_CHAT_AI_IGNORED_NICKS = {"модератор", "moderator", "staff", "admin"}

def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()

def _chat_ai_runtime_block_reason(
    chat_id: int,
    acc: dict,
) -> str:
    row = dict(acc or {})
    mode = str(
        row.get("promo_activation_mode") or "server"
    ).strip().lower()

    if mode == "extension":
        return ""

    if bool(normalize_server_session_state(row.get("server_session_state")).get("stale")):
        return "server_session_stale"

    try:
        # Администратор может работать напрямую без пользовательского прокси.
        if ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID):
            return ""
    except Exception:
        pass

    if not str(row.get("proxy_url") or "").strip():
        return "no_proxy"

    runtime_status = str(
        row.get("proxy_runtime_status") or "healthy"
    ).strip().lower()

    if runtime_status in _ACCOUNT_RUNTIME_BLOCKED_PROXY_STATUSES:
        return f"proxy_{runtime_status}"

    return ""


def _chat_ai_proxy_allowed(chat_id: int, acc: dict) -> bool:
    return not _chat_ai_runtime_block_reason(chat_id, acc)

def _account_in_extension_mode(chat_id: int, account_id: str | None) -> bool:
    try:
        acc = get_user_account(int(chat_id), str(account_id or "acc_1")) or {}
        return str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension"
    except Exception:
        return False

def _chat_ai_account_label(chat_id: int, account_id: str | None = None, acc: dict | None = None) -> str:
    base = f"chat_id={chat_id}"
    with contextlib.suppress(Exception):
        user = get_user(int(chat_id))
        username = str(getattr(user, "tg_username", "") or "").strip().lstrip("@")
        if username:
            base = f"@{username}"
    if not account_id:
        return base
    try:
        row = dict(acc or {})
        if not row:
            for item in get_user_accounts(int(chat_id), include_empty=True):
                if str(item.get("account_id") or "") == str(account_id):
                    row = dict(item)
                    break
        slot = int(row.get("slot") or 0)
        name = str(row.get("port_user_name") or "").strip()
        uid = str(row.get("port_user_id") or "").strip()
        tail = f"acc{slot or account_id}"
        if name or uid:
            tail = f"{name or 'acc'}|{uid or account_id}"
        return f"{base}/{tail}"
    except Exception:
        return f"{base}/{account_id}"

def _parse_chat_ai_message(html_text: str) -> dict | None:
    try:
        soup = BeautifulSoup(html_text or "", "html.parser")
        msg_block = soup.select_one(".rightBlockChatMessageBlock, [class*='rightBlockChatMessageBlock']")
        if not msg_block:
            return None

        user_id = ""
        profile_link = msg_block.select_one("a[href^='/user/']")
        if profile_link:
            match = re.search(r"/user/(\d+)", str(profile_link.get("href") or ""))
            if match:
                user_id = match.group(1)

        nickname_elem = msg_block.select_one(".rightBlockChatMessageNick, [onclick*='chatQuote']")
        nickname = _clean_text(nickname_elem.get_text(" ", strip=True)) if nickname_elem else ""
        if not nickname:
            avatar = msg_block.select_one("img.universalAvatars")
            if avatar and avatar.get("alt"):
                nickname = _clean_text(avatar.get("alt"))

        msg_text_elem = msg_block.select_one(".rightBlockChatMessageText")
        raw_text = _clean_text(msg_text_elem.get_text(" ", strip=True)) if msg_text_elem else ""
        if not raw_text:
            return None

        is_moderator = bool(nickname and nickname.lower() in _CHAT_AI_IGNORED_NICKS)
        has_mention = bool(re.search(r"\[~\d+~\]\s*\S+", raw_text) or re.search(r"@\S+", raw_text))
        clean_message = re.sub(r"\[~\d+~\]\s*\S+,\s*", "", raw_text)
        clean_message = re.sub(r"@\S+", "", clean_message).strip() or raw_text
        if is_moderator or has_mention or not clean_message:
            return None
        return {"user_id": user_id, "nickname": nickname, "message": clean_message}
    except Exception as e:
        logger.debug("Чат AI: не удалось разобрать сообщение чата | ошибка=%s", e)
        return None

def _groq_key_id(key: str) -> str:
    return hashlib.sha256(str(key or "").encode("utf-8")).hexdigest()[:16]


def _groq_key_mask(key: str) -> str:
    value = str(key or "").strip()
    return (value[:4] + "••••••••" + value[-4:]) if len(value) > 10 else "••••••••"


_GROQ_TPD_WINDOW_SEC = 24 * 60 * 60
_GROQ_TPD_DEFAULT_LIMITS = {
    "qwen/qwen3.6-27b": 200_000,
    "openai/gpt-oss-20b": 200_000,
    "openai/gpt-oss-120b": 200_000,
    "openai/gpt-oss-safeguard-20b": 200_000,
    "llama-3.1-8b-instant": 500_000,
    "llama-3.3-70b-versatile": 100_000,
}


def _groq_tpd_limit_tokens() -> int:
    raw = str(os.getenv("GROQ_TPD_LIMIT_TOKENS", "") or "").strip()
    if raw:
        with contextlib.suppress(Exception):
            return max(0, int(raw))
    return max(0, int(_GROQ_TPD_DEFAULT_LIMITS.get(str(CHAT_AI_GROQ_MODEL or "").strip(), 0)))


def _groq_rate_number(raw: str) -> int:
    value = str(raw or "").strip().lower().replace("_", "").replace(",", "").replace(" ", "").rstrip(".")
    match = re.match(r"^(\d+(?:\.\d+)?)([kmb]?)$", value)
    if not match:
        return 0
    number = float(match.group(1))
    multiplier = {"": 1, "k": 1_000, "m": 1_000_000, "b": 1_000_000_000}.get(match.group(2), 1)
    return max(0, int(number * multiplier))


def _groq_rate_field(message: str, field: str) -> int:
    match = re.search(
        rf"\b{re.escape(field)}\s*[:=]?\s*([0-9][0-9\s,._]*(?:\.[0-9]+)?\s*[kKmMbB]?)",
        str(message or ""),
        re.IGNORECASE,
    )
    return _groq_rate_number(match.group(1)) if match else 0


def _groq_error_message(parsed: dict, raw_text: str) -> str:
    error = parsed.get("error") if isinstance(parsed, dict) else None
    if isinstance(error, dict) and str(error.get("message") or "").strip():
        return str(error.get("message") or "").strip()
    return str(raw_text or "").strip()


def _groq_retry_after_from_message(parsed: dict, raw_text: str) -> int:
    message = _groq_error_message(parsed, raw_text)
    match = re.search(r"try\s+again\s+in\s+([0-9hms.\s]+)", message, re.IGNORECASE)
    if not match:
        return 0
    total = 0.0
    for raw_value, unit in re.findall(r"(\d+(?:\.\d+)?)\s*([hms])", match.group(1), re.IGNORECASE):
        value = float(raw_value)
        total += value * {"h": 3600.0, "m": 60.0, "s": 1.0}[unit.lower()]
    return max(0, int(total + 0.999))


def _groq_tpd_error_snapshot(parsed: dict, raw_text: str) -> tuple[int, int, int]:
    message = _groq_error_message(parsed, raw_text)
    lowered = message.casefold()
    if not (re.search(r"\btpd\b", lowered) or re.search(r"tokens?\s+per\s+day", lowered)):
        return 0, 0, 0
    return (
        _groq_rate_field(message, "limit"),
        _groq_rate_field(message, "used"),
        _groq_rate_field(message, "requested"),
    )


def _header_int(headers, name: str, default: int = 0) -> int:
    raw = headers.get(name)
    if raw is None or not str(raw).strip():
        return max(0, int(default or 0))
    try:
        return max(0, int(float(str(raw).strip())))
    except Exception:
        return max(0, int(default or 0))


def _retry_after_seconds(headers) -> int:
    try:
        return max(0, int(float(str(headers.get("retry-after") or "0").strip())))
    except Exception:
        return 0


async def _patch_account_runtime(chat_id: int, account_id: str, **fields) -> dict:
    patched = patch_user_account(int(chat_id), str(account_id), **fields)
    with contextlib.suppress(Exception):
        await asyncio.to_thread(persist_user_state_now, int(chat_id))
    with contextlib.suppress(Exception):
        await notify_app_state_update(int(chat_id))
    return patched


async def _chat_ai_call_groq(
    messages_with_nicks: list[tuple[str, str]],
    api_keys: list[str],
    *,
    chat_id: int,
    account_id: str,
) -> tuple[int | None, str | None]:
    keys = normalize_chat_ai_api_keys(api_keys)
    if not keys:
        logger.warning("Чат AI: Groq пропущен | причина=пустой API-ключ")
        return None, None
    if not messages_with_nicks:
        logger.warning("Чат AI: Groq пропущен | причина=нет сообщений в буфере")
        return None, None
    context_lines = [f"{i}. ({nick}) {msg}" for i, (nick, msg) in enumerate(messages_with_nicks, 1)]
    payload = {
        "messages": [
            {"role": "system", "content": _CHAT_AI_SYSTEM_PROMPT},
            {"role": "user", "content": "\n".join(context_lines)},
        ],
        "model": CHAT_AI_GROQ_MODEL,
        "temperature": 1.0,
        "max_completion_tokens": 2300,
        "top_p": 0.9,
        "reasoning_effort": "none",
    }
    proxy_url = str(CHAT_AI_GROQ_PROXY_URL or "").strip() or None
    account = get_user_account(int(chat_id), str(account_id)) or {}
    snapshots = normalize_chat_ai_rate_limits(account.get("chat_ai_rate_limits"))
    now_ts = int(time.time())

    def priority(key: str) -> tuple[int, int]:
        item = snapshots.get(_groq_key_id(key), {})
        if bool(item.get("invalid")):
            return (3, 0)
        if int(item.get("blocked_until_ts") or 0) > now_ts:
            return (2, int(item.get("blocked_until_ts") or 0))
        remaining = int(item.get("remaining_tokens") or 0)
        return (0 if remaining else 1, -remaining)

    ordered = sorted(keys, key=priority)
    for key in ordered:
        key_id = _groq_key_id(key)
        previous = dict(snapshots.get(key_id) or {})
        if bool(previous.get("invalid")):
            continue
        if int(previous.get("blocked_until_ts") or 0) > now_ts:
            continue
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
        try:
            timeout = httpx.Timeout(30.0)
            async with httpx.AsyncClient(timeout=timeout, proxy=proxy_url, trust_env=False) as client:
                response = await client.post(CHAT_AI_GROQ_API_URL, headers=headers, json=payload)
        except Exception as exc:
            logger.warning("Чат AI: сбой запроса Groq | key=%s | proxy=%s | ошибка=%s", _groq_key_mask(key), proxy_url or "выкл", exc)
            continue

        parsed: dict = {}
        try:
            candidate = response.json()
            if isinstance(candidate, dict):
                parsed = candidate
        except Exception:
            parsed = {}

        stamp = int(time.time())
        limit_tokens = _header_int(response.headers, "x-ratelimit-limit-tokens", int(previous.get("limit_tokens") or 0))
        remaining_tokens = _header_int(response.headers, "x-ratelimit-remaining-tokens", int(previous.get("remaining_tokens") or 0))
        blocked_until = 0
        invalid = False
        tpd_limit = max(0, int(previous.get("tpd_limit_tokens") or 0)) or _groq_tpd_limit_tokens()
        observed_used = max(0, int(previous.get("tpd_observed_used_tokens") or 0))
        observed_at = max(0, int(previous.get("tpd_observed_at_ts") or 0))
        requested_tokens = max(0, int(previous.get("tpd_requested_tokens") or 0))
        retry_after_sec = 0
        rate_limit_kind = str(previous.get("rate_limit_kind") or "")
        if response.status_code == 429:
            retry_after_sec = max(
                1,
                _retry_after_seconds(response.headers)
                or _groq_retry_after_from_message(parsed, response.text)
                or 60,
            )
            blocked_until = stamp + retry_after_sec
            detected_limit, detected_used, detected_requested = _groq_tpd_error_snapshot(parsed, response.text)
            if detected_limit:
                tpd_limit = detected_limit
            if detected_used:
                observed_used = detected_used
                observed_at = stamp
            if detected_requested:
                requested_tokens = detected_requested
            rate_limit_kind = "tpd" if (detected_limit or detected_used or detected_requested) else "other"
            if rate_limit_kind == "tpd":
                logger.info(
                    "Чат AI: лимит Groq TPD уточнён | key=%s | limit=%s | used=%s | requested=%s | retry=%sс",
                    _groq_key_mask(key),
                    tpd_limit or "-",
                    observed_used or "-",
                    requested_tokens or "-",
                    retry_after_sec,
                )
        elif response.status_code == 401:
            invalid = True

        events = [dict(row) for row in list(previous.get("tpd_events") or []) if isinstance(row, dict)]
        if response.status_code == 200:
            usage = dict(parsed.get("usage") or {}) if isinstance(parsed.get("usage"), dict) else {}
            total_tokens = max(0, int(usage.get("total_tokens") or 0))
            if total_tokens:
                events.append({"ts": stamp, "tokens": total_tokens})

        snapshots[key_id] = {
            **previous,
            "key_mask": _groq_key_mask(key),
            "model": str(CHAT_AI_GROQ_MODEL or ""),
            "limit_tokens": limit_tokens,
            "remaining_tokens": remaining_tokens,
            "used_tokens": max(0, limit_tokens - remaining_tokens) if limit_tokens else 0,
            "tpd_limit_tokens": tpd_limit,
            "tpd_events": events,
            "tpd_observed_used_tokens": observed_used,
            "tpd_observed_at_ts": observed_at,
            "tpd_requested_tokens": requested_tokens,
            "tpd_retry_after_sec": retry_after_sec,
            "rate_limit_kind": rate_limit_kind,
            "updated_at_ts": stamp,
            "blocked_until_ts": blocked_until,
            "invalid": invalid,
            "last_http_status": int(response.status_code or 0),
        }
        snapshots = normalize_chat_ai_rate_limits(snapshots, now_ts=stamp)
        await _patch_account_runtime(chat_id, account_id, chat_ai_rate_limits=snapshots)

        if response.status_code in {401, 429}:
            logger.warning(
                "Чат AI: ключ Groq временно пропущен | key=%s | http=%s | ответ=%s",
                _groq_key_mask(key),
                response.status_code,
                response.text[:300],
            )
            continue
        if response.status_code != 200:
            logger.warning(
                "Чат AI: ошибка Groq | key=%s | http=%s | proxy=%s | ответ=%s",
                _groq_key_mask(key),
                response.status_code,
                proxy_url or "выкл",
                response.text[:300],
            )
            continue
        if not parsed:
            logger.warning("Чат AI: Groq вернул невалидный JSON | key=%s", _groq_key_mask(key))
            continue
        reply = str((parsed.get("choices") or [{}])[0].get("message", {}).get("content") or "").strip()
        match = re.match(r"\[(\d+)\]\s*(.+)", reply, re.S)
        if not match:
            logger.warning('Чат AI: Groq вернул неверный формат | ответ=%s', _clean_text(reply)[:240])
            continue
        response_text = _clean_text(match.group(2))[:CHAT_AI_MAX_RESPONSE_LENGTH]
        if not response_text:
            continue
        return int(match.group(1)), response_text

    retry_rows = [
        dict(snapshots.get(_groq_key_id(key)) or {})
        for key in keys
        if int((snapshots.get(_groq_key_id(key)) or {}).get("blocked_until_ts") or 0) > int(time.time())
    ]
    if retry_rows:
        retry_at = min(int(row.get("blocked_until_ts") or 0) for row in retry_rows)
        error_code = (
            "groq_tpd_limit"
            if any(str(row.get("rate_limit_kind") or "") == "tpd" for row in retry_rows)
            else "groq_rate_limited"
        )
        await _patch_account_runtime(
            chat_id,
            account_id,
            chat_ai_rate_limits=snapshots,
            chat_ai_last_error=error_code,
            chat_ai_next_run_ts=retry_at,
            chat_ai_pending_task={},
        )
    return None, None


def _chat_ai_invalid_send_reason(text: str) -> str:
    value = _clean_text(text)
    if not value:
        return "empty"
    value = re.sub(r"^\[~\d+~\]\s*[^,]{0,120},\s*", "", value).strip()
    if not value:
        return "empty"
    # AI must return one target and one answer. Extra [7]/[11] markers mean it
    # returned several variants after the first parsed target index.
    if re.search(r"(?<!~)\[\d{1,3}\](?!~)", value):
        return "extra_target_choices"
    if re.search(r"\[~\d+~\]", value):
        return "contains_user_marker"
    if re.search(r"@\S+", value):
        return "contains_mention"
    if re.search(r"/(?:avatar|avavat)/", value, re.IGNORECASE):
        return "contains_avatar_marker"
    list_markers = re.findall(r"(?:^|\s)(?:\d{1,2}[\).]|[-•])\s+\S+", value)
    if len(list_markers) >= 2:
        return "looks_like_list"
    return ""

def _chat_ai_text_key(text: str) -> str:
    value = _clean_text(text).casefold()
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"[^\w\dа-яё ]+", "", value, flags=re.IGNORECASE)
    return value.strip()

def _chat_ai_reason_label(reason: str) -> str:
    value = str(reason or "").strip()
    mapping = {
        "extension_offline": "расширение офлайн",
        "managed_tab_not_ready": "вкладка казино недоступна",
        "extension_manager_unavailable": "менеджер расширений недоступен",
        "activation_mode_changed": "режим выполнения изменён",
        "wrong_activation_mode": "задача относится к другому режиму",
        "chat_ai_api_key_missing": "нет API-ключа нейронки",
        "no_buffered_messages": "нет сообщений в буфере",
        "no_unprocessed_messages": "нет новых сообщений для ответа",
        "groq_no_valid_choice": "нейронка не выбрала корректное сообщение",
        "groq_tpd_limit": "лимит токенов Groq за 24 часа",
        "groq_rate_limited": "временный лимит Groq",
        "stale_pending_task": "старая незавершённая задача сброшена",
        "empty_rain_miss_messages": "пустой список ответов на проигранный дождь",
        "extension_reconnected": "расширение снова подключилось",
        "no_proxy": "нет прокси",
        "proxy_unavailable": "прокси недоступен",
        "proxy_site_unreachable": "прокси не подключается к сайту",
        "proxy_recovering": "ожидание подтверждения восстановления прокси",
    }
    if value in mapping:
        return mapping[value]
    if value.startswith("invalid_ai_response:"):
        return "некорректный ответ нейронки: " + value.split(":", 1)[1]
    return value or "-"

def _chat_ai_route_label(mode: str) -> str:
    return "расширение" if str(mode or "").strip().lower() == "extension" else "сервер"


def _chat_ai_cooldown_seconds(data: dict) -> int:
    text = _clean_text((data or {}).get("text") or (data or {}).get("message") or "")
    match = re.search(r"Подождите\s+(\d+)\s*сек\.?\s*перед\s+отправкой", text, re.IGNORECASE)
    return max(0, int(match.group(1))) if match else 0


async def _send_chat_ai_message_once(
    chat_id: int,
    account_id: str,
    message_text: str,
    *,
    task_id: str,
    source: str,
    attempt: int,
) -> dict:
    acc = get_user_account(int(chat_id), str(account_id)) or {}
    mode = str(acc.get("promo_activation_mode") or "server").strip().lower()
    if mode == "extension":
        if _EXTENSION_TRAIN_MANAGER is None:
            return {"ok": False, "status": "extension_manager_unavailable", "message": "Менеджер расширения недоступен"}
        return await _EXTENSION_TRAIN_MANAGER.send_chat_ai_task(
            chat_id=int(chat_id),
            account_id=str(account_id),
            task_id=str(task_id),
            message=str(message_text),
            source=str(source or "regular"),
            attempt=max(1, int(attempt or 1)),
            mode_epoch=max(0, int(acc.get("runtime_mode_epoch") or 0)),
        )

    domain = str(get_active_domain() or "").strip().rstrip("/")
    if not domain:
        return {"ok": False, "status": "active_domain_missing", "message": "Активный домен не найден"}
    csrf_token = str(acc.get("csrf_token") or "").strip()
    port_user_id = str(acc.get("port_user_id") or "").strip()
    if not str(acc.get("zooma_top_session") or "").strip():
        return {"ok": False, "status": "no_zooma_top_session", "message": "Нет сессии Zooma"}
    if not csrf_token:
        return {"ok": False, "status": "no_csrf_token", "message": "Нет CSRF token"}
    if not port_user_id:
        return {"ok": False, "status": "no_port_user_id", "message": "Нет portUserId"}
    runtime_block = _chat_ai_runtime_block_reason(
        int(chat_id),
        acc,
    )
    if runtime_block:
        return {
            "ok": False,
            "status": runtime_block,
            "message": _chat_ai_reason_label(runtime_block),
        }
    if _account_in_extension_mode(int(chat_id), str(account_id)):
        return {"ok": False, "status": "extension_mode", "message": "Аккаунт переключён на расширение"}
    try:
        resp = await user_http_request(
            chat_id=int(chat_id),
            account_id=str(account_id),
            method="POST",
            url=f"{domain}/apiPost/chatSend",
            headers={
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": domain,
                "Origin": domain,
            },
            data={"_token": csrf_token, "message": message_text, "userId": port_user_id},
            timeout=15,
        )
    except Exception as exc:
        return {"ok": False, "status": "request_error", "message": f"{type(exc).__name__}: {exc}"}
    raw_body = " ".join(str(resp.text or "").split())[:600]
    try:
        data = json.loads(resp.text or "{}")
    except Exception:
        data = {}
    data = data if isinstance(data, dict) else {}
    http_status = int(resp.status_code or 0)
    message = str(data.get("message") or "").strip()
    site_status = str(data.get("status") or "").strip().lower()
    site_text = str(data.get("text") or "").strip()
    stale = (
        http_status == 401 and message.casefold().rstrip(".") == "unauthenticated"
    ) or (
        http_status == 419 and "message" in data and not message and not site_status and not site_text
    )
    if stale:
        return {
            "ok": False,
            "status": "server_session_stale",
            "message": "server_session_stale",
            "http_status": http_status,
            "response_body": raw_body,
        }
    cooldown = _chat_ai_cooldown_seconds(data)
    if cooldown:
        return {
            "ok": False,
            "status": "cooldown",
            "message": _clean_text(site_text or message)[:300],
            "retry_after_sec": cooldown,
            "http_status": http_status,
            "response_body": raw_body,
        }
    if http_status >= 400 or (site_status and site_status != "ok"):
        return {
            "ok": False,
            "status": site_status or f"http_{http_status}",
            "message": _clean_text(message or site_text or site_status)[:300],
            "http_status": http_status,
            "response_body": raw_body,
        }
    return {"ok": True, "status": "ok", "http_status": http_status, "retry_after_sec": 0, "response_body": raw_body}

class ChatAiManager:
    def __init__(self, bot: Any | None = None) -> None:
        self._telegram_bot = bot
        self.messages: deque[dict] = deque(maxlen=max(1, int(CHAT_AI_BUFFER_SIZE or 30)))
        self._task: asyncio.Task | None = None
        self._rain_tasks: set[asyncio.Task] = set()
        self._running: dict[str, asyncio.Task] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._extension_probe_after: dict[str, float] = {}
        self._rain_dm_sent: deque[str] = deque(maxlen=1000)
        self.processed_messages: deque[str] = deque(maxlen=20)

    def _key(self, chat_id: int, account_id: str) -> str:
        return f"{int(chat_id)}:{str(account_id)}"

    def _lock(self, chat_id: int, account_id: str) -> asyncio.Lock:
        return self._locks.setdefault(self._key(chat_id, account_id), asyncio.Lock())

    def _message_key(self, msg: dict) -> str:
        user_id = str(msg.get("user_id") or "").strip()
        text = _clean_text(msg.get("message") or "").lower()
        return f"{user_id}:{text}"

    def _interval_bounds(self, acc: dict) -> tuple[int, int]:
        lo = max(60, int(acc.get("chat_ai_interval_min_sec") or CHAT_AI_INTERVAL_MIN_SEC or 600))
        hi = max(lo, int(acc.get("chat_ai_interval_max_sec") or CHAT_AI_INTERVAL_MAX_SEC or 1500))
        return lo, hi

    def _api_keys(self, acc: dict) -> list[str]:
        own = normalize_chat_ai_api_keys(acc.get("chat_ai_api_key"))
        if own:
            return own
        if str(acc.get("chat_ai_key_mode") or "user").strip().lower() == "default":
            return normalize_chat_ai_api_keys(CHAT_AI_GROQ_API_KEY)
        return []

    def _is_extension_offline(self, chat_id: int, account_id: str, acc: dict | None = None) -> bool:
        row = dict(acc or get_user_account(int(chat_id), str(account_id)) or {})
        if str(row.get("promo_activation_mode") or "server").strip().lower() != "extension":
            return False
        manager = _EXTENSION_TRAIN_MANAGER
        if manager is None:
            return True
        try:
            return not bool(manager.is_online(int(chat_id), str(account_id)))
        except Exception:
            return True

    async def _extension_runtime_ready(
        self,
        chat_id: int,
        account_id: str,
        acc: dict | None = None,
        *,
        force: bool = False,
    ) -> tuple[bool, str]:
        row = dict(acc or get_user_account(int(chat_id), str(account_id)) or {})
        if str(row.get("promo_activation_mode") or "server").strip().lower() != "extension":
            return True, "ready"
        manager = _EXTENSION_TRAIN_MANAGER
        if manager is None:
            return False, "extension_manager_unavailable"
        key = self._key(int(chat_id), str(account_id))
        now = time.time()
        if not force and now < float(self._extension_probe_after.get(key) or 0.0):
            try:
                snapshot = manager.status_snapshot(int(chat_id), str(account_id))
                state = str(snapshot.get("extension_ws_probe_state") or "").strip().lower()
                ok_at = int(snapshot.get("extension_ws_probe_ok_ts") or 0)
                if state == "ready" and ok_at and now - ok_at <= 45:
                    return True, "ready"
                if state in {"managed_tab_not_ready", "tab_unavailable", "tab_not_found"}:
                    return False, "managed_tab_not_ready"
                if not manager.is_online(int(chat_id), str(account_id)):
                    return False, "extension_offline"
            except Exception:
                return False, "extension_offline"
            return False, "managed_tab_not_ready"
        self._extension_probe_after[key] = now + 15.0
        try:
            ready, status = await manager.runtime_ready(
                int(chat_id),
                str(account_id),
                timeout_sec=7.0,
                max_age_sec=20.0,
            )
            return bool(ready), str(status or ("ready" if ready else "extension_offline"))
        except Exception:
            return False, "extension_offline"

    async def _suspend_extension_tab_unavailable(
        self,
        chat_id: int,
        account_id: str,
        acc: dict | None = None,
    ) -> None:
        row = dict(acc or get_user_account(int(chat_id), str(account_id)) or {})
        changed = bool(row.get("chat_ai_pending_task")) or bool(row.get("chat_ai_resume_when_extension_online"))
        changed = changed or int(row.get("chat_ai_next_run_ts") or 0) != 0
        changed = changed or str(row.get("chat_ai_last_error") or "") != "managed_tab_not_ready"
        if not changed:
            return
        await self._patch(
            int(chat_id),
            str(account_id),
            chat_ai_pending_task={},
            chat_ai_resume_when_extension_online=False,
            chat_ai_next_run_ts=0,
            chat_ai_last_error="managed_tab_not_ready",
        )
        logger.info(
            "Чат AI приостановлен | %s | acc=%s | причина=вкладка казино недоступна",
            _chat_ai_account_label(int(chat_id), str(account_id), row),
            account_id,
        )

    async def _suspend_extension_offline(self, chat_id: int, account_id: str, acc: dict | None = None, *, reason: str = "extension_offline") -> None:
        row = dict(acc or get_user_account(int(chat_id), str(account_id)) or {})
        patch: dict[str, Any] = {}
        now_ts = int(time.time())
        pending = dict(row.get("chat_ai_pending_task") or {})
        next_run_ts = int(row.get("chat_ai_next_run_ts") or 0)
        should_resume = bool(pending)
        if next_run_ts and next_run_ts <= now_ts:
            patch["chat_ai_next_run_ts"] = 0
        if should_resume and not bool(row.get("chat_ai_resume_when_extension_online")):
            patch["chat_ai_resume_when_extension_online"] = True
        if str(row.get("chat_ai_last_error") or "") != reason:
            patch["chat_ai_last_error"] = reason
        if patch:
            await self._patch(int(chat_id), str(account_id), **patch)
            logger.info(
                "Чат AI приостановлен | %s | acc=%s | причина=%s",
                _chat_ai_account_label(int(chat_id), str(account_id), row),
                account_id,
                _chat_ai_reason_label(reason),
            )

    async def on_extension_connection_event(self, event_type: str, chat_id: int, account_id: str) -> None:
        event = str(event_type or "").strip().lower()
        cid = int(chat_id)
        aid = str(account_id or "acc_1")
        acc = get_user_account(cid, aid) or {}
        if str(acc.get("promo_activation_mode") or "server").strip().lower() != "extension":
            return
        if not bool(acc.get("chat_ai_enabled")):
            return
        if bool(acc.get("subscription_paused")) or not has_active_account_subscription(cid, aid, int(time.time())):
            return
        if event == "disconnected":
            if self._is_extension_offline(cid, aid, acc):
                await self._suspend_extension_offline(cid, aid, acc)
            return
        if event != "connected":
            return
        runtime_ready, runtime_status = await self._extension_runtime_ready(cid, aid, acc, force=True)
        if not runtime_ready:
            if runtime_status == "managed_tab_not_ready":
                await self._suspend_extension_tab_unavailable(cid, aid, acc)
            else:
                await self._suspend_extension_offline(cid, aid, acc)
            return
        pending = dict(acc.get("chat_ai_pending_task") or {})
        should_resume = bool(acc.get("chat_ai_resume_when_extension_online")) or bool(pending)
        last_error = str(acc.get("chat_ai_last_error") or "").strip()
        next_run_ts = int(acc.get("chat_ai_next_run_ts") or 0)
        if should_resume and pending:
            await self._patch(
                cid,
                aid,
                chat_ai_resume_when_extension_online=False,
                chat_ai_last_error="",
            )
            logger.info(
                "Чат AI возобновлён после подключения расширения | %s | acc=%s | действие=повтор pending сообщения",
                _chat_ai_account_label(cid, aid, acc),
                aid,
            )
            self._spawn(cid, aid, self._resume_pending(cid, aid, pending), f"chat-ai-resume-{cid}-{aid}")
            return
        if should_resume:
            await self._patch(
                cid,
                aid,
                chat_ai_resume_when_extension_online=False,
                chat_ai_last_error="",
            )
            logger.info(
                "Чат AI возобновлён после подключения расширения | %s | acc=%s | действие=ожидание следующего цикла",
                _chat_ai_account_label(cid, aid, acc),
                aid,
            )
            return
        if last_error == "extension_offline":
            await self._patch(cid, aid, chat_ai_last_error="")
            return

    async def handover_account_mode(
        self,
        chat_id: int,
        account_id: str,
        target_mode: str,
        *,
        previous_mode: str = "",
        mode_epoch: int = 0,
    ) -> int:
        """Move Chat AI scheduling to the selected executor without replaying old text."""
        cid = int(chat_id)
        aid = str(account_id or "acc_1")
        target = "extension" if str(target_mode or "server").strip().lower() == "extension" else "server"
        previous = "extension" if str(previous_mode or "server").strip().lower() == "extension" else "server"
        key = self._key(cid, aid)

        running = self._running.get(key)
        if running is not None and running is not asyncio.current_task() and not running.done():
            running.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await running
        self._running.pop(key, None)
        self._extension_probe_after.pop(key, None)

        row = get_user_account(cid, aid) or {}
        pending = dict(row.get("chat_ai_pending_task") or {})
        pending_mode = str(pending.get("mode") or previous).strip().lower()
        pending_epoch = max(0, int(pending.get("mode_epoch") or mode_epoch or row.get("runtime_mode_epoch") or 0))
        if pending and pending_mode == "extension" and target == "server" and _EXTENSION_TRAIN_MANAGER is not None:
            with contextlib.suppress(Exception):
                await _EXTENSION_TRAIN_MANAGER.send_chat_ai_cancel(
                    chat_id=cid,
                    account_id=aid,
                    task_id=str(pending.get("task_id") or ""),
                    attempt=max(1, int(pending.get("attempt") or 1)),
                    mode_epoch=pending_epoch,
                    reason=f"runtime_handover:{previous}->{target}",
                )

        row = await self._patch(
            cid,
            aid,
            chat_ai_pending_task={},
            chat_ai_resume_when_extension_online=False,
            chat_ai_last_error="",
        )

        if not bool(row.get("chat_ai_enabled")):
            logger.info(
                "Чат AI: режим переключён | %s | acc=%s | %s->%s | выключен",
                _chat_ai_account_label(cid, aid, row),
                aid,
                previous,
                target,
            )
            return 1

        now_ts = int(time.time())
        if int(row.get("chat_ai_rest_until_ts") or 0) > now_ts:
            logger.info(
                "Чат AI: режим переключён | %s | acc=%s | %s->%s | состояние=отдых",
                _chat_ai_account_label(cid, aid, row),
                aid,
                previous,
                target,
            )
            return 1

        if target == "extension":
            ready, status = await self._extension_runtime_ready(cid, aid, row, force=True)
            if not ready:
                if status == "managed_tab_not_ready":
                    await self._suspend_extension_tab_unavailable(cid, aid, row)
                else:
                    await self._suspend_extension_offline(cid, aid, row)
                logger.info(
                    "Чат AI: режим переключён | %s | acc=%s | %s->%s | состояние=%s",
                    _chat_ai_account_label(cid, aid, row),
                    aid,
                    previous,
                    target,
                    _chat_ai_reason_label(status),
                )
                return 1

        next_run_ts = max(0, int(row.get("chat_ai_next_run_ts") or 0))
        if pending or next_run_ts <= now_ts:
            await self._schedule_next(
                cid,
                aid,
                reason_override=f"режим изменён: {_chat_ai_route_label(target)}",
            )
        logger.info(
            "Чат AI: режим переключён | %s | acc=%s | %s->%s | epoch=%s",
            _chat_ai_account_label(cid, aid, row),
            aid,
            previous,
            target,
            max(0, int(mode_epoch or row.get("runtime_mode_epoch") or 0)),
        )
        return 1

    async def _patch(self, chat_id: int, account_id: str, **fields) -> dict:
        patched = patch_user_account(int(chat_id), str(account_id), **fields)
        try:
            await asyncio.to_thread(persist_user_state_now, int(chat_id))
        except Exception as exc:
            logger.warning("Чат AI: не удалось сохранить состояние | chat_id=%s | acc=%s | ошибка=%s", chat_id, account_id, exc)
        with contextlib.suppress(Exception):
            await notify_app_state_update(int(chat_id))
        return patched

    async def _cycle_gate(
        self,
        chat_id: int,
        account_id: str,
        acc: dict | None = None,
    ) -> tuple[bool, dict]:
        row = dict(acc or get_user_account(int(chat_id), str(account_id)) or {})
        now_ts = int(time.time())
        rest_until = max(0, int(row.get("chat_ai_rest_until_ts") or 0))
        next_run = max(0, int(row.get("chat_ai_next_run_ts") or 0))

        if rest_until > now_ts:
            if next_run:
                row = await self._patch(chat_id, account_id, chat_ai_next_run_ts=0)
            return False, row

        if rest_until:
            row = await self._patch(
                chat_id,
                account_id,
                chat_ai_cycle_started_ts=now_ts,
                chat_ai_rest_until_ts=0,
                chat_ai_next_run_ts=0,
                chat_ai_last_error="",
            )
            logger.info(
                "Чат AI: отдых завершён | %s | acc=%s | новый цикл=5ч",
                _chat_ai_account_label(chat_id, account_id, row),
                account_id,
            )
            return True, row

        cycle_started = max(0, int(row.get("chat_ai_cycle_started_ts") or 0))
        if cycle_started <= 0:
            row = await self._patch(
                chat_id,
                account_id,
                chat_ai_cycle_started_ts=now_ts,
                chat_ai_rest_until_ts=0,
            )
            logger.info(
                "Чат AI: цикл запущен | %s | acc=%s | активное время=5ч",
                _chat_ai_account_label(chat_id, account_id, row),
                account_id,
            )
            return True, row

        if now_ts - cycle_started >= _CHAT_AI_ACTIVE_CYCLE_SEC:
            rest_until = now_ts + _CHAT_AI_REST_SEC
            row = await self._patch(
                chat_id,
                account_id,
                chat_ai_cycle_started_ts=0,
                chat_ai_rest_until_ts=rest_until,
                chat_ai_next_run_ts=0,
            )
            logger.info(
                "Чат AI: начался отдых | %s | acc=%s | отдых=1ч | до=%s OMSK",
                _chat_ai_account_label(chat_id, account_id, row),
                account_id,
                _train_log_time(rest_until),
            )
            return False, row

        return True, row

    async def _schedule_next(self, chat_id: int, account_id: str, *, error: str = "", new_enabled: bool = False, reason_override: str = "") -> int:
        acc = get_user_account(int(chat_id), str(account_id)) or {}
        if not bool(acc.get("chat_ai_enabled")):
            await self._patch(
                chat_id,
                account_id,
                chat_ai_next_run_ts=0,
                chat_ai_pending_task={},
                chat_ai_cycle_started_ts=0,
                chat_ai_rest_until_ts=0,
            )
            return 0
        allowed, acc = await self._cycle_gate(chat_id, account_id, acc)
        if not allowed:
            return 0
        lo, hi = self._interval_bounds(acc)
        delay = random.randint(lo, hi)
        next_ts = int(time.time()) + delay
        await self._patch(
            chat_id,
            account_id,
            chat_ai_next_run_ts=next_ts,
            chat_ai_pending_task={},
            chat_ai_last_error=str(error or "")[:500],
        )
        if reason_override:
            schedule_reason = str(reason_override)[:180]
        elif new_enabled:
            schedule_reason = "включено пользователем"
        elif error:
            schedule_reason = f"после ошибки: {_chat_ai_reason_label(str(error)[:160])}"
        else:
            schedule_reason = "обычный цикл"
        logger.info(
            "Чат AI запланирован | %s | acc=%s | через=%dм %02dс | запуск=%s OMSK | причина=%s",
            _chat_ai_account_label(chat_id, account_id, acc),
            account_id,
            delay // 60,
            delay % 60,
            _train_log_time(next_ts),
            schedule_reason,
        )
        return next_ts

    async def _record_success(self, chat_id: int, account_id: str, *, message: str, target: str, source: str) -> None:
        acc = get_user_account(int(chat_id), str(account_id)) or {}
        mode = str(acc.get("promo_activation_mode") or "server").strip().lower()
        recent = [dict(x) for x in (acc.get("chat_ai_recent_messages") or []) if isinstance(x, dict)]
        sent_at = int(time.time())
        recent.append({
            "sent_at_ts": sent_at,
            "text": str(message or "")[:500],
            "target": str(target or "")[:255],
            "source": str(source or "regular")[:32],
            "mode": mode if mode in {"server", "extension"} else "server",
        })
        await self._patch(
            chat_id,
            account_id,
            chat_ai_last_sent_ts=sent_at,
            chat_ai_last_error="",
            chat_ai_recent_messages=recent[-3:],
            chat_ai_pending_task={},
            chat_ai_next_run_ts=0,
        )
        via = "extension" if mode == "extension" else "server"
        if source == "rain_miss":
            logger.info(
                'Чат AI после дождя | %s | через=%s | выигрыш=нет | текст="%s"',
                _chat_ai_account_label(chat_id, account_id, acc),
                _chat_ai_route_label(via),
                str(message).replace('"', '\\"')[:160],
            )
        else:
            logger.info(
                'Чат AI отправлен | %s | через=%s | кому=%s | текст="%s"',
                _chat_ai_account_label(chat_id, account_id, acc),
                _chat_ai_route_label(via),
                target or "?",
                str(message).replace('"', '\\"')[:160],
            )
        await self._schedule_next(chat_id, account_id)

    async def _finish_failure(self, chat_id: int, account_id: str, result: dict) -> None:
        reason = _clean_text(result.get("message") or result.get("text") or result.get("status") or "chat_ai_send_failed")[:500]
        status = str(result.get("status") or "").strip().lower()
        response_body = _clean_text(result.get("response_body") or "")[:600]
        http_status = int(result.get("http_status") or 0)
        reason_folded = reason.casefold()
        if status in {"activation_mode_changed", "wrong_activation_mode"}:
            await self._patch(
                chat_id,
                account_id,
                chat_ai_pending_task={},
                chat_ai_resume_when_extension_online=False,
                chat_ai_last_error="",
            )
            fresh = get_user_account(int(chat_id), str(account_id)) or {}
            if (
                bool(fresh.get("chat_ai_enabled"))
                and not bool(fresh.get("subscription_paused"))
                and has_active_account_subscription(int(chat_id), str(account_id), int(time.time()))
            ):
                await self._schedule_next(
                    chat_id,
                    account_id,
                    reason_override="режим выполнения изменён",
                )
            return
        tab_unavailable = status in {
            "managed_tab_not_ready",
            "managed_tab_not_found",
            "tab_not_ready",
            "tab_not_found",
        } or any(marker in reason_folded for marker in (
            "managed_tab_not_ready",
            "managed_tab_not_found",
            "tab_not_ready",
            "tab_not_found",
            "no tab with id",
        ))
        if tab_unavailable:
            await self._suspend_extension_tab_unavailable(chat_id, account_id)
            return
        if status == "stale_pending_task":
            await self._patch(
                chat_id,
                account_id,
                chat_ai_pending_task={},
                chat_ai_resume_when_extension_online=False,
            )
        if self._is_extension_offline(chat_id, account_id) or status in {"extension_offline", "extension_manager_unavailable"}:
            await self._suspend_extension_offline(chat_id, account_id, reason="extension_offline")
            return
        if status == "server_session_stale":
            acc = mark_account_server_session_stale(
                chat_id,
                account_id,
                reason="chat_ai_send",
                http_status=http_status,
                response=response_body,
            )
            with contextlib.suppress(Exception):
                await asyncio.to_thread(persist_user_state_now, int(chat_id))
            if _SERVER_WS_MANAGER is not None:
                with contextlib.suppress(Exception):
                    await _SERVER_WS_MANAGER.stop_for_user(int(chat_id), account_id=str(account_id))
            state = normalize_server_session_state(acc.get("server_session_state"))
            if not int(state.get("notified_at_ts") or 0) and self._telegram_bot is not None:
                slot = int(acc.get("slot") or 1)
                name = str(acc.get("port_user_name") or "-")
                casino_id = str(acc.get("port_user_id") or "-")
                account_line = f"Аккаунт: #{slot} · {name} | ID {casino_id}"
                user_text = "⚠️ Сессия протухла\n\nТребуется повторно подключить аккаунт казино.\n" + account_line
                with contextlib.suppress(Exception):
                    await self._telegram_bot.send_message(chat_id=int(chat_id), text=user_text)
                if ADMIN_CHAT_ID:
                    username = str(getattr(get_user(int(chat_id)), "tg_username", "") or "-")
                    admin_text = f"⚠️ Сессия пользователя протухла\nchat_id: {chat_id}\nuser: {username}\n{account_line}"
                    with contextlib.suppress(Exception):
                        await self._telegram_bot.send_message(chat_id=ADMIN_CHAT_ID, text=admin_text)
                mark_account_server_session_notified(chat_id, account_id)
                with contextlib.suppress(Exception):
                    await asyncio.to_thread(persist_user_state_now, int(chat_id))
            with contextlib.suppress(Exception):
                await notify_app_state_update(int(chat_id))
            logger.warning(
                "Чат AI: серверная сессия протухла | %s | acc=%s | http=%s | body=%s",
                _chat_ai_account_label(chat_id, account_id, acc),
                account_id,
                http_status,
                response_body,
            )
            return
        if http_status == 419:
            logger.warning(
                "Чат AI: ответ сайта 419 | %s | acc=%s | body=%s",
                _chat_ai_account_label(chat_id, account_id),
                account_id,
                response_body,
            )
        logger.warning("Чат AI: отправка не удалась | %s | acc=%s | ошибка=%s", _chat_ai_account_label(chat_id, account_id), account_id, _chat_ai_reason_label(reason))
        await self._schedule_next(chat_id, account_id, error=reason)

    async def _dispatch_ready_message(
        self,
        chat_id: int,
        account_id: str,
        *,
        message: str,
        target: str,
        source: str,
        task_id: str | None = None,
        attempt: int = 1,
        processed_message_key: str = "",
    ) -> None:
        runtime_acc = get_user_account(
            int(chat_id),
            str(account_id),
        ) or {}
        if _chat_ai_runtime_block_reason(
            int(chat_id),
            runtime_acc,
        ):
            return

        invalid_reason = _chat_ai_invalid_send_reason(message)
        if invalid_reason:
            logger.warning(
                'Чат AI: отправка заблокирована | %s | acc=%s | причина=%s | текст="%s"',
                _chat_ai_account_label(chat_id, account_id),
                account_id,
                _chat_ai_reason_label(f"invalid_ai_response:{invalid_reason}"),
                _clean_text(message)[:220].replace('"', '\\"'),
            )
            await self._schedule_next(chat_id, account_id, error=f"invalid_ai_response:{invalid_reason}")
            return
        tid = str(task_id or uuid.uuid4().hex)
        pending = {
            "task_id": tid,
            "message": str(message),
            "target": str(target or ""),
            "source": str(source or "regular"),
            "attempt": max(1, int(attempt or 1)),
            "status": "sending",
            "created_at_ts": int(time.time()),
            "retry_at_ts": 0,
            "mode": str(runtime_acc.get("promo_activation_mode") or "server").strip().lower(),
            "mode_epoch": max(0, int(runtime_acc.get("runtime_mode_epoch") or 0)),
            "processed_message_key": str(processed_message_key or ""),
        }
        await self._patch(chat_id, account_id, chat_ai_pending_task=pending, chat_ai_next_run_ts=0)
        result = await _send_chat_ai_message_once(
            chat_id,
            account_id,
            str(message),
            task_id=tid,
            source=source,
            attempt=attempt,
        )
        if bool(result.get("ok")):
            processed_message_key = str(pending.get("processed_message_key") or "").strip()
            if processed_message_key:
                self.processed_messages.append(processed_message_key)
            await self._record_success(chat_id, account_id, message=message, target=target, source=source)
            return
        retry_after = max(0, int(result.get("retry_after_sec") or 0))
        if str(result.get("status") or "").lower() == "cooldown" and retry_after > 0 and int(attempt) < 2:
            retry_at = int(time.time()) + retry_after + 1
            pending.update({"attempt": 2, "status": "cooldown", "retry_at_ts": retry_at})
            await self._patch(chat_id, account_id, chat_ai_pending_task=pending, chat_ai_last_error="")
            logger.info(
                "Чат AI: cooldown сайта | %s | acc=%s | через=%s | task=%s | повтор через=%sс | попытка=1/2",
                _chat_ai_account_label(chat_id, account_id),
                account_id,
                _chat_ai_route_label(str((get_user_account(chat_id, account_id) or {}).get("promo_activation_mode") or "server")),
                tid,
                retry_after + 1,
            )
            return
        await self._finish_failure(chat_id, account_id, result)

    async def _resume_pending(self, chat_id: int, account_id: str, pending: dict) -> None:
        async with self._lock(chat_id, account_id):
            fresh = get_user_account(chat_id, account_id) or {}
            current = dict(fresh.get("chat_ai_pending_task") or {})
            if not current or str(current.get("task_id") or "") != str(pending.get("task_id") or ""):
                return
            if not bool(fresh.get("chat_ai_enabled")) or not has_active_account_subscription(chat_id, account_id, int(time.time())):
                await self._patch(chat_id, account_id, chat_ai_pending_task={}, chat_ai_next_run_ts=0)
                return
            current_mode = str(fresh.get("promo_activation_mode") or "server").strip().lower()
            current_epoch = max(0, int(fresh.get("runtime_mode_epoch") or 0))
            pending_mode = str(current.get("mode") or current_mode).strip().lower()
            pending_epoch = max(0, int(current.get("mode_epoch") or current_epoch))
            if pending_mode != current_mode or pending_epoch != current_epoch:
                await self._patch(
                    chat_id,
                    account_id,
                    chat_ai_pending_task={},
                    chat_ai_resume_when_extension_online=False,
                    chat_ai_last_error="",
                )
                await self._schedule_next(
                    chat_id,
                    account_id,
                    reason_override="режим выполнения изменён",
                )
                return
            if _chat_ai_runtime_block_reason(chat_id, fresh):
                return
            await self._dispatch_ready_message(
                chat_id,
                account_id,
                message=str(current.get("message") or ""),
                target=str(current.get("target") or ""),
                source=str(current.get("source") or "regular"),
                task_id=str(current.get("task_id") or ""),
                attempt=max(2, int(current.get("attempt") or 2)),
                processed_message_key=str(current.get("processed_message_key") or ""),
            )

    def _spawn(self, chat_id: int, account_id: str, coro, name: str) -> None:
        key = self._key(chat_id, account_id)
        if key in self._running and not self._running[key].done():
            return
        task = asyncio.create_task(coro, name=name)
        self._running[key] = task
        def done(t: asyncio.Task) -> None:
            if self._running.get(key) is t:
                self._running.pop(key, None)
            with contextlib.suppress(asyncio.CancelledError):
                exc = t.exception()
                if exc:
                    logger.warning("Чат AI: задача аварийно завершилась | key=%s | ошибка=%s", key, exc)
        task.add_done_callback(done)

    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self._scheduler_loop(), name="chat-ai-scheduler")

    async def stop(self) -> None:
        tasks = [t for t in [self._task, *self._rain_tasks, *self._running.values()] if t and not t.done()]
        for task in tasks:
            task.cancel()
        for task in tasks:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
        self._task = None
        self._rain_tasks.clear()
        self._running.clear()

    def on_chat_html(self, html_text: str) -> None:
        msg = _parse_chat_ai_message(html_text)
        if msg:
            self.messages.append(msg)

    def on_rain(self, rain: dict) -> None:
        for chat_id, acc in self._rain_watch_accounts():
            task = asyncio.create_task(self._handle_rain_for_account(chat_id, acc, rain), name=f"chat-ai-rain-{chat_id}-{acc.get('account_id')}")
            self._rain_tasks.add(task)
            task.add_done_callback(lambda t: self._rain_tasks.discard(t))

    def _rain_watch_accounts(self) -> list[tuple[int, dict]]:
        now_ts = int(time.time())
        out: list[tuple[int, dict]] = []
        for cid in list(USERS.keys()):
            try:
                for acc in get_user_accounts(int(cid), include_empty=False):
                    aid = str(acc.get("account_id") or "").strip()
                    if not aid or bool(acc.get("subscription_paused")):
                        continue
                    if not has_active_account_subscription(int(cid), aid, now_ts):
                        continue
                    if not str(acc.get("port_user_id") or "").strip() and not str(acc.get("port_user_name") or "").strip():
                        continue
                    out.append((int(cid), dict(acc)))
            except Exception as e:
                logger.debug("Rain watch scan failed chat_id=%s err=%s", cid, e)
        return out

    async def _scheduler_loop(self) -> None:
        while True:
            try:
                now_ts = int(time.time())
                for cid in list(USERS.keys()):
                    for acc in get_user_accounts(int(cid), include_empty=False):
                        aid = str(acc.get("account_id") or "").strip()
                        if not aid or not bool(acc.get("chat_ai_enabled")):
                            continue
                        until_ts = int(acc.get("subscription_until_ts") or 0)
                        if until_ts <= now_ts:
                            await self._patch(
                                int(cid),
                                aid,
                                chat_ai_enabled=False,
                                chat_ai_next_run_ts=0,
                                chat_ai_pending_task={},
                                chat_ai_last_error="",
                                chat_ai_cycle_started_ts=0,
                                chat_ai_rest_until_ts=0,
                            )
                            logger.info("Чат AI выключен | chat_id=%s | acc=%s | причина=подписка закончилась", cid, aid)
                            continue
                        if bool(acc.get("subscription_paused")):
                            if (
                                int(acc.get("chat_ai_cycle_started_ts") or 0)
                                or int(acc.get("chat_ai_rest_until_ts") or 0)
                                or int(acc.get("chat_ai_next_run_ts") or 0)
                            ):
                                await self._patch(
                                    int(cid),
                                    aid,
                                    chat_ai_cycle_started_ts=0,
                                    chat_ai_rest_until_ts=0,
                                    chat_ai_next_run_ts=0,
                                )
                            continue
                        if not self._api_keys(acc):
                            if (
                                str(acc.get("chat_ai_last_error") or "") != "chat_ai_api_key_missing"
                                or int(acc.get("chat_ai_cycle_started_ts") or 0)
                                or int(acc.get("chat_ai_rest_until_ts") or 0)
                                or int(acc.get("chat_ai_next_run_ts") or 0)
                            ):
                                await self._patch(
                                    int(cid),
                                    aid,
                                    chat_ai_last_error="chat_ai_api_key_missing",
                                    chat_ai_next_run_ts=0,
                                    chat_ai_cycle_started_ts=0,
                                    chat_ai_rest_until_ts=0,
                                )
                            continue
                        current_mode = str(acc.get("promo_activation_mode") or "server").strip().lower()
                        current_error = str(acc.get("chat_ai_last_error") or "").strip()

                        # Ошибки поездов относятся только к train job и никогда
                        # не должны управлять или отображаться как состояние Chat AI.
                        # Заодно очищаем значения, сохраненные старыми версиями.
                        if current_error.startswith("train_join_"):
                            acc = await self._patch(
                                int(cid),
                                aid,
                                chat_ai_last_error="",
                            )
                            current_error = ""
                        extension_only_errors = {
                            "extension_offline",
                            "managed_tab_not_ready",
                            "extension_manager_unavailable",
                            "extension_timeout",
                            "extension_send_error",
                            "extension_not_bound",
                            "extension_subscription_inactive",
                            "extension_mode",
                            "wrong_activation_mode",
                            "activation_mode_changed",
                        }
                        server_only_errors = {
                            "server_session_stale",
                            "no_proxy",
                            "proxy_unavailable",
                            "proxy_site_unreachable",
                            "proxy_recovering",
                            "no_zooma_top_session",
                            "no_csrf_token",
                            "no_port_user_id",
                            "active_domain_missing",
                        }
                        if (current_mode == "server" and current_error in extension_only_errors) or (
                            current_mode == "extension" and current_error in server_only_errors
                        ):
                            acc = await self._patch(
                                int(cid),
                                aid,
                                chat_ai_last_error="",
                                chat_ai_resume_when_extension_online=False,
                            )

                        runtime_block = (
                            _chat_ai_runtime_block_reason(
                                int(cid),
                                acc,
                            )
                        )
                        if runtime_block:
                            if (
                                str(
                                    acc.get("chat_ai_last_error") or ""
                                )
                                != runtime_block
                            ):
                                await self._patch(
                                    int(cid),
                                    aid,
                                    chat_ai_last_error=runtime_block,
                                )
                                logger.info(
                                    "Чат AI приостановлен | %s | acc=%s | причина=%s",
                                    _chat_ai_account_label(
                                        int(cid),
                                        aid,
                                        acc,
                                    ),
                                    aid,
                                    _chat_ai_reason_label(
                                        runtime_block
                                    ),
                                )
                            continue

                        if str(
                            acc.get("chat_ai_last_error") or ""
                        ) in {
                            "no_proxy",
                            "proxy_unavailable",
                            "proxy_site_unreachable",
                            "proxy_recovering",
                        }:
                            acc = await self._patch(
                                int(cid),
                                aid,
                                chat_ai_last_error="",
                            )

                        if self._is_extension_offline(
                            int(cid),
                            aid,
                            acc,
                        ):
                            await self._suspend_extension_offline(
                                int(cid),
                                aid,
                                acc,
                            )
                            continue

                        tab_restored = False
                        if (
                            str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension"
                            and str(acc.get("chat_ai_last_error") or "") == "managed_tab_not_ready"
                        ):
                            runtime_ready, runtime_status = await self._extension_runtime_ready(int(cid), aid, acc)
                            if not runtime_ready:
                                if runtime_status == "extension_offline":
                                    await self._suspend_extension_offline(int(cid), aid, acc)
                                continue
                            acc = await self._patch(
                                int(cid),
                                aid,
                                chat_ai_last_error="",
                                chat_ai_pending_task={},
                                chat_ai_resume_when_extension_online=False,
                                chat_ai_next_run_ts=0,
                            )
                            tab_restored = True
                            logger.info(
                                "Чат AI: вкладка казино снова доступна | %s | acc=%s",
                                _chat_ai_account_label(int(cid), aid, acc),
                                aid,
                            )

                        pending = dict(
                            acc.get("chat_ai_pending_task") or {}
                        )
                        current_mode = str(acc.get("promo_activation_mode") or "server").strip().lower()
                        current_epoch = max(0, int(acc.get("runtime_mode_epoch") or 0))
                        pending_mode = str(pending.get("mode") or current_mode).strip().lower() if pending else current_mode
                        pending_epoch = max(0, int(pending.get("mode_epoch") or current_epoch)) if pending else current_epoch
                        if pending and (pending_mode != current_mode or pending_epoch != current_epoch):
                            acc = await self._patch(
                                int(cid),
                                aid,
                                chat_ai_pending_task={},
                                chat_ai_resume_when_extension_online=False,
                                chat_ai_last_error="",
                            )
                            pending = {}
                        key = self._key(int(cid), aid)
                        if pending:
                            status = str(pending.get("status") or "")
                            retry_at = int(pending.get("retry_at_ts") or 0)
                            if status == "cooldown" and retry_at > 0 and retry_at <= now_ts and key not in self._running:
                                self._spawn(int(cid), aid, self._resume_pending(int(cid), aid, pending), f"chat-ai-retry-{cid}-{aid}")
                            elif status == "sending" and now_ts - int(pending.get("created_at_ts") or now_ts) > 90:
                                await self._finish_failure(int(cid), aid, {"status": "stale_pending_task", "message": "Незавершённая задача сброшена после перезапуска"})
                            continue
                        rest_finished = 0 < int(acc.get("chat_ai_rest_until_ts") or 0) <= now_ts
                        allowed, acc = await self._cycle_gate(int(cid), aid, acc)
                        if not allowed:
                            continue
                        next_ts = int(acc.get("chat_ai_next_run_ts") or 0)
                        if next_ts <= 0:
                            await self._schedule_next(
                                int(cid),
                                aid,
                                new_enabled=not rest_finished and not tab_restored,
                                reason_override=(
                                    "отдых завершён, новый цикл 5ч"
                                    if rest_finished
                                    else ("вкладка казино снова доступна" if tab_restored else "")
                                ),
                            )
                            continue
                        if next_ts <= now_ts and key not in self._running:
                            self._spawn(int(cid), aid, self._process_account(int(cid), aid), f"chat-ai-send-{cid}-{aid}")
                await asyncio.sleep(5)
            except asyncio.CancelledError:
                return
            except Exception as e:
                logger.warning("Чат AI: ошибка планировщика | ошибка=%s", e)
                await asyncio.sleep(10)

    async def _process_account(self, chat_id: int, account_id: str) -> None:
        async with self._lock(chat_id, account_id):
            acc = get_user_account(chat_id, account_id) or {}
            label = _chat_ai_account_label(chat_id, account_id, acc)
            if not bool(acc.get("chat_ai_enabled")) or bool(acc.get("subscription_paused")) or not has_active_account_subscription(chat_id, account_id, int(time.time())):
                return
            if _chat_ai_runtime_block_reason(chat_id, acc):
                return
            if self._is_extension_offline(chat_id, account_id, acc):
                await self._suspend_extension_offline(chat_id, account_id, acc)
                return
            allowed, acc = await self._cycle_gate(chat_id, account_id, acc)
            if not allowed:
                return
            if not self.messages:
                logger.warning("Чат AI пропущен | %s | acc=%s | причина=%s", label, account_id, _chat_ai_reason_label("no_buffered_messages"))
                await self._schedule_next(chat_id, account_id, error="no_buffered_messages")
                return
            own_user_id = str(acc.get("port_user_id") or "").strip()
            rows = []
            seen_texts: set[str] = set()
            for m in list(self.messages):
                if str(m.get("user_id") or "") == own_user_id:
                    continue
                if self._message_key(m) in self.processed_messages:
                    continue
                text_key = _chat_ai_text_key(str(m.get("message") or ""))
                if text_key and text_key in seen_texts:
                    continue
                if text_key:
                    seen_texts.add(text_key)
                rows.append(m)
            rows = rows[-max(1, int(CHAT_AI_BUFFER_SIZE or 30)):]
            if not rows:
                logger.warning("Чат AI пропущен | %s | acc=%s | причина=%s", label, account_id, _chat_ai_reason_label("no_unprocessed_messages"))
                await self._schedule_next(chat_id, account_id, error="no_unprocessed_messages")
                return
            api_keys = self._api_keys(acc)
            target_index, response_text = await _chat_ai_call_groq(
                [(str(m.get("nickname") or ""), str(m.get("message") or "")) for m in rows],
                api_keys,
                chat_id=chat_id,
                account_id=account_id,
            )
            if not response_text or not target_index or target_index < 1 or target_index > len(rows):
                fresh = get_user_account(chat_id, account_id) or {}
                groq_error = str(fresh.get("chat_ai_last_error") or "").strip()
                if groq_error in {"groq_tpd_limit", "groq_rate_limited"}:
                    retry_at = max(0, int(fresh.get("chat_ai_next_run_ts") or 0))
                    retry_sec = max(0, retry_at - int(time.time()))
                    logger.warning(
                        "Чат AI приостановлен | %s | acc=%s | причина=%s | повтор через=%sс",
                        label,
                        account_id,
                        _chat_ai_reason_label(groq_error),
                        retry_sec,
                    )
                    return
                logger.warning("Чат AI пропущен | %s | acc=%s | причина=%s | выбор=%s | строк=%s", label, account_id, _chat_ai_reason_label("groq_no_valid_choice"), target_index, len(rows))
                await self._schedule_next(chat_id, account_id, error="groq_no_valid_choice")
                return
            target = rows[target_index - 1]
            response_text = remove_asian_chars(response_text)
            invalid_reason = _chat_ai_invalid_send_reason(response_text)
            if invalid_reason:
                logger.warning(
                    'Чат AI пропущен | %s | acc=%s | причина=%s | текст="%s"',
                    label,
                    account_id,
                    _chat_ai_reason_label(f"invalid_ai_response:{invalid_reason}"),
                    _clean_text(response_text)[:220].replace('"', '\\"'),
                )
                await self._schedule_next(chat_id, account_id, error=f"invalid_ai_response:{invalid_reason}")
                return
            target_uid = str(target.get("user_id") or "").strip()
            target_nick = str(target.get("nickname") or "").strip()
            final_message = f"[~{target_uid}~]{target_nick}, {response_text}" if target_uid and target_nick else response_text
            await self._dispatch_ready_message(
                chat_id,
                account_id,
                message=final_message,
                target=target_nick or target_uid or "?",
                source="regular",
                processed_message_key=self._message_key(target),
            )

    def _winner_user_id(self, winner: Any) -> str:
        if not isinstance(winner, dict):
            return ""
        for key in ("user_id", "userId", "id", "port_user_id"):
            value = str(winner.get(key) or "").strip()
            if value:
                return value
        profile = str(winner.get("profile") or "").strip()
        match = re.search(r"/user/(\d+)", profile)
        return match.group(1) if match else ""

    def _winner_amount(self, winner: Any, rain: dict) -> str:
        if isinstance(winner, dict):
            for key in ("amount", "sum", "winAmount", "prize", "perUserAmount"):
                value = _clean_text(winner.get(key) or "")
                if value:
                    return value
        return _clean_text(rain.get("perUserAmount") or rain.get("totalAmount") or "-")

    def _find_account_rain_win(self, acc: dict, rain: dict) -> tuple[dict | None, str]:
        own_name = str(acc.get("port_user_name") or "").strip()
        own_uid = str(acc.get("port_user_id") or "").strip()
        for raw in rain.get("winners") or []:
            winner = raw if isinstance(raw, dict) else {"nickname": str(raw or "").strip()}
            winner_name = str(winner.get("nickname") or "").strip()
            winner_uid = self._winner_user_id(winner)
            if own_uid and winner_uid and own_uid == winner_uid:
                return winner, "user_id"
            if own_name and winner_name and own_name.casefold() == winner_name.casefold():
                return winner, "nickname"
        return None, ""

    async def _send_rain_win_dm(self, chat_id: int, acc: dict, rain: dict, winner: dict, match_by: str) -> None:
        if not self._telegram_bot:
            return
        aid = str(acc.get("account_id") or "acc_1")
        rain_id = str(rain.get("rainId") or f"{rain.get('messageTime')}:{rain.get('totalAmount')}:{rain.get('text')}").strip()
        dedup_key = f"{rain_id}:{int(chat_id)}:{aid}"
        if dedup_key in self._rain_dm_sent:
            return
        self._rain_dm_sent.append(dedup_key)
        amount = self._winner_amount(winner, rain)
        text = f"Поздравляю, вы выиграли в дожде\nСумма выигрыша: {amount}"
        await self._telegram_bot.send_message(chat_id=int(chat_id), text=text)
        logger.info("Дождь: уведомление о выигрыше отправлено | %s | совпадение=%s | сумма=%s", _chat_ai_account_label(int(chat_id), aid, acc), match_by, amount)

    async def _handle_rain_for_account(self, chat_id: int, acc: dict, rain: dict) -> None:
        aid = str(acc.get("account_id") or "acc_1")
        try:
            winner, match_by = self._find_account_rain_win(acc, rain)
            if winner is not None:
                await self._send_rain_win_dm(chat_id, acc, rain, winner, match_by)
                return
            if not bool(acc.get("chat_ai_enabled")):
                return
            lo = max(0, int(CHAT_AI_RAIN_MISS_MIN_DELAY_SEC or 5))
            hi = max(lo, int(CHAT_AI_RAIN_MISS_MAX_DELAY_SEC or 20))
            await asyncio.sleep(random.randint(lo, hi))
            lock = self._lock(chat_id, aid)
            if lock.locked():
                return
            async with lock:
                fresh = get_user_account(chat_id, aid) or {}
                if not bool(fresh.get("chat_ai_enabled")) or bool(fresh.get("chat_ai_pending_task")):
                    return
                if not has_active_account_subscription(chat_id, aid, int(time.time())):
                    return
                if _chat_ai_runtime_block_reason(chat_id, fresh):
                    return
                if self._is_extension_offline(chat_id, aid, fresh):
                    await self._suspend_extension_offline(chat_id, aid, fresh)
                    return
                rain_miss_messages = normalize_chat_ai_rain_miss_messages(
                    fresh.get("chat_ai_rain_miss_messages")
                )
                if not rain_miss_messages:
                    logger.info(
                        "Чат AI после дождя пропущен | %s | acc=%s | причина=%s",
                        _chat_ai_account_label(int(chat_id), aid, fresh),
                        aid,
                        _chat_ai_reason_label("empty_rain_miss_messages"),
                    )
                    return
                response = random.choice(rain_miss_messages)
                await self._dispatch_ready_message(chat_id, aid, message=response, target="", source="rain_miss")
        except Exception as e:
            logger.warning("Чат AI после дождя: ошибка | %s | acc=%s | ошибка=%s", _chat_ai_account_label(int(chat_id), aid, acc), aid, e)
            with contextlib.suppress(Exception):
                await self._schedule_next(chat_id, aid, error=str(e)[:500])

def _parse_finish_ts(train: dict) -> float | None:
    """Parse the raw data-ga-finish value without changing train discovery/posting.

    Zooma has used both Unix timestamps and ISO-8601 values. The Telegram post
    formatter already treats timezone-less ISO values as Moscow time, so the
    scheduler mirrors that rule to keep the displayed and actual join time equal.
    """
    raw = str(train.get("finishAt") or "").strip()
    if not raw:
        return None

    with contextlib.suppress(ValueError, OverflowError):
        numeric = float(raw.replace(",", "."))
        if numeric > 10_000_000_000:
            numeric /= 1000.0
        if numeric > 0:
            return numeric

    iso_value = raw[:-1] + "+00:00" if raw.endswith(("Z", "z")) else raw
    with contextlib.suppress(ValueError, OverflowError):
        parsed = datetime.fromisoformat(iso_value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone(timedelta(hours=3)))
        return parsed.timestamp()
    return None


def _train_task_key(kind: str, join_id: str, chat_id: int | None = None, account_id: str | None = None) -> str:
    if kind == "winner":
        return f"winner:{join_id}"
    return f"{kind}:{join_id}:{int(chat_id or 0)}:{str(account_id or '')}"


def _train_task_active(key: str) -> bool:
    task = _TRAIN_TASKS.get(key)
    return bool(task and not task.done())


def _track_train_task(
    task: asyncio.Task,
    *,
    key: str,
    kind: str,
    gid: str,
    join_id: str,
    chat_id: int | None = None,
    account_id: str | None = None,
) -> None:
    _TRAIN_TASKS[key] = task

    def _done(done: asyncio.Task) -> None:
        if _TRAIN_TASKS.get(key) is done:
            _TRAIN_TASKS.pop(key, None)
        if done.cancelled():
            logger.info(
                "Поезд: задача отменена | тип=%s | chat_id=%s | acc=%s | поезд=%s | join_id=%s | активных_задач=%s",
                kind,
                chat_id if chat_id is not None else "-",
                account_id or "-",
                gid,
                join_id,
                len(_TRAIN_TASKS),
            )
            return
        with contextlib.suppress(asyncio.CancelledError):
            exc = done.exception()
            if exc is not None:
                logger.error(
                    "Поезд: задача аварийно завершилась | тип=%s | chat_id=%s | acc=%s | поезд=%s | join_id=%s | ошибка=%s",
                    kind,
                    chat_id if chat_id is not None else "-",
                    account_id or "-",
                    gid,
                    join_id,
                    exc,
                )

    task.add_done_callback(_done)


async def _cancel_train_join_tasks() -> None:
    pending = [task for task in _TRAIN_TASKS.values() if not task.done()]
    if not pending:
        _TRAIN_TASKS.clear()
        return
    logger.info("Поезд: отменяю ожидающие задачи | количество=%s", len(pending))
    for task in pending:
        task.cancel()
    await asyncio.gather(*pending, return_exceptions=True)
    _TRAIN_TASKS.clear()


def _extract_train_join_id(train: dict) -> str:
    """Return the API giveaway id from /giveaways/<id>, not the numeric train number."""
    for key in ("joinId", "join_id"):
        direct = str(train.get(key) or "").strip()
        if direct:
            return direct

    for key in ("href", "url"):
        value = str(train.get(key) or "").strip()
        match = re.search(r"/giveaways/([^/?#]+)", value)
        if match:
            return match.group(1).strip()

    gid = str(train.get("gid") or "").strip()
    return gid if gid and not gid.isdigit() else ""


def _get_train_account(chat_id: int, account_id: str, *, include_empty: bool = False) -> dict | None:
    for acc in get_user_accounts(int(chat_id), include_empty=include_empty):
        if str(acc.get("account_id") or "") == str(account_id):
            return dict(acc)
    return None


def _is_train_admin(chat_id: int) -> bool:
    try:
        return bool(ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID))
    except Exception:
        return False


def _train_jobs_from_account(acc: dict | None) -> dict[str, dict]:
    raw = (acc or {}).get("train_jobs")
    if not isinstance(raw, dict):
        return {}
    return {
        str(key): dict(value)
        for key, value in raw.items()
        if str(key).strip() and isinstance(value, dict)
    }


def _get_train_job(chat_id: int, account_id: str, join_id: str) -> dict | None:
    acc = _get_train_account(chat_id, account_id, include_empty=True)
    if not acc:
        return None
    job = _train_jobs_from_account(acc).get(str(join_id))
    return dict(job) if isinstance(job, dict) else None


def _patch_train_job(
    chat_id: int,
    account_id: str,
    join_id: str,
    *,
    create: dict | None = None,
    **fields: Any,
) -> dict | None:
    acc = _get_train_account(chat_id, account_id, include_empty=True)
    if not acc:
        return None
    jobs = _train_jobs_from_account(acc)
    current = jobs.get(str(join_id))
    if current is None:
        if create is None:
            return None
        current = dict(create)
    else:
        current = dict(current)
    current.update(fields)
    current["join_id"] = str(join_id)
    current["updated_at_ts"] = int(time.time())
    jobs[str(join_id)] = current
    patch_user_account(int(chat_id), str(account_id), train_jobs=jobs)
    return dict(current)


def _remove_train_job(chat_id: int, account_id: str, join_id: str) -> bool:
    acc = _get_train_account(chat_id, account_id, include_empty=True)
    if not acc:
        return False
    jobs = _train_jobs_from_account(acc)
    if str(join_id) not in jobs:
        return False
    jobs.pop(str(join_id), None)
    patch_user_account(int(chat_id), str(account_id), train_jobs=jobs)
    return True


def _cleanup_train_job_everywhere(join_id: str) -> int:
    removed = 0
    for chat_id in get_all_chat_ids():
        with contextlib.suppress(Exception):
            for acc in get_user_accounts(int(chat_id), include_empty=True):
                aid = str(acc.get("account_id") or "").strip()
                if aid and _remove_train_job(int(chat_id), aid, join_id):
                    removed += 1
    return removed


def _train_job_payload(job: dict) -> dict:
    return {
        "gid": str(job.get("gid") or ""),
        "join_id": str(job.get("join_id") or ""),
        "joinId": str(job.get("join_id") or ""),
        "url": str(job.get("url") or ""),
        "href": str(job.get("url") or ""),
        "conductor": str(job.get("conductor") or "поезде"),
        "finishAt": float(job.get("finish_ts") or 0.0),
        "finishText": str(job.get("finish_text") or ""),
    }


def _train_join_terminal_state(state: str) -> bool:
    return str(state or "").strip().lower() in _TRAIN_JOIN_TERMINAL_STATES


def _train_activation_mode(chat_id: int, acc: dict | None) -> str:
    mode = str((acc or {}).get("promo_activation_mode") or "").strip().lower()
    if not mode:
        with contextlib.suppress(Exception):
            mode = str(getattr(get_user(int(chat_id)), "promo_activation_mode", "server") or "server").strip().lower()
    return "extension" if mode == "extension" else "server"


def _extension_train_task_id(chat_id: int, account_id: str, join_id: str) -> str:
    return f"train:{str(join_id)}:{int(chat_id)}:{str(account_id)}"


def _extension_train_payload(chat_id: int, account_id: str, job: dict) -> dict:
    join_id = str(job.get("join_id") or "").strip()
    return {
        "type": "train_task",
        "task_id": _extension_train_task_id(chat_id, account_id, join_id),
        "chat_id": int(chat_id),
        "account_id": str(account_id),
        "gid": str(job.get("gid") or ""),
        "join_id": join_id,
        "path": f"/giveaways/{join_id}",
        "url": str(job.get("url") or ""),
        "conductor": str(job.get("conductor") or "поезде"),
        "join_at_utc_ms": int(float(job.get("join_at_ts") or 0.0) * 1000),
        "finish_at_utc_ms": int(float(job.get("finish_ts") or 0.0) * 1000),
        "max_attempts": _TRAIN_JOIN_MAX_ATTEMPTS,
        "attempts_used": max(0, int(job.get("attempts_used") or 0)),
        "server_ts_ms": int(time.time() * 1000),
    }


async def _pending_extension_train_payloads(chat_id: int, account_id: str) -> list[dict]:
    if str(account_id) != "acc_1":
        return []
    acc = _get_train_account(int(chat_id), str(account_id), include_empty=True)
    if not acc or _train_activation_mode(int(chat_id), acc) != "extension":
        return []
    now = time.time()
    if not has_active_account_subscription(int(chat_id), str(account_id), int(now)):
        for join_id, job in _train_jobs_from_account(acc).items():
            if str(job.get("join_mode") or "server").strip().lower() == "extension" and not _train_join_terminal_state(str(job.get("join_state") or "scheduled")):
                _patch_train_job(int(chat_id), str(account_id), join_id, join_state="subscription_inactive", last_error="subscription_inactive")
        return []
    payloads: list[dict] = []
    for join_id, job in _train_jobs_from_account(acc).items():
        if str(job.get("join_mode") or "server").strip().lower() != "extension":
            continue
        state = str(job.get("join_state") or "scheduled")
        finish_ts = float(job.get("finish_ts") or 0.0)
        if _train_join_terminal_state(state):
            continue
        if finish_ts <= now + _TRAIN_JOIN_DEADLINE_MARGIN_SEC:
            _patch_train_job(int(chat_id), str(account_id), join_id, join_state="deadline", last_error="extension_reconnect_after_deadline")
            continue
        payloads.append(_extension_train_payload(int(chat_id), str(account_id), job))
    return payloads


async def _handle_extension_train_event(conn: Any, msg: dict) -> dict:
    chat_id = int(getattr(conn, "chat_id", 0) or 0)
    account_id = str(getattr(conn, "account_id", "acc_1") or "acc_1")
    event_type = str(msg.get("type") or "").strip().lower()
    join_id = str(msg.get("join_id") or "").strip()
    task_id = str(msg.get("task_id") or "").strip()
    expected_task_id = _extension_train_task_id(chat_id, account_id, join_id) if join_id else ""
    if not join_id or task_id != expected_task_id:
        logger.warning(
            "Поезд через расширение: событие отклонено | %s | acc=%s | тип=%s | причина=неверный task_id/join_id",
            _train_user_label(chat_id), account_id, event_type or "-",
        )
        return {"accepted": False, "status": "bad_task_identity"}

    job = _get_train_job(chat_id, account_id, join_id)
    if not job:
        if event_type == "train_result":
            return {"accepted": True, "terminal": True, "status": "job_already_cleaned"}
        return {"accepted": False, "status": "job_not_found"}

    current_acc = _get_train_account(chat_id, account_id, include_empty=True) or {}
    current_mode = _train_activation_mode(chat_id, current_acc)
    if current_mode != "extension" or str(job.get("join_mode") or "server").strip().lower() != "extension":
        if event_type == "train_result":
            return {"accepted": True, "terminal": True, "status": "cancelled"}
        return {"accepted": False, "status": "wrong_activation_mode"}

    gid = str(job.get("gid") or "-")
    dispatch_state = str(job.get("extension_dispatch_state") or "")
    if event_type == "train_delivered":
        if dispatch_state != "delivered":
            _patch_train_job(chat_id, account_id, join_id, extension_dispatch_state="delivered", extension_delivered_at_ts=int(time.time()), last_error="")
            logger.info("Поезд #%s через расширение: задача доставлена | %s | acc=%s | join_id=%s", gid, _train_user_label(chat_id), account_id, join_id)
        return {"accepted": True, "status": "delivered"}

    if event_type == "train_task_ack":
        if dispatch_state != "stored":
            _patch_train_job(chat_id, account_id, join_id, extension_dispatch_state="stored", extension_stored_at_ts=int(time.time()), last_error="")
            logger.info("Поезд #%s через расширение: задача принята расширением | %s | acc=%s", gid, _train_user_label(chat_id), account_id)
        return {"accepted": True, "status": "stored"}

    attempts_used = max(0, int(msg.get("attempts_used") or msg.get("attempt") or 0))
    executed_at_ms = max(0, int(msg.get("executed_at_utc_ms") or 0))
    if event_type == "train_progress":
        if attempts_used < 1 or attempts_used > _TRAIN_JOIN_MAX_ATTEMPTS:
            return {"accepted": False, "status": "bad_attempt_count"}
        stage = str(msg.get("stage") or "request").strip().lower()
        _patch_train_job(
            chat_id, account_id, join_id,
            join_state="attempting" if stage == "request" else str(job.get("join_state") or "scheduled"),
            attempts_used=max(int(job.get("attempts_used") or 0), attempts_used),
            last_attempt_at_ts=int(executed_at_ms / 1000) if executed_at_ms else int(time.time()),
            extension_dispatch_state="executing",
        )
        if stage == "request":
            logger.info("Поезд #%s через расширение: запрос участия | %s | acc=%s | попытка=%s/%s", gid, _train_user_label(chat_id), account_id, attempts_used, _TRAIN_JOIN_MAX_ATTEMPTS)
        return {"accepted": True, "status": stage}

    if event_type != "train_result":
        return {"accepted": False, "status": "unsupported_event"}
    if str(job.get("extension_result_task_id") or "") == task_id:
        return {"accepted": True, "status": str(job.get("join_state") or "duplicate")}

    raw_status = str(msg.get("status") or "extension_error").strip().lower()
    allowed = {"success", "joined", "rejected", "deadline", "exhausted", "extension_error", "failed"}
    if raw_status not in allowed:
        _patch_train_job(chat_id, account_id, join_id, join_state="exhausted", last_error="invalid_extension_status", extension_dispatch_state="result")
        return {"accepted": True, "terminal": True, "status": "invalid_result"}
    if attempts_used < 0 or attempts_used > _TRAIN_JOIN_MAX_ATTEMPTS:
        _patch_train_job(chat_id, account_id, join_id, join_state="exhausted", last_error="invalid_attempt_count", extension_dispatch_state="result")
        return {"accepted": True, "terminal": True, "status": "invalid_result"}

    created_ms = int(float(job.get("created_at_ts") or 0) * 1000)
    finish_ms = int(float(job.get("finish_ts") or 0) * 1000)
    now_ms = int(time.time() * 1000)
    timestamp_valid = bool(executed_at_ms and executed_at_ms <= now_ms + 30_000 and (not created_ms or executed_at_ms >= created_ms - 300_000))
    late = bool(finish_ms and executed_at_ms > finish_ms - int(_TRAIN_JOIN_DEADLINE_MARGIN_SEC * 1000) + 5_000)
    reason = str(msg.get("message") or msg.get("reason") or raw_status).strip()[:500]
    if not timestamp_valid:
        join_state = "exhausted"
        raw_status = "invalid_timestamp"
        reason = "invalid_extension_timestamp"
    elif late and raw_status in {"success", "joined", "rejected"}:
        join_state = "deadline"
        raw_status = "deadline"
        reason = "extension_result_after_deadline"
    elif raw_status in {"success", "joined"}:
        join_state = "success"
    elif raw_status == "rejected":
        join_state = "rejected"
    elif raw_status == "deadline":
        join_state = "deadline"
    else:
        join_state = "exhausted"

    _patch_train_job(
        chat_id, account_id, join_id,
        join_state=join_state,
        attempts_used=max(int(job.get("attempts_used") or 0), attempts_used),
        last_attempt_at_ts=int(executed_at_ms / 1000) if executed_at_ms else int(time.time()),
        last_error="" if join_state == "success" else reason,
        extension_dispatch_state="result",
        extension_result_task_id=task_id,
        extension_result_status=raw_status,
        extension_result_at_ts=int(time.time()),
        extension_http_status=int(msg.get("http_status") or 0),
    )

    if join_state == "success":
        logger.info("Поезд #%s через расширение: участие принято | %s | acc=%s | попытка=%s/%s", gid, _train_user_label(chat_id), account_id, attempts_used or 1, _TRAIN_JOIN_MAX_ATTEMPTS)
        bot = _TRAIN_BOT
        if bot is not None:
            safe_url = str(job.get("url") or "").strip() or f"{str(get_active_domain() or '').rstrip('/')}/giveaways/{join_id}"
            conductor = str(job.get("conductor") or "поезде").strip() or "поезде"
            safe_name = conductor.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            with contextlib.suppress(Exception):
                await bot.send_message(chat_id=chat_id, text=f'Участие в поезде от <a href="{safe_url}">{safe_name}</a>', parse_mode=ParseMode.HTML)
    elif join_state == "rejected":
        logger.warning("Поезд #%s через расширение: участие отклонено | %s | acc=%s | причина=%s", gid, _train_user_label(chat_id), account_id, reason)
    elif join_state == "deadline":
        logger.warning("Поезд #%s через расширение: дедлайн участия прошёл | %s | acc=%s | причина=%s", gid, _train_user_label(chat_id), account_id, reason)
    else:
        logger.warning("Поезд #%s через расширение: попытки закончились | %s | acc=%s | попыток=%s | причина=%s", gid, _train_user_label(chat_id), account_id, attempts_used, reason)
    return {"accepted": True, "status": join_state}



async def _dispatch_extension_train_job(chat_id: int, account_id: str, job: dict) -> None:
    manager = _EXTENSION_TRAIN_MANAGER
    gid = str(job.get("gid") or "-")
    join_id = str(job.get("join_id") or "").strip()
    if not has_active_account_subscription(int(chat_id), str(account_id), int(time.time())):
        _patch_train_job(chat_id, account_id, join_id, join_state="subscription_inactive", last_error="subscription_inactive")
        logger.info("Поезд #%s через расширение: пропущен | %s | acc=%s | причина=нет активной подписки", gid, _train_user_label(chat_id), account_id)
        return
    if manager is None:
        _patch_train_job(chat_id, account_id, join_id, extension_dispatch_state="pending", last_error="extension_manager_unavailable")
        logger.info("Поезд #%s через расширение: ждёт отправки | %s | acc=%s | причина=менеджер расширений недоступен", gid, _train_user_label(chat_id), account_id)
        return
    result = await manager.send_train_task(
        chat_id=int(chat_id),
        account_id=str(account_id),
        payload=_extension_train_payload(int(chat_id), str(account_id), job),
    )
    if not bool(result.get("sent")):
        reason = str(result.get("status") or "extension_offline")
        _patch_train_job(chat_id, account_id, join_id, extension_dispatch_state="pending", last_error=reason)
        logger.info("Поезд #%s через расширение: ждёт отправки | %s | acc=%s | причина=%s", gid, _train_user_label(chat_id), account_id, reason)


def _schedule_extension_train_dispatch(chat_id: int, account_id: str, job: dict) -> bool:
    join_id = str(job.get("join_id") or "").strip()
    gid = str(job.get("gid") or "-")
    key = _train_task_key("extension", join_id, chat_id, account_id)
    if not join_id or _train_task_active(key):
        return False
    task = asyncio.create_task(
        _dispatch_extension_train_job(int(chat_id), str(account_id), dict(job)),
        name=f"train-extension:{join_id}:{chat_id}:{account_id}",
    )
    _track_train_task(
        task,
        key=key,
        kind="extension",
        gid=gid,
        join_id=join_id,
        chat_id=int(chat_id),
        account_id=str(account_id),
    )
    return True


async def handover_train_jobs_for_account(chat_id: int, account_id: str, target_mode: str) -> int:
    # Move only unfinished jobs to the selected executor; discovery and Telegram posting stay untouched.
    cid = int(chat_id)
    aid = str(account_id or "acc_1")
    mode = "extension" if str(target_mode or "server").strip().lower() == "extension" else "server"
    acc = _get_train_account(cid, aid, include_empty=True)
    if not acc:
        return 0
    changed = 0
    now = time.time()
    for join_id, job in list(_train_jobs_from_account(acc).items()):
        state = str(job.get("join_state") or "scheduled").strip().lower()
        finish_ts = float(job.get("finish_ts") or 0.0)
        if _train_join_terminal_state(state) or finish_ts <= now + _TRAIN_JOIN_DEADLINE_MARGIN_SEC:
            continue
        old_mode = str(job.get("join_mode") or "server").strip().lower()
        if old_mode == mode:
            continue
        for kind in ("join", "extension"):
            key = _train_task_key(kind, str(join_id), cid, aid)
            task = _TRAIN_TASKS.get(key)
            if task and not task.done():
                task.cancel()
        if old_mode == "extension" and _EXTENSION_TRAIN_MANAGER is not None:
            with contextlib.suppress(Exception):
                await _EXTENSION_TRAIN_MANAGER.send_train_cancel(
                    chat_id=cid,
                    account_id=aid,
                    join_id=str(join_id),
                    task_id=_extension_train_task_id(cid, aid, str(join_id)),
                    reason=f"runtime_handover:{old_mode}->{mode}",
                )
        fresh = _patch_train_job(
            cid,
            aid,
            str(join_id),
            join_mode=mode,
            join_state="scheduled",
            last_error="",
            extension_dispatch_state=("pending" if mode == "extension" else ""),
        ) or dict(job)
        if _TRAIN_BOT is not None:
            if mode == "extension":
                _schedule_extension_train_dispatch(cid, aid, fresh)
            else:
                _schedule_train_join_task(_TRAIN_BOT, cid, aid, fresh)
        changed += 1
    if changed:
        logger.info("Поезд: задачи переключены на другой режим | %s | acc=%s | режим=%s | задач=%s", _train_user_label(cid), aid, mode, changed)
    return changed


async def cancel_train_jobs_for_account(chat_id: int, account_id: str, reason: str = "activation_mode_changed") -> int:
    acc = _get_train_account(int(chat_id), str(account_id), include_empty=True)
    if not acc:
        return 0
    cancelled = 0
    for join_id, job in list(_train_jobs_from_account(acc).items()):
        state = str(job.get("join_state") or "scheduled")
        if _train_join_terminal_state(state):
            continue
        for kind in ("join", "extension"):
            key = _train_task_key(kind, join_id, int(chat_id), str(account_id))
            task = _TRAIN_TASKS.get(key)
            if task and not task.done():
                task.cancel()
        if str(job.get("join_mode") or "server").strip().lower() == "extension" and _EXTENSION_TRAIN_MANAGER is not None:
            with contextlib.suppress(Exception):
                await _EXTENSION_TRAIN_MANAGER.send_train_cancel(
                    chat_id=int(chat_id),
                    account_id=str(account_id),
                    join_id=str(join_id),
                    task_id=_extension_train_task_id(int(chat_id), str(account_id), str(join_id)),
                    reason=str(reason or "cancelled"),
                )
        _patch_train_job(
            int(chat_id), str(account_id), str(join_id),
            join_state="cancelled",
            join_enabled=False,
            last_error=str(reason or "cancelled")[:500],
            extension_dispatch_state="cancelled",
        )
        cancelled += 1
    if cancelled:
        logger.info("Поезд: задачи аккаунта отменены | %s | acc=%s | количество=%s | причина=%s", _train_user_label(int(chat_id)), account_id, cancelled, reason)
    return cancelled

def _train_join_readiness(chat_id: int, account_id: str) -> tuple[dict | None, str, str, bool]:
    """Return (account, domain, wait_reason, terminal_failure)."""
    try:
        acc = _get_train_account(chat_id, account_id)
    except Exception as exc:
        return None, "", f"account_read_error:{type(exc).__name__}", False

    if not acc:
        return None, "", "account_missing", True

    if _train_activation_mode(int(chat_id), acc) == "extension":
        return acc, "", "extension_mode", True

    if bool(normalize_server_session_state(acc.get("server_session_state")).get("stale")):
        return acc, "", "server_session_stale", False

    now_ts = int(time.time())
    if not has_active_account_subscription(int(chat_id), str(account_id), now_ts):
        return acc, "", "subscription_inactive", True

    if not _is_train_admin(chat_id):
        if not str(acc.get("proxy_url") or "").strip():
            return acc, "", "no_proxy", True
        proxy_status = str(acc.get("proxy_runtime_status") or "healthy").strip().lower()
        if proxy_status in _TRAIN_PROXY_BLOCKED_STATUSES:
            return acc, "", f"proxy_{proxy_status}", False

    if not str(acc.get("zooma_top_session") or "").strip():
        return acc, "", "no_session", False
    if not str(acc.get("csrf_token") or "").strip():
        return acc, "", "no_csrf", False

    domain = str(get_active_domain() or "").strip().rstrip("/")
    if not domain:
        return acc, "", "no_active_domain", False
    return acc, domain, "", False


async def _wait_for_train_join_ready(
    *,
    chat_id: int,
    account_id: str,
    gid: str,
    join_id: str,
    attempt: int,
    deadline_ts: float,
    not_before_ts: float = 0.0,
) -> tuple[dict, str] | None:
    last_reason = ""
    last_log_ts = 0.0
    saw_unready_state = False

    while True:
        now = time.time()
        current_job = _get_train_job(chat_id, account_id, join_id) or {}
        current_state = str(current_job.get("join_state") or "").strip().lower()
        if current_state and _train_join_terminal_state(current_state):
            logger.info(
                "Поезд: ожидание участия остановлено | chat_id=%s | acc=%s | поезд=%s | join_id=%s | состояние=%s | попытка=%s/%s",
                chat_id,
                account_id,
                gid,
                join_id,
                current_state,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
            )
            return None

        if now >= deadline_ts:
            _patch_train_job(chat_id, account_id, join_id, join_state="deadline")
            logger.warning(
                "Поезд: дедлайн участия достигнут | chat_id=%s | acc=%s | поезд=%s | join_id=%s | попытка=%s/%s",
                chat_id,
                account_id,
                gid,
                join_id,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
            )
            return None

        acc, domain, reason, terminal = _train_join_readiness(chat_id, account_id)
        if terminal:
            if reason == "extension_mode":
                job = _get_train_job(chat_id, account_id, join_id) or {}
                fresh = _patch_train_job(
                    chat_id,
                    account_id,
                    join_id,
                    join_mode="extension",
                    join_state="scheduled",
                    extension_dispatch_state="pending",
                    last_error="",
                ) or job
                _schedule_extension_train_dispatch(chat_id, account_id, fresh)
                logger.info(
                    "Поезд: серверная задача передана в расширение | chat_id=%s | acc=%s | поезд=%s | join_id=%s | попытка=%s/%s",
                    chat_id,
                    account_id,
                    gid,
                    join_id,
                    attempt,
                    _TRAIN_JOIN_MAX_ATTEMPTS,
                )
                return None
            _patch_train_job(chat_id, account_id, join_id, join_state=reason)
            logger.warning(
                "Поезд: участие пропущено | chat_id=%s | acc=%s | поезд=%s | join_id=%s | причина=%s | попытка=%s/%s",
                chat_id,
                account_id,
                gid,
                join_id,
                reason,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
            )
            return None

        ready = not reason
        if ready and (now >= not_before_ts or saw_unready_state):
            if saw_unready_state:
                logger.info(
                    "Поезд: аккаунт снова готов к участию | chat_id=%s | acc=%s | поезд=%s | join_id=%s "
                    "попытка=%s/%s | до_дедлайна=%.1fs",
                    chat_id,
                    account_id,
                    gid,
                    join_id,
                    attempt,
                    _TRAIN_JOIN_MAX_ATTEMPTS,
                    max(0.0, deadline_ts - now),
                )
            return acc or {}, domain

        wait_reason = reason or "retry_backoff"
        if reason:
            saw_unready_state = True
        if wait_reason != last_reason or now - last_log_ts >= 60.0:
            logger.info(
                "Поезд: ждём готовность аккаунта | chat_id=%s | acc=%s | поезд=%s | join_id=%s "
                "причина=%s | попытка=%s/%s | повтор_через=%.1fs | до_дедлайна=%.1fs",
                chat_id,
                account_id,
                gid,
                join_id,
                wait_reason,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
                max(0.0, not_before_ts - now) if not reason else 0.0,
                max(0.0, deadline_ts - now),
            )
            last_reason = wait_reason
            last_log_ts = now

        sleep_for = min(_TRAIN_JOIN_WAIT_POLL_SEC, max(0.1, deadline_ts - now))
        if ready and now < not_before_ts:
            sleep_for = min(sleep_for, max(0.1, not_before_ts - now))
        await asyncio.sleep(sleep_for)


async def _join_train_for_account(
    bot,
    chat_id: int,
    account_id: str,
    train: dict,
    join_at_ts: float,
) -> None:
    finish_ts = _parse_finish_ts(train)
    gid = str(train.get("gid") or "").strip()
    join_id = _extract_train_join_id(train)
    url = str(train.get("url") or "").strip()
    conductor = str(train.get("conductor") or "поезде").strip() or "поезде"

    if not gid or not join_id or not finish_ts:
        logger.warning(
            "Поезд: пропущен некорректный поезд | chat_id=%s | acc=%s | поезд=%s | join_id=%s | finish=%r",
            chat_id,
            account_id,
            gid or "-",
            join_id or "-",
            train.get("finishAt"),
        )
        return

    deadline_ts = finish_ts - _TRAIN_JOIN_DEADLINE_MARGIN_SEC
    delay = max(0.0, float(join_at_ts or 0.0) - time.time())
    logger.info(
        "Поезд #%s: участие запланировано | %s | acc=%s | join_id=%s | время=%s OMSK | попыток=%s",
        gid,
        _train_user_label(chat_id),
        account_id,
        join_id,
        _train_log_time(join_at_ts),
        _TRAIN_JOIN_MAX_ATTEMPTS,
    )
    if delay > 0:
        await asyncio.sleep(min(delay, max(0.0, deadline_ts - time.time())))

    job = _get_train_job(chat_id, account_id, join_id) or {}
    attempts_used = max(0, int(job.get("attempts_used") or 0))
    if attempts_used >= _TRAIN_JOIN_MAX_ATTEMPTS:
        _patch_train_job(chat_id, account_id, join_id, join_state="exhausted")
        return

    not_before_ts = 0.0
    for attempt in range(attempts_used + 1, _TRAIN_JOIN_MAX_ATTEMPTS + 1):
        ready = await _wait_for_train_join_ready(
            chat_id=chat_id,
            account_id=account_id,
            gid=gid,
            join_id=join_id,
            attempt=attempt,
            deadline_ts=deadline_ts,
            not_before_ts=not_before_ts,
        )
        if ready is None:
            return
        acc, domain = ready

        remaining = finish_ts - time.time()
        if remaining <= _TRAIN_JOIN_DEADLINE_MARGIN_SEC:
            _patch_train_job(chat_id, account_id, join_id, join_state="deadline")
            return

        csrf = str(acc.get("csrf_token") or "").strip()
        fp = str(acc.get("fingerprint_now") or "").strip()
        zooma_session = str(acc.get("zooma_top_session") or "").strip()
        proxy_url = str(acc.get("proxy_url") or "").strip()
        proxy_status = str(acc.get("proxy_runtime_status") or "healthy").strip().lower()
        data = {
            "_token": csrf,
            "id": join_id,
            "arg1": "",
            "arg2": "",
            "arg3": "",
            "arg4": "",
            "arg5": "",
            "betAmount": "0",
        }
        if fp:
            data["fingerPrintNow"] = fp

        safe_url = url or f"{domain}/giveaways/{join_id}"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "*/*",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": safe_url,
            "Origin": domain,
            "Cookie": f"zooma_top_session={zooma_session}" if zooma_session else "",
        }
        _patch_train_job(
            chat_id,
            account_id,
            join_id,
            join_state="attempting",
            attempts_used=attempt,
            last_attempt_at_ts=int(time.time()),
        )
        logger.info(
            "Поезд #%s: запрос участия через сервер | %s | acc=%s | попытка=%s/%s | прокси=%s",
            gid,
            _train_user_label(chat_id),
            account_id,
            attempt,
            _TRAIN_JOIN_MAX_ATTEMPTS,
            proxy_status if proxy_url else "direct",
        )

        if _account_in_extension_mode(int(chat_id), account_id):
            fresh = _patch_train_job(
                chat_id,
                account_id,
                join_id,
                join_mode="extension",
                join_state="scheduled",
                extension_dispatch_state="pending",
                last_error="",
            ) or job
            _schedule_extension_train_dispatch(chat_id, account_id, fresh)
            logger.info(
                "Поезд #%s: серверная задача передана в расширение | %s | acc=%s | причина=режим расширения",
                gid,
                _train_user_label(chat_id),
                account_id,
            )
            return

        try:
            resp = await user_http_request(
                chat_id=int(chat_id),
                account_id=account_id,
                method="POST",
                url=f"{domain}/apiPost/giveAwayJoin",
                headers=headers,
                data=data,
                timeout=min(25.0, max(3.0, remaining - 1.0)),
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning(
                "Поезд: сетевая ошибка участия | chat_id=%s | acc=%s | поезд=%s | join_id=%s "
                "попытка=%s/%s | ошибка=%s: %s",
                chat_id,
                account_id,
                gid,
                join_id,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
                type(exc).__name__,
                exc,
            )
            if attempt >= _TRAIN_JOIN_MAX_ATTEMPTS:
                _patch_train_job(
                    chat_id,
                    account_id,
                    join_id,
                    join_state="exhausted",
                    last_error=f"{type(exc).__name__}: {exc}"[:500],
                )
                logger.error(
                    "Поезд: попытки участия закончились | chat_id=%s | acc=%s | поезд=%s | join_id=%s | попыток=%s",
                    chat_id,
                    account_id,
                    gid,
                    join_id,
                    attempt,
                )
                return
            _patch_train_job(chat_id, account_id, join_id, join_state="scheduled")
            not_before_ts = time.time() + random.uniform(_TRAIN_JOIN_RETRY_MIN_SEC, _TRAIN_JOIN_RETRY_MAX_SEC)
            continue

        transient_http = int(resp.status_code or 0) in {408, 425, 429} or int(resp.status_code or 0) >= 500
        if transient_http:
            logger.warning(
                "Поезд: временная HTTP ошибка участия | chat_id=%s | acc=%s | поезд=%s | join_id=%s "
                "попытка=%s/%s | http=%s | ответ=%r",
                chat_id,
                account_id,
                gid,
                join_id,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
                resp.status_code,
                (resp.text or "")[:300],
            )
            if attempt >= _TRAIN_JOIN_MAX_ATTEMPTS:
                _patch_train_job(chat_id, account_id, join_id, join_state="exhausted", last_error=f"http_{resp.status_code}")
                return
            _patch_train_job(chat_id, account_id, join_id, join_state="scheduled")
            not_before_ts = time.time() + random.uniform(_TRAIN_JOIN_RETRY_MIN_SEC, _TRAIN_JOIN_RETRY_MAX_SEC)
            continue

        try:
            payload = json.loads(resp.text or "{}")
        except json.JSONDecodeError as exc:
            logger.warning(
                "Поезд: сайт вернул не JSON | chat_id=%s | acc=%s | поезд=%s | join_id=%s "
                "попытка=%s/%s | http=%s | ошибка=%s | ответ=%r",
                chat_id,
                account_id,
                gid,
                join_id,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
                resp.status_code,
                exc,
                (resp.text or "")[:500],
            )
            if attempt >= _TRAIN_JOIN_MAX_ATTEMPTS:
                _patch_train_job(chat_id, account_id, join_id, join_state="exhausted", last_error="invalid_json")
                return
            _patch_train_job(chat_id, account_id, join_id, join_state="scheduled")
            not_before_ts = time.time() + random.uniform(_TRAIN_JOIN_RETRY_MIN_SEC, _TRAIN_JOIN_RETRY_MAX_SEC)
            continue

        if not isinstance(payload, dict):
            if attempt >= _TRAIN_JOIN_MAX_ATTEMPTS:
                _patch_train_job(chat_id, account_id, join_id, join_state="exhausted", last_error="invalid_payload")
                return
            _patch_train_job(chat_id, account_id, join_id, join_state="scheduled")
            not_before_ts = time.time() + random.uniform(_TRAIN_JOIN_RETRY_MIN_SEC, _TRAIN_JOIN_RETRY_MAX_SEC)
            continue

        if payload.get("status") == "success":
            _patch_train_job(chat_id, account_id, join_id, join_state="success", last_error="")
            safe_name = conductor.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            logger.info(
                "Поезд #%s: участие принято | %s | acc=%s | попытка=%s/%s",
                gid,
                _train_user_label(chat_id),
                account_id,
                attempt,
                _TRAIN_JOIN_MAX_ATTEMPTS,
            )
            try:
                await bot.send_message(
                    chat_id=int(chat_id),
                    text=f'Участие в поезде от <a href="{safe_url}">{safe_name}</a>',
                    parse_mode=ParseMode.HTML,
                )
            except Exception as exc:
                logger.warning(
                    "Поезд: не удалось отправить уведомление об участии | chat_id=%s | acc=%s | поезд=%s | join_id=%s | ошибка=%s",
                    chat_id,
                    account_id,
                    gid,
                    join_id,
                    exc,
                )
            return

        error_msg = payload.get("message") or payload.get("text") or "Неизвестная ошибка"
        _patch_train_job(chat_id, account_id, join_id, join_state="rejected", last_error=str(error_msg)[:500])
        logger.warning(
            "Поезд #%s: участие отклонено | %s | acc=%s | причина=%s",
            gid,
            _train_user_label(chat_id),
            account_id,
            error_msg,
        )
        return


def _parse_train_amount(value: Any) -> float | None:
    text = str(value or "").replace("\xa0", " ").strip()
    if not text:
        return None
    cleaned = re.sub(r"[^0-9,.-]", "", text.replace(" ", ""))
    if not cleaned:
        return None
    if cleaned.count(",") == 1 and "." not in cleaned:
        cleaned = cleaned.replace(",", ".")
    with contextlib.suppress(ValueError, OverflowError):
        amount = float(cleaned)
        if amount >= 0:
            return amount
    return None


def _format_train_amount(amount: float | None) -> str:
    value = max(0.0, float(amount or 0.0))
    if abs(value - round(value)) < 0.005:
        return f"{int(round(value)):,}".replace(",", " ") + " ₽"
    return f"{value:,.2f}".replace(",", " ").replace(".", ",") + " ₽"


def _parse_train_result_html(html_text: str) -> dict | None:
    soup = BeautifulSoup(html_text or "", "html.parser")
    root = soup.select_one("#giveAwayBlock")
    if root is None:
        return None

    prize_places = int(_parse_train_amount(root.get("data-giveaway-prizeplace")) or 0)
    per_place = _parse_train_amount(root.get("data-giveaway-prizeperplace"))
    if not per_place or per_place <= 0:
        cond_text = _clean_text(root.get_text(" ", strip=True))
        match = re.search(r"([\d\s]+(?:[.,]\d+)?)\s*₽\s*/\s*мест", cond_text, re.IGNORECASE)
        if match:
            per_place = _parse_train_amount(match.group(1))
    if not per_place or per_place <= 0:
        fund_node = root.select_one(".gaTicket__prizeNum")
        fund = _parse_train_amount(fund_node.get_text(" ", strip=True) if fund_node else "")
        if fund and prize_places > 0:
            per_place = fund / prize_places

    table = soup.select_one("#giveAwayWinnersTable")
    if table is None:
        return None

    winners: list[dict] = []
    seen_ids: set[str] = set()
    for row in table.select("[id^='giveAwayWinnerRow_']"):
        link = row.select_one("a[href^='/user/']")
        match = re.search(r"/user/(\d+)", str(link.get("href") or "")) if link else None
        if not match:
            continue
        casino_id = match.group(1)
        if casino_id in seen_ids:
            continue
        seen_ids.add(casino_id)
        name_node = row.select_one(".tl-name")
        name = _clean_text(name_node.get_text(" ", strip=True) if name_node else "")
        prize_node = row.select_one(".tl-col-prize")
        row_amount = _parse_train_amount(prize_node.get_text(" ", strip=True) if prize_node else "")
        if not row_amount or row_amount <= 0:
            row_amount = per_place
        place_match = re.search(r"_(\d+)$", str(row.get("id") or ""))
        winners.append({
            "casino_id": casino_id,
            "name": name,
            "place": int(place_match.group(1)) if place_match else len(winners) + 1,
            "amount": float(row_amount or 0.0),
        })

    if not winners:
        return None
    if prize_places > 0 and len(winners) < prize_places:
        return None
    return {
        "winners": winners,
        "prize_places": prize_places or len(winners),
        "per_place": float(per_place or 0.0),
    }


def _train_result_fetch_url(job: dict) -> str:
    join_id = str(job.get("join_id") or "").strip()
    domain = str(get_active_domain() or "").strip().rstrip("/")
    if domain and join_id:
        return f"{domain}/giveaways/{join_id}"
    return str(job.get("url") or "").strip()


async def _notify_train_winners(bot, job: dict, parsed: dict, result_url: str) -> bool:
    join_id = str(job.get("join_id") or "").strip()
    gid = str(job.get("gid") or "").strip()
    all_sent = True
    active_by_casino_id: dict[str, list[tuple[int, str, dict]]] = {}
    now_ts = int(time.time())

    for chat_id in get_all_chat_ids():
        with contextlib.suppress(Exception):
            for acc in get_user_accounts(int(chat_id), include_empty=False):
                aid = str(acc.get("account_id") or "").strip()
                casino_id = str(acc.get("port_user_id") or "").strip()
                if not aid or not casino_id:
                    continue
                if not has_active_account_subscription(int(chat_id), aid, now_ts):
                    continue
                active_by_casino_id.setdefault(casino_id, []).append((int(chat_id), aid, dict(acc)))

    for winner in parsed.get("winners") or []:
        casino_id = str(winner.get("casino_id") or "").strip()
        if not casino_id:
            continue
        for chat_id, account_id, acc in active_by_casino_id.get(casino_id, []):
            current_job = _get_train_job(chat_id, account_id, join_id)
            if current_job and bool(current_job.get("winner_notified")):
                continue
            if current_job is None:
                current_job = _patch_train_job(
                    chat_id,
                    account_id,
                    join_id,
                    create=dict(job),
                    winner_check_state="processing",
                )
            account_name = str(acc.get("port_user_name") or winner.get("name") or f"ID {casino_id}").strip()
            amount_text = _format_train_amount(_parse_train_amount(winner.get("amount")))
            message = (
                "🎉 Поздравляю, вы выиграли в поезде!\n\n"
                f"Аккаунт: {account_name}\n\n"
                f"Сумма: {amount_text}\n\n"
                f"Ссылка: {result_url}"
            )
            try:
                await bot.send_message(chat_id=int(chat_id), text=message)
                _patch_train_job(
                    chat_id,
                    account_id,
                    join_id,
                    create=current_job or dict(job),
                    winner_notified=True,
                    winner_notified_at_ts=int(time.time()),
                    winner_casino_id=casino_id,
                    winner_amount=float(winner.get("amount") or 0.0),
                    winner_place=int(winner.get("place") or 0),
                )
                logger.info(
                    "Поезд #%s: уведомление о выигрыше отправлено | %s | acc=%s | место=%s | сумма=%s",
                    gid,
                    _train_user_label(chat_id),
                    account_id,
                    winner.get("place"),
                    amount_text,
                )
            except Exception as exc:
                all_sent = False
                logger.warning(
                    "Поезд: не удалось отправить уведомление о выигрыше | chat_id=%s | acc=%s | поезд=%s | join_id=%s "
                    "casino_id=%s | ошибка=%s",
                    chat_id,
                    account_id,
                    gid,
                    join_id,
                    casino_id,
                    exc,
                )
    return all_sent


async def _check_train_winners(bot, job: dict) -> None:
    join_id = str(job.get("join_id") or "").strip()
    gid = str(job.get("gid") or "").strip()
    check_at_ts = float(job.get("finish_ts") or 0.0) + _TRAIN_WINNER_INITIAL_DELAY_SEC
    delay = max(0.0, check_at_ts - time.time())
    logger.info(
        "Поезд: проверка победителей запланирована | поезд=%s | join_id=%s | через=%.1fs | время=%s",
        gid or "-",
        join_id,
        delay,
        int(check_at_ts),
    )
    if delay > 0:
        await asyncio.sleep(delay)

    for attempt, retry_delay in enumerate(_TRAIN_WINNER_RETRY_DELAYS_SEC, start=1):
        if retry_delay > 0:
            await asyncio.sleep(float(retry_delay))
        result_url = _train_result_fetch_url(job)
        if not result_url:
            logger.warning(
                "Поезд: проверка победителей невозможна | поезд=%s | join_id=%s | попытка=%s/%s | причина=нет ссылки",
                gid,
                join_id,
                attempt,
                len(_TRAIN_WINNER_RETRY_DELAYS_SEC),
            )
            continue
        logger.info(
            "Поезд: запрос проверки победителей | поезд=%s | join_id=%s | попытка=%s/%s | url=%s",
            gid,
            join_id,
            attempt,
            len(_TRAIN_WINNER_RETRY_DELAYS_SEC),
            result_url,
        )
        try:
            html_text = await asyncio.to_thread(_http_get_text, result_url, 25.0)
            parsed = _parse_train_result_html(html_text)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning(
                "Поезд: сетевая ошибка проверки победителей | поезд=%s | join_id=%s | попытка=%s/%s | ошибка=%s: %s",
                gid,
                join_id,
                attempt,
                len(_TRAIN_WINNER_RETRY_DELAYS_SEC),
                type(exc).__name__,
                exc,
            )
            continue

        if parsed is None:
            logger.info(
                "Поезд: победители ещё не готовы | поезд=%s | join_id=%s | попытка=%s/%s",
                gid,
                join_id,
                attempt,
                len(_TRAIN_WINNER_RETRY_DELAYS_SEC),
            )
            continue

        logger.info(
            "Поезд: победители найдены | поезд=%s | join_id=%s | победителей=%s | сумма_за_место=%s | попытка=%s/%s",
            gid,
            join_id,
            len(parsed.get("winners") or []),
            _format_train_amount(parsed.get("per_place")),
            attempt,
            len(_TRAIN_WINNER_RETRY_DELAYS_SEC),
        )
        if await _notify_train_winners(bot, job, parsed, result_url):
            removed = _cleanup_train_job_everywhere(join_id)
            logger.info(
                "Поезд: проверка победителей завершена | поезд=%s | join_id=%s | очищено_аккаунтов=%s",
                gid,
                join_id,
                removed,
            )
            return

    removed = _cleanup_train_job_everywhere(join_id)
    logger.warning(
        "Поезд: проверки победителей закончились | поезд=%s | join_id=%s | попыток=%s | очищено_аккаунтов=%s",
        gid,
        join_id,
        len(_TRAIN_WINNER_RETRY_DELAYS_SEC),
        removed,
    )


def _schedule_train_join_task(bot, chat_id: int, account_id: str, job: dict) -> bool:
    if str(job.get("join_mode") or "server").strip().lower() == "extension":
        return False
    join_id = str(job.get("join_id") or "").strip()
    gid = str(job.get("gid") or "").strip()
    key = _train_task_key("join", join_id, chat_id, account_id)
    if not join_id or _train_task_active(key):
        return False
    train = _train_job_payload(job)
    task = asyncio.create_task(
        _join_train_for_account(bot, int(chat_id), str(account_id), train, float(job.get("join_at_ts") or time.time())),
        name=f"train-join:{join_id}:{chat_id}:{account_id}",
    )
    _track_train_task(
        task,
        key=key,
        kind="join",
        gid=gid or "-",
        join_id=join_id,
        chat_id=int(chat_id),
        account_id=str(account_id),
    )
    return True


def _schedule_train_winner_task(bot, job: dict) -> bool:
    join_id = str(job.get("join_id") or "").strip()
    gid = str(job.get("gid") or "").strip()
    key = _train_task_key("winner", join_id)
    if not join_id or _train_task_active(key):
        return False
    task = asyncio.create_task(
        _check_train_winners(bot, dict(job)),
        name=f"train-winners:{join_id}",
    )
    _track_train_task(task, key=key, kind="winner", gid=gid or "-", join_id=join_id)
    return True


async def _restore_train_jobs(bot) -> None:
    now = time.time()
    join_restored = 0
    extension_restored = 0
    winner_restored = 0
    stale_removed = 0
    representative: dict[str, dict] = {}

    for chat_id in get_all_chat_ids():
        with contextlib.suppress(Exception):
            for acc in get_user_accounts(int(chat_id), include_empty=True):
                aid = str(acc.get("account_id") or "").strip()
                if not aid:
                    continue
                for join_id, job in list(_train_jobs_from_account(acc).items()):
                    finish_ts = float(job.get("finish_ts") or 0.0)
                    if not join_id or finish_ts <= 0:
                        if _remove_train_job(int(chat_id), aid, join_id):
                            stale_removed += 1
                        continue
                    if now > finish_ts + _TRAIN_JOB_STALE_SEC:
                        if _remove_train_job(int(chat_id), aid, join_id):
                            stale_removed += 1
                        continue

                    stored_mode = str(job.get("join_mode") or "").strip().lower()
                    join_mode = stored_mode or _train_activation_mode(int(chat_id), acc)
                    state = str(job.get("join_state") or "scheduled")
                    join_enabled = bool(job.get("join_enabled", True))
                    if not stored_mode:
                        migration_fields: dict[str, Any] = {
                            "schema": 2,
                            "join_mode": join_mode,
                            "join_at_utc_ms": int(float(job.get("join_at_ts") or 0.0) * 1000),
                            "finish_at_utc_ms": int(finish_ts * 1000),
                        }
                        if join_mode == "extension":
                            supported = aid == "acc_1"
                            migration_fields["join_enabled"] = supported
                            if not supported:
                                migration_fields["join_state"] = "extension_account_not_supported"
                            elif state in {"no_proxy", "scheduled"}:
                                migration_fields["join_state"] = "scheduled"
                                migration_fields["extension_dispatch_state"] = "pending"
                        migrated = _patch_train_job(int(chat_id), aid, join_id, **migration_fields)
                        if migrated:
                            job = migrated
                            state = str(job.get("join_state") or state)
                            join_enabled = bool(job.get("join_enabled", join_enabled))
                    representative.setdefault(join_id, dict(job))
                    attempts_used = int(job.get("attempts_used") or 0)
                    if finish_ts > now and join_enabled and not _train_join_terminal_state(state) and attempts_used < _TRAIN_JOIN_MAX_ATTEMPTS:
                        if join_mode == "extension":
                            if _schedule_extension_train_dispatch(int(chat_id), aid, job):
                                extension_restored += 1
                        elif _schedule_train_join_task(bot, int(chat_id), aid, job):
                            join_restored += 1
                    elif finish_ts <= now and join_enabled and not _train_join_terminal_state(state):
                        _patch_train_job(int(chat_id), aid, join_id, join_state="deadline")

    for job in representative.values():
        if _schedule_train_winner_task(bot, job):
            winner_restored += 1

    logger.info(
        "Поезд: задачи восстановлены после рестарта | сервер=%s | расширение=%s | проверки_победителей=%s | удалено_старых=%s | активных_задач=%s",
        join_restored,
        extension_restored,
        winner_restored,
        stale_removed,
        len(_TRAIN_TASKS),
    )


async def _schedule_train_joins(bot, train: dict) -> None:
    now = time.time()
    gid = str(train.get("gid") or "").strip()
    join_id = _extract_train_join_id(train)
    raw_finish = str(train.get("finishAt") or "").strip()
    finish_ts = _parse_finish_ts(train)

    if not join_id:
        logger.warning(
            "Поезд: планирование пропущено | поезд=%s | причина=неверный join_id | href=%r | url=%r",
            gid or "-",
            train.get("href"),
            train.get("url"),
        )
        return
    if not finish_ts:
        logger.warning(
            "Поезд: планирование пропущено | поезд=%s | join_id=%s | причина=неверное время окончания | raw=%r | текст=%s",
            gid or "-",
            join_id,
            raw_finish,
            train.get("finishText") or "-",
        )
        return
    if finish_ts <= now:
        logger.info(
            "Поезд: планирование пропущено | поезд=%s | join_id=%s | причина=уже закончился | raw=%r | просрочка=%.1fs",
            gid or "-",
            join_id,
            raw_finish,
            now - finish_ts,
        )
        return

    duration = finish_ts - now
    start_delay = duration * 0.20
    end_delay = duration * 0.70
    server_scheduled = 0
    extension_scheduled = 0
    persisted = 0
    now_ts = int(now)
    skipped = {"inactive": 0, "no_proxy": 0, "extension_unsupported": 0, "scan_error": 0}
    waiting = {"no_session": 0, "no_csrf": 0, "proxy_unavailable": 0}
    representative: dict | None = None

    for chat_id in get_all_chat_ids():
        try:
            user = get_user(int(chat_id))
            for acc in get_user_accounts(int(chat_id), include_empty=False):
                aid = str(acc.get("account_id") or "").strip()
                if not aid or not has_active_account_subscription(int(chat_id), aid, now_ts):
                    skipped["inactive"] += 1
                    continue

                join_mode = _train_activation_mode(int(chat_id), acc)
                is_admin = _is_train_admin(int(chat_id))
                has_proxy = bool(str(acc.get("proxy_url") or "").strip())
                if join_mode == "extension":
                    join_enabled = aid == "acc_1"
                    join_state = "scheduled" if join_enabled else "extension_account_not_supported"
                    if not join_enabled:
                        skipped["extension_unsupported"] += 1
                else:
                    join_enabled = bool(is_admin or has_proxy)
                    join_state = "scheduled" if join_enabled else "no_proxy"
                    if not join_enabled:
                        skipped["no_proxy"] += 1
                    if not str(acc.get("zooma_top_session") or "").strip():
                        waiting["no_session"] += 1
                    if not str(acc.get("csrf_token") or "").strip():
                        waiting["no_csrf"] += 1
                    if not is_admin:
                        proxy_status = str(acc.get("proxy_runtime_status") or "healthy").strip().lower()
                        if proxy_status in _TRAIN_PROXY_BLOCKED_STATUSES:
                            waiting["proxy_unavailable"] += 1

                join_at_ts = now + random.uniform(start_delay, end_delay)
                job = {
                    "schema": 2,
                    "gid": gid,
                    "join_id": join_id,
                    "url": str(train.get("url") or train.get("href") or "").strip(),
                    "conductor": str(train.get("conductor") or "поезде").strip() or "поезде",
                    "finish_ts": float(finish_ts),
                    "finish_text": str(train.get("finishText") or ""),
                    "join_at_ts": float(join_at_ts),
                    "join_at_utc_ms": int(float(join_at_ts) * 1000),
                    "finish_at_utc_ms": int(float(finish_ts) * 1000),
                    "join_mode": join_mode,
                    "join_enabled": join_enabled,
                    "join_state": join_state,
                    "attempts_used": 0,
                    "extension_dispatch_state": "pending" if join_mode == "extension" and join_enabled else "",
                    "winner_check_at_ts": float(finish_ts + _TRAIN_WINNER_INITIAL_DELAY_SEC),
                    "winner_check_state": "pending",
                    "winner_notified": False,
                    "created_at_ts": now_ts,
                    "updated_at_ts": now_ts,
                }
                _patch_train_job(int(chat_id), aid, join_id, create=job)
                persisted += 1
                representative = representative or dict(job)
                if not join_enabled:
                    continue
                if join_mode == "extension":
                    if _schedule_extension_train_dispatch(int(chat_id), aid, job):
                        extension_scheduled += 1
                    logger.info(
                        "Поезд #%s через расширение: участие запланировано | %s | acc=%s | время=%s OMSK",
                        gid or "-",
                        _train_user_label(int(chat_id)),
                        aid,
                        _train_log_time(join_at_ts),
                    )
                elif _schedule_train_join_task(bot, int(chat_id), aid, job):
                    server_scheduled += 1
        except Exception as exc:
            skipped["scan_error"] += 1
            logger.warning(
                "Поезд: ошибка сканирования аккаунта | поезд=%s | join_id=%s | chat_id=%s | ошибка=%s",
                gid or "-",
                join_id,
                chat_id,
                exc,
            )

    winner_scheduled = bool(representative and _schedule_train_winner_task(bot, representative))
    waiting_total = sum(int(value or 0) for value in waiting.values())
    logger.info(
        "Поезд #%s: задачи созданы | join_id=%s | сервер=%s | расширение=%s | сохранено=%s | окно=%s-%s OMSK | финиш=%s OMSK "
        "| без_подписки=%s | без_прокси=%s | расширение_не_поддержано=%s | ждут_готовности=%s | проверка_победителей=%s | активных_задач=%s",
        gid or "-",
        join_id,
        server_scheduled,
        extension_scheduled,
        persisted,
        _train_log_time(now + start_delay),
        _train_log_time(now + end_delay),
        _train_log_time(finish_ts),
        skipped["inactive"],
        skipped["no_proxy"],
        skipped["extension_unsupported"],
        waiting_total,
        int(winner_scheduled),
        len(_TRAIN_TASKS),
    )


def _rain_history_normalize_text(value: Any) -> str:
    return re.sub(
        r"\s+",
        " ",
        str(value or "").replace("\xa0", " "),
    ).strip()


def _rain_history_normalize_name(value: Any) -> str:
    text = _rain_history_normalize_text(value)
    lowered = text.casefold()

    if lowered in {
        "модератор",
        "moderator",
        "staff",
        "admin",
        "администратор",
    }:
        return "модератор"

    return lowered


def _rain_history_extract_creator(creator_html: Any) -> str:
    soup = BeautifulSoup(str(creator_html or ""), "html.parser")

    staff = soup.select_one(".historyRainStaffCell")
    if staff is not None:
        title = _rain_history_normalize_text(staff.get("title"))
        text = _rain_history_normalize_text(
            staff.get_text(" ", strip=True)
        )

        combined = f"{title} {text}".casefold()

        if (
            "модератор" in combined
            or "moderator" in combined
            or "staff" in combined
        ):
            return "Модератор"

    user_link = soup.select_one("a[href*='/user/']")
    if user_link is not None:
        return _rain_history_normalize_text(
            user_link.get_text(" ", strip=True)
        )

    return _rain_history_normalize_text(
        soup.get_text(" ", strip=True)
    )


def _rain_history_extract_int(value: Any) -> int | None:
    soup = BeautifulSoup(str(value or ""), "html.parser")
    text = soup.get_text(" ", strip=True)
    digits = re.sub(r"\D", "", text)

    if not digits:
        return None

    return int(digits)


def _rain_history_parse_msk_datetime(value: Any) -> datetime | None:
    text = _rain_history_normalize_text(value)

    if not text:
        return None

    for fmt in (
        "%d.%m.%y - %H:%M",
        "%d.%m.%Y - %H:%M",
    ):
        try:
            return datetime.strptime(
                text,
                fmt,
            ).replace(tzinfo=_RAIN_HISTORY_MSK_TZ)
        except ValueError:
            continue

    return None


def _rain_event_msk_datetime(rain: dict) -> datetime | None:
    # Сначала пытаемся использовать полноценное время из payload,
    # если оно имеется.
    for key in (
        "createdAt",
        "created_at",
        "timestamp",
        "time",
        "date",
        "gameDate",
        "game_date",
    ):
        raw = rain.get(key)

        if raw in (None, ""):
            continue

        if isinstance(raw, (int, float)):
            stamp = float(raw)

            if stamp > 10_000_000_000:
                stamp /= 1000.0

            with contextlib.suppress(Exception):
                return datetime.fromtimestamp(
                    stamp,
                    tz=timezone.utc,
                ).astimezone(_RAIN_HISTORY_MSK_TZ)

        text = _rain_history_normalize_text(raw)

        if not text:
            continue

        with contextlib.suppress(Exception):
            parsed = datetime.fromisoformat(
                text.replace("Z", "+00:00")
            )

            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)

            return parsed.astimezone(_RAIN_HISTORY_MSK_TZ)

        parsed_history_style = _rain_history_parse_msk_datetime(text)
        if parsed_history_style is not None:
            return parsed_history_style

    # В сообщении чата сейчас обычно есть только HH:MM.
    # Привязываем его к текущей дате по Москве.
    message_time = _rain_history_normalize_text(
        rain.get("messageTime")
    )

    match = re.search(
        r"(?<!\d)(\d{1,2}):(\d{2})(?::(\d{2}))?(?!\d)",
        message_time,
    )

    if not match:
        return None

    now_msk = datetime.now(_RAIN_HISTORY_MSK_TZ)

    candidate = now_msk.replace(
        hour=int(match.group(1)),
        minute=int(match.group(2)),
        second=int(match.group(3) or 0),
        microsecond=0,
    )

    # Корректировка на дождь около полуночи.
    if candidate - now_msk > timedelta(hours=12):
        candidate -= timedelta(days=1)
    elif now_msk - candidate > timedelta(hours=12):
        candidate += timedelta(days=1)

    return candidate


def _rain_history_row_matches(rain: dict, row: dict) -> bool:
    expected_launcher = _rain_history_normalize_name(
        rain.get("launcher")
    )

    actual_launcher = _rain_history_normalize_name(
        _rain_history_extract_creator(
            row.get("creator_cell")
        )
    )

    if not expected_launcher:
        return False

    if expected_launcher != actual_launcher:
        return False

    expected_total = _rain_history_extract_int(
        rain.get("totalAmount")
    )
    expected_prize = _rain_history_extract_int(
        rain.get("perUserAmount")
    )

    try:
        expected_count = int(
            rain.get("prizesCount") or 0
        )
    except (TypeError, ValueError):
        expected_count = 0

    actual_total = _rain_history_extract_int(
        row.get("bank_col")
    )
    actual_prize = _rain_history_extract_int(
        row.get("prize_col")
    )
    actual_count = _rain_history_extract_int(
        row.get("winners_cell")
    )

    if expected_total is None:
        return False

    if actual_total != expected_total:
        return False

    if expected_prize is None:
        return False

    if actual_prize != expected_prize:
        return False

    if expected_count <= 0:
        return False

    if actual_count != expected_count:
        return False

    expected_dt = _rain_event_msk_datetime(rain)
    actual_dt = _rain_history_parse_msk_datetime(
        row.get("game_date")
    )

    if expected_dt is None or actual_dt is None:
        return False

    difference = abs(
        (actual_dt - expected_dt).total_seconds()
    )

    return difference <= _RAIN_HISTORY_MATCH_TIME_TOLERANCE_SEC


def _rain_history_get_admin_session() -> tuple[str, str]:
    account = get_user_account(
        _RAIN_HISTORY_ADMIN_CHAT_ID,
        "acc_1",
    ) or {}

    session_cookie = str(
        account.get("zooma_top_session") or ""
    ).strip()

    user_agent = str(
        account.get("user_agent") or ""
    ).strip()

    if not session_cookie:
        user = get_user(_RAIN_HISTORY_ADMIN_CHAT_ID)

        session_cookie = str(
            getattr(user, "zooma_top_session", "") or ""
        ).strip()

        if not user_agent:
            user_agent = str(
                getattr(user, "user_agent", "") or ""
            ).strip()

    if not user_agent:
        user_agent = _RAIN_HISTORY_USER_AGENT

    return session_cookie, user_agent


def _rain_history_headers(
    site_base_url: str,
    user_agent: str,
    session_cookie: str,
    *,
    accept: str,
) -> dict[str, str]:
    return {
        "Accept": accept,
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": user_agent or _RAIN_HISTORY_USER_AGENT,
        "Referer": (
            site_base_url.rstrip("/")
            + "/historyRain"
        ),
        "Cookie": (
            f"zooma_top_session={session_cookie}"
        ),
    }


def _rain_history_list_params() -> list[tuple[str, str]]:
    return [
        ("draw", "1"),

        ("columns[0][data]", "id"),
        ("columns[0][name]", "g.id"),
        ("columns[0][searchable]", "true"),
        ("columns[0][orderable]", "false"),
        ("columns[0][search][value]", ""),
        ("columns[0][search][regex]", "false"),

        ("columns[1][data]", "creator_cell"),
        ("columns[1][name]", "creator_cell"),
        ("columns[1][searchable]", "true"),
        ("columns[1][orderable]", "false"),
        ("columns[1][search][value]", ""),
        ("columns[1][search][regex]", "false"),

        ("columns[2][data]", "bank_col"),
        ("columns[2][name]", "bank_col"),
        ("columns[2][searchable]", "true"),
        ("columns[2][orderable]", "true"),
        ("columns[2][search][value]", ""),
        ("columns[2][search][regex]", "false"),

        ("columns[3][data]", "prize_col"),
        ("columns[3][name]", "prize_col"),
        ("columns[3][searchable]", "true"),
        ("columns[3][orderable]", "true"),
        ("columns[3][search][value]", ""),
        ("columns[3][search][regex]", "false"),

        ("columns[4][data]", "winners_cell"),
        ("columns[4][name]", "winners_cell"),
        ("columns[4][searchable]", "false"),
        ("columns[4][orderable]", "false"),
        ("columns[4][search][value]", ""),
        ("columns[4][search][regex]", "false"),

        ("columns[5][data]", "game_date"),
        ("columns[5][name]", "game_date"),
        ("columns[5][searchable]", "false"),
        ("columns[5][orderable]", "true"),
        ("columns[5][search][value]", ""),
        ("columns[5][search][regex]", "false"),

        ("order[0][column]", "5"),
        ("order[0][dir]", "desc"),
        ("start", "0"),
        ("length", str(_RAIN_HISTORY_ROWS_LIMIT)),
        ("search[value]", ""),
        ("search[regex]", "false"),
        ("_", str(int(time.time() * 1000))),
    ]


def _rain_history_fetch_rows(
    site_base_url: str,
    session_cookie: str,
    user_agent: str,
) -> list[dict]:
    response = _HTTP.get(
        site_base_url.rstrip("/")
        + "/historyRain/data",
        params=_rain_history_list_params(),
        headers=_rain_history_headers(
            site_base_url,
            user_agent,
            session_cookie,
            accept=(
                "application/json, "
                "text/javascript, */*; q=0.01"
            ),
        ),
        timeout=_RAIN_HISTORY_REQUEST_TIMEOUT_SEC,
        allow_redirects=True,
        verify=False,
    )

    response.raise_for_status()

    payload = response.json()

    rows = (
        payload.get("data")
        if isinstance(payload, dict)
        else None
    )

    if not isinstance(rows, list):
        raise RuntimeError(
            "rain_history_bad_data"
        )

    return [
        dict(row)
        for row in rows
        if isinstance(row, dict)
    ]


def _rain_history_fetch_details(
    site_base_url: str,
    rain_history_id: str,
    session_cookie: str,
    user_agent: str,
) -> str:
    response = _HTTP.get(
        site_base_url.rstrip("/")
        + f"/historyRain/{rain_history_id}/winners",
        headers=_rain_history_headers(
            site_base_url,
            user_agent,
            session_cookie,
            accept="*/*",
        ),
        timeout=_RAIN_HISTORY_REQUEST_TIMEOUT_SEC,
        allow_redirects=True,
        verify=False,
    )

    response.raise_for_status()

    return response.text or ""


def _rain_history_normalize_condition_value(
    label: str,
    value: str,
) -> str:
    text = _rain_history_normalize_text(value)

    if not text:
        return ""

    lowered = text.casefold()

    if "без ограничений" in lowered:
        return ""

    if label == "Активность в чате":
        # Убираем служебную часть про обязательную активность.
        # Любое дополнительное условие после неё сохраняем.
        text = re.sub(
            r"^Писал\s+за\s+последние\s+\d+\s*"
            r"(?:мин(?:\.|ут(?:у|ы)?)?)\s*",
            "",
            text,
            flags=re.IGNORECASE,
        ).strip()

        # Убираем разделитель перед дополнительным условием:
        # · статус Gold и выше
        text = re.sub(
            r"^[·•:—–-]+\s*",
            "",
            text,
        ).strip()

        # Если было только «Писал за последние N мин»,
        # в сообщение ничего не добавляем.
        if not text:
            return ""

    text = re.sub(
        r"^От\b",
        "от",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(
        r"\bдн\.?(?=\s|$)",
        "дней",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(
        r"\bдень\b",
        "дней",
        text,
        flags=re.IGNORECASE,
    )

    return _rain_history_normalize_text(text)


def _rain_history_extract_conditions(
    html_text: str,
) -> list[tuple[str, str]]:
    soup = BeautifulSoup(
        html_text or "",
        "html.parser",
    )

    found: dict[str, str] = {}

    for block in soup.select(
        ".historyRainWinCond"
    ):
        label_el = block.select_one(
            ".historyRainWinCond__label"
        )

        value_el = block.select_one(
            ".historyRainWinCond__value"
        )

        if label_el is None or value_el is None:
            continue

        label = _rain_history_normalize_text(
            label_el.get_text(" ", strip=True)
        )

        if label not in _RAIN_HISTORY_CONDITION_LABELS:
            continue

        value = _rain_history_normalize_condition_value(
            label,
            value_el.get_text(" ", strip=True),
        )

        if value:
            found[label] = value

    return [
        (label, found[label])
        for label in _RAIN_HISTORY_CONDITION_LABELS
        if label in found
    ]


def _rain_history_insert_conditions(
    post_text: str,
    conditions: list[tuple[str, str]],
) -> str:
    if not conditions:
        return post_text

    marker = "\n<b>Победители:</b>"

    if marker not in post_text:
        raise RuntimeError(
            "rain_post_winners_marker_missing"
        )

    lines = []

    for label, value in conditions:
        safe_label = html.escape(
            str(label),
            quote=False,
        )

        safe_value = html.escape(
            str(value),
            quote=False,
        )

        lines.append(
            f"{safe_label}: <b>{safe_value}</b>"
        )

    if not lines:
        return post_text

    condition_block = "\n".join(lines)

    return post_text.replace(
        marker,
        f"\n{condition_block}\n{marker}",
        1,
    )


def _rain_history_enrich_sync(
    rain: dict,
    post_text: str,
    site_base_url: str,
) -> str:
    session_cookie, user_agent = (
        _rain_history_get_admin_session()
    )

    if not session_cookie:
        raise RuntimeError(
            "rain_history_admin_session_missing"
        )

    # Первый запрос.
    rows = _rain_history_fetch_rows(
        site_base_url,
        session_cookie,
        user_agent,
    )

    matched_row = None

    for row in rows:
        if _rain_history_row_matches(
            rain,
            row,
        ):
            matched_row = row
            break

    if matched_row is None:
        raise RuntimeError(
            "rain_history_matching_row_not_found"
        )

    history_id = str(
        matched_row.get("id") or ""
    ).strip()

    if not history_id.isdigit():
        raise RuntimeError(
            "rain_history_bad_id"
        )

    # Небольшая случайная задержка между первым
    # и вторым запросом.
    history_request_delay = random.uniform(
        0.15,
        0.30,
    )

    logger.debug(
        "Дождь: пауза перед запросом деталей "
        "| history_id=%s | delay=%.3fs",
        history_id,
        history_request_delay,
    )

    time.sleep(history_request_delay)

    # Второй запрос.
    details_html = _rain_history_fetch_details(
        site_base_url,
        history_id,
        session_cookie,
        user_agent,
    )

    conditions = _rain_history_extract_conditions(
        details_html
    )

    logger.info(
        "Дождь: запись истории совпала "
        "| history_id=%s | условий=%s",
        history_id,
        len(conditions),
    )

    return _rain_history_insert_conditions(
        post_text,
        conditions,
    )


async def _rain_history_enrich_best_effort(
    rain: dict,
    post_text: str,
    site_base_url: str,
) -> str:
    try:
        return await asyncio.to_thread(
            _rain_history_enrich_sync,
            dict(rain or {}),
            post_text,
            site_base_url,
        )

    except Exception as exc:
        # При любой ошибке исходный пост отправляется
        # без условий и без повторных попыток.
        logger.warning(
            "Дождь: условия истории не добавлены, "
            "отправляется исходный пост | ошибка=%s",
            exc,
        )

        return post_text


async def _send_post(bot, text: str) -> None:
    await bot.send_message(
        chat_id=RAIN_TARGET_CHAT,
        text=text,
        parse_mode=ParseMode.HTML,
        link_preview_options=LinkPreviewOptions(
            is_disabled=True
        ),
        disable_notification=True,
    )

async def _setup_initial_giveaways(state: dict, seen_train_ids: set[str]) -> None:
    if state.get("giveaway_initial_loaded"):
        return
    site_base_url = str(state.get("site_base_url") or "").strip()
    if not site_base_url:
        return
    trains = await asyncio.to_thread(_fetch_active_giveaway_trains_quiet, site_base_url)
    for train in trains:
        gid = str(train.get("gid") or "").strip()
        if gid:
            seen_train_ids.add(gid)
    state["giveaway_initial_loaded"] = True

async def _fetch_and_post_new_giveaway_trains(bot, state: dict, seen_train_ids: set[str]) -> None:
    site_base_url = str(state.get("site_base_url") or "").strip()
    if not site_base_url:
        return
    trains: list[dict] = []
    for attempt in range(1, GIVEAWAY_FETCH_ATTEMPTS + 1):
        try:
            trains = await asyncio.to_thread(_fetch_active_giveaway_trains_quiet, site_base_url)
            break
        except Exception:
            if attempt >= GIVEAWAY_FETCH_ATTEMPTS:
                return
            await asyncio.sleep(GIVEAWAY_FETCH_DELAY)
    for train in trains:
        gid = str(train.get("gid") or "").strip()
        if not gid or gid in seen_train_ids:
            continue
        seen_train_ids.add(gid)
        detected_join_id = _extract_train_join_id(train)
        detected_finish_ts = _parse_finish_ts(train)
        logger.info(
            "Поезд #%s: найден новый | ведущий=%s | join_id=%s | финиш=%s OMSK",
            gid,
            train.get("conductor") or "-",
            detected_join_id or "-",
            _train_log_time(detected_finish_ts),
        )
        await _send_post(bot, build_telegram_train_message(train))
        logger.info("Поезд #%s: пост отправлен | чат=%s", gid, RAIN_TARGET_CHAT)
        await _schedule_train_joins(bot, train)

async def _handle_giveaway_publication(bot, state: dict, seen_train_ids: set[str], publication: dict) -> None:
    event = extract_giveaway_publication_event(publication)
    if str(event.get("eventType") or "").strip() != "GiveAway-New":
        return
    await _fetch_and_post_new_giveaway_trains(bot, state, seen_train_ids)

async def _subscribe(ws, ids: Ids, channel: str, state: dict) -> None:
    sub_id = ids.next()
    state.setdefault("pending_subscribes", {})[sub_id] = {
        "channel": channel,
        "time": time.time(),
    }
    await send_ws(ws, {
        "id": sub_id,
        "method": METHOD_SUBSCRIBE,
        "params": {"channel": channel},
    })

async def _ping_loop(ws, ids: Ids, state: dict) -> None:
    while True:
        await asyncio.sleep(25.0)
        ping_id = ids.next()
        state["pending_ping_id"] = ping_id
        state["pending_ping_time"] = time.time()
        await send_ws(ws, {"id": ping_id, "method": METHOD_PING})

async def _domain_watch_loop(state: dict) -> None:
    while True:
        await asyncio.sleep(DOMAIN_CHECK_INTERVAL_SEC)
        site_base_url = str(state.get("site_base_url") or "").strip()
        if not site_base_url:
            continue
        current_shared = str(get_active_domain() or "").strip().rstrip("/")
        if current_shared and current_shared != site_base_url.rstrip("/"):
            state["domain_dead"] = True
        else:
            alive = await is_domain_alive(site_base_url)
            if not alive:
                state["domain_dead"] = True
        if state.get("domain_dead") and state.get("ws") is not None:
            with contextlib.suppress(Exception):
                await state["ws"].close()

async def _ws_watchdog_loop(state: dict) -> None:
    while True:
        await asyncio.sleep(10.0)
        ws = state.get("ws")
        if ws is None:
            continue
        now = time.time()
        pending_ping_time = state.get("pending_ping_time")
        if pending_ping_time and (now - float(pending_ping_time)) >= 90.0:
            state["reconnect_reason"] = "ping_timeout"
            logger.warning("Rain runtime watchdog closing ws | reason=ping_timeout age=%ss", int(now - float(pending_ping_time)))
            with contextlib.suppress(Exception):
                await ws.close()
            continue
        last_packet_time = state.get("last_packet_time")
        if last_packet_time and (now - float(last_packet_time)) >= 240.0:
            state["reconnect_reason"] = "silent_socket"
            logger.warning("Rain runtime watchdog closing ws | reason=silent_socket age=%ss", int(now - float(last_packet_time)))
            with contextlib.suppress(Exception):
                await ws.close()
            continue
        last_connected_time = state.get("last_connected_time")
        planned_reconnect_after = state.get("planned_reconnect_after")
        if last_connected_time and planned_reconnect_after and (now - float(last_connected_time)) >= float(planned_reconnect_after):
            state["reconnect_reason"] = "planned_refresh"
            logger.info("Rain runtime watchdog closing ws | reason=planned_refresh age=%ss", int(now - float(last_connected_time)))
            with contextlib.suppress(Exception):
                await ws.close()
            continue
        pending_subscribes = state.get("pending_subscribes") or {}
        for sub_id, sub_data in list(pending_subscribes.items()):
            if (time.time() - float(sub_data.get("time") or time.time())) >= 30.0:
                state["reconnect_reason"] = "subscribe_timeout"
                logger.warning("Rain runtime watchdog closing ws | reason=subscribe_timeout channel=%s", sub_data.get("channel"))
                with contextlib.suppress(Exception):
                    await ws.close()
                break

def _handle_command_response(packet: dict, state: dict) -> bool:
    packet_id = packet.get("id")
    if not packet_id:
        return False
    if packet_id == state.get("pending_ping_id"):
        state["pending_ping_id"] = None
        state["pending_ping_time"] = None
        state["last_pong_time"] = time.time()
        return True
    pending_subscribes = state.get("pending_subscribes") or {}
    if packet_id in pending_subscribes:
        pending_subscribes.pop(packet_id, None)
        return True
    return True

async def _run_once(bot, sent_rain_ids: set[str], seen_train_ids: set[str], state: dict, chat_ai: ChatAiManager) -> None:
    site_base_url = str(get_active_domain() or "").strip().rstrip("/")
    if not site_base_url:
        site_base_url = str(await resolve_active_domain(
            zref_url=ZREF_URL,
            proxy_scheme=PROXY_SCHEME,
            proxy_host=PROXY_HOST,
            proxy_port=PROXY_PORT,
        ) or "").strip().rstrip("/")
    if not site_base_url:
        raise RuntimeError("active_domain_missing")

    config = await asyncio.to_thread(_fetch_centrifuge_config_for_domain, site_base_url)
    state["site_base_url"] = config["site_base_url"]
    state["domain_dead"] = False
    state["pending_ping_id"] = None
    state["pending_ping_time"] = None
    state["pending_subscribes"] = {}
    state["first_chat_logged"] = False
    state["last_packet_time"] = None
    state["last_connected_time"] = None
    state["planned_reconnect_after"] = random.randint(60 * 60, 90 * 60)
    state["reconnect_reason"] = ""

    await _setup_initial_giveaways(state, seen_train_ids)

    ids = Ids()
    ping_task = None
    try:
        try:
            connect_ctx = websockets.connect(
                config["ws_url"],
                additional_headers={"Origin": config["origin"], "User-Agent": "Mozilla/5.0"},
                ping_interval=None,
            )
        except TypeError:
            connect_ctx = websockets.connect(
                config["ws_url"],
                extra_headers={"Origin": config["origin"], "User-Agent": "Mozilla/5.0"},
                ping_interval=None,
            )
        async with connect_ctx as ws:
            state["ws"] = ws
            state["last_connected_time"] = time.time()
            state["last_packet_time"] = time.time()
            connect_id = ids.next()
            await send_ws(ws, {
                "id": connect_id,
                "method": METHOD_CONNECT,
                "params": {"token": config["token"]},
            })
            async for raw_packet in ws:
                state["last_packet_time"] = time.time()
                if state.get("domain_dead"):
                    raise RuntimeError("domain_dead")
                for line in str(raw_packet).split("\n"):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        packet = json.loads(line)
                    except Exception:
                        continue
                    if packet.get("id") == connect_id:
                        if packet.get("error"):
                            raise RuntimeError("centrifuge_connect_error")
                        await _subscribe(ws, ids, CHAT_CHANNEL, state)
                        await _subscribe(ws, ids, GIVEAWAY_LOBBY_CHANNEL, state)
                        ping_task = asyncio.create_task(_ping_loop(ws, ids, state), name="rain-runtime-ping")
                        continue
                    if packet.get("id"):
                        _handle_command_response(packet, state)
                        continue
                    result = packet.get("result")
                    if not isinstance(result, dict) or result.get("type", PUSH_PUBLICATION) != PUSH_PUBLICATION:
                        continue
                    channel = str(result.get("channel") or "").strip()
                    publication = result.get("data", {}) or {}
                    if channel == CHAT_CHANNEL:
                        html_text, _raw = extract_html_from_publication(publication)
                        if html_text:
                            chat_ai.on_chat_html(html_text)
                            if not state.get("first_chat_logged"):
                                first_text = str(parse_chat_message_html(html_text) or "").strip()
                                if first_text:
                                    logger.info("Rain first chat message: %s", first_text)
                                    state["first_chat_logged"] = True
                            rain = extract_rain_from_publication(publication, config["site_base_url"])
                            if not rain:
                                continue
                            rain_id = str(rain.get("rainId") or f"{rain.get('messageTime')}:{rain.get('totalAmount')}:{rain.get('text')}").strip()
                            if not rain_id or rain_id in sent_rain_ids:
                                continue
                            sent_rain_ids.add(rain_id)
                            chat_ai.on_rain(rain)

                            rain_post = build_telegram_rain_message(rain)

                            rain_post = await _rain_history_enrich_best_effort(
                                rain,
                                rain_post,
                                config["site_base_url"],
                            )

                            await _send_post(bot, rain_post)
                    elif channel == GIVEAWAY_LOBBY_CHANNEL:
                        await _handle_giveaway_publication(bot, state, seen_train_ids, publication)
    finally:
        if ping_task:
            ping_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await ping_task
        state["ws"] = None

async def _runner(bot) -> None:
    global _CHAT_AI_MANAGER
    sent_rain_ids: set[str] = set()
    seen_train_ids: set[str] = set()
    startup_domain = str(get_active_domain() or "").strip() or "-"
    bot_name = RAIN_BOT_NAME
    with contextlib.suppress(Exception):
        me = await bot.get_me()
        if getattr(me, "username", None):
            bot_name = f"{bot_name} (@{me.username})"
    logger.info("Rain runtime started | bot=%s target=%s domain=%s", bot_name, RAIN_TARGET_CHAT, startup_domain)

    last_warn_key = ""
    last_warn_ts = 0.0
    failures = 0
    chat_ai = ChatAiManager(bot)
    _CHAT_AI_MANAGER = chat_ai
    if _EXTENSION_TRAIN_MANAGER is not None:
        with contextlib.suppress(Exception):
            _EXTENSION_TRAIN_MANAGER.set_connection_event_handler(chat_ai.on_extension_connection_event)
    chat_ai.start()
    try:
        await _restore_train_jobs(bot)
    except Exception:
        logger.exception("Поезд: не удалось восстановить сохранённые задачи")
    try:
        while True:
            state = {
                "site_base_url": "",
                "domain_dead": False,
                "ws": None,
                "pending_ping_id": None,
                "pending_ping_time": None,
                "pending_subscribes": {},
                "last_packet_time": None,
                "last_connected_time": None,
                "planned_reconnect_after": None,
                "reconnect_reason": "",
                "giveaway_initial_loaded": False,
            }
            domain_task = asyncio.create_task(_domain_watch_loop(state), name="rain-runtime-domain-watch")
            ws_watchdog_task = asyncio.create_task(_ws_watchdog_loop(state), name="rain-runtime-ws-watchdog")
            try:
                await _run_once(bot, sent_rain_ids, seen_train_ids, state, chat_ai)
                failures = 0
            except asyncio.CancelledError:
                raise
            except Exception as e:
                failures += 1
                warn_key = str(state.get("reconnect_reason") or f"{type(e).__name__}:{e}")
                now = time.time()
                if warn_key != last_warn_key or (now - last_warn_ts) >= 300.0:
                    logger.warning("Rain runtime reconnect | reason=%s failures=%s", warn_key, failures)
                    last_warn_key = warn_key
                    last_warn_ts = now
            finally:
                for task in (domain_task, ws_watchdog_task):
                    task.cancel()
                    with contextlib.suppress(asyncio.CancelledError, Exception):
                        await task
            await asyncio.sleep(_retry_delay(failures))
    finally:
        await _cancel_train_join_tasks()
        await chat_ai.stop()
        if _CHAT_AI_MANAGER is chat_ai:
            _CHAT_AI_MANAGER = None

async def handover_chat_ai_for_account(
    chat_id: int,
    account_id: str,
    target_mode: str,
    *,
    previous_mode: str = "",
    mode_epoch: int = 0,
) -> int:
    manager = _CHAT_AI_MANAGER
    if manager is not None:
        return await manager.handover_account_mode(
            int(chat_id),
            str(account_id or "acc_1"),
            target_mode,
            previous_mode=previous_mode,
            mode_epoch=mode_epoch,
        )

    cid = int(chat_id)
    aid = str(account_id or "acc_1")
    row = get_user_account(cid, aid) or {}
    pending = dict(row.get("chat_ai_pending_task") or {})
    previous = "extension" if str(previous_mode or "server").strip().lower() == "extension" else "server"
    target = "extension" if str(target_mode or "server").strip().lower() == "extension" else "server"
    if pending and previous == "extension" and target == "server" and _EXTENSION_TRAIN_MANAGER is not None:
        with contextlib.suppress(Exception):
            await _EXTENSION_TRAIN_MANAGER.send_chat_ai_cancel(
                chat_id=cid,
                account_id=aid,
                task_id=str(pending.get("task_id") or ""),
                attempt=max(1, int(pending.get("attempt") or 1)),
                mode_epoch=max(0, int(pending.get("mode_epoch") or mode_epoch or 0)),
                reason=f"runtime_handover:{previous}->{target}",
            )
    patch_user_account(
        cid,
        aid,
        chat_ai_pending_task={},
        chat_ai_resume_when_extension_online=False,
        chat_ai_last_error="",
    )
    with contextlib.suppress(Exception):
        await asyncio.to_thread(persist_user_state_now, cid)
    with contextlib.suppress(Exception):
        await notify_app_state_update(cid)
    return 1

def start_rain_runtime(bot, extension_ws_manager: Any | None = None, server_ws_manager: Any | None = None) -> asyncio.Task:
    global _TASK, _EXTENSION_TRAIN_MANAGER, _TRAIN_BOT, _SERVER_WS_MANAGER
    _TRAIN_BOT = bot
    _EXTENSION_TRAIN_MANAGER = extension_ws_manager
    _SERVER_WS_MANAGER = server_ws_manager
    if extension_ws_manager is not None:
        extension_ws_manager.set_train_handlers(
            task_provider=_pending_extension_train_payloads,
            event_handler=_handle_extension_train_event,
        )
    if _TASK and not _TASK.done():
        return _TASK
    _TASK = asyncio.create_task(_runner(bot), name="rain-runtime")
    return _TASK

async def stop_rain_runtime() -> None:
    global _TASK
    if not _TASK:
        return
    _TASK.cancel()
    with contextlib.suppress(Exception):
        await _TASK
    _TASK = None
