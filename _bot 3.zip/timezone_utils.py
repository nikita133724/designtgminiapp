import asyncio
import contextlib
import hashlib
import hmac
import json
import logging
import re
import sys
import threading
import time
from datetime import datetime, timezone, timedelta
from typing import Any, Optional
from urllib.parse import parse_qs
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import Query, Request
from fastapi.responses import HTMLResponse

from config import ADMIN_CHAT_ID, BOT_TOKEN
import store

logger = logging.getLogger("timezone_utils")

TZ_FIELDS = (
    "timezone_name",
    "timezone_offset_min",
    "timezone_updated_at_ts",
    "timezone_source",
    "timezone_valid",
    "locale",
)
MSK_TZ = timezone(timedelta(hours=3))
OMSK_TZ_NAME = "Asia/Omsk"


def _get_user(chat_id: int):
    return store.get_user(int(chat_id))


def _set_tz_attrs(user: Any, data: dict) -> None:
    for key in TZ_FIELDS:
        value = data.get(key)
        if key == "timezone_valid":
            # An unknown timezone is a valid initial state. Never keep NULL
            # for the NOT NULL public.users.timezone_valid column.
            value = bool(value)
        setattr(user, key, value)


def _tz_data_from_user(user: Any) -> dict:
    data = {key: getattr(user, key, None) for key in TZ_FIELDS}
    # New users can bind the extension before opening Telegram Mini App.
    # In that case timezone attributes may not have been populated yet.
    data["timezone_valid"] = bool(data.get("timezone_valid"))
    return data


def _zone_for_user(chat_id: int) -> Optional[ZoneInfo]:
    try:
        user = _get_user(int(chat_id))
        if not bool(getattr(user, "timezone_valid", False)):
            return None
        name = str(getattr(user, "timezone_name", "") or "").strip()
        if not name:
            return None
        return ZoneInfo(name)
    except Exception:
        return None


def _offset_string(dt: datetime) -> str:
    off = dt.utcoffset() or timedelta(0)
    total_min = int(off.total_seconds() // 60)
    sign = "+" if total_min >= 0 else "-"
    total_min = abs(total_min)
    return f"UTC{sign}{total_min // 60:02d}:{total_min % 60:02d}"


def timezone_label(chat_id: int, at_ts: Optional[int] = None) -> str:
    zone = _zone_for_user(int(chat_id))
    if not zone:
        return ""
    user = _get_user(int(chat_id))
    name = str(getattr(user, "timezone_name", "") or "").strip()
    ts = int(at_ts or time.time())
    dt = datetime.fromtimestamp(ts, tz=zone)
    return f"{name} ({_offset_string(dt)})"


def timezone_line(chat_id: int, at_ts: Optional[int] = None) -> str:
    label = timezone_label(chat_id, at_ts)
    return f"Часовой пояс: {label}" if label else ""


def format_user_dt(chat_id: int, ts: Optional[int], fmt: str = "%d.%m.%Y %H:%M") -> str:
    if not ts:
        return "-"
    zone = _zone_for_user(int(chat_id))
    if zone:
        return datetime.fromtimestamp(int(ts), tz=zone).strftime(fmt)
    return datetime.fromtimestamp(int(ts), tz=MSK_TZ).strftime(fmt) + " МСК"


def format_user_dt_with_tz_line(chat_id: int, ts: Optional[int], fmt: str = "%d.%m.%Y %H:%M") -> str:
    base = format_user_dt(chat_id, ts, fmt)
    line = timezone_line(chat_id, ts)
    return f"{base}\n{line}" if line else base


def _parse_msk_dt(raw: str) -> Optional[int]:
    s = str(raw or "").strip()
    for fmt in ("%d.%m.%Y %H:%M", "%H:%M %d.%m.%Y"):
        try:
            dt = datetime.strptime(s, fmt).replace(tzinfo=MSK_TZ)
            return int(dt.timestamp())
        except Exception:
            pass
    return None


def rewrite_subscription_text_for_user(chat_id: int, text: str) -> str:
    try:
        if ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID):
            return text
    except Exception:
        pass
    zone = _zone_for_user(int(chat_id))
    if not zone:
        return text
    src = str(text or "")
    if "МСК" not in src:
        return src
    if not any(x in src.lower() for x in ("подписк", "срок", "действует", "активна", "активирован", "продлена")):
        return src

    converted_ts: list[int] = []

    def repl_date_first(m: re.Match) -> str:
        raw = m.group(1)
        ts = _parse_msk_dt(raw)
        if not ts:
            return raw
        converted_ts.append(ts)
        return datetime.fromtimestamp(ts, tz=zone).strftime("%d.%m.%Y %H:%M")

    def repl_time_first(m: re.Match) -> str:
        raw = m.group(1)
        ts = _parse_msk_dt(raw)
        if not ts:
            return raw
        converted_ts.append(ts)
        return datetime.fromtimestamp(ts, tz=zone).strftime("%H:%M %d.%m.%Y")

    out = re.sub(r"(\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2})", repl_date_first, src)
    out = re.sub(r"(\d{2}:\d{2}\s+\d{2}\.\d{2}\.\d{4})", repl_time_first, out)
    out = out.replace(" МСК", "")
    if converted_ts and "Часовой пояс:" not in out:
        out = out.rstrip() + "\n" + timezone_line(chat_id, converted_ts[-1])
    return out


def _validate_tg_init_data(init_data: str) -> dict:
    raw = str(init_data or "").strip()
    if not raw:
        raise ValueError("empty_init_data")
    parsed = parse_qs(raw, keep_blank_values=True)
    got_hash = str((parsed.get("hash") or [""])[0] or "").strip()
    if not got_hash:
        raise ValueError("missing_hash")
    data_check_items = []
    for k in sorted(parsed.keys()):
        if k == "hash":
            continue
        v = str((parsed.get(k) or [""])[0] or "")
        data_check_items.append(f"{k}={v}")
    data_check_string = "\n".join(data_check_items)
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode("utf-8"), hashlib.sha256).digest()
    calc_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc_hash, got_hash):
        raise ValueError("bad_hash")
    user_raw = str((parsed.get("user") or ["{}"])[0] or "{}")
    data = json.loads(user_raw)
    if not isinstance(data, dict) or not data.get("id"):
        raise ValueError("bad_user_json")
    return data


def _validate_timezone_payload(tz_name: str, offset_min: Optional[int], at_ts: Optional[int] = None) -> tuple[bool, Optional[int]]:
    name = str(tz_name or "").strip()
    if not name or len(name) > 64 or "/" not in name:
        return False, None
    try:
        zone = ZoneInfo(name)
    except ZoneInfoNotFoundError:
        return False, None
    ts = int(at_ts or time.time())
    dt = datetime.fromtimestamp(ts, tz=zone)
    expected_js_offset = -int((dt.utcoffset() or timedelta(0)).total_seconds() // 60)
    if offset_min is None:
        return True, expected_js_offset
    try:
        got = int(offset_min)
    except Exception:
        return False, expected_js_offset
    if abs(got - expected_js_offset) > 90:
        return False, expected_js_offset
    return True, expected_js_offset


def capture_user_timezone(chat_id: int, tz_name: str, offset_min: Optional[int], locale: str = "", source: str = "tg_mini_app_intl") -> dict:
    now_ts = int(time.time())
    valid, normalized_offset = _validate_timezone_payload(tz_name, offset_min, now_ts)
    clean_tz = str(tz_name or "").strip() if valid else ""
    data = {
        "timezone_name": clean_tz,
        "timezone_offset_min": int(normalized_offset if normalized_offset is not None else 0) if valid else None,
        "timezone_updated_at_ts": now_ts,
        "timezone_source": str(source or "tg_mini_app_intl")[:64],
        "timezone_valid": bool(valid),
        "locale": str(locale or "")[:32],
    }
    user = _get_user(int(chat_id))
    _set_tz_attrs(user, data)
    with contextlib.suppress(Exception):
        store._sb_upsert_patch(int(chat_id), data)
    with contextlib.suppress(Exception):
        store.save_state()
    return data


def install_store_timezone_patches() -> None:
    if getattr(store, "_zooma_timezone_patched", False):
        return

    orig_to_db_row = store._to_db_row
    orig_apply_db_row = store._apply_db_row
    orig_user_to_dict = store._user_to_dict
    orig_dict_to_user = store._dict_to_user

    def patched_to_db_row(chat_id: int, user: Any) -> dict:
        row = orig_to_db_row(chat_id, user)
        row.update(_tz_data_from_user(user))
        return row

    def patched_apply_db_row(chat_id: int, row: dict) -> None:
        orig_apply_db_row(chat_id, row)
        user = store.get_user(chat_id)
        _set_tz_attrs(user, {key: row.get(key) for key in TZ_FIELDS})
        with contextlib.suppress(Exception):
            with store._SB_LAST_ROWS_LOCK:
                store._SB_LAST_ROWS[chat_id] = store._to_db_row(chat_id, user)

    def patched_user_to_dict(user: Any) -> dict:
        data = orig_user_to_dict(user)
        data.update(_tz_data_from_user(user))
        return data

    def patched_dict_to_user(data: dict):
        user = orig_dict_to_user(data)
        _set_tz_attrs(user, {key: data.get(key) for key in TZ_FIELDS})
        return user

    store._to_db_row = patched_to_db_row
    store._apply_db_row = patched_apply_db_row
    store._user_to_dict = patched_user_to_dict
    store._dict_to_user = patched_dict_to_user
    store._zooma_timezone_patched = True


def install_main_timezone_patches(main_mod: Any, manager: Any) -> None:
    if getattr(main_mod, "_zooma_timezone_main_patched", False):
        return
    if not hasattr(main_mod, "profile_text") or not hasattr(main_mod, "account_detail_text"):
        return

    def profile_text(chat_id: int, tg_username: str):
        accounts = main_mod._sorted_accounts_for_view(chat_id, include_empty=True)
        visible = [a for a in accounts if main_mod._is_visible_account_for_profile(a)]
        text = (
            "ZOOMA client\n\n"
            "Профиль\n"
            f"{main_mod.html.escape(tg_username)}\n\n"
        )
        if not visible:
            return text + "Активных подписок нет"
        if len(visible) > 1:
            now_ts = int(time.time())
            active_until = [int(a.get("subscription_until_ts") or 0) for a in visible if int(a.get("subscription_until_ts") or 0) > now_ts]
            nearest = min(active_until) if active_until else 0
            text += f"Аккаунтов {len(visible)}\n"
            if nearest:
                text += "Наиближайшие окончание: " + format_user_dt(chat_id, nearest, "%H:%M %d.%m.%Y")
                line = timezone_line(chat_id, nearest)
                if line:
                    text += f"\n{line}"
            else:
                text += "Наиближайшие окончание: -"
            return text
        acc = visible[0]
        until_ts = int(acc.get("subscription_until_ts") or 0)
        if until_ts:
            text += (
                f"Тариф: {main_mod.html.escape(main_mod._clean_tier_view(acc.get('subscription_tier')))}\n"
                f"Действует до {format_user_dt(chat_id, until_ts, '%H:%M %d.%m.%Y')}"
            )
            line = timezone_line(chat_id, until_ts)
            if line:
                text += f"\n{line}"
        else:
            text += "Тариф: не активный"
        if acc.get("connected") and str(acc.get("port_user_name") or "").strip():
            text += f"\n\nАккаунт: {main_mod._account_html_link(acc)}"
        return text

    def account_detail_text(chat_id: int, account_id: str) -> str:
        acc = main_mod.get_user_account(chat_id, account_id) or {}
        slot = int(acc.get("slot") or 1)
        proxy_ip = str(acc.get("proxy_ip") or "").strip()
        proxy_country = str(acc.get("proxy_country") or "").strip()
        proxy_view = main_mod._mask_proxy_ip(proxy_ip)
        flag = main_mod._country_flag(proxy_country)
        if flag:
            proxy_view = f"{proxy_view} {flag}"
        until_ts = int(acc.get("subscription_until_ts") or 0)
        until_view = format_user_dt(chat_id, until_ts, "%H:%M %d.%m.%Y")
        line = timezone_line(chat_id, until_ts)
        tz_part = f"\n{line}" if line else ""
        return (
            f"{main_mod._account_number_emoji(slot)}аккаунт\n"
            f"Ник: {main_mod.html.escape(str(acc.get('port_user_name') or '-'))}\n"
            f"ID: {main_mod.html.escape(str(acc.get('port_user_id') or '-'))}\n"
            f"Прокси: {main_mod.html.escape(proxy_view)}\n"
            f"До: {until_view}{tz_part}"
        )

    main_mod.profile_text = profile_text
    main_mod.account_detail_text = account_detail_text
    main_mod._zooma_timezone_main_patched = True


def install_bot_message_rewrite(main_mod: Any) -> None:
    if getattr(main_mod, "_zooma_timezone_post_init_patched", False):
        return
    orig_post_init = getattr(main_mod, "post_init", None)
    if not callable(orig_post_init):
        return

    def patch_bot(app: Any) -> None:
        bot = getattr(app, "bot", None)
        if not bot or getattr(bot, "_zooma_timezone_send_patched", False):
            return
        orig_send = bot.send_message

        async def send_message(*args, **kwargs):
            chat_id = kwargs.get("chat_id")
            if chat_id is None and args:
                chat_id = args[0]
            text = kwargs.get("text")
            if text is None and len(args) >= 2:
                text = args[1]
            if text is not None and chat_id is not None:
                new_text = rewrite_subscription_text_for_user(int(chat_id), str(text))
                if "text" in kwargs:
                    kwargs["text"] = new_text
                elif len(args) >= 2:
                    args = (args[0], new_text, *args[2:])
            return await orig_send(*args, **kwargs)

        bot.send_message = send_message
        bot._zooma_timezone_send_patched = True

    async def patched_post_init(app):
        patch_bot(app)
        return await orig_post_init(app)

    main_mod.post_init = patched_post_init
    main_mod._zooma_timezone_post_init_patched = True


def install_billing_timezone_patches(billing_mod: Any) -> None:
    if getattr(billing_mod, "_zooma_timezone_billing_patched", False):
        return
    cls = getattr(billing_mod, "BillingService", None)
    if cls is None:
        return
    billing_mod._zooma_timezone_billing_patched = True


def _server_ping_ms_from_billing(billing: Any) -> Optional[float]:
    val = None
    with contextlib.suppress(Exception):
        getter = getattr(billing, "get_server_ping_ms", None)
        if callable(getter):
            val = getter()
    if val is None:
        with contextlib.suppress(Exception):
            val = getattr(billing, "_server_ping_ms", None)
    if val is None:
        return None
    try:
        return round(float(val), 1)
    except Exception:
        return None


def _is_admin_chat_id(chat_id: Any) -> bool:
    try:
        return bool(ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID))
    except Exception:
        return False


def _apply_effective_ping_to_account_row(row: dict, chat_id: Any, billing: Any) -> dict:
    if not isinstance(row, dict):
        return row
    server_ping = _server_ping_ms_from_billing(billing)
    if server_ping is not None:
        row["server_ping_ms"] = server_ping

    mode = str(row.get("promo_activation_mode") or "server").strip().lower()
    if mode == "extension":
        ext_ping = row.get("extension_ws_ping_ms")
        if ext_ping is not None:
            try:
                ext_ping = round(float(ext_ping), 1)
            except Exception:
                ext_ping = None
        row["proxy_ping_ms"] = None
        row["proxy_ping_last_ts"] = 0
        row["proxy_ping_error"] = ""
        row["proxy_ping_source"] = ""
        row["effective_ping_ms"] = ext_ping
        row["effective_ping_source"] = "extension"
        row["server_ws_live"] = False
        row["ws_live"] = bool(row.get("extension_ws_live"))
        row["runtime_live"] = bool(row.get("extension_ws_live"))
        return row

    has_proxy = bool(row.get("proxy_set"))
    if _is_admin_chat_id(chat_id) and not has_proxy and server_ping is not None:
        row["proxy_ping_ms"] = server_ping
        row["proxy_ping_last_ts"] = int(time.time())
        row["proxy_ping_error"] = ""
        row["proxy_ping_source"] = "server"
        row["effective_ping_ms"] = server_ping
        row["effective_ping_source"] = "server"
        return row

    if row.get("proxy_ping_ms") is not None:
        try:
            row["proxy_ping_ms"] = round(float(row.get("proxy_ping_ms")), 1)
        except Exception:
            pass
        row["effective_ping_ms"] = row.get("proxy_ping_ms")
        row["effective_ping_source"] = "proxy" if has_proxy else ""
        row["proxy_ping_source"] = "proxy" if has_proxy else ""
    else:
        row["effective_ping_ms"] = None
        row["effective_ping_source"] = ""
        row["proxy_ping_source"] = "proxy" if has_proxy else ""
    return row


def _patch_closure_callable(app: Any, target_name: str, wrapper_factory) -> None:
    for route in list(getattr(app, "routes", []) or []):
        endpoint = getattr(route, "endpoint", None)
        closure = getattr(endpoint, "__closure__", None)
        if not closure:
            continue
        for cell in closure:
            with contextlib.suppress(Exception):
                obj = cell.cell_contents
                if not callable(obj) or getattr(obj, "__name__", "") != target_name:
                    continue
                if getattr(obj, "_zooma_effective_ping_patched", False):
                    continue
                patched = wrapper_factory(obj)
                setattr(patched, "_zooma_effective_ping_patched", True)
                cell.cell_contents = patched


def _install_effective_ping_patches(app: Any, billing: Any) -> None:
    if getattr(app, "_zooma_effective_ping_patched", False):
        return

    def account_row_wrapper(original):
        def patched_account_admin_row(chat_id: int, acc: dict, now_ts: int) -> dict:
            return _apply_effective_ping_to_account_row(original(chat_id, acc, now_ts), chat_id, billing)
        patched_account_admin_row.__name__ = getattr(original, "__name__", "_account_admin_row")
        return patched_account_admin_row

    def app_state_wrapper(original):
        def patched_build_user_app_state(chat_id: int) -> dict:
            state = original(chat_id)
            server_ping = _server_ping_ms_from_billing(billing)
            if server_ping is not None:
                state["server_ping_ms"] = server_ping
            accounts = state.get("accounts") if isinstance(state, dict) else None
            if isinstance(accounts, list):
                for acc in accounts:
                    _apply_effective_ping_to_account_row(acc, chat_id, billing)
            active_id = str(state.get("active_account_id") or "") if isinstance(state, dict) else ""
            primary = None
            if isinstance(accounts, list):
                for acc in accounts:
                    if active_id and str(acc.get("account_id") or "") == active_id:
                        primary = acc
                        break
                if primary is None and accounts:
                    primary = accounts[0]
            if isinstance(primary, dict):
                state["proxy_ping_ms"] = primary.get("proxy_ping_ms")
                state["proxy_ping_source"] = primary.get("proxy_ping_source") or ""
                state["effective_ping_ms"] = primary.get("effective_ping_ms")
                state["effective_ping_source"] = primary.get("effective_ping_source") or ""
            return state
        patched_build_user_app_state.__name__ = getattr(original, "__name__", "_build_user_app_state")
        return patched_build_user_app_state

    _patch_closure_callable(app, "_account_admin_row", account_row_wrapper)
    _patch_closure_callable(app, "_build_user_app_state", app_state_wrapper)
    app._zooma_effective_ping_patched = True


def install_promo_api_timezone_patches(promo_api_mod: Any, manager: Any) -> None:
    if getattr(promo_api_mod, "_zooma_timezone_build_patched", False):
        return
    orig_build = getattr(promo_api_mod, "build_promo_app", None)
    if not callable(orig_build):
        return

    def wrapped_build_promo_app(engine, billing):
        app = orig_build(engine, billing)
        _install_effective_ping_patches(app, billing)

        @app.post("/app/api/timezone")
        async def user_app_timezone(request: Request, init_data: str = Query(default="")) -> dict:
            try:
                tg_user = _validate_tg_init_data(init_data)
                chat_id = int(tg_user.get("id"))
                body = await request.json()
                data = capture_user_timezone(
                    chat_id=chat_id,
                    tz_name=str(body.get("timezone") or ""),
                    offset_min=body.get("offset_min"),
                    locale=str(body.get("locale") or ""),
                    source="tg_mini_app_intl",
                )
                return {"ok": True, "data": data}
            except Exception as e:
                return {"ok": False, "error": str(e)[:120]}

        @app.middleware("http")
        async def admin_omsk_time_middleware(request, call_next):
            response = await call_next(request)
            try:
                if request.url.path != "/admin":
                    return response
                ctype = str(response.headers.get("content-type") or "")
                if "text/html" not in ctype:
                    return response
                body = b""
                async for chunk in response.body_iterator:
                    body += chunk
                html = body.decode("utf-8", errors="ignore")
                inject = """
    function _zoomaOmskParts(ts){
      const n = Number(ts || 0);
      if (!n) return null;
      try {
        const parts = new Intl.DateTimeFormat('ru-RU',{timeZone:'Asia/Omsk',hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).formatToParts(new Date(n*1000));
        const m = Object.fromEntries(parts.filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));
        return m;
      } catch (_) { return null; }
    }
    _fmtTs = function(ts){ const m=_zoomaOmskParts(ts); return m ? `${m.day}.${m.month}.${m.year}, ${m.hour}:${m.minute}:${m.second} UTC+06:00` : '-'; };
    _fmtSubShort = function(ts){ const m=_zoomaOmskParts(ts); return m ? `${m.hour}:${m.minute} ${m.day}.${m.month}` : '-'; };
    _accountLineHtml = function(u, a) {
      const frozen = !!a.subscription_paused;
      const active = !!a.subscription_active;
      const connected = !!a.connected && !!a.ws_live && active && !frozen;
      const subBadge = frozen ? '<span class="badge warnb">заморожен</span>' : (active ? '<span class="badge ok">sub active</span>' : '<span class="badge warnb">sub off</span>');
      const connBadge = connected ? '<span class="badge ok">connected</span>' : '<span class="badge err">offline</span>';
      const promoMode = a.promo_activation_mode === 'extension' ? 'extension' : 'server';
      const pingMs = (a.effective_ping_ms != null ? a.effective_ping_ms : a.proxy_ping_ms);
      const pingSource = String(a.effective_ping_source || a.proxy_ping_source || '').toLowerCase();
      const pingLabel = pingSource === 'extension' ? 'Пинг расширения' : (pingSource === 'server' ? 'Пинг сервера' : 'Пинг прокси');
      const ping = pingMs != null ? ` · ${pingLabel}: <span style="color:${_pingColor(pingMs)}">${Number(pingMs).toFixed(1)} ms</span>` : '';
      const err = promoMode === 'server' && a.proxy_set && a.proxy_ping_error ? ` · Ошибка: ${esc(a.proxy_ping_error)}` : '';
      const flag = a.proxy_country ? ` ${esc(String(a.proxy_country).toUpperCase())}` : '';
      const accountId = esc(a.account_id || '');
      return `
        <div class="account-card">
          <div class="muted account-main">${esc(_accountShort(a))} · ${frozen ? `Заморожен · остаток: ${Math.floor(Number(a.subscription_frozen_left_sec || 0)/86400)} дн.` : `До: ${active ? _fmtSubShort(a.subscription_until_ts) : '-'}`} · Прокси: ${a.proxy_set ? 'есть' : 'нет'}${a.proxy_set ? ` · ${esc(_maskedProxy(a.proxy_ip))}${flag}` : ''}${ping}${err} · промо: ${promoMode === 'extension' ? 'расширение' : 'сервер'}</div>
          <div style="margin:6px 0">${subBadge} ${connBadge} <button class="secondary micro" data-session-recheck="${u.chat_id}" data-account-id="${accountId}" data-username="${esc(u.tg_username || '')}">Токен</button> <button class="secondary micro" data-promo-mode="${u.chat_id}" data-account-id="${accountId}" data-mode="${promoMode === 'extension' ? 'server' : 'extension'}" title="Нажми, чтобы переключить на ${promoMode === 'extension' ? 'сервер' : 'расширение'}">${promoMode === 'extension' ? 'Промо: расширение' : 'Промо: сервер'}</button></div>
          <div class="account-actions">
            <button class="secondary micro" data-sub-manage="${u.chat_id}" data-account-id="${accountId}" data-username="${esc(u.tg_username || '')}">Подписка</button>
            <button class="secondary micro" data-proxy-manage="${u.chat_id}" data-account-id="${accountId}" data-username="${esc(u.tg_username || '')}">Прокси</button>${(active && !frozen) ? `<button class="secondary micro" data-ws-reconnect="${u.chat_id}" data-account-id="${accountId}" data-username="${esc(u.tg_username || '')}">${promoMode === 'extension' ? 'Обновить вкладку' : 'WS reconnect'}</button><button class="secondary micro" data-ua-manage="${u.chat_id}" data-account-id="${accountId}" data-username="${esc(u.tg_username || '')}">Юзер агент</button>` : ''}
          </div>
        </div>
      `;
    };
"""
                html = html.replace("</script>\n</body>", inject + "\n</script>\n</body>")
                return HTMLResponse(html, status_code=response.status_code)
            except Exception:
                return response

        return app

    promo_api_mod.build_promo_app = wrapped_build_promo_app
    promo_api_mod._zooma_timezone_build_patched = True


def install_late_timezone_patches(manager: Any) -> None:
    def loop() -> None:
        for _ in range(100):
            try:
                promo_api_mod = sys.modules.get("promo_api")
                if promo_api_mod:
                    install_promo_api_timezone_patches(promo_api_mod, manager)

                billing_mod = sys.modules.get("billing")
                if billing_mod:
                    install_billing_timezone_patches(billing_mod)

                for name in ("__main__", "main"):
                    main_mod = sys.modules.get(name)
                    if not main_mod:
                        continue
                    install_main_timezone_patches(main_mod, manager)
                    install_bot_message_rewrite(main_mod)
                    if promo_api_mod and hasattr(main_mod, "build_promo_app"):
                        setattr(main_mod, "build_promo_app", getattr(promo_api_mod, "build_promo_app"))
            except Exception as e:
                logger.warning("timezone late patch warning: %s", e)
            time.sleep(0.1)
    threading.Thread(target=loop, name="timezone-patcher", daemon=True).start()


def install_timezone_patches(manager: Any) -> None:
    install_store_timezone_patches()
    install_late_timezone_patches(manager)
