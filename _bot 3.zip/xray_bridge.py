import json
import logging
import os
import random
import shutil
import socket
import subprocess
import time
from contextlib import suppress
from urllib.parse import urlparse

from config import ADMIN_CHAT_ID
from store import get_user

logger = logging.getLogger("xray_bridge")

_SESSIONS: dict[str, dict] = {}
_CFG_DIR = os.path.join(os.path.dirname(__file__), "xray-sessions")
_EXCLUDED_PORTS = {25, 389, 465, 587, 2525, 3389, 53413}


def _is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        with suppress(Exception):
            s.bind(("127.0.0.1", port))
            return True
    return False


def _pick_port() -> int:
    for _ in range(256):
        p = random.randint(20000, 60000)
        if p in _EXCLUDED_PORTS:
            continue
        if _is_port_free(p):
            return p
    raise RuntimeError("no_free_port_for_xray")


def _parse_proxy(proxy_url: str) -> dict:
    u = urlparse((proxy_url or "").strip())
    if not u.scheme or not u.hostname or not u.port:
        raise RuntimeError("invalid_user_proxy_url")
    scheme = u.scheme.lower()
    if scheme.startswith("socks5"):
        protocol = "socks"
    elif scheme in {"http", "https"}:
        protocol = "http"
    else:
        raise RuntimeError(f"unsupported_proxy_scheme:{scheme}")
    server = u.hostname
    port = int(u.port)
    user = u.username or ""
    pwd = u.password or ""
    return {"protocol": protocol, "server": server, "port": port, "user": user, "pwd": pwd}


def _build_config(inbound_port: int, proxy: dict) -> dict:
    outbound_settings = {
        "servers": [
            {
                "address": proxy["server"],
                "port": proxy["port"],
            }
        ]
    }
    user = proxy.get("user") or ""
    pwd = proxy.get("pwd") or ""
    if user or pwd:
        outbound_settings["servers"][0]["users"] = [{"user": user, "pass": pwd}]
    return {
        "log": {"loglevel": "warning"},
        "inbounds": [
            {
                "listen": "127.0.0.1",
                "port": inbound_port,
                "protocol": "http",
                "settings": {"allowTransparent": False},
            }
        ],
        "outbounds": [
            {
                "protocol": proxy["protocol"],
                "settings": outbound_settings,
            }
        ],
    }


def _wait_port_open(port: int, timeout_sec: float = 2.5) -> bool:
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.25)
            with suppress(Exception):
                s.connect(("127.0.0.1", port))
                return True
        time.sleep(0.1)
    return False


def ensure_xray_bridge(sid: str, chat_id: int) -> str | None:
    # Admin auth flow without proxy.
    if chat_id == ADMIN_CHAT_ID:
        return None

    user = get_user(chat_id)
    proxy_url = (user.user_proxy_url or "").strip()
    if not proxy_url:
        raise RuntimeError("proxy_required")

    if sid in _SESSIONS:
        return _SESSIONS[sid]["bridge_url"]

    xray_bin = shutil.which("xray")
    if not xray_bin:
        raise RuntimeError("xray_not_installed")

    os.makedirs(_CFG_DIR, exist_ok=True)
    proxy = _parse_proxy(proxy_url)
    port = _pick_port()
    cfg_path = os.path.join(_CFG_DIR, f"{chat_id}-{sid}-{port}.json")
    cfg = _build_config(port, proxy)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False)

    proc = subprocess.Popen(
        [xray_bin, "run", "-config", cfg_path],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if proc.poll() is not None:
        with suppress(Exception):
            os.remove(cfg_path)
        raise RuntimeError("xray_start_failed")
    if not _wait_port_open(port):
        with suppress(Exception):
            proc.terminate()
        with suppress(Exception):
            proc.wait(timeout=2)
        with suppress(Exception):
            os.remove(cfg_path)
        raise RuntimeError("xray_bridge_not_ready")

    bridge_url = f"http://127.0.0.1:{port}"
    _SESSIONS[sid] = {
        "chat_id": chat_id,
        "pid": proc.pid,
        "proc": proc,
        "cfg_path": cfg_path,
        "port": port,
        "bridge_url": bridge_url,
    }
    logger.info("[%s] xray bridge started port=%s", sid, port)
    return bridge_url


def stop_xray_bridge(sid: str) -> None:
    item = _SESSIONS.pop(sid, None)
    if not item:
        return
    proc = item.get("proc")
    if proc and proc.poll() is None:
        with suppress(Exception):
            proc.terminate()
        with suppress(Exception):
            proc.wait(timeout=2)
        if proc.poll() is None:
            with suppress(Exception):
                proc.kill()
    cfg_path = item.get("cfg_path")
    if cfg_path:
        with suppress(Exception):
            os.remove(cfg_path)
    logger.info("[%s] xray bridge stopped", sid)
