import random
import asyncio
import time
import logging
import uuid
from dataclasses import dataclass
from contextlib import suppress
from typing import Optional
from urllib.parse import quote
from collections import deque

import httpx

from config import PROXYLINE_API_BASE, PROXYLINE_API_TOKEN, PROXYLINE_COUNTRY_POOL


logger = logging.getLogger("proxyline")


@dataclass
class ProxyPurchaseResult:
    ok: bool
    reason: str
    proxy_url: Optional[str] = None
    order_id: Optional[str] = None
    country: Optional[str] = None
    city: Optional[str] = None
    ip: Optional[str] = None
    masked_ip: Optional[str] = None
    price_rub: Optional[float] = None
    proxy_id: Optional[int] = None
    port_http: Optional[int] = None
    port_socks5: Optional[int] = None
    login: Optional[str] = None
    password: Optional[str] = None
    scheme: Optional[str] = None


class ProxylineService:
    def __init__(self) -> None:
        self.api_base = PROXYLINE_API_BASE
        self.api_token = PROXYLINE_API_TOKEN
        self.country_pool = PROXYLINE_COUNTRY_POOL or ["de", "nl", "fr", "pl", "es", "it"]
        self._rl_lock = asyncio.Lock()
        self._rl_hits: deque[float] = deque()
        self._rl_limit = 48  # below documented 50 req/min
        self._rl_window_sec = 60.0

    def _new_proxy_op_id(self) -> str:
        return uuid.uuid4().hex[:12]

    async def buy_user_proxy(self, chat_id: int, *, period: int = 30, tags: Optional[list[str]] = None, proxy_op_id: Optional[str] = None) -> ProxyPurchaseResult:
        if not self.api_token:
            return ProxyPurchaseResult(ok=False, reason="Не задан PROXYLINE_API_TOKEN")
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        tried = set()
        attempts = min(3, len(self.country_pool))
        for _ in range(attempts):
            country = self._pick_country(tried)
            tried.add(country)
            logger.info("proxyline buy_user_proxy start | op_id=%s chat_id=%s country=%s period=%s attempts_left=%s", op_id, chat_id, country, int(period or 30), max(0, attempts - len(tried)))
            try:
                order = await self._api(
                    "new-order/",
                    method="POST",
                    payload={
                        "type": "dedicated_ipv4",
                        "country": country,
                        "quantity": 1,
                        "period": max(1, int(period or 30)),
                    },
                    proxy_op_id=op_id,
                )
                order_id = self._extract_order_id(order)
                price_rub = self._extract_price_rub(order)
                logger.info(
                    "proxyline new-order ok | op_id=%s chat_id=%s country=%s order_id=%s price_raw=%s",
                    op_id,
                    chat_id,
                    country,
                    order_id,
                    (price_rub if price_rub is not None else "-"),
                )
                proxy_item = await self._get_proxy_item(order_id=order_id, proxy_op_id=op_id)
                if not proxy_item:
                    logger.warning(
                        "proxyline proxies empty | op_id=%s chat_id=%s country=%s order_id=%s",
                        op_id,
                        chat_id,
                        country,
                        order_id,
                    )
                    return ProxyPurchaseResult(
                        ok=False,
                        reason="Прокси куплен, но API не вернул данные прокси в списке",
                        order_id=order_id,
                        country=country,
                    )
                proxy_url = self._build_proxy_url(proxy_item)
                if not proxy_url:
                    logger.warning(
                        "proxyline proxy_url build failed | op_id=%s chat_id=%s country=%s order_id=%s item=%s",
                        op_id,
                        chat_id,
                        country,
                        order_id,
                        self._proxy_item_debug(proxy_item),
                    )
                    return ProxyPurchaseResult(
                        ok=False,
                        reason="Не удалось собрать URL прокси из ответа API",
                        order_id=order_id,
                        country=country,
                    )
                # Real Proxyline tags are applied after purchase because order_id exists only after new-order.
                with suppress(Exception):
                    await self.ensure_tags_for_order(order_id=order_id, tags=(tags or [str(chat_id)]), proxy_op_id=op_id)
                ip, city = await self._resolve_geo_via_proxy(proxy_url)
                proxy_id, port_http, port_socks5, login, password = self._extract_proxy_identity(proxy_item)
                logger.info(
                    "proxyline buy_user_proxy success | op_id=%s chat_id=%s country=%s order_id=%s ip=%s city=%s",
                    op_id,
                    chat_id,
                    country,
                    order_id,
                    ip or "-",
                    city or "-",
                )
                return ProxyPurchaseResult(
                    ok=True,
                    reason="ok",
                    proxy_url=proxy_url,
                    order_id=order_id,
                    country=country,
                    city=city,
                    ip=ip,
                    masked_ip=self._mask_ip(ip),
                    price_rub=price_rub,
                    proxy_id=proxy_id,
                    port_http=port_http,
                    port_socks5=port_socks5,
                    login=login,
                    password=password,
                    scheme="socks5",
                )
            except Exception as e:
                last_error = str(e)
                if self._is_fatal_buy_error(e):
                    logger.warning(
                        "proxyline buy_user_proxy fatal failed | op_id=%s chat_id=%s country=%s period=%s err=%s",
                        op_id,
                        chat_id,
                        country,
                        int(period or 30),
                        last_error,
                    )
                    return ProxyPurchaseResult(ok=False, reason=last_error, country=country)
                logger.warning(
                    "proxyline buy_user_proxy attempt failed | op_id=%s chat_id=%s country=%s err=%s",
                    op_id,
                    chat_id,
                    country,
                    last_error,
                )
        final_err = last_error if "last_error" in locals() else "Ошибка покупки прокси"
        logger.error("proxyline buy_user_proxy failed | op_id=%s chat_id=%s err=%s", op_id, chat_id, final_err)
        return ProxyPurchaseResult(ok=False, reason=final_err)

    async def get_balance_amount(self) -> tuple[float, str]:
        if not self.api_token:
            raise RuntimeError("Не задан PROXYLINE_API_TOKEN")
        data = await self._api("balance/", method="GET", payload={})
        currency = self._extract_currency(data)
        for key in ("balance", "money", "amount", "result"):
            v = data.get(key)
            if isinstance(v, (int, float, str)):
                with suppress(Exception):
                    return float(v), currency
            if isinstance(v, dict):
                for kk in ("balance", "amount", "rub"):
                    vv = v.get(kk)
                    if isinstance(vv, (int, float, str)):
                        with suppress(Exception):
                            return float(vv), currency
        raise RuntimeError("Не удалось получить баланс Proxyline")

    async def buy_proxy(
        self,
        *,
        country: str,
        period: int = 30,
        tag: Optional[str] = None,
        tags: Optional[list[str]] = None,
        proxy_type: str = "dedicated_ipv4",
        exclude_no_access_from_ru: bool = False,
        proxy_op_id: Optional[str] = None,
    ) -> ProxyPurchaseResult:
        if not self.api_token:
            return ProxyPurchaseResult(ok=False, reason="Не задан PROXYLINE_API_TOKEN")
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        payload = {
            "type": proxy_type.strip() or "dedicated_ipv4",
            "country": country.strip().lower(),
            "quantity": 1,
            "period": int(period),
        }
        if exclude_no_access_from_ru:
            payload["exclude_no_access_from_ru"] = 1
        if tag:
            payload["comment"] = str(tag)[:128]
        order = await self._api("new-order/", method="POST", payload=payload, proxy_op_id=op_id)
        order_id = self._extract_order_id(order)
        price_rub = self._extract_price_rub(order)
        logger.info(
            "proxyline buy_proxy new-order ok | op_id=%s country=%s type=%s period=%s order_id=%s price_raw=%s",
            op_id,
            country,
            proxy_type,
            period,
            order_id,
            (price_rub if price_rub is not None else "-"),
        )
        proxy_item = await self._get_proxy_item(order_id=order_id, proxy_op_id=op_id)
        if not proxy_item:
            logger.warning("proxyline buy_proxy proxies empty | op_id=%s country=%s order_id=%s", op_id, country, order_id)
            return ProxyPurchaseResult(ok=False, reason="Прокси куплен, но нет данных в proxies", order_id=order_id, country=country, price_rub=price_rub)
        proxy_url = self._build_proxy_url(proxy_item)
        if not proxy_url:
            logger.warning(
                "proxyline buy_proxy proxy_url build failed | op_id=%s country=%s order_id=%s item=%s",
                op_id,
                country,
                order_id,
                self._proxy_item_debug(proxy_item),
            )
            return ProxyPurchaseResult(ok=False, reason="Не удалось собрать URL прокси", order_id=order_id, country=country, price_rub=price_rub)
        tag_names = tags if tags is not None else ([str(tag)] if tag else [])
        if tag_names:
            with suppress(Exception):
                await self.ensure_tags_for_order(order_id=order_id, tags=tag_names, proxy_op_id=op_id)
        ip, city = await self._resolve_geo_via_proxy(proxy_url)
        proxy_id, port_http, port_socks5, login, password = self._extract_proxy_identity(proxy_item)
        return ProxyPurchaseResult(
            ok=True,
            reason="ok",
            proxy_url=proxy_url,
            order_id=order_id,
            country=country,
            city=city,
            ip=ip,
            masked_ip=self._mask_ip(ip),
            price_rub=price_rub,
            proxy_id=proxy_id,
            port_http=port_http,
            port_socks5=port_socks5,
            login=login,
            password=password,
            scheme="socks5",
        )

    async def resolve_proxy_id(
        self,
        *,
        order_id: Optional[str] = None,
        proxy_url: Optional[str] = None,
        ip: Optional[str] = None,
        port_socks5: Optional[int] = None,
        login: Optional[str] = None,
        proxy_op_id: Optional[str] = None,
    ) -> Optional[int]:
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        # 1) Fast path by order_id.
        oid = str(order_id or "").strip()
        if oid:
            item = await self._get_proxy_item(order_id=oid, proxy_op_id=op_id)
            if item:
                pid, *_ = self._extract_proxy_identity(item)
                if pid is not None:
                    return pid

        # 2) Fallback: scan proxy list and match endpoint/login.
        host = ""
        port = None
        lg = (login or "").strip()
        purl = str(proxy_url or "").strip()
        if purl:
            with suppress(Exception):
                from urllib.parse import urlparse
                pu = urlparse(purl)
                host = pu.hostname or ""
                if pu.port:
                    port = int(pu.port)
                if not lg and pu.username:
                    lg = pu.username
        if not host and ip:
            host = str(ip).strip()
        if port is None and port_socks5:
            with suppress(Exception):
                port = int(port_socks5)
        if not host:
            return None

        data = await self._api("proxies/", method="GET", payload={"limit": 2000, "offset": 0, "status": "active"}, proxy_op_id=op_id)
        items = self._extract_items(data)
        for it in items:
            it_host = str(it.get("ip") or it.get("host") or "").strip()
            if it_host != host:
                continue
            it_port = None
            with suppress(Exception):
                if it.get("port_socks5") is not None:
                    it_port = int(it.get("port_socks5"))
                elif it.get("port_http") is not None:
                    it_port = int(it.get("port_http"))
            if port is not None and it_port is not None and it_port != port:
                continue
            if lg:
                it_login = str(it.get("username") or it.get("user") or "").strip()
                if it_login and it_login != lg:
                    continue
            with suppress(Exception):
                return int(it.get("id"))
        return None

    async def renew_proxy(self, *, proxy_id: int, period: int, proxy_op_id: Optional[str] = None) -> ProxyPurchaseResult:
        if not self.api_token:
            return ProxyPurchaseResult(ok=False, reason="Не задан PROXYLINE_API_TOKEN")
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        pid = int(proxy_id)
        data = await self._api("renew/", method="POST", payload={"proxies": str(pid), "period": int(period)}, proxy_op_id=op_id)
        items = self._extract_items(data)
        item = items[0] if items else (data[0] if isinstance(data, list) and data and isinstance(data[0], dict) else None)
        if not isinstance(item, dict):
            return ProxyPurchaseResult(ok=False, reason="Proxyline renew вернул пустой ответ")
        proxy_url = self._build_proxy_url(item)
        if not proxy_url:
            return ProxyPurchaseResult(ok=False, reason="Не удалось собрать URL прокси после продления")
        pid2, port_http, port_socks5, login, password = self._extract_proxy_identity(item)
        return ProxyPurchaseResult(
            ok=True,
            reason="ok",
            proxy_url=proxy_url,
            order_id=str(item.get("order_id") or "") or None,
            country=str(item.get("country") or "") or None,
            ip=str(item.get("ip") or "") or None,
            masked_ip=self._mask_ip(str(item.get("ip") or "") or None),
            proxy_id=pid2 if pid2 is not None else pid,
            port_http=port_http,
            port_socks5=port_socks5,
            login=login,
            password=password,
            scheme="socks5",
        )

    async def buy_batch(
        self,
        *,
        countries: list[str],
        period: int = 30,
        tag_prefix: Optional[str] = None,
        proxy_type: str = "dedicated_ipv4",
        exclude_no_access_from_ru: bool = False,
        proxy_op_id: Optional[str] = None,
    ) -> list[ProxyPurchaseResult]:
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        results: list[ProxyPurchaseResult] = []
        for idx, c in enumerate(countries):
            tag = None
            if tag_prefix:
                tag = f"{tag_prefix}-{idx+1}"
            try:
                r = await self.buy_proxy(
                    country=c,
                    period=period,
                    tag=tag,
                    proxy_type=proxy_type,
                    exclude_no_access_from_ru=exclude_no_access_from_ru,
                    proxy_op_id=op_id,
                )
            except Exception as e:
                r = ProxyPurchaseResult(ok=False, reason=str(e), country=c)
            results.append(r)
        return results

    async def estimate_price_rub(
        self,
        *,
        country: str,
        period: int = 30,
        quantity: int = 1,
        proxy_type: str = "dedicated_ipv4",
        exclude_no_access_from_ru: bool = False,
        proxy_op_id: Optional[str] = None,
    ) -> Optional[float]:
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        # new-order-amount is documented and should return exact pre-charge amount.
        probe_payload = {
            "country": country,
            "period": int(period),
            "quantity": int(quantity),
            "type": proxy_type.strip() or "dedicated_ipv4",
        }
        if exclude_no_access_from_ru:
            probe_payload["exclude_no_access_from_ru"] = 1
        with suppress(Exception):
            data = await self._api("new-order-amount/", method="POST", payload=probe_payload, proxy_op_id=op_id)
            p = self._extract_price_rub(data)
            if p is not None:
                return float(p)
        # Fallback probe for compatibility with older accounts.
        for endpoint in ("prices/", "packages/", "price/"):
            with suppress(Exception):
                data = await self._api(endpoint, method="GET", payload=probe_payload, proxy_op_id=op_id)
                p = self._extract_price_rub(data)
                if p is not None:
                    return float(p) * max(1, int(quantity))
        return None

    def _is_fatal_buy_error(self, err: object) -> bool:
        text = str(err or "").strip().lower()
        return any(x in text for x in (
            "not enough money",
            "insufficient funds",
            "недостаточно средств",
            "balance",
            "api token",
            "proxyline_api_token",
            "forbidden",
            "unauthorized",
            "401",
            "403",
        ))

    def _pick_country(self, tried: set[str]) -> str:
        variants = [c for c in self.country_pool if c not in tried]
        if not variants:
            variants = self.country_pool
        return random.choice(variants)

    async def _get_proxy_item(self, order_id: Optional[str], proxy_op_id: Optional[str] = None) -> Optional[dict]:
        payload = {"limit": 50, "offset": 0}
        if order_id:
            payload["orders"] = order_id
        data = await self._api("proxies/", method="GET", payload=payload, proxy_op_id=proxy_op_id)
        proxies = self._extract_items(data)
        logger.info("proxyline proxies fetch | op_id=%s order_id=%s count=%s", proxy_op_id or "-", order_id or "-", len(proxies))
        if proxies:
            return proxies[0]
        return None

    def _mask_payload(self, payload: dict) -> dict:
        out = dict(payload or {})
        for k in ("api_key", "password", "pass", "token", "apikey"):
            if k in out:
                out[k] = "***"
        return out

    async def _api(self, path: str, method: str, payload: dict, proxy_op_id: Optional[str] = None) -> dict:
        await self._throttle()
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        headers = {"API-KEY": self.api_token}
        params = {"api_key": self.api_token}
        url = f"{self.api_base}/{path.lstrip('/')}"
        low_path = str(path or "").strip().lower()
        log_raw = not low_path.startswith("balance")
        if log_raw:
            logger.info("proxyline raw req | op_id=%s method=%s path=%s payload=%s", op_id, method.upper(), path, self._mask_payload(payload))
        async with httpx.AsyncClient(timeout=35) as client:
            if method.upper() == "GET":
                r = await client.get(url, headers=headers, params={**params, **payload})
            else:
                r = await client.post(url, headers=headers, params=params, data=payload)
            if log_raw:
                body_preview = (r.text or "")[:4000]
                logger.info("proxyline raw res | op_id=%s status=%s path=%s body=%s", op_id, int(r.status_code), path, body_preview)
            try:
                r.raise_for_status()
            except httpx.HTTPStatusError as e:
                details = ""
                with_context = False
                try:
                    body = e.response.json()
                    if isinstance(body, dict):
                        for key in ("non_field_errors", "detail", "message", "error"):
                            val = body.get(key)
                            if isinstance(val, list) and val:
                                details = str(val[0])
                                break
                            if isinstance(val, str) and val.strip():
                                details = val.strip()
                                break
                        if not details:
                            details = str(body)
                        with_context = True
                except Exception:
                    with suppress(Exception):
                        text = e.response.text.strip()
                        if text:
                            details = text[:500]
                            with_context = True
                if with_context:
                    raise RuntimeError(f"HTTP {e.response.status_code}: {details}") from None
                raise RuntimeError(f"HTTP {e.response.status_code}: {e}") from None
            data = r.json()
        if isinstance(data, dict) and data.get("status") == "error":
            msg = data.get("message") or data.get("error") or str(data)
            raise RuntimeError(str(msg))
        return data if isinstance(data, dict) else {"result": data}

    async def _throttle(self) -> None:
        while True:
            wait_for = 0.0
            async with self._rl_lock:
                now = time.monotonic()
                while self._rl_hits and (now - self._rl_hits[0]) >= self._rl_window_sec:
                    self._rl_hits.popleft()
                if len(self._rl_hits) < self._rl_limit:
                    self._rl_hits.append(now)
                    return
                wait_for = self._rl_window_sec - (now - self._rl_hits[0])
            await asyncio.sleep(max(0.05, wait_for))

    def _extract_items(self, data: dict) -> list[dict]:
        for key in ("data", "results", "result", "proxies", "items"):
            val = data.get(key)
            if isinstance(val, list):
                return [x for x in val if isinstance(x, dict)]
        if isinstance(data.get("list"), list):
            return [x for x in data["list"] if isinstance(x, dict)]
        return []

    def _extract_order_id(self, data: dict) -> Optional[str]:
        candidates = []
        for key in ("order_id", "id", "order", "orderId"):
            v = data.get(key)
            if v:
                candidates.append(str(v))
        for container in ("data", "result"):
            val = data.get(container)
            if isinstance(val, dict):
                for key in ("order_id", "id", "order", "orderId"):
                    v = val.get(key)
                    if v:
                        candidates.append(str(v))
            if isinstance(val, list) and val and isinstance(val[0], dict):
                for key in ("order_id", "id", "order", "orderId"):
                    v = val[0].get(key)
                    if v:
                        candidates.append(str(v))
        return candidates[0] if candidates else None

    def _extract_price_rub(self, data: dict) -> Optional[float]:
        candidates: list[object] = []
        for key in ("price", "amount", "sum", "cost", "total"):
            v = data.get(key)
            if v is not None:
                candidates.append(v)
        for container in ("data", "result", "order"):
            val = data.get(container)
            if isinstance(val, dict):
                for key in ("price", "amount", "sum", "cost", "total"):
                    v = val.get(key)
                    if v is not None:
                        candidates.append(v)
        # Some responses keep amounts in lists or nested dicts.
        for container in ("data", "result"):
            val = data.get(container)
            if isinstance(val, list):
                for item in val:
                    if isinstance(item, dict):
                        for key in ("price", "amount", "sum", "cost", "total"):
                            v = item.get(key)
                            if v is not None:
                                candidates.append(v)
        for v in candidates:
            with suppress(Exception):
                if isinstance(v, str):
                    vv = v.strip().replace(",", ".").replace("$", "").replace("₽", "").replace("rub", "").replace("usd", "")
                    return float(vv)
                return float(v)
        return None

    def _extract_currency(self, data: dict) -> str:
        for key in ("currency", "curr", "unit"):
            v = data.get(key)
            if isinstance(v, str) and v.strip():
                return v.strip().lower()
        for container in ("data", "result"):
            val = data.get(container)
            if isinstance(val, dict):
                for key in ("currency", "curr", "unit"):
                    v = val.get(key)
                    if isinstance(v, str) and v.strip():
                        return v.strip().lower()
        return ""

    def _build_proxy_url(self, item: dict) -> Optional[str]:
        host = str(item.get("ip") or item.get("host") or item.get("server") or "").strip()
        # Prefer SOCKS5 if present, fallback to HTTP.
        port = str(
            item.get("port")
            or item.get("port_socks5")
            or item.get("port_http")
            or item.get("http_port")
            or ""
        ).strip()
        login = str(item.get("login") or item.get("user") or item.get("username") or "").strip()
        password = str(item.get("password") or item.get("pass") or "").strip()
        if not host or not port:
            return None
        if login and password:
            return f"socks5://{quote(login, safe='')}:{quote(password, safe='')}@{host}:{port}"
        return f"socks5://{host}:{port}"

    def _normalize_tag_names(self, tags: Optional[list[str]]) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for raw in (tags or []):
            t = str(raw or "").strip()
            if not t:
                continue
            # Proxyline tag limit is 30 chars. Keep only stable short ids: chat_id and slot.
            t = t[:30]
            if t and t not in seen:
                seen.add(t)
                out.append(t)
            if len(out) >= 5:
                break
        return out

    async def ensure_tags_for_order(self, order_id: Optional[str], tags: Optional[list[str]]) -> None:
        oid = str(order_id or "").strip()
        if not oid:
            return
        for tag_name in self._normalize_tag_names(tags):
            await self._ensure_tag_for_order(order_id=oid, tag_name=tag_name)

    async def _ensure_tag_for_order(self, order_id: Optional[str], tag_name: str) -> None:
        oid = str(order_id or "").strip()
        tname = str(tag_name or "").strip()
        if not oid or not tname:
            return
        tag_id = await self._get_or_create_tag_id(tname)
        if tag_id is None:
            logger.warning("proxyline tag ensure skipped | order_id=%s tag=%s reason=no_tag_id", oid, tname)
            return
        await self._apply_tag_to_order(oid, tag_id)
        logger.info("proxyline tag applied | order_id=%s tag=%s tag_id=%s", oid, tname, tag_id)

    async def _get_or_create_tag_id(self, tag_name: str) -> Optional[int]:
        name = str(tag_name or "").strip()
        if not name:
            return None
        data = await self._api("tags/", method="GET", payload={"limit": 500, "offset": 0})
        items = self._extract_items(data)
        for it in items:
            nm = str(it.get("name") or "").strip()
            if nm == name:
                with suppress(Exception):
                    return int(it.get("id"))
        # Create tag if absent
        created = await self._api("tags/", method="POST", payload={"name": name})
        for src in (created,):
            if isinstance(src, dict):
                for k in ("id", "tag_id"):
                    with suppress(Exception):
                        if src.get(k) is not None:
                            return int(src.get(k))
                for box in ("data", "result"):
                    b = src.get(box)
                    if isinstance(b, dict):
                        for k in ("id", "tag_id"):
                            with suppress(Exception):
                                if b.get(k) is not None:
                                    return int(b.get(k))
        # Re-read tags as fallback
        data2 = await self._api("tags/", method="GET", payload={"limit": 500, "offset": 0})
        items2 = self._extract_items(data2)
        for it in items2:
            nm = str(it.get("name") or "").strip()
            if nm == name:
                with suppress(Exception):
                    return int(it.get("id"))
        return None

    async def _apply_tag_to_order(self, order_id: str, tag_id: int) -> None:
        await self._throttle()
        headers = {"API-KEY": self.api_token}
        params = {"api_key": self.api_token, "orders": str(order_id)}
        payload = {"action": "add", "ids": str(tag_id)}
        url = f"{self.api_base}/proxies/tags/"
        async with httpx.AsyncClient(timeout=35) as client:
            r = await client.post(url, headers=headers, params=params, data=payload)
            try:
                r.raise_for_status()
            except httpx.HTTPStatusError as e:
                body = ""
                with suppress(Exception):
                    body = e.response.text[:400]
                raise RuntimeError(f"HTTP {e.response.status_code}: {body or e}") from None

    def _proxy_item_debug(self, item: dict) -> dict:
        # Safe compact diagnostics without exposing full secrets/token
        login = str(item.get("login") or item.get("user") or item.get("username") or "").strip()
        password = str(item.get("password") or item.get("pass") or "").strip()
        return {
            "id": item.get("id"),
            "order_id": item.get("order_id") or item.get("order"),
            "ip": item.get("ip") or item.get("host") or item.get("server"),
            "port": item.get("port") or item.get("http_port") or item.get("port_http") or item.get("port_socks5"),
            "port_http": item.get("port_http"),
            "port_socks5": item.get("port_socks5"),
            "has_login": bool(login),
            "has_password": bool(password),
            "login_preview": (login[:2] + "***") if login else "",
        }

    def _extract_proxy_identity(self, item: dict) -> tuple[Optional[int], Optional[int], Optional[int], Optional[str], Optional[str]]:
        pid = None
        port_http = None
        port_socks5 = None
        login = None
        password = None
        with suppress(Exception):
            if item.get("id") is not None:
                pid = int(item.get("id"))
        with suppress(Exception):
            if item.get("port_http") is not None:
                port_http = int(item.get("port_http"))
        with suppress(Exception):
            if item.get("port_socks5") is not None:
                port_socks5 = int(item.get("port_socks5"))
        lg = str(item.get("username") or item.get("user") or item.get("login") or "").strip()
        pw = str(item.get("password") or item.get("pass") or "").strip()
        login = lg or None
        password = pw or None
        return pid, port_http, port_socks5, login, password

    async def _resolve_geo_via_proxy(self, proxy_url: str) -> tuple[Optional[str], Optional[str]]:
        url = "https://ipapi.co/json/"
        async with httpx.AsyncClient(timeout=20, proxy=proxy_url) as client:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
        ip = str(data.get("ip") or "").strip() or None
        city = str(data.get("city") or "").strip() or None
        return ip, city

    def _mask_ip(self, ip: Optional[str]) -> Optional[str]:
        if not ip:
            return None
        parts = ip.split(".")
        if len(parts) != 4:
            return ip
        return f"{parts[0]}.{parts[1]}.#.#"
