import inspect
import contextlib
import hashlib
import json
import math
import os
import time
import logging
import queue
import re
import secrets
import socket
import threading
from urllib.parse import urlparse
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Callable, Optional
from zoneinfo import ZoneInfo
from config import (
    DEFAULT_TARIFFS,
    DEFAULT_CENTRIFUGO_SOCKET,
    SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY,
    SUPABASE_USERS_TABLE,
    SUPABASE_PENDING_ORDERS_TABLE,
)

try:
    from supabase import create_client
except Exception:
    create_client = None


@dataclass
class UserAccount:
    tg_username: Optional[str] = None
    port_user_id: Optional[str] = None
    port_user_name: Optional[str] = None
    centrifugo_socket: Optional[str] = None
    centrifugo_secret: Optional[str] = None
    zooma_top_session: Optional[str] = None
    zooma_top_session_expires_at: Optional[str] = None
    csrf_token: Optional[str] = None
    fingerprint_now: Optional[str] = None
    user_agent: Optional[str] = None
    subscription_tier: Optional[str] = None
    subscription_until_ts: Optional[int] = None
    subscription_paused: bool = False
    subscription_pause_started_ts: Optional[int] = None
    subscription_frozen_left_sec: Optional[int] = None
    subscription_warn_1d_for_ts: Optional[int] = None
    stale_notified_at_ts: Optional[int] = None
    last_invoice_id: Optional[str] = None
    connected: bool = False
    waiting_token: bool = False
    user_proxy_url: Optional[str] = None
    user_proxy_country: Optional[str] = None
    user_proxy_city: Optional[str] = None
    user_proxy_order_id: Optional[str] = None
    user_proxy_ip: Optional[str] = None
    user_proxy_port_http: Optional[int] = None
    user_proxy_port_socks5: Optional[int] = None
    user_proxy_login: Optional[str] = None
    user_proxy_password: Optional[str] = None
    user_proxy_scheme: Optional[str] = None
    last_profile_message_id: Optional[int] = None
    last_ui_message_id: Optional[int] = None
    proxy_ping_ms: Optional[float] = None
    proxy_ping_last_ts: Optional[int] = None
    proxy_ping_error: Optional[str] = None
    casino_accounts_json: list[dict] = field(default_factory=list)
    active_account_id: Optional[str] = None
    accounts_schema_version: int = 1
    promo_activated_count: int = 0
    promo_activated_total_amount: float = 0.0
    promo_month_key: Optional[str] = None
    promo_month_count: int = 0
    promo_month_total_amount: float = 0.0
    promo_activation_paused: bool = False
    promo_activation_mode: str = "server"
    extension_bound_chat_id: Optional[int] = None
    extension_bound_account_id: Optional[str] = None
    extension_bound_at_ts: Optional[int] = None
    timezone_name: Optional[str] = None
    timezone_offset_min: Optional[int] = None
    timezone_updated_at_ts: Optional[int] = None
    timezone_source: Optional[str] = None
    timezone_valid: bool = False
    locale: Optional[str] = None


USERS: dict[int, UserAccount] = {}
ACTIVE_DOMAIN: dict[str, Optional[str]] = {"base_url": None}
INVOICES: dict[str, dict] = {}
PENDING_ORDERS: dict[str, dict] = {}
BILLING_STATS: dict[str, float | int] = {
    "paid_total_usdt": 0.0,
    "paid_total_rub": 0.0,
    "paid_total_count": 0,
    "proxy_spent_total_rub": 0.0,
    "proxy_spent_total_count": 0,
}
BILLING_DAILY: dict[str, dict[str, float | int]] = {}
STATE_FILE = os.getenv("ZOOMA_BOT_STATE_FILE", "users_state.json").strip() or "users_state.json"
logger = logging.getLogger("store")
_SB_CLIENT = None
_SB_ENABLED = bool(SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY and create_client)
_SB_LAST_ROWS: dict[int, dict] = {}
_SB_LAST_ROWS_LOCK = threading.Lock()
_SB_WRITE_QUEUE: "queue.Queue[tuple[int, dict] | tuple[int, dict, int]]" = queue.Queue()
_SB_WRITER_THREAD: Optional[threading.Thread] = None
_SB_PROFILE_FLUSH_THREAD: Optional[threading.Thread] = None
_SB_WRITER_STOP = threading.Event()
_LEGACY_FILE_IO_ENABLED = False
_PROFILE_MSG_FLUSH_INTERVAL_SEC = 60
_SB_WRITE_RETRY_MAX = max(0, int(os.getenv("SUPABASE_ASYNC_WRITE_RETRY_MAX", "12").strip() or "12"))
_SB_WRITE_RETRY_BASE_SEC = max(0.2, float(os.getenv("SUPABASE_ASYNC_WRITE_RETRY_BASE_SEC", "2.0").strip() or "2.0"))
_SB_WRITE_RETRY_MAX_SEC = max(1.0, float(os.getenv("SUPABASE_ASYNC_WRITE_RETRY_MAX_SEC", "60.0").strip() or "60.0"))
_SB_LOAD_RETRY_MAX_SEC = max(0.0, float(os.getenv("SUPABASE_LOAD_RETRY_MAX_SEC", "120.0").strip() or "120.0"))
_SB_LOAD_RETRY_BASE_SEC = max(0.2, float(os.getenv("SUPABASE_LOAD_RETRY_BASE_SEC", "1.0").strip() or "1.0"))
_SB_LOAD_RETRY_MAX_SLEEP_SEC = max(1.0, float(os.getenv("SUPABASE_LOAD_RETRY_MAX_SLEEP_SEC", "10.0").strip() or "10.0"))
_SB_REQUIRE_INITIAL_LOAD = os.getenv("SUPABASE_REQUIRE_INITIAL_LOAD", "1" if os.getenv("RENDER") else "0").strip().lower() in {"1", "true", "yes", "on"}
_PROFILE_MSG_PENDING: dict[int, Optional[int]] = {}
_PROFILE_MSG_PENDING_LOCK = threading.Lock()
_PROMO_STATS_FLUSH_DELAY_SEC = max(1.0, float(os.getenv("ZOOMA_PROMO_STATS_FLUSH_DELAY_SEC", "30").strip() or "30"))
_PROMO_STATS_PENDING: dict[int, dict] = {}
_PROMO_STATS_PENDING_LOCK = threading.RLock()
_PROMO_STATS_FLUSH_THREAD: Optional[threading.Thread] = None
_PROMO_STATS_DIRTY = threading.Event()
_BILLING_STATS_TABLE = os.getenv("SUPABASE_BILLING_STATS_TABLE", "billing_stats").strip() or "billing_stats"
_BILLING_DAILY_TABLE = os.getenv("SUPABASE_BILLING_DAILY_TABLE", "billing_stats_daily").strip() or "billing_stats_daily"
_TARIFFS_TABLE = os.getenv("SUPABASE_TARIFFS_TABLE", "tariffs").strip() or "tariffs"
TARIFFS_RUNTIME: dict[str, dict] = {}
_APP_STATE_PUSHERS: list[Callable[[int], object]] = []
_PERSIST_USER_STATE_NOW_HANDLER: Optional[Callable[[int], bool]] = None
_PROMO_MONTH_FALLBACK_TZ = "Europe/Moscow"
_PROMO_MONTH_LABELS_RU = {
    "01": "январь",
    "02": "февраль",
    "03": "март",
    "04": "апрель",
    "05": "май",
    "06": "июнь",
    "07": "июль",
    "08": "август",
    "09": "сентябрь",
    "10": "октябрь",
    "11": "ноябрь",
    "12": "декабрь",
}


def register_app_state_pusher(fn: Callable[[int], object]) -> None:
    if fn not in _APP_STATE_PUSHERS:
        _APP_STATE_PUSHERS.append(fn)


async def notify_app_state_update(chat_id: int) -> None:
    for fn in list(_APP_STATE_PUSHERS):
        try:
            res = fn(int(chat_id))
            if inspect.isawaitable(res):
                await res
        except Exception as e:
            logger.warning("app state push callback failed chat_id=%s error=%s", chat_id, e)


def _promo_timezone_name(user: UserAccount) -> str:
    tz_name = str(getattr(user, "timezone_name", "") or "").strip()
    if not tz_name:
        return _PROMO_MONTH_FALLBACK_TZ
    try:
        ZoneInfo(tz_name)
        return tz_name
    except Exception:
        return _PROMO_MONTH_FALLBACK_TZ


def _promo_month_now(user: UserAccount, now_ts: int | None = None) -> datetime:
    stamp = int(now_ts or time.time())
    return datetime.fromtimestamp(stamp, tz=ZoneInfo(_promo_timezone_name(user)))


def _promo_month_snapshot(month_key: str, month_label: str, count: int, total_amount: float) -> dict:
    return {
        "promo_month_key": month_key,
        "promo_month_label": month_label,
        "promo_month_count": int(count or 0),
        "promo_month_total_amount": round(float(total_amount or 0.0), 2),
    }


def get_user_promo_month_snapshot(chat_id: int, now_ts: int | None = None, *, persist_reset: bool = True) -> dict:
    user = get_user(int(chat_id))
    now_local = _promo_month_now(user, now_ts=now_ts)
    month_key = now_local.strftime("%Y-%m")
    month_label = _PROMO_MONTH_LABELS_RU.get(now_local.strftime("%m"), now_local.strftime("%B").lower())
    stored_key = str(getattr(user, "promo_month_key", "") or "").strip()
    if stored_key != month_key:
        user.promo_month_key = month_key
        user.promo_month_count = 0
        user.promo_month_total_amount = 0.0
        snapshot = _promo_month_snapshot(month_key, month_label, 0, 0.0)
        if persist_reset:
            try:
                _queue_promo_stats_patch(int(chat_id), _promo_stats_patch_from_user(user))
                logger.info(
                    "promo month stats reset | chat_id=%s old_month=%s new_month=%s",
                    chat_id,
                    stored_key or "-",
                    month_key,
                )
            except Exception:
                logger.exception("promo month stats reset queue failed | chat_id=%s month=%s", chat_id, month_key)
        return snapshot
    return _promo_month_snapshot(
        month_key,
        month_label,
        int(getattr(user, "promo_month_count", 0) or 0),
        float(getattr(user, "promo_month_total_amount", 0.0) or 0.0),
    )


def get_user(chat_id: int) -> UserAccount:
    if chat_id not in USERS:
        USERS[chat_id] = UserAccount()
    return USERS[chat_id]


def _is_valid_fingerprint_now(value: Optional[str]) -> bool:
    v = str(value or "").strip().lower()
    if len(v) != 64:
        return False
    return all(c in "0123456789abcdef" for c in v)


def generate_fingerprint_now() -> str:
    # SHA-256-like value: 64 hex chars, stable after saving.
    return secrets.token_hex(32)


def _unique_fingerprint_now(used: set[str]) -> str:
    for _ in range(1000):
        fp = generate_fingerprint_now()
        if fp not in used:
            return fp
    raise RuntimeError("cannot_generate_unique_fingerprint_now")


def repair_fingerprint_now_duplicates() -> int:
    """
    Startup/data-integrity repair:
    - keep existing valid unique fingerprint_now values;
    - generate a new value only for null/empty/invalid values or duplicates;
    - persist only changed users.
    """
    used: set[str] = set()
    changed = 0
    for chat_id in sorted(USERS.keys()):
        user = USERS[chat_id]
        fp = str(user.fingerprint_now or "").strip().lower()
        if _is_valid_fingerprint_now(fp) and fp not in used:
            user.fingerprint_now = fp
            used.add(fp)
            continue

        new_fp = _unique_fingerprint_now(used)
        used.add(new_fp)
        user.fingerprint_now = new_fp
        changed += 1
        _sb_upsert_patch(chat_id, {"fingerprint_now": new_fp})

    if changed:
        logger.info("fingerprint_now repair: changed=%s", changed)
        save_state()
    return changed


def ensure_user_fingerprint_now(chat_id: int) -> str:
    """
    Get-or-create fingerprint for one user.
    Does not recalculate from user_agent/platform/screen.
    Keeps existing unique value. Regenerates only if missing/invalid/duplicate.
    """
    user = get_user(chat_id)
    fp = str(user.fingerprint_now or "").strip().lower()

    owners = [
        cid for cid, u in USERS.items()
        if str(u.fingerprint_now or "").strip().lower() == fp and _is_valid_fingerprint_now(fp)
    ]
    is_duplicate_for_this_user = bool(fp and len(owners) > 1 and int(chat_id) != min(owners))

    if _is_valid_fingerprint_now(fp) and not is_duplicate_for_this_user:
        user.fingerprint_now = fp
        return fp

    used = {
        str(u.fingerprint_now or "").strip().lower()
        for cid, u in USERS.items()
        if cid != chat_id and _is_valid_fingerprint_now(str(u.fingerprint_now or "").strip().lower())
    }
    new_fp = _unique_fingerprint_now(used)
    user.fingerprint_now = new_fp
    _sb_upsert_patch(chat_id, {"fingerprint_now": new_fp})
    save_state()
    return new_fp


ACCOUNT_LIMIT = 10


_ACCOUNT_LEGACY_TO_JSON = {
    "port_user_id": "port_user_id",
    "port_user_name": "port_user_name",
    "centrifugo_socket": "centrifugo_socket",
    "centrifugo_secret": "centrifugo_secret",
    "zooma_top_session": "zooma_top_session",
    "zooma_top_session_expires_at": "zooma_top_session_expires_at",
    "csrf_token": "csrf_token",
    "fingerprint_now": "fingerprint_now",
    "user_agent": "user_agent",
    "subscription_tier": "subscription_tier",
    "subscription_until_ts": "subscription_until_ts",
    "subscription_warn_1d_for_ts": "subscription_warn_1d_for_ts",
    "user_proxy_url": "proxy_url",
    "user_proxy_country": "proxy_country",
    "user_proxy_city": "proxy_city",
    "user_proxy_order_id": "proxy_order_id",
    "user_proxy_ip": "proxy_ip",
    "user_proxy_port_http": "proxy_port_http",
    "user_proxy_port_socks5": "proxy_port_socks5",
    "user_proxy_login": "proxy_login",
    "user_proxy_password": "proxy_password",
    "user_proxy_scheme": "proxy_scheme",
    "proxy_ping_ms": "proxy_ping_ms",
    "proxy_ping_last_ts": "proxy_ping_last_ts",
    "proxy_ping_error": "proxy_ping_error",
}


def _boolish(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


CHAT_AI_RAIN_MISS_DEFAULT = ["мимо"]
CHAT_AI_RAIN_MISS_MAX_ITEMS = 100
CHAT_AI_RAIN_MISS_MAX_ITEM_LEN = 160


def normalize_chat_ai_rain_miss_messages(value) -> list[str]:
    """Normalize semicolon-delimited rain miss messages for one account."""
    if isinstance(value, str):
        raw_items = value.replace("\r", "\n").split(";")
    elif isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    else:
        raw_items = []

    out: list[str] = []
    seen: set[str] = set()

    for raw in raw_items:
        text = " ".join(
            str(raw or "").replace("\u00a0", " ").split()
        ).strip(" ;")

        if not text:
            continue

        text = text[:CHAT_AI_RAIN_MISS_MAX_ITEM_LEN].strip()
        key = text.casefold()

        if not text or key in seen:
            continue

        seen.add(key)
        out.append(text)

        if len(out) >= CHAT_AI_RAIN_MISS_MAX_ITEMS:
            break

    # Явно пустой список означает: не писать после проигранного дождя.

    if value is None:
        return list(CHAT_AI_RAIN_MISS_DEFAULT)
    return out


CHAT_AI_API_KEYS_MAX = 8
CHAT_AI_API_KEY_MAX_LEN = 256


def normalize_chat_ai_api_keys(value) -> list[str]:
    if isinstance(value, (list, tuple, set)):
        raw = [str(x or "") for x in value]
    else:
        raw = re.split(r"\s+", str(value or "").strip())
    out: list[str] = []
    seen: set[str] = set()
    for item in raw:
        key = str(item or "").strip()
        if not key or len(key) > CHAT_AI_API_KEY_MAX_LEN or key in seen:
            continue
        seen.add(key)
        out.append(key)
        if len(out) >= CHAT_AI_API_KEYS_MAX:
            break
    return out


def serialize_chat_ai_api_keys(value) -> str:
    return " ".join(normalize_chat_ai_api_keys(value))


def mask_chat_ai_api_key(value: str) -> str:
    key = str(value or "").strip()
    if not key:
        return ""
    if len(key) <= 10:
        return "••••••••"
    return f"{key[:4]}••••••••{key[-4:]}"


def normalize_server_session_state(value) -> dict:
    raw = dict(value or {}) if isinstance(value, dict) else {}
    return {
        "stale": bool(_boolish(raw.get("stale"))),
        "reason": str(raw.get("reason") or "")[:120],
        "detected_at_ts": max(0, int(raw.get("detected_at_ts") or 0)),
        "notified_at_ts": max(0, int(raw.get("notified_at_ts") or 0)),
        "http_status": max(0, int(raw.get("http_status") or 0)),
        "response": " ".join(str(raw.get("response") or "").split())[:600],
    }


CHAT_AI_TPD_WINDOW_SEC = 24 * 60 * 60
CHAT_AI_TPD_EVENTS_MAX = 4096


def normalize_chat_ai_rate_limits(value, now_ts: Optional[int] = None) -> dict:
    raw = dict(value or {}) if isinstance(value, dict) else {}
    out: dict[str, dict] = {}
    now = max(0, int(now_ts or time.time()))
    cutoff = now - CHAT_AI_TPD_WINDOW_SEC
    for key_id, item in list(raw.items())[:CHAT_AI_API_KEYS_MAX]:
        if not isinstance(item, dict):
            continue
        kid = str(key_id or "").strip()[:32]
        if not kid:
            continue
        limit_tokens = max(0, int(item.get("limit_tokens") or 0))
        remaining_tokens = max(0, int(item.get("remaining_tokens") or 0))
        events: list[dict] = []
        for event in list(item.get("tpd_events") or [])[-CHAT_AI_TPD_EVENTS_MAX:]:
            if not isinstance(event, dict):
                continue
            ts = max(0, int(event.get("ts") or 0))
            tokens = max(0, int(event.get("tokens") or 0))
            if tokens <= 0 or ts <= cutoff or ts > now + 300:
                continue
            events.append({"ts": ts, "tokens": tokens})
        events.sort(key=lambda row: int(row.get("ts") or 0))
        events = events[-CHAT_AI_TPD_EVENTS_MAX:]
        event_used = sum(int(row.get("tokens") or 0) for row in events)
        tpd_limit = max(0, int(item.get("tpd_limit_tokens") or 0))
        observed_used = max(0, int(item.get("tpd_observed_used_tokens") or 0))
        observed_at = max(0, int(item.get("tpd_observed_at_ts") or 0))
        if observed_used and tpd_limit and observed_at:
            # Groq TPD behaves as a continuously refilling token bucket.
            # A fresh 429 snapshot is the exact anchor; successful requests
            # after it are added at their timestamps and refill continuously.
            refill_per_sec = float(tpd_limit) / float(CHAT_AI_TPD_WINDOW_SEC)
            cursor_ts = observed_at
            bucket_used = float(observed_used)
            for event in events:
                event_ts = int(event.get("ts") or 0)
                if event_ts <= observed_at or event_ts > now:
                    continue
                bucket_used = max(
                    0.0,
                    bucket_used - refill_per_sec * max(0, event_ts - cursor_ts),
                )
                bucket_used += max(0, int(event.get("tokens") or 0))
                cursor_ts = max(cursor_ts, event_ts)
            bucket_used = max(
                0.0,
                bucket_used - refill_per_sec * max(0, now - cursor_ts),
            )
            tpd_used = max(0, int(bucket_used))
        elif observed_used:
            tpd_used = max(event_used, observed_used)
        else:
            tpd_used = event_used
        out[kid] = {
            "key_mask": str(item.get("key_mask") or "")[:32],
            "model": str(item.get("model") or "")[:120],
            # TPM is kept internally for key selection and 429 handling.
            "limit_tokens": limit_tokens,
            "remaining_tokens": min(limit_tokens, remaining_tokens) if limit_tokens else remaining_tokens,
            "used_tokens": max(0, int(item.get("used_tokens") or max(0, limit_tokens - remaining_tokens))),
            # TPD is a persisted rolling 24-hour ledger based on usage.total_tokens.
            "tpd_limit_tokens": tpd_limit,
            "tpd_used_tokens": tpd_used,
            "tpd_remaining_tokens": max(0, tpd_limit - tpd_used) if tpd_limit else 0,
            "tpd_events": events,
            "tpd_window_started_ts": int(events[0]["ts"]) if events else 0,
            "tpd_observed_used_tokens": observed_used,
            "tpd_observed_at_ts": observed_at,
            "tpd_requested_tokens": max(0, int(item.get("tpd_requested_tokens") or 0)),
            "tpd_retry_after_sec": max(0, int(item.get("tpd_retry_after_sec") or 0)),
            "rate_limit_kind": str(item.get("rate_limit_kind") or "")[:32],
            "updated_at_ts": max(0, int(item.get("updated_at_ts") or 0)),
            "blocked_until_ts": max(0, int(item.get("blocked_until_ts") or 0)),
            "invalid": bool(_boolish(item.get("invalid"))),
            "last_http_status": max(0, int(item.get("last_http_status") or 0)),
        }
    return out


def _account_status_from_until(until_ts: int | None) -> str:
    until = int(until_ts or 0)
    if until <= 0:
        return "empty"
    return "active" if until > int(time.time()) else "expired"


def _parse_accounts_json(value) -> list[dict]:
    if isinstance(value, list):
        return [dict(x) for x in value if isinstance(x, dict)]
    if isinstance(value, str) and value.strip():
        try:
            obj = json.loads(value)
            if isinstance(obj, list):
                return [dict(x) for x in obj if isinstance(x, dict)]
        except Exception:
            return []
    return []


def _legacy_account_from_user(chat_id: int, user: UserAccount) -> dict:
    now_ts = int(time.time())
    until_ts = int(user.subscription_until_ts or 0)
    return {
        "account_id": "acc_1",
        "slot": 1,
        "billing_type": "main",
        "status": _account_status_from_until(until_ts),
        "owner_chat_id": int(chat_id),
        "port_user_id": user.port_user_id or "",
        "port_user_name": user.port_user_name or "",
        "subscription_tier": user.subscription_tier or "",
        "subscription_until_ts": until_ts,
        "subscription_paused": bool(user.subscription_paused),
        "subscription_pause_started_ts": int(user.subscription_pause_started_ts or 0) or None,
        "subscription_frozen_left_sec": int(user.subscription_frozen_left_sec or 0) or None,
        "subscription_warn_1d_for_ts": int(user.subscription_warn_1d_for_ts or 0),
        "zooma_top_session": user.zooma_top_session or "",
        "zooma_top_session_expires_at": user.zooma_top_session_expires_at,
        "csrf_token": user.csrf_token or "",
        "fingerprint_now": user.fingerprint_now or "",
        "user_agent": user.user_agent or "",
        "proxy_url": user.user_proxy_url or "",
        "proxy_country": user.user_proxy_country or "",
        "proxy_city": user.user_proxy_city or "",
        "proxy_order_id": user.user_proxy_order_id or "",
        "proxy_ip": user.user_proxy_ip or "",
        "proxy_port_http": user.user_proxy_port_http,
        "proxy_port_socks5": user.user_proxy_port_socks5,
        "proxy_login": user.user_proxy_login or "",
        "proxy_password": user.user_proxy_password or "",
        "proxy_scheme": user.user_proxy_scheme or "socks5",
        "centrifugo_socket": user.centrifugo_socket or DEFAULT_CENTRIFUGO_SOCKET,
        "centrifugo_secret": user.centrifugo_secret or "",
        "connected": bool(user.connected),
        "promo_activation_mode": str(getattr(user, "promo_activation_mode", "server") or "server"),
        "extension_bound_chat_id": int(getattr(user, "extension_bound_chat_id", 0) or 0),
        "extension_bound_account_id": str(getattr(user, "extension_bound_account_id", "") or ""),
        "extension_bound_at_ts": int(getattr(user, "extension_bound_at_ts", 0) or 0),
        "extension_bound_status": "bound" if int(getattr(user, "extension_bound_chat_id", 0) or 0) else "unbound",
        "extension_bound_device_id": "",
        "extension_public_key_jwk": {},
        "extension_key_id": "",
        "extension_binding_version": 0,
        "extension_key_created_ts": 0,
        "chat_ai_enabled": False,
        "chat_ai_api_key": "",
        "chat_ai_key_mode": "user",
        "chat_ai_interval_min_sec": 10 * 60,
        "chat_ai_interval_max_sec": 25 * 60,
        "chat_ai_next_run_ts": 0,
        "chat_ai_last_error": "",
        "chat_ai_last_sent_ts": 0,
        "chat_ai_recent_messages": [],
        "chat_ai_pending_task": {},
        "chat_ai_rain_miss_messages": list(CHAT_AI_RAIN_MISS_DEFAULT),
        "chat_ai_cycle_started_ts": 0,
        "chat_ai_rest_until_ts": 0,
        "chat_ai_rate_limits": {},
        "server_session_state": {},
        "proxy_ping_ms": user.proxy_ping_ms,
        "proxy_ping_last_ts": int(user.proxy_ping_last_ts or 0),
        "proxy_ping_error": user.proxy_ping_error or "",
        "created_at_ts": now_ts,
        "updated_at_ts": now_ts,
    }


def _normalize_account(chat_id: int, acc: dict, slot: int) -> dict:
    a = dict(acc or {})
    a["slot"] = int(a.get("slot") or slot or 1)
    a["account_id"] = str(a.get("account_id") or f"acc_{a['slot']}").strip()
    a["billing_type"] = str(a.get("billing_type") or ("main" if a["slot"] == 1 else "addon")).strip()
    if a["billing_type"] not in {"main", "addon"}:
        a["billing_type"] = "main" if a["slot"] == 1 else "addon"
    a["owner_chat_id"] = int(a.get("owner_chat_id") or chat_id)
    until_ts = int(a.get("subscription_until_ts") or 0)
    paused = _boolish(a.get("subscription_paused"))
    pause_started = int(a.get("subscription_pause_started_ts") or 0)
    frozen_left = int(a.get("subscription_frozen_left_sec") or 0)

    a["subscription_until_ts"] = until_ts
    a["subscription_paused"] = bool(paused)
    a["subscription_pause_started_ts"] = pause_started or None
    a["subscription_frozen_left_sec"] = frozen_left or None

    if paused:
        a["status"] = "frozen"
    else:
        a["status"] = str(a.get("status") or _account_status_from_until(until_ts))
        if a["status"] in {"active", "expired", "empty", "frozen"}:
            a["status"] = _account_status_from_until(until_ts)

    # `connected` means factual live WS state, not just "token exists".
    has_live_sub = until_ts > int(time.time()) and not paused
    a["connected"] = bool(has_live_sub and a.get("connected"))

    proxy_runtime_status = str(a.get("proxy_runtime_status") or "healthy").strip().lower()
    if proxy_runtime_status not in {"healthy", "unavailable", "site_unreachable", "recovering"}:
        proxy_runtime_status = "healthy"
    a["proxy_runtime_status"] = proxy_runtime_status
    a["proxy_runtime_reason"] = str(a.get("proxy_runtime_reason") or "")[:500]
    a["proxy_runtime_source"] = str(a.get("proxy_runtime_source") or "")[:120]
    a["proxy_runtime_domain"] = str(a.get("proxy_runtime_domain") or "")[:500]
    a["proxy_unavailable_since_ts"] = int(a.get("proxy_unavailable_since_ts") or 0)
    a["proxy_recovery_successes"] = max(0, int(a.get("proxy_recovery_successes") or 0))
    a["proxy_runtime_alerted_at_ts"] = int(a.get("proxy_runtime_alerted_at_ts") or 0)

    a["server_session_state"] = normalize_server_session_state(a.get("server_session_state"))

    a["promo_activation_paused"] = _boolish(a.get("promo_activation_paused"))
    mode = str(a.get("promo_activation_mode") or "server").strip().lower()
    a["promo_activation_mode"] = mode if mode in {"server", "extension"} else "server"
    a["runtime_mode_epoch"] = max(0, int(a.get("runtime_mode_epoch") or 0))

    extension_bound_chat_id = int(a.get("extension_bound_chat_id") or 0)
    extension_bound_account_id = str(a.get("extension_bound_account_id") or "").strip()
    extension_bound_at_ts = int(a.get("extension_bound_at_ts") or 0)
    extension_bound_status = str(a.get("extension_bound_status") or "").strip().lower()
    extension_bound_device_id = str(a.get("extension_bound_device_id") or "").strip().lower()
    extension_public_key_jwk = dict(a.get("extension_public_key_jwk") or {}) if isinstance(a.get("extension_public_key_jwk"), dict) else {}
    extension_key_id = str(a.get("extension_key_id") or "").strip().lower()
    extension_binding_version = max(0, int(a.get("extension_binding_version") or 0))
    extension_key_created_ts = max(0, int(a.get("extension_key_created_ts") or 0))
    if extension_bound_chat_id > 0:
        extension_bound_account_id = extension_bound_account_id or a["account_id"]
        extension_bound_status = "bound"
        extension_binding_version = max(1, extension_binding_version)
    else:
        extension_bound_chat_id = 0
        extension_bound_account_id = ""
        extension_bound_at_ts = 0
        extension_bound_status = "unbound"
        extension_bound_device_id = ""
        extension_public_key_jwk = {}
        extension_key_id = ""
        extension_key_created_ts = 0
    a["extension_bound_chat_id"] = extension_bound_chat_id
    a["extension_bound_account_id"] = extension_bound_account_id
    a["extension_bound_at_ts"] = extension_bound_at_ts
    a["extension_bound_status"] = extension_bound_status
    a["extension_bound_device_id"] = extension_bound_device_id
    a["extension_public_key_jwk"] = extension_public_key_jwk
    a["extension_key_id"] = extension_key_id
    a["extension_binding_version"] = extension_binding_version
    a["extension_key_created_ts"] = extension_key_created_ts

    a["chat_ai_enabled"] = _boolish(a.get("chat_ai_enabled"))
    a["chat_ai_api_key"] = serialize_chat_ai_api_keys(a.get("chat_ai_api_key"))
    a["chat_ai_rate_limits"] = normalize_chat_ai_rate_limits(a.get("chat_ai_rate_limits"))
    key_mode = str(a.get("chat_ai_key_mode") or "user").strip().lower()
    a["chat_ai_key_mode"] = key_mode if key_mode in {"user", "default"} else "user"
    interval_min = max(60, min(24 * 60 * 60, int(a.get("chat_ai_interval_min_sec") or 10 * 60)))
    interval_max = max(interval_min, min(24 * 60 * 60, int(a.get("chat_ai_interval_max_sec") or 25 * 60)))
    a["chat_ai_interval_min_sec"] = interval_min
    a["chat_ai_interval_max_sec"] = interval_max
    a["chat_ai_next_run_ts"] = max(0, int(a.get("chat_ai_next_run_ts") or 0))
    a["chat_ai_last_error"] = str(a.get("chat_ai_last_error") or "")[:500]
    a["chat_ai_last_sent_ts"] = max(0, int(a.get("chat_ai_last_sent_ts") or 0))
    recent_raw = a.get("chat_ai_recent_messages")
    recent: list[dict] = []
    if isinstance(recent_raw, list):
        for item in recent_raw[-3:]:
            if not isinstance(item, dict):
                continue
            recent.append({
                "sent_at_ts": max(0, int(item.get("sent_at_ts") or 0)),
                "text": str(item.get("text") or "")[:500],
                "target": str(item.get("target") or "")[:255],
                "source": str(item.get("source") or "regular")[:32],
                "mode": str(item.get("mode") or "server")[:16],
            })
    a["chat_ai_recent_messages"] = recent[-3:]
    pending = a.get("chat_ai_pending_task")
    a["chat_ai_pending_task"] = dict(pending) if isinstance(pending, dict) else {}
    a["chat_ai_rain_miss_messages"] = normalize_chat_ai_rain_miss_messages(
        a.get("chat_ai_rain_miss_messages")
    )
    a["chat_ai_cycle_started_ts"] = max(0, int(a.get("chat_ai_cycle_started_ts") or 0))
    a["chat_ai_rest_until_ts"] = max(0, int(a.get("chat_ai_rest_until_ts") or 0))
    a.setdefault("created_at_ts", int(time.time()))
    a["updated_at_ts"] = int(a.get("updated_at_ts") or int(time.time()))
    return a


def _normalize_accounts_for_user(chat_id: int, user: UserAccount, value=None) -> list[dict]:
    accounts = _parse_accounts_json(value if value is not None else getattr(user, "casino_accounts_json", None))
    if not accounts:
        accounts = [_legacy_account_from_user(chat_id, user)]
    out: list[dict] = []
    seen: set[str] = set()
    for idx, acc in enumerate(accounts[:ACCOUNT_LIMIT], start=1):
        a = _normalize_account(chat_id, acc, idx)
        if a["account_id"] in seen:
            a["account_id"] = f"acc_{idx}"
        seen.add(a["account_id"])
        out.append(a)
    out.sort(key=lambda a: (int(a.get("slot") or 999), str(a.get("account_id") or "")))
    return out or [_legacy_account_from_user(chat_id, user)]


def _compact_accounts(chat_id: int, accounts: list[dict], active_account_id: Optional[str]) -> tuple[list[dict], str]:
    src = [dict(a) for a in (accounts or []) if isinstance(a, dict)]
    if not src:
        return [], "acc_1"
    src.sort(key=lambda a: (int(a.get("slot") or 999), str(a.get("account_id") or "")))
    id_map: dict[str, str] = {}
    out: list[dict] = []
    for idx, acc in enumerate(src, start=1):
        old_id = str(acc.get("account_id") or "").strip()
        new_id = f"acc_{idx}"
        a = dict(acc)
        a["slot"] = idx
        a["account_id"] = new_id
        a["owner_chat_id"] = int(chat_id)
        # After compaction first slot is primary by definition.
        a["billing_type"] = "main" if idx == 1 else "addon"
        a = _normalize_account(chat_id, a, idx)
        out.append(a)
        if old_id:
            id_map[old_id] = new_id
    active_old = str(active_account_id or "").strip()
    if active_old and active_old in id_map:
        return out, id_map[active_old]
    return out, str(out[0].get("account_id") or "acc_1")


def _accounts_need_compaction(accounts: list[dict]) -> bool:
    src = [dict(a) for a in (accounts or []) if isinstance(a, dict)]
    if len(src) <= 1:
        return False
    src.sort(key=lambda a: (int(a.get("slot") or 999), str(a.get("account_id") or "")))
    for idx, acc in enumerate(src, start=1):
        slot = int(acc.get("slot") or 0)
        aid = str(acc.get("account_id") or "").strip()
        expected_id = f"acc_{idx}"
        if slot != idx or aid != expected_id:
            return True
    return False


def _account_has_meaningful_state(acc: dict) -> bool:
    """
    True if account contains any meaningful state and must not be treated as
    an empty shell during startup-repair compaction.
    """
    a = dict(acc or {})
    if int(a.get("subscription_until_ts") or 0) > 0:
        return True
    if bool(a.get("connected")):
        return True
    if int(a.get("extension_bound_chat_id") or 0) > 0:
        return True
    text_fields = (
        "port_user_id",
        "port_user_name",
        "zooma_top_session",
        "zooma_top_session_expires_at",
        "csrf_token",
        "fingerprint_now",
        "user_agent",
        "proxy_url",
        "proxy_country",
        "proxy_city",
        "proxy_order_id",
        "proxy_ip",
        "proxy_login",
        "proxy_password",
        "centrifugo_secret",
        "chat_ai_api_key",
    )
    for key in text_fields:
        if str(a.get(key) or "").strip():
            return True
    if int(a.get("proxy_port_http") or 0) > 0 or int(a.get("proxy_port_socks5") or 0) > 0:
        return True
    if _boolish(a.get("chat_ai_enabled")):
        return True
    if int(a.get("chat_ai_next_run_ts") or 0) > 0:
        return True
    if isinstance(a.get("chat_ai_recent_messages"), list) and a.get("chat_ai_recent_messages"):
        return True
    if isinstance(a.get("chat_ai_pending_task"), dict) and a.get("chat_ai_pending_task"):
        return True
    if normalize_chat_ai_rain_miss_messages(
        a.get("chat_ai_rain_miss_messages")
    ) != CHAT_AI_RAIN_MISS_DEFAULT:
        return True
    if int(a.get("chat_ai_cycle_started_ts") or 0) > 0:
        return True
    if int(a.get("chat_ai_rest_until_ts") or 0) > 0:
        return True
    return False


def _pending_locked_account_ids(chat_id: int) -> set[str]:
    """
    Pending orders lock account_id remapping to avoid breaking in-flight payments.
    """
    now_ts = int(time.time())
    locked: set[str] = set()
    for row in PENDING_ORDERS.values():
        if not isinstance(row, dict):
            continue
        try:
            if int(row.get("chat_id") or 0) != int(chat_id):
                continue
        except Exception:
            continue
        status = str(row.get("status") or "").strip().lower()
        if status != "pending":
            continue
        exp_ts = int(row.get("expires_at_ts") or row.get("expires_at") or 0)
        if exp_ts > 0 and exp_ts <= now_ts:
            continue
        aid = str(row.get("account_id") or "").strip()
        if aid:
            locked.add(aid)
    return locked


def _compact_accounts_drop_empty_shells(
    chat_id: int, accounts: list[dict], active_account_id: Optional[str]
) -> tuple[list[dict], str, int]:
    """
    Drop empty/stale account shells and compact kept accounts to acc_1..acc_N.
    Returns (accounts, new_active_account_id, removed_count).
    """
    src = [dict(a) for a in (accounts or []) if isinstance(a, dict)]
    if len(src) <= 1:
        return src, str(active_account_id or "acc_1"), 0
    # Never remap account ids while there are in-flight pending orders.
    if _pending_locked_account_ids(chat_id):
        return src, str(active_account_id or "acc_1"), 0
    src.sort(key=lambda a: (int(a.get("slot") or 999), str(a.get("account_id") or "")))
    keep: list[dict] = []
    removed = 0
    for acc in src:
        if _account_has_meaningful_state(acc):
            keep.append(dict(acc))
        else:
            removed += 1
    if removed <= 0:
        return src, str(active_account_id or "acc_1"), 0
    # Keep at least one shell for a user with no active data.
    if not keep:
        keep = [dict(src[0])]
        removed = max(0, len(src) - 1)
    compacted, new_active = _compact_accounts(chat_id, keep, active_account_id)
    return compacted, str(new_active or "acc_1"), removed


def _select_account(user: UserAccount, account_id: Optional[str] = None) -> Optional[dict]:
    accounts = getattr(user, "casino_accounts_json", None) or []
    if not accounts:
        return None
    aid = str(account_id or user.active_account_id or "").strip()
    if aid:
        for acc in accounts:
            if str(acc.get("account_id") or "") == aid:
                return acc
    return accounts[0]


def _mirror_account_to_user(user: UserAccount, account: Optional[dict]) -> None:
    if not account:
        return
    user.port_user_id = str(account.get("port_user_id") or "") or None
    user.port_user_name = str(account.get("port_user_name") or "") or None
    user.centrifugo_socket = str(account.get("centrifugo_socket") or DEFAULT_CENTRIFUGO_SOCKET) or None
    user.centrifugo_secret = str(account.get("centrifugo_secret") or "") or None
    user.zooma_top_session = str(account.get("zooma_top_session") or "") or None
    user.zooma_top_session_expires_at = account.get("zooma_top_session_expires_at") or None
    user.csrf_token = str(account.get("csrf_token") or "") or None
    user.fingerprint_now = str(account.get("fingerprint_now") or "") or None
    user.user_agent = str(account.get("user_agent") or "") or None
    user.subscription_tier = str(account.get("subscription_tier") or "") or None
    user.subscription_until_ts = int(account.get("subscription_until_ts") or 0) or None
    user.subscription_paused = bool(_boolish(account.get("subscription_paused")))
    user.subscription_pause_started_ts = int(account.get("subscription_pause_started_ts") or 0) or None
    user.subscription_frozen_left_sec = int(account.get("subscription_frozen_left_sec") or 0) or None
    user.subscription_warn_1d_for_ts = int(account.get("subscription_warn_1d_for_ts") or 0) or None
    user.user_proxy_url = str(account.get("proxy_url") or "") or None
    user.user_proxy_country = str(account.get("proxy_country") or "") or None
    user.user_proxy_city = str(account.get("proxy_city") or "") or None
    user.user_proxy_order_id = str(account.get("proxy_order_id") or "") or None
    user.user_proxy_ip = str(account.get("proxy_ip") or "") or None
    user.user_proxy_port_http = int(account.get("proxy_port_http") or 0) or None
    user.user_proxy_port_socks5 = int(account.get("proxy_port_socks5") or 0) or None
    user.user_proxy_login = str(account.get("proxy_login") or "") or None
    user.user_proxy_password = str(account.get("proxy_password") or "") or None
    user.user_proxy_scheme = str(account.get("proxy_scheme") or "") or None
    user.proxy_ping_ms = account.get("proxy_ping_ms")
    user.proxy_ping_last_ts = int(account.get("proxy_ping_last_ts") or 0) or None
    user.proxy_ping_error = str(account.get("proxy_ping_error") or "") or None
    user.extension_bound_chat_id = int(account.get("extension_bound_chat_id") or 0) or None
    user.extension_bound_account_id = str(account.get("extension_bound_account_id") or "") or None
    user.extension_bound_at_ts = int(account.get("extension_bound_at_ts") or 0) or None
    user.connected = bool(account.get("connected"))


def ensure_user_accounts(chat_id: int) -> list[dict]:
    user = get_user(chat_id)
    user.casino_accounts_json = _normalize_accounts_for_user(chat_id, user)
    if not user.active_account_id:
        user.active_account_id = str(user.casino_accounts_json[0].get("account_id") or "acc_1")
    user.accounts_schema_version = int(getattr(user, "accounts_schema_version", 1) or 1)
    _mirror_account_to_user(user, _select_account(user))
    return user.casino_accounts_json


def _sync_active_account_from_user(chat_id: int) -> dict:
    user = get_user(chat_id)
    accounts = _normalize_accounts_for_user(chat_id, user)
    user.casino_accounts_json = accounts
    if not user.active_account_id:
        user.active_account_id = str(accounts[0].get("account_id") or "acc_1")
    active_id = str(user.active_account_id or accounts[0].get("account_id") or "acc_1")
    protected_prefixes = ("chat_ai_", "proxy_", "extension_")
    protected_names = {
        "promo_activation_mode",
        "runtime_mode_epoch",
        "promo_activation_paused",
        "server_session_state",
        "train_jobs",
    }
    for idx, acc in enumerate(accounts):
        if str(acc.get("account_id") or "") == active_id:
            fresh = _legacy_account_from_user(chat_id, user)
            fresh["account_id"] = active_id
            fresh["slot"] = int(acc.get("slot") or idx + 1)
            fresh["billing_type"] = str(acc.get("billing_type") or ("main" if fresh["slot"] == 1 else "addon"))
            fresh["created_at_ts"] = int(acc.get("created_at_ts") or fresh["created_at_ts"])
            fresh["status"] = _account_status_from_until(fresh.get("subscription_until_ts"))
            preserved = {
                key: value
                for key, value in acc.items()
                if key.startswith(protected_prefixes) or key in protected_names
            }
            accounts[idx] = _normalize_account(chat_id, {**acc, **fresh, **preserved}, fresh["slot"])
            break
    else:
        accounts.insert(0, _legacy_account_from_user(chat_id, user))
        accounts = accounts[:ACCOUNT_LIMIT]
        user.active_account_id = str(accounts[0].get("account_id") or "acc_1")
    user.casino_accounts_json = accounts
    user.accounts_schema_version = 1
    return {
        "casino_accounts_json": accounts,
        "active_account_id": user.active_account_id,
        "accounts_schema_version": 1,
    }


def get_user_accounts(chat_id: int, include_empty: bool = True) -> list[dict]:
    accounts = ensure_user_accounts(chat_id)
    if include_empty:
        return [dict(a) for a in accounts]
    return [dict(a) for a in accounts if str(a.get("status") or "") != "empty"]


def get_user_account(chat_id: int, account_id: Optional[str] = None) -> Optional[dict]:
    ensure_user_accounts(chat_id)
    acc = _select_account(get_user(chat_id), account_id)
    return dict(acc) if acc else None


def patch_user_account(chat_id: int, account_id: Optional[str] = None, **fields) -> dict:
    user = get_user(chat_id)
    accounts = ensure_user_accounts(chat_id)
    aid = str(account_id or user.active_account_id or accounts[0].get("account_id") or "acc_1")
    patched = None
    changed = False
    for idx, acc in enumerate(accounts):
        if str(acc.get("account_id") or "") == aid:
            old_acc = _normalize_account(chat_id, dict(acc), int(acc.get("slot") or idx + 1))
            next_acc = dict(old_acc)
            next_acc.update(fields)
            next_acc = _normalize_account(chat_id, next_acc, int(next_acc.get("slot") or idx + 1))
            changed = _json_stable(next_acc) != _json_stable(old_acc)
            if changed:
                next_acc["updated_at_ts"] = int(time.time())
                next_acc = _normalize_account(chat_id, next_acc, int(next_acc.get("slot") or idx + 1))
                accounts[idx] = next_acc
            else:
                accounts[idx] = old_acc
            patched = accounts[idx]
            break
    if patched is None:
        raise KeyError(f"account_not_found:{aid}")
    user.casino_accounts_json = accounts
    if str(user.active_account_id or "") == aid:
        _mirror_account_to_user(user, patched)
    if changed:
        _sb_upsert_patch(chat_id, {
            "casino_accounts_json": accounts,
            "active_account_id": user.active_account_id or aid,
            "accounts_schema_version": 1,
        })
        save_state()
    return dict(patched)



def account_server_session_is_stale(account: dict | None) -> bool:
    state = normalize_server_session_state((account or {}).get("server_session_state"))
    return bool(state.get("stale"))


def mark_account_server_session_stale(
    chat_id: int,
    account_id: str,
    *,
    reason: str,
    http_status: int = 0,
    response: str = "",
) -> dict:
    current = get_user_account(int(chat_id), str(account_id)) or {}
    previous = normalize_server_session_state(current.get("server_session_state"))
    state = {
        "stale": True,
        "reason": str(reason or "server_session_stale")[:120],
        "detected_at_ts": int(previous.get("detected_at_ts") or time.time()),
        "notified_at_ts": int(previous.get("notified_at_ts") or 0),
        "http_status": max(0, int(http_status or 0)),
        "response": " ".join(str(response or "").split())[:600],
    }
    return patch_user_account(
        int(chat_id),
        str(account_id),
        connected=False,
        server_session_state=state,
        chat_ai_pending_task={},
        chat_ai_next_run_ts=0,
        chat_ai_last_error="server_session_stale",
    )


def mark_account_server_session_notified(chat_id: int, account_id: str, notified_at_ts: Optional[int] = None) -> dict:
    current = get_user_account(int(chat_id), str(account_id)) or {}
    state = normalize_server_session_state(current.get("server_session_state"))
    state["notified_at_ts"] = int(notified_at_ts or time.time())
    return patch_user_account(int(chat_id), str(account_id), server_session_state=state)


def clear_account_server_session_state(chat_id: int, account_id: str) -> dict:
    current = get_user_account(int(chat_id), str(account_id)) or {}
    patch: dict = {"server_session_state": {}}
    if str(current.get("chat_ai_last_error") or "") == "server_session_stale":
        patch["chat_ai_last_error"] = ""
    return patch_user_account(int(chat_id), str(account_id), **patch)


def reset_account_casino_identity(chat_id: int, account_id: str) -> dict:
    """Clear casino identity/runtime while preserving the slot, subscription and slot settings."""
    if not get_user_account(int(chat_id), str(account_id)):
        raise KeyError(f"account_not_found:{account_id}")
    return patch_user_account(
        int(chat_id),
        str(account_id),
        port_user_id="",
        port_user_name="",
        centrifugo_socket=DEFAULT_CENTRIFUGO_SOCKET,
        centrifugo_secret="",
        zooma_top_session="",
        zooma_top_session_expires_at=None,
        csrf_token="",
        fingerprint_now="",
        user_agent="",
        connected=False,
        train_jobs={},
        server_session_state={},
        chat_ai_pending_task={},
        chat_ai_next_run_ts=0,
        chat_ai_last_error="",
        chat_ai_cycle_started_ts=0,
        chat_ai_rest_until_ts=0,
        proxy_url="",
        proxy_country="",
        proxy_city="",
        proxy_order_id="",
        proxy_ip="",
        proxy_port_http=None,
        proxy_port_socks5=None,
        proxy_login="",
        proxy_password="",
        proxy_scheme="socks5",
        proxy_runtime_status="healthy",
        proxy_runtime_reason="",
        proxy_runtime_source="",
        proxy_runtime_domain="",
        proxy_unavailable_since_ts=0,
        proxy_recovery_successes=0,
        proxy_runtime_alerted_at_ts=0,
        proxy_ping_ms=None,
        proxy_ping_last_ts=0,
        proxy_ping_error="",
    )


def hash_extension_installation_id(installation_id: str) -> str:
    value = str(installation_id or "").strip().lower()
    if len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
        raise ValueError("bad_extension_installation_id")
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def bind_extension(
    chat_id: int,
    account_id: str,
    *,
    device_hash: str,
    bound_at_ts: Optional[int] = None,
) -> dict:
    cid = int(chat_id)
    aid = str(account_id or "acc_1").strip() or "acc_1"
    candidate_hash = str(device_hash or "").strip().lower()
    if len(candidate_hash) != 64 or any(ch not in "0123456789abcdef" for ch in candidate_hash):
        raise ValueError("bad_extension_installation_hash")

    acc = get_user_account(cid, aid)
    if not acc:
        raise KeyError(f"account_not_found:{aid}")

    existing_chat_id = int(acc.get("extension_bound_chat_id") or 0)
    existing_device_hash = str(acc.get("extension_bound_device_id") or "").strip().lower()
    if existing_chat_id:
        if existing_chat_id != cid:
            raise ValueError("extension_bound_to_another_user")
        if not existing_device_hash:
            raise ValueError("extension_legacy_binding_requires_unbind")
        if not secrets.compare_digest(existing_device_hash, candidate_hash):
            raise ValueError("extension_bound_to_another_device")

    ts = int(bound_at_ts or time.time())
    patched = patch_user_account(
        cid,
        aid,
        extension_bound_chat_id=cid,
        extension_bound_account_id=aid,
        extension_bound_at_ts=ts,
        extension_bound_status="bound",
        extension_bound_device_id=candidate_hash,
        extension_binding_version=max(1, int(acc.get("extension_binding_version") or 0)),
    )
    update_user_fields(
        cid,
        extension_bound_chat_id=cid,
        extension_bound_account_id=aid,
        extension_bound_at_ts=ts,
    )
    return patched


def register_extension_key(
    chat_id: int,
    account_id: str,
    *,
    public_key_jwk: dict,
    key_id: str,
    created_ts: Optional[int] = None,
) -> dict:
    cid = int(chat_id)
    aid = str(account_id or "acc_1").strip() or "acc_1"
    kid = str(key_id or "").strip().lower()
    if len(kid) != 64 or any(ch not in "0123456789abcdef" for ch in kid):
        raise ValueError("bad_extension_key_id")
    acc = get_user_account(cid, aid)
    if not acc:
        raise KeyError(f"account_not_found:{aid}")
    if int(acc.get("extension_bound_chat_id") or 0) != cid:
        raise ValueError("extension_not_bound")
    existing = str(acc.get("extension_key_id") or "").strip().lower()
    if existing and not secrets.compare_digest(existing, kid):
        raise ValueError("extension_key_already_registered")
    return patch_user_account(
        cid,
        aid,
        extension_public_key_jwk=dict(public_key_jwk or {}),
        extension_key_id=kid,
        extension_binding_version=max(1, int(acc.get("extension_binding_version") or 0)),
        extension_key_created_ts=int(created_ts or acc.get("extension_key_created_ts") or time.time()),
    )


def unbind_extension(chat_id: int, account_id: str) -> dict:
    cid = int(chat_id)
    aid = str(account_id or "acc_1").strip() or "acc_1"
    if not get_user_account(cid, aid):
        raise KeyError(f"account_not_found:{aid}")

    current = get_user_account(cid, aid) or {}
    patched = patch_user_account(
        cid,
        aid,
        extension_bound_chat_id=None,
        extension_bound_account_id="",
        extension_bound_at_ts=None,
        extension_bound_status="unbound",
        extension_bound_device_id="",
        extension_public_key_jwk={},
        extension_key_id="",
        extension_binding_version=max(1, int(current.get("extension_binding_version") or 0) + 1),
        extension_key_created_ts=0,
    )

    remaining = None
    for candidate in get_user_accounts(cid, include_empty=True):
        candidate_id = str(candidate.get("account_id") or "").strip()
        if candidate_id == aid:
            continue
        if int(candidate.get("extension_bound_chat_id") or 0) > 0:
            remaining = candidate
            break

    if remaining:
        update_user_fields(
            cid,
            extension_bound_chat_id=int(remaining.get("extension_bound_chat_id") or 0) or None,
            extension_bound_account_id=str(remaining.get("account_id") or "") or None,
            extension_bound_at_ts=int(remaining.get("extension_bound_at_ts") or 0) or None,
        )
    else:
        update_user_fields(
            cid,
            extension_bound_chat_id=None,
            extension_bound_account_id=None,
            extension_bound_at_ts=None,
        )
    return patched


def _legacy_fields_from_active_user(user: UserAccount) -> dict:
    return {
        "port_user_id": user.port_user_id,
        "port_user_name": user.port_user_name,
        "centrifugo_secret": user.centrifugo_secret,
        "zooma_top_session": user.zooma_top_session,
        "zooma_top_session_expires_at": user.zooma_top_session_expires_at,
        "csrf_token": user.csrf_token,
        "fingerprint_now": user.fingerprint_now,
        "user_agent": user.user_agent,
        "subscription_tier": user.subscription_tier,
        "subscription_until_ts": user.subscription_until_ts,
        "subscription_warn_1d_for_ts": user.subscription_warn_1d_for_ts,
        "proxy_url": user.user_proxy_url,
        "proxy_order_id": user.user_proxy_order_id,
        "proxy_ip": user.user_proxy_ip,
        "proxy_port_http": user.user_proxy_port_http,
        "proxy_port_socks5": user.user_proxy_port_socks5,
        "proxy_login": user.user_proxy_login,
        "proxy_password": user.user_proxy_password,
        "proxy_scheme": user.user_proxy_scheme,
        "extension_bound_chat_id": user.extension_bound_chat_id,
        "extension_bound_account_id": user.extension_bound_account_id,
        "extension_bound_at_ts": user.extension_bound_at_ts,
    }


def clear_account_casino_data(chat_id: int, account_id: Optional[str] = None) -> dict:
    """
    Fully clears casino-account/runtime data for one account slot.

    Keeps only technical slot identity so menus/callbacks do not break:
    chat_id lives on the user row; inside casino_accounts_json we keep only
    account_id, slot, billing_type, owner_chat_id, empty status/timestamps.

    Removes casino data, auth/session data, subscription data and proxy data.
    """
    user = get_user(int(chat_id))
    accounts = ensure_user_accounts(int(chat_id))
    aid = str(account_id or user.active_account_id or (accounts[0].get("account_id") if accounts else "acc_1") or "acc_1").strip()

    cleared = None
    old_active_id = str(user.active_account_id or "").strip()

    for idx, acc in enumerate(accounts):
        if str(acc.get("account_id") or "") != aid:
            continue

        slot = int(acc.get("slot") or idx + 1)
        billing_type = str(acc.get("billing_type") or ("main" if slot == 1 else "addon"))
        if billing_type not in {"main", "addon"}:
            billing_type = "main" if slot == 1 else "addon"

        # If there are other slots, remove this slot and compact numbering.
        # This enables acc_2->acc_1, acc_3->acc_2 when acc_1 is disabled/expired.
        has_other_slots = len(accounts) > 1
        if has_other_slots and (slot == 1 or (billing_type == "addon" and slot > 1)):
            removed = dict(acc)
            accounts.pop(idx)
            compacted, new_active = _compact_accounts(int(chat_id), accounts, old_active_id)
            user.casino_accounts_json = compacted
            user.active_account_id = str(new_active or "acc_1")
            _mirror_account_to_user(user, _select_account(user))
            _sb_upsert_patch(int(chat_id), {
                "casino_accounts_json": compacted,
                "active_account_id": user.active_account_id or "acc_1",
                "accounts_schema_version": 1,
            })
            save_state()
            return removed

        clean = {
            "account_id": aid,
            "slot": slot,
            "billing_type": billing_type,
            "owner_chat_id": int(chat_id),
            "status": "empty",
            "connected": False,
            "subscription_tier": "",
            "subscription_until_ts": 0,
            "subscription_warn_1d_for_ts": 0,
            "created_at_ts": int(acc.get("created_at_ts") or time.time()),
            "updated_at_ts": int(time.time()),
        }
        clean = _normalize_account(int(chat_id), clean, slot)
        accounts[idx] = clean
        cleared = clean
        break

    if cleared is None:
        raise KeyError(f"account_not_found:{aid}")

    # If the cleared account was active, switch only to another account with live subscription.
    # Never switch to stale casino/session/proxy data, because that re-mirrors trash into top-level columns.
    if not user.active_account_id or str(user.active_account_id or "") == aid:
        next_active = None
        now_ts = int(time.time())
        for acc in accounts:
            if str(acc.get("account_id") or "") == aid:
                continue
            if int(acc.get("subscription_until_ts") or 0) > now_ts:
                next_active = str(acc.get("account_id") or "")
                break
        user.active_account_id = next_active or "acc_1"

    user.casino_accounts_json = accounts
    _mirror_account_to_user(user, _select_account(user))

    patch = {
        "casino_accounts_json": accounts,
        "active_account_id": user.active_account_id or "acc_1",
        "accounts_schema_version": 1,
    }

    # Keep legacy columns clean/in sync if the active view changed or the cleared account was active.
    if old_active_id == aid or str(user.active_account_id or "") == aid:
        patch.update(_legacy_fields_from_active_user(user))

    _sb_upsert_patch(int(chat_id), patch)
    save_state()
    return dict(cleared)


def create_user_account_slot(chat_id: int, billing_type: str = "addon") -> dict:
    user = get_user(chat_id)
    accounts = ensure_user_accounts(chat_id)
    if len(accounts) >= ACCOUNT_LIMIT:
        raise RuntimeError("account_limit_reached")
    used_slots = {int(a.get("slot") or 0) for a in accounts}
    slot = 1
    while slot in used_slots:
        slot += 1
    acc = _normalize_account(chat_id, {
        "account_id": f"acc_{slot}",
        "slot": slot,
        "billing_type": "main" if billing_type == "main" else "addon",
        "status": "empty",
        "owner_chat_id": int(chat_id),
    }, slot)
    accounts.append(acc)
    accounts.sort(key=lambda a: int(a.get("slot") or 999))
    user.casino_accounts_json = accounts
    _sb_upsert_patch(chat_id, {
        "casino_accounts_json": accounts,
        "active_account_id": user.active_account_id or "acc_1",
        "accounts_schema_version": 1,
    })
    save_state()
    return dict(acc)


def get_tariffs_by_type(tariff_type: str = "main") -> dict[str, dict]:
    ttype = str(tariff_type or "main").strip()
    return {
        k: v for k, v in get_all_tariffs().items()
        if str(v.get("tariff_type") or "main") == ttype and bool(v.get("active", True))
    }



def _user_to_dict(user: UserAccount) -> dict:
    return {
        "tg_username": user.tg_username,
        "port_user_id": user.port_user_id,
        "port_user_name": user.port_user_name,
        "centrifugo_socket": user.centrifugo_socket,
        "centrifugo_secret": user.centrifugo_secret,
        "zooma_top_session": user.zooma_top_session,
        "zooma_top_session_expires_at": user.zooma_top_session_expires_at,
        "csrf_token": user.csrf_token,
        "fingerprint_now": user.fingerprint_now,
        "user_agent": user.user_agent,
        "subscription_tier": user.subscription_tier,
        "subscription_until_ts": user.subscription_until_ts,
        "subscription_paused": bool(user.subscription_paused),
        "subscription_pause_started_ts": user.subscription_pause_started_ts,
        "subscription_frozen_left_sec": user.subscription_frozen_left_sec,
        "subscription_warn_1d_for_ts": user.subscription_warn_1d_for_ts,
        "subscription_freeze_reason": getattr(user, "subscription_freeze_reason", None),
        "proxy_failure_notified_at_ts": getattr(user, "proxy_failure_notified_at_ts", None),
        "stale_notified_at_ts": user.stale_notified_at_ts,
        "last_invoice_id": user.last_invoice_id,
        "connected": bool(user.connected),
        "user_proxy_url": user.user_proxy_url,
        "user_proxy_country": user.user_proxy_country,
        "user_proxy_city": user.user_proxy_city,
        "user_proxy_order_id": user.user_proxy_order_id,
        "user_proxy_ip": user.user_proxy_ip,
        "user_proxy_port_http": user.user_proxy_port_http,
        "user_proxy_port_socks5": user.user_proxy_port_socks5,
        "user_proxy_login": user.user_proxy_login,
        "user_proxy_password": user.user_proxy_password,
        "user_proxy_scheme": user.user_proxy_scheme,
        "last_profile_message_id": user.last_profile_message_id,
        "last_ui_message_id": user.last_ui_message_id,
        "casino_accounts_json": list(getattr(user, "casino_accounts_json", []) or []),
        "active_account_id": user.active_account_id,
        "accounts_schema_version": int(getattr(user, "accounts_schema_version", 1) or 1),
        "promo_activated_count": int(getattr(user, "promo_activated_count", 0) or 0),
        "promo_activated_total_amount": round(float(getattr(user, "promo_activated_total_amount", 0.0) or 0.0), 2),
        "promo_month_key": str(getattr(user, "promo_month_key", "") or ""),
        "promo_month_count": int(getattr(user, "promo_month_count", 0) or 0),
        "promo_month_total_amount": round(float(getattr(user, "promo_month_total_amount", 0.0) or 0.0), 2),
        "promo_activation_paused": bool(getattr(user, "promo_activation_paused", False)),
        "promo_activation_mode": str(getattr(user, "promo_activation_mode", "server") or "server"),
        "extension_bound_chat_id": getattr(user, "extension_bound_chat_id", None),
        "extension_bound_account_id": getattr(user, "extension_bound_account_id", None),
        "extension_bound_at_ts": getattr(user, "extension_bound_at_ts", None),
    }



def persist_user_state_now(chat_id: int) -> bool:
    # Interactive switches wait for this write so a fast restart cannot restore stale state.
    cid = int(chat_id)
    save_state()
    if not _SB_ENABLED:
        return True

    handler = _PERSIST_USER_STATE_NOW_HANDLER
    if callable(handler):
        return bool(handler(cid))

    # Compatibility fallback when the normalized DB layer is explicitly disabled.
    # The live users table does not contain accounts_schema_version.
    client = _sb_client()
    if not client:
        raise RuntimeError("supabase_client_unavailable")
    row = _to_db_row(cid, get_user(cid))
    row.pop("accounts_schema_version", None)
    client.table(SUPABASE_USERS_TABLE).upsert(row, on_conflict="chat_id").execute()
    with _SB_LAST_ROWS_LOCK:
        _SB_LAST_ROWS[cid] = dict(row)
    return True


def _supabase_host() -> str:
    try:
        return str(urlparse(SUPABASE_URL).hostname or "").strip()
    except Exception:
        return ""


def _wait_for_supabase_dns_once() -> None:
    host = _supabase_host()
    if host:
        socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)


def _load_state_from_supabase_once(started: float) -> int:
    _wait_for_supabase_dns_once()
    rows = _sb_load_all()
    _sb_load_pending_orders()
    _sb_load_billing_stats()
    _sb_load_tariffs()
    _backfill_billing_metrics_from_pending_once()
    repair_fingerprint_now_duplicates()
    checked, fixed = _repair_users_account_sync()
    with_auth = sum(1 for user in USERS.values() if (user.zooma_top_session or "").strip())
    with_sub = sum(1 for user in USERS.values() if user.subscription_until_ts)
    with_proxy = sum(1 for user in USERS.values() if (user.user_proxy_url or "").strip())
    with_invoice = sum(1 for user in USERS.values() if user.last_invoice_id)
    logger.info("DB: connect ok")
    logger.info(
        "DB restore: users=%s auth=%s subs=%s proxies=%s last_invoices=%s tariffs=%s",
        rows, with_auth, with_sub, with_proxy, with_invoice, len(TARIFFS_RUNTIME)
    )
    if fixed > 0:
        logger.info("DB restore account sync repair: checked=%s changed=%s", checked, fixed)
    logger.info("DB restore done in %.2fs", time.time() - started)
    return rows

def _dict_to_user(data: dict) -> UserAccount:
    return UserAccount(
        tg_username=data.get("tg_username"),
        port_user_id=data.get("port_user_id"),
        port_user_name=data.get("port_user_name"),
        centrifugo_socket=data.get("centrifugo_socket"),
        centrifugo_secret=data.get("centrifugo_secret"),
        zooma_top_session=data.get("zooma_top_session"),
        zooma_top_session_expires_at=data.get("zooma_top_session_expires_at"),
        csrf_token=data.get("csrf_token"),
        fingerprint_now=data.get("fingerprint_now"),
        user_agent=data.get("user_agent"),
        subscription_tier=data.get("subscription_tier"),
        subscription_until_ts=data.get("subscription_until_ts"),
        subscription_paused=bool(data.get("subscription_paused", False)),
        subscription_pause_started_ts=data.get("subscription_pause_started_ts"),
        subscription_frozen_left_sec=data.get("subscription_frozen_left_sec"),
        subscription_warn_1d_for_ts=data.get("subscription_warn_1d_for_ts"),
        stale_notified_at_ts=data.get("stale_notified_at_ts"),
        last_invoice_id=data.get("last_invoice_id"),
        connected=bool(data.get("connected", False)),
        waiting_token=False,
        user_proxy_url=data.get("user_proxy_url"),
        user_proxy_country=data.get("user_proxy_country"),
        user_proxy_city=data.get("user_proxy_city"),
        user_proxy_order_id=data.get("user_proxy_order_id"),
        user_proxy_ip=data.get("user_proxy_ip"),
        user_proxy_port_http=data.get("user_proxy_port_http"),
        user_proxy_port_socks5=data.get("user_proxy_port_socks5"),
        user_proxy_login=data.get("user_proxy_login"),
        user_proxy_password=data.get("user_proxy_password"),
        user_proxy_scheme=data.get("user_proxy_scheme"),
        last_profile_message_id=data.get("last_profile_message_id"),
        last_ui_message_id=data.get("last_ui_message_id"),
        casino_accounts_json=_parse_accounts_json(data.get("casino_accounts_json")),
        active_account_id=data.get("active_account_id"),
        accounts_schema_version=int(data.get("accounts_schema_version") or 1),
        promo_activated_count=int(data.get("promo_activated_count", 0) or 0),
        promo_activated_total_amount=round(float(data.get("promo_activated_total_amount", 0.0) or 0.0), 2),
        promo_month_key=str(data.get("promo_month_key") or "") or None,
        promo_month_count=int(data.get("promo_month_count", 0) or 0),
        promo_month_total_amount=round(float(data.get("promo_month_total_amount", 0.0) or 0.0), 2),
        promo_activation_paused=bool(data.get("promo_activation_paused", False)),
        promo_activation_mode=str(data.get("promo_activation_mode") or "server") if str(data.get("promo_activation_mode") or "server") in {"server", "extension"} else "server",
        extension_bound_chat_id=int(data.get("extension_bound_chat_id") or 0) or None,
        extension_bound_account_id=str(data.get("extension_bound_account_id") or "") or None,
        extension_bound_at_ts=int(data.get("extension_bound_at_ts") or 0) or None,
    )


def _merge_user_dict(old: dict, new: dict) -> dict:
    merged = dict(old or {})
    for k, v in (new or {}).items():
        if v is None:
            continue
        if isinstance(v, str) and v == "" and isinstance(merged.get(k), str) and merged.get(k):
            continue
        merged[k] = v
    return merged


def _sb_client():
    global _SB_CLIENT
    if not _SB_ENABLED:
        return None
    if _SB_CLIENT is None:
        _SB_CLIENT = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    return _SB_CLIENT


def _sb_reset_client() -> None:
    global _SB_CLIENT
    _SB_CLIENT = None


def _sb_retry_delay(attempt: int) -> float:
    return min(_SB_WRITE_RETRY_MAX_SEC, _SB_WRITE_RETRY_BASE_SEC * (2 ** max(0, int(attempt))))


def _sb_queue_retry(chat_id: int, patch: dict, attempt: int, error: Exception) -> None:
    patch = dict(patch or {})

    # Billing metrics are additive. Blind retry can double-count if the first
    # request partially succeeded before the connection died.
    if int(chat_id) == -2 and "__billing_metric__" in patch:
        logger.warning("Supabase async billing metric write failed, not retried to avoid double count: %s", error)
        return

    if attempt >= _SB_WRITE_RETRY_MAX:
        logger.warning(
            "Supabase async upsert failed after retries: chat_id=%s attempt=%s/%s error=%s",
            chat_id,
            attempt,
            _SB_WRITE_RETRY_MAX,
            error,
        )
        return

    delay = _sb_retry_delay(attempt)
    logger.debug(
        "Supabase async upsert retry scheduled: chat_id=%s attempt=%s/%s delay=%.1fs error=%s",
        chat_id,
        attempt + 1,
        _SB_WRITE_RETRY_MAX,
        delay,
        error,
    )
    threading.Timer(
        delay,
        lambda cid=int(chat_id), p=dict(patch), a=attempt + 1: _SB_WRITE_QUEUE.put((cid, p, a)),
    ).start()


def _ensure_sb_writer_started() -> None:
    global _SB_WRITER_THREAD, _SB_PROFILE_FLUSH_THREAD, _PROMO_STATS_FLUSH_THREAD
    if not _SB_ENABLED:
        return
    if (
        _SB_WRITER_THREAD and _SB_WRITER_THREAD.is_alive()
        and _SB_PROFILE_FLUSH_THREAD and _SB_PROFILE_FLUSH_THREAD.is_alive()
        and _PROMO_STATS_FLUSH_THREAD and _PROMO_STATS_FLUSH_THREAD.is_alive()
    ):
        return
    _SB_WRITER_STOP.clear()
    if not _SB_WRITER_THREAD or not _SB_WRITER_THREAD.is_alive():
        _SB_WRITER_THREAD = threading.Thread(target=_sb_writer_loop, name="sb-writer", daemon=True)
        _SB_WRITER_THREAD.start()
    if not _SB_PROFILE_FLUSH_THREAD or not _SB_PROFILE_FLUSH_THREAD.is_alive():
        _SB_PROFILE_FLUSH_THREAD = threading.Thread(
            target=_sb_profile_flush_loop,
            name="sb-profile-flush",
            daemon=True,
        )
        _SB_PROFILE_FLUSH_THREAD.start()
    if not _PROMO_STATS_FLUSH_THREAD or not _PROMO_STATS_FLUSH_THREAD.is_alive():
        _PROMO_STATS_FLUSH_THREAD = threading.Thread(
            target=_promo_stats_flush_loop,
            name="promo-stats-flush",
            daemon=True,
        )
        _PROMO_STATS_FLUSH_THREAD.start()


def _sb_writer_loop() -> None:
    if not _SB_ENABLED:
        return
    while not _SB_WRITER_STOP.is_set():
        try:
            item = _SB_WRITE_QUEUE.get(timeout=0.5)
        except queue.Empty:
            continue

        taken = 1
        merged: dict[int, dict] = {}
        attempts: dict[int, int] = {}

        try:
            if len(item) >= 3:
                chat_id, patch, attempt = item
            else:
                chat_id, patch = item
                attempt = 0

            chat_id = int(chat_id)
            merged = {chat_id: dict(patch)}
            attempts = {chat_id: int(attempt or 0)}

            # Coalesce a short burst into one patch per chat_id.
            while True:
                try:
                    nxt = _SB_WRITE_QUEUE.get_nowait()
                    taken += 1

                    if len(nxt) >= 3:
                        c2, p2, a2 = nxt
                    else:
                        c2, p2 = nxt
                        a2 = 0

                    c2 = int(c2)
                    p2 = dict(p2)
                    if c2 == -4 and "__promo_stats_batch__" in p2 and "__promo_stats_batch__" in merged.get(c2, {}):
                        merged[c2]["__promo_stats_batch__"] = list(merged[c2].get("__promo_stats_batch__") or []) + list(p2.get("__promo_stats_batch__") or [])
                    else:
                        merged.setdefault(c2, {}).update(p2)
                    attempts[c2] = max(int(attempts.get(c2, 0)), int(a2 or 0))
                except queue.Empty:
                    break
            client = _sb_client()
            if not client:
                raise RuntimeError("supabase_client_unavailable")

            for cid, p in merged.items():
                if cid == -4 and "__promo_stats_batch__" in p:
                    rows = [dict(r) for r in (p.get("__promo_stats_batch__") or []) if isinstance(r, dict) and r.get("chat_id")]
                    if rows:
                        client.table(SUPABASE_USERS_TABLE).upsert(rows, on_conflict="chat_id").execute()
                    continue
                if cid == -1 and "__pending_upsert__" in p:
                    row = dict(p["__pending_upsert__"])
                    client.table(SUPABASE_PENDING_ORDERS_TABLE).upsert(row, on_conflict="order_id").execute()
                    continue
                if cid == -1 and "__pending_delete__" in p:
                    order_id = str((p["__pending_delete__"] or {}).get("order_id") or "")
                    if order_id:
                        client.table(SUPABASE_PENDING_ORDERS_TABLE).delete().eq("order_id", order_id).execute()
                    continue
                if cid == -2 and "__billing_metric__" in p:
                    row = dict(p["__billing_metric__"] or {})
                    day = str(row.get("day") or "")
                    paid_usdt = float(row.get("paid_usdt") or 0.0)
                    paid_rub = float(row.get("paid_rub") or 0.0)
                    paid_count = int(row.get("paid_count") or 0)
                    proxy_spent_rub = float(row.get("proxy_spent_rub") or 0.0)
                    proxy_spent_count = int(row.get("proxy_spent_count") or 0)
                    # total
                    cur = client.table(_BILLING_STATS_TABLE).select("*").eq("id", 1).limit(1).execute()
                    cur_rows = getattr(cur, "data", None) or []
                    if cur_rows:
                        current = cur_rows[0] if isinstance(cur_rows[0], dict) else {}
                        total_usdt = float(current.get("paid_total_usdt") or 0.0) + paid_usdt
                        total_rub = float(current.get("paid_total_rub") or 0.0) + paid_rub
                        total_cnt = int(current.get("paid_total_count") or 0) + paid_count
                        total_proxy_spent_rub = float(current.get("proxy_spent_total_rub") or 0.0) + proxy_spent_rub
                        total_proxy_spent_cnt = int(current.get("proxy_spent_total_count") or 0) + proxy_spent_count
                    else:
                        total_usdt = paid_usdt
                        total_rub = paid_rub
                        total_cnt = paid_count
                        total_proxy_spent_rub = proxy_spent_rub
                        total_proxy_spent_cnt = proxy_spent_count
                    try:
                        client.table(_BILLING_STATS_TABLE).upsert(
                            {
                                "id": 1,
                                "paid_total_usdt": total_usdt,
                                "paid_total_rub": total_rub,
                                "paid_total_count": total_cnt,
                                "proxy_spent_total_rub": total_proxy_spent_rub,
                                "proxy_spent_total_count": total_proxy_spent_cnt,
                            },
                            on_conflict="id",
                        ).execute()
                    except Exception:
                        client.table(_BILLING_STATS_TABLE).upsert(
                            {"id": 1, "paid_total_usdt": total_usdt, "paid_total_rub": total_rub, "paid_total_count": total_cnt},
                            on_conflict="id",
                        ).execute()
                    # daily
                    if day:
                        dcur = client.table(_BILLING_DAILY_TABLE).select("*").eq("day", day).limit(1).execute()
                        drows = getattr(dcur, "data", None) or []
                        if drows:
                            d0 = drows[0] if isinstance(drows[0], dict) else {}
                            dusdt = float(d0.get("paid_usdt") or 0.0) + paid_usdt
                            drub = float(d0.get("paid_rub") or 0.0) + paid_rub
                            dcnt = int(d0.get("paid_count") or 0) + paid_count
                            dproxy_rub = float(d0.get("proxy_spent_rub") or 0.0) + proxy_spent_rub
                            dproxy_cnt = int(d0.get("proxy_spent_count") or 0) + proxy_spent_count
                        else:
                            dusdt = paid_usdt
                            drub = paid_rub
                            dcnt = paid_count
                            dproxy_rub = proxy_spent_rub
                            dproxy_cnt = proxy_spent_count
                        try:
                            client.table(_BILLING_DAILY_TABLE).upsert(
                                {
                                    "day": day,
                                    "paid_usdt": dusdt,
                                    "paid_rub": drub,
                                    "paid_count": dcnt,
                                    "proxy_spent_rub": dproxy_rub,
                                    "proxy_spent_count": dproxy_cnt,
                                },
                                on_conflict="day",
                            ).execute()
                        except Exception:
                            client.table(_BILLING_DAILY_TABLE).upsert(
                                {"day": day, "paid_usdt": dusdt, "paid_rub": drub, "paid_count": dcnt},
                                on_conflict="day",
                            ).execute()
                    continue
                if cid == -3 and "__tariff_upsert__" in p:
                    row = dict(p["__tariff_upsert__"] or {})
                    if row.get("key"):
                        client.table(_TARIFFS_TABLE).upsert(row, on_conflict="key").execute()
                    continue
                if cid == -3 and "__tariff_delete__" in p:
                    key = str((p["__tariff_delete__"] or {}).get("key") or "")
                    if key:
                        client.table(_TARIFFS_TABLE).delete().eq("key", key).execute()
                    continue
                payload = {"chat_id": cid}
                payload.update(p)
                client.table(SUPABASE_USERS_TABLE).upsert(payload, on_conflict="chat_id").execute()
                with _SB_LAST_ROWS_LOCK:
                    previous = dict(_SB_LAST_ROWS.get(int(cid), {}))
                    previous.update(p)
                    _SB_LAST_ROWS[int(cid)] = previous
        except Exception as e:
            _sb_reset_client()
            if merged:
                for cid, retry_patch in merged.items():
                    _sb_queue_retry(
                        int(cid),
                        dict(retry_patch),
                        int(attempts.get(int(cid), 0)),
                        e,
                    )
            else:
                logger.warning("Supabase async upsert failed before merge: %s", e)
        finally:
            for _ in range(taken):
                _SB_WRITE_QUEUE.task_done()


def _sb_profile_flush_loop() -> None:
    while not _SB_WRITER_STOP.is_set():
        _SB_WRITER_STOP.wait(_PROFILE_MSG_FLUSH_INTERVAL_SEC)
        if _SB_WRITER_STOP.is_set():
            return
        with _PROFILE_MSG_PENDING_LOCK:
            pending = dict(_PROFILE_MSG_PENDING)
            _PROFILE_MSG_PENDING.clear()
        if not pending:
            continue
        for chat_id, mid in pending.items():
            _sb_upsert_patch(chat_id, {"last_profile_message_id": mid})


def _queue_profile_msg_patch(chat_id: int, message_id: Optional[int]) -> None:
    if not _SB_ENABLED:
        return
    _ensure_sb_writer_started()
    with _PROFILE_MSG_PENDING_LOCK:
        _PROFILE_MSG_PENDING[chat_id] = message_id


def _to_db_row(chat_id: int, user: UserAccount) -> dict:
    return {
        "chat_id": chat_id,
        "tg_username": user.tg_username,
        "port_user_id": user.port_user_id,
        "port_user_name": user.port_user_name,
        "centrifugo_secret": user.centrifugo_secret,
        "zooma_top_session": user.zooma_top_session,
        "zooma_top_session_expires_at": user.zooma_top_session_expires_at,
        "csrf_token": user.csrf_token,
        "fingerprint_now": user.fingerprint_now,
        "user_agent": user.user_agent,
        "subscription_tier": user.subscription_tier,
        "subscription_until_ts": user.subscription_until_ts,
        "subscription_warn_1d_for_ts": user.subscription_warn_1d_for_ts,
        "stale_notified_at_ts": user.stale_notified_at_ts,
        "proxy_url": user.user_proxy_url,
        "proxy_order_id": user.user_proxy_order_id,
        "proxy_ip": user.user_proxy_ip,
        "last_profile_message_id": user.last_profile_message_id,
        "last_ui_message_id": user.last_ui_message_id,
        "last_invoice_id": None,
        "last_invoice_status": None,
        "last_invoice_expires_at_ts": None,
        "last_invoice_message_id": None,
        "last_invoice_pay_url": None,
        "last_invoice_payload": None,
        "casino_accounts_json": _normalize_accounts_for_user(chat_id, user),
        "active_account_id": user.active_account_id or "acc_1",
        "accounts_schema_version": int(getattr(user, "accounts_schema_version", 1) or 1),
        "promo_activated_count": int(getattr(user, "promo_activated_count", 0) or 0),
        "promo_activated_total_amount": round(float(getattr(user, "promo_activated_total_amount", 0.0) or 0.0), 2),
        "promo_month_key": str(getattr(user, "promo_month_key", "") or "") or None,
        "promo_month_count": int(getattr(user, "promo_month_count", 0) or 0),
        "promo_month_total_amount": round(float(getattr(user, "promo_month_total_amount", 0.0) or 0.0), 2),
        "promo_activation_paused": bool(getattr(user, "promo_activation_paused", False)),
        "promo_activation_mode": str(getattr(user, "promo_activation_mode", "server") or "server"),
        "extension_bound_chat_id": getattr(user, "extension_bound_chat_id", None),
        "extension_bound_account_id": getattr(user, "extension_bound_account_id", None),
        "extension_bound_at_ts": getattr(user, "extension_bound_at_ts", None),
    }


def _apply_db_row(chat_id: int, row: dict) -> None:
    user = get_user(chat_id)
    user.tg_username = row.get("tg_username") or user.tg_username
    user.port_user_id = row.get("port_user_id") or user.port_user_id
    user.port_user_name = row.get("port_user_name") or user.port_user_name
    user.centrifugo_socket = DEFAULT_CENTRIFUGO_SOCKET
    user.centrifugo_secret = row.get("centrifugo_secret") or user.centrifugo_secret
    user.zooma_top_session = row.get("zooma_top_session") or user.zooma_top_session
    user.zooma_top_session_expires_at = row.get("zooma_top_session_expires_at") or user.zooma_top_session_expires_at
    user.csrf_token = row.get("csrf_token") or user.csrf_token
    user.fingerprint_now = row.get("fingerprint_now") or user.fingerprint_now
    user.user_agent = row.get("user_agent") or user.user_agent
    user.subscription_tier = row.get("subscription_tier")
    user.subscription_until_ts = row.get("subscription_until_ts")
    user.subscription_paused = bool(row.get("subscription_paused", False))
    user.subscription_pause_started_ts = row.get("subscription_pause_started_ts")
    user.subscription_frozen_left_sec = row.get("subscription_frozen_left_sec")
    with contextlib.suppress(Exception):
        user.subscription_freeze_reason = row.get("subscription_freeze_reason")
    with contextlib.suppress(Exception):
        user.proxy_failure_notified_at_ts = row.get("proxy_failure_notified_at_ts")
    user.subscription_warn_1d_for_ts = row.get("subscription_warn_1d_for_ts")
    user.stale_notified_at_ts = row.get("stale_notified_at_ts")
    user.user_proxy_url = row.get("proxy_url") or user.user_proxy_url
    user.user_proxy_order_id = row.get("proxy_order_id") or user.user_proxy_order_id
    user.user_proxy_ip = row.get("proxy_ip") or user.user_proxy_ip
    user.user_proxy_port_http = row.get("proxy_port_http") or user.user_proxy_port_http
    user.user_proxy_port_socks5 = row.get("proxy_port_socks5") or user.user_proxy_port_socks5
    user.user_proxy_login = row.get("proxy_login") or user.user_proxy_login
    user.user_proxy_password = row.get("proxy_password") or user.user_proxy_password
    user.user_proxy_scheme = row.get("proxy_scheme") or user.user_proxy_scheme
    user.last_profile_message_id = row.get("last_profile_message_id") or user.last_profile_message_id
    user.last_ui_message_id = row.get("last_ui_message_id") or user.last_ui_message_id
    user.casino_accounts_json = _normalize_accounts_for_user(chat_id, user, row.get("casino_accounts_json"))
    user.active_account_id = row.get("active_account_id") or (user.casino_accounts_json[0].get("account_id") if user.casino_accounts_json else "acc_1")
    user.accounts_schema_version = int(row.get("accounts_schema_version") or 1)
    user.promo_activated_count = int(row.get("promo_activated_count") or 0)
    user.promo_activated_total_amount = round(float(row.get("promo_activated_total_amount") or 0.0), 2)
    user.promo_month_key = str(row.get("promo_month_key") or "") or None
    user.promo_month_count = int(row.get("promo_month_count") or 0)
    user.promo_month_total_amount = round(float(row.get("promo_month_total_amount") or 0.0), 2)
    user.promo_activation_paused = bool(row.get("promo_activation_paused", False))
    mode = str(row.get("promo_activation_mode") or "server").strip().lower()
    user.promo_activation_mode = mode if mode in {"server", "extension"} else "server"
    user.extension_bound_chat_id = int(row.get("extension_bound_chat_id") or 0) or None
    user.extension_bound_account_id = str(row.get("extension_bound_account_id") or "") or None
    user.extension_bound_at_ts = int(row.get("extension_bound_at_ts") or 0) or None
    _mirror_account_to_user(user, _select_account(user))
    active_acc = _select_account(user)
    user.connected = bool((active_acc or {}).get("connected"))
    user.waiting_token = False

    inv = row.get("last_invoice_payload")
    if isinstance(inv, str):
        try:
            inv = json.loads(inv)
        except Exception:
            inv = None
    if isinstance(inv, dict):
        inv_id = str(inv.get("invoice_id") or row.get("last_invoice_id") or "").strip()
        if inv_id:
            INVOICES[inv_id] = inv
            user.last_invoice_id = inv_id
    elif row.get("last_invoice_id"):
        user.last_invoice_id = str(row.get("last_invoice_id"))
    with _SB_LAST_ROWS_LOCK:
        _SB_LAST_ROWS[chat_id] = _to_db_row(chat_id, user)


def _repair_users_account_sync() -> tuple[int, int]:
    """
    Soft repair: ensure normalized accounts JSON and active-account mirroring to legacy fields.
    Returns (checked, changed).
    """
    checked = 0
    changed = 0
    for chat_id in list(USERS.keys()):
        checked += 1
        user = get_user(chat_id)
        before = _to_db_row(chat_id, user)
        # Normalize first.
        user.casino_accounts_json = _normalize_accounts_for_user(chat_id, user, getattr(user, "casino_accounts_json", None))
        # Drop legacy empty shells from old data and compact surviving accounts.
        compacted_shells, new_active_shells, removed_shells = _compact_accounts_drop_empty_shells(
            chat_id, user.casino_accounts_json, getattr(user, "active_account_id", None)
        )
        if removed_shells > 0:
            user.casino_accounts_json = compacted_shells
            user.active_account_id = str(new_active_shells or "acc_1")
        # Compact historical gaps: e.g. old data with empty acc_1 + active acc_2/acc_3.
        if _accounts_need_compaction(user.casino_accounts_json) and not _pending_locked_account_ids(chat_id):
            compacted, new_active = _compact_accounts(chat_id, user.casino_accounts_json, getattr(user, "active_account_id", None))
            user.casino_accounts_json = compacted
            user.active_account_id = str(new_active or "acc_1")
        if not user.active_account_id and user.casino_accounts_json:
            user.active_account_id = str(user.casino_accounts_json[0].get("account_id") or "acc_1")
        _mirror_account_to_user(user, _select_account(user))
        user.accounts_schema_version = 1
        after = _to_db_row(chat_id, user)
        patch = {}
        for k, v in after.items():
            if k == "chat_id":
                continue
            if before.get(k) != v:
                patch[k] = v
        if patch:
            _sb_upsert_patch(chat_id, patch)
            changed += 1
    return checked, changed


def _sb_load_all() -> int:
    client = _sb_client()
    if not client:
        return 0
    resp = client.table(SUPABASE_USERS_TABLE).select("*").execute()
    rows = getattr(resp, "data", None) or []
    if not isinstance(rows, list):
        return 0
    USERS.clear()
    INVOICES.clear()
    with _SB_LAST_ROWS_LOCK:
        _SB_LAST_ROWS.clear()
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            chat_id = int(row.get("chat_id"))
        except Exception:
            continue
        _apply_db_row(chat_id, row)
    return len(rows)


def _sb_load_pending_orders() -> int:
    client = _sb_client()
    if not client:
        return 0
    resp = client.table(SUPABASE_PENDING_ORDERS_TABLE).select("*").execute()
    rows = getattr(resp, "data", None) or []
    if not isinstance(rows, list):
        return 0
    PENDING_ORDERS.clear()
    for row in rows:
        if not isinstance(row, dict):
            continue
        order_id = str(row.get("order_id") or "").strip()
        if not order_id:
            continue
        PENDING_ORDERS[order_id] = row
    return len(PENDING_ORDERS)


def _sb_load_billing_stats() -> None:
    client = _sb_client()
    if not client:
        return
    BILLING_STATS["paid_total_usdt"] = 0.0
    BILLING_STATS["paid_total_rub"] = 0.0
    BILLING_STATS["paid_total_count"] = 0
    BILLING_STATS["proxy_spent_total_rub"] = 0.0
    BILLING_STATS["proxy_spent_total_count"] = 0
    BILLING_DAILY.clear()
    try:
        r = client.table(_BILLING_STATS_TABLE).select("*").eq("id", 1).limit(1).execute()
        rows = getattr(r, "data", None) or []
        if rows and isinstance(rows[0], dict):
            BILLING_STATS["paid_total_usdt"] = float(rows[0].get("paid_total_usdt") or 0.0)
            BILLING_STATS["paid_total_rub"] = float(rows[0].get("paid_total_rub") or 0.0)
            BILLING_STATS["paid_total_count"] = int(rows[0].get("paid_total_count") or 0)
            BILLING_STATS["proxy_spent_total_rub"] = float(rows[0].get("proxy_spent_total_rub") or 0.0)
            BILLING_STATS["proxy_spent_total_count"] = int(rows[0].get("proxy_spent_total_count") or 0)
    except Exception:
        pass
    try:
        dr = client.table(_BILLING_DAILY_TABLE).select("*").execute()
        drows = getattr(dr, "data", None) or []
        for row in drows:
            if not isinstance(row, dict):
                continue
            day = str(row.get("day") or "").strip()
            if not day:
                continue
            BILLING_DAILY[day] = {
                "paid_usdt": float(row.get("paid_usdt") or 0.0),
                "paid_rub": float(row.get("paid_rub") or 0.0),
                "paid_count": int(row.get("paid_count") or 0),
                "proxy_spent_rub": float(row.get("proxy_spent_rub") or 0.0),
                "proxy_spent_count": int(row.get("proxy_spent_count") or 0),
            }
    except Exception:
        pass


def _seed_default_tariffs_if_empty() -> None:
    if TARIFFS_RUNTIME:
        return
    for key, cfg in (DEFAULT_TARIFFS or {}).items():
        TARIFFS_RUNTIME[str(key)] = {
            "key": str(key),
            "title": str(cfg.get("title", key)),
            "price_rub_base": int(cfg.get("price_rub", 700)),
            "days": int(cfg.get("days", 30)),
            "discount_pct": 0.0,
            "active": True,
            "tariff_type": str(cfg.get("tariff_type", "main")),
            "sort_order": int(cfg.get("sort_order", 100)),
        }


def _sb_load_tariffs() -> int:
    client = _sb_client()
    if not client:
        _seed_default_tariffs_if_empty()
        return len(TARIFFS_RUNTIME)
    try:
        resp = client.table(_TARIFFS_TABLE).select("*").execute()
        rows = getattr(resp, "data", None) or []
        TARIFFS_RUNTIME.clear()
        for row in rows:
            if not isinstance(row, dict):
                continue
            key = str(row.get("key") or "").strip()
            if not key:
                continue
            TARIFFS_RUNTIME[key] = {
                "key": key,
                "title": str(row.get("title") or key),
                "price_rub_base": int(float(row.get("price_rub_base") or 0)),
                "days": int(row.get("days") or 30),
                "discount_pct": float(row.get("discount_pct") or 0.0),
                "active": bool(row.get("active", True)),
                "tariff_type": str(row.get("tariff_type") or "main"),
                "sort_order": int(row.get("sort_order") or 100),
            }
        if not TARIFFS_RUNTIME:
            _seed_default_tariffs_if_empty()
            for row in TARIFFS_RUNTIME.values():
                client.table(_TARIFFS_TABLE).upsert(row, on_conflict="key").execute()
        return len(TARIFFS_RUNTIME)
    except Exception:
        _seed_default_tariffs_if_empty()
        return len(TARIFFS_RUNTIME)


def _sb_write_billing_snapshot() -> None:
    client = _sb_client()
    if not client:
        return
    client.table(_BILLING_STATS_TABLE).upsert(
        {
            "id": 1,
            "paid_total_usdt": float(BILLING_STATS.get("paid_total_usdt") or 0.0),
            "paid_total_rub": float(BILLING_STATS.get("paid_total_rub") or 0.0),
            "paid_total_count": int(BILLING_STATS.get("paid_total_count") or 0),
            "proxy_spent_total_rub": float(BILLING_STATS.get("proxy_spent_total_rub") or 0.0),
            "proxy_spent_total_count": int(BILLING_STATS.get("proxy_spent_total_count") or 0),
        },
        on_conflict="id",
    ).execute()
    if not BILLING_DAILY:
        return
    rows = []
    for day, row in BILLING_DAILY.items():
        rows.append(
            {
                "day": day,
                "paid_usdt": float(row.get("paid_usdt") or 0.0),
                "paid_rub": float(row.get("paid_rub") or 0.0),
                "paid_count": int(row.get("paid_count") or 0),
                "proxy_spent_rub": float(row.get("proxy_spent_rub") or 0.0),
                "proxy_spent_count": int(row.get("proxy_spent_count") or 0),
            }
        )
    if rows:
        client.table(_BILLING_DAILY_TABLE).upsert(rows, on_conflict="day").execute()


def _backfill_billing_metrics_from_pending_once() -> None:
    total_usdt = float(BILLING_STATS.get("paid_total_usdt") or 0.0)
    total_rub = float(BILLING_STATS.get("paid_total_rub") or 0.0)
    total_cnt = int(BILLING_STATS.get("paid_total_count") or 0)
    # Safety gate: run backfill only for a completely empty metrics state.
    if total_usdt > 0 or total_rub > 0 or total_cnt > 0 or bool(BILLING_DAILY):
        return
    by_day: dict[str, dict[str, float | int]] = {}
    agg_usdt = 0.0
    agg_rub = 0.0
    agg_cnt = 0
    for pending in PENDING_ORDERS.values():
        if str(pending.get("status") or "") != "paid":
            continue
        amount = float(pending.get("paid_amount") or pending.get("expected_amount") or 0.0)
        amount_rub = float(pending.get("price_rub") or pending.get("price_rub_effective") or 0.0)
        if amount <= 0:
            continue
        paid_at_ts = int(pending.get("paid_at_ts") or 0)
        if paid_at_ts <= 0:
            continue
        day = datetime.fromtimestamp(paid_at_ts, tz=timezone.utc).date().isoformat()
        cur = by_day.get(day) or {"paid_usdt": 0.0, "paid_rub": 0.0, "paid_count": 0}
        cur["paid_usdt"] = float(cur.get("paid_usdt") or 0.0) + amount
        cur["paid_rub"] = float(cur.get("paid_rub") or 0.0) + max(0.0, amount_rub)
        cur["paid_count"] = int(cur.get("paid_count") or 0) + 1
        by_day[day] = cur
        agg_usdt += amount
        agg_rub += max(0.0, amount_rub)
        agg_cnt += 1
    if agg_cnt <= 0:
        return
    BILLING_STATS["paid_total_usdt"] = round(agg_usdt, 6)
    BILLING_STATS["paid_total_rub"] = round(agg_rub, 2)
    BILLING_STATS["paid_total_count"] = agg_cnt
    BILLING_STATS["proxy_spent_total_rub"] = float(BILLING_STATS.get("proxy_spent_total_rub") or 0.0)
    BILLING_STATS["proxy_spent_total_count"] = int(BILLING_STATS.get("proxy_spent_total_count") or 0)
    BILLING_DAILY.clear()
    BILLING_DAILY.update(by_day)
    if _SB_ENABLED:
        try:
            _sb_write_billing_snapshot()
            logger.info("DB billing backfill: restored_count=%s restored_usdt=%.6f", agg_cnt, agg_usdt)
        except Exception as e:
            logger.warning("DB billing backfill warning: %s", e)



def _json_stable(value):
    """Return a deterministic representation for dirty-checking JSON-ish DB values."""
    if isinstance(value, float) and math.isnan(value):
        return None
    if isinstance(value, dict):
        return {str(k): _json_stable(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, list):
        return [_json_stable(v) for v in value]
    return value


def _patch_changed(chat_id: int, patch: dict) -> dict:
    with _SB_LAST_ROWS_LOCK:
        prev = dict(_SB_LAST_ROWS.get(int(chat_id), {}))
    changed = {}
    for k, v in dict(patch).items():
        if k == "chat_id":
            continue
        if _json_stable(prev.get(k)) != _json_stable(v):
            changed[k] = v
    return changed

def _sb_upsert_patch(chat_id: int, patch: dict) -> None:
    if not _SB_ENABLED or not patch:
        return
    patch = _patch_changed(int(chat_id), {k: v for k, v in patch.items() if k != "chat_id"})
    if not patch:
        return
    _ensure_sb_writer_started()
    _SB_WRITE_QUEUE.put((int(chat_id), patch))


def _sb_upsert_tariff(row: dict) -> None:
    if not _SB_ENABLED:
        return
    _ensure_sb_writer_started()
    _SB_WRITE_QUEUE.put((-3, {"__tariff_upsert__": dict(row)}))


def _sb_delete_tariff(key: str) -> None:
    if not _SB_ENABLED:
        return
    _ensure_sb_writer_started()
    _SB_WRITE_QUEUE.put((-3, {"__tariff_delete__": {"key": str(key)}}))


def _persist_user(chat_id: int) -> None:
    user = USERS.get(chat_id)
    if not user:
        return
    row = _to_db_row(chat_id, user)
    with _SB_LAST_ROWS_LOCK:
        prev = dict(_SB_LAST_ROWS.get(chat_id, {}))
    patch = {}
    for k, v in row.items():
        if k == "chat_id":
            continue
        if prev.get(k) != v:
            patch[k] = v
    if patch:
        _sb_upsert_patch(chat_id, patch)


def _persist_invoice_snapshot(chat_id: int, invoice: dict) -> None:
    if not invoice:
        return
    patch = {
        "last_invoice_id": invoice.get("invoice_id"),
        "last_invoice_status": invoice.get("status"),
        "last_invoice_expires_at_ts": invoice.get("expires_at"),
        "last_invoice_message_id": invoice.get("message_id"),
        "last_invoice_pay_url": invoice.get("pay_url"),
        "last_invoice_payload": invoice,
    }
    _sb_upsert_patch(chat_id, patch)


def _promo_stats_patch_from_user(user: UserAccount) -> dict:
    return {
        "promo_activated_count": int(getattr(user, "promo_activated_count", 0) or 0),
        "promo_activated_total_amount": round(float(getattr(user, "promo_activated_total_amount", 0.0) or 0.0), 2),
        "promo_month_key": str(getattr(user, "promo_month_key", "") or "") or None,
        "promo_month_count": int(getattr(user, "promo_month_count", 0) or 0),
        "promo_month_total_amount": round(float(getattr(user, "promo_month_total_amount", 0.0) or 0.0), 2),
    }


def _queue_promo_stats_patch(chat_id: int, patch: dict) -> None:
    if not _SB_ENABLED or not patch:
        return
    with _SB_LAST_ROWS_LOCK:
        last = dict(_SB_LAST_ROWS.get(int(chat_id), {}))
        last.update({k: v for k, v in dict(patch).items() if not str(k).startswith("_")})
        _SB_LAST_ROWS[int(chat_id)] = last
    _ensure_sb_writer_started()
    now = time.time()
    with _PROMO_STATS_PENDING_LOCK:
        cur = dict(_PROMO_STATS_PENDING.get(int(chat_id)) or {})
        first_ts = float(cur.get("_first_ts") or now)
        cur.update(dict(patch))
        cur["_first_ts"] = first_ts
        cur["_last_ts"] = now
        _PROMO_STATS_PENDING[int(chat_id)] = cur
    _PROMO_STATS_DIRTY.set()


def _promo_stats_flush_loop() -> None:
    while not _SB_WRITER_STOP.is_set():
        _PROMO_STATS_DIRTY.wait(timeout=1.0)
        if _SB_WRITER_STOP.is_set():
            return
        _PROMO_STATS_DIRTY.clear()
        now = time.time()
        due: dict[int, dict] = {}
        with _PROMO_STATS_PENDING_LOCK:
            for chat_id, patch in list(_PROMO_STATS_PENDING.items()):
                first_ts = float(patch.get("_first_ts") or now)
                if (now - first_ts) < _PROMO_STATS_FLUSH_DELAY_SEC:
                    continue
                due[int(chat_id)] = {k: v for k, v in dict(patch).items() if not str(k).startswith("_")}
                _PROMO_STATS_PENDING.pop(int(chat_id), None)
        rows = []
        for chat_id, patch in due.items():
            row = {"chat_id": int(chat_id)}
            row.update(patch)
            rows.append(row)
        _sb_upsert_promo_stats_batch(rows)


def _sb_upsert_promo_stats_batch(rows: list[dict]) -> None:
    if not _SB_ENABLED or not rows:
        return
    _ensure_sb_writer_started()
    _SB_WRITE_QUEUE.put((-4, {"__promo_stats_batch__": [dict(r) for r in rows if r.get("chat_id")]}))


def flush_promo_stats_now() -> None:
    """Force pending promo stats patches into the normal Supabase writer queue."""
    with _PROMO_STATS_PENDING_LOCK:
        due = {
            int(chat_id): {k: v for k, v in dict(patch).items() if not str(k).startswith("_")}
            for chat_id, patch in list(_PROMO_STATS_PENDING.items())
        }
        _PROMO_STATS_PENDING.clear()
        _PROMO_STATS_DIRTY.clear()
    rows = []
    for chat_id, patch in due.items():
        row = {"chat_id": int(chat_id)}
        row.update(patch)
        rows.append(row)
    _sb_upsert_promo_stats_batch(rows)


def record_promo_activation(
    chat_id: int,
    amount: float | None = None,
    *,
    promo: str | None = None,
    account_id: str | None = None,
) -> tuple[int, float]:
    user = get_user(int(chat_id))

    add_amount = 0.0
    try:
        if amount is not None:
            add_amount = max(0.0, float(amount))
    except Exception:
        logger.exception(
            "promo stats amount parse failed | chat_id=%s account_id=%s promo=%s raw_amount=%r",
            chat_id,
            account_id or "",
            promo or "",
            amount,
        )
        add_amount = 0.0

    if abs(add_amount - 5.0) <= 0.01:
        return (
            int(getattr(user, "promo_activated_count", 0) or 0),
            round(float(getattr(user, "promo_activated_total_amount", 0.0) or 0.0), 2),
        )

    try:
        count = int(getattr(user, "promo_activated_count", 0) or 0) + 1
        total = round(float(getattr(user, "promo_activated_total_amount", 0.0) or 0.0) + add_amount, 2)
        month_snapshot = get_user_promo_month_snapshot(int(chat_id))
        month_key = str(month_snapshot.get("promo_month_key") or "").strip() or None
        month_count = int(month_snapshot.get("promo_month_count") or 0) + 1
        month_total = round(float(month_snapshot.get("promo_month_total_amount") or 0.0) + add_amount, 2)

        user.promo_activated_count = count
        user.promo_activated_total_amount = total
        user.promo_month_key = month_key
        user.promo_month_count = month_count
        user.promo_month_total_amount = month_total

        patch = _promo_stats_patch_from_user(user)
        _queue_promo_stats_patch(int(chat_id), patch)
        return count, total
    except Exception:
        logger.exception(
            "promo stats update failed | chat_id=%s account_id=%s promo=%s amount=%r",
            chat_id,
            account_id or "",
            promo or "",
            amount,
        )
        raise


def save_state() -> None:
    if not _LEGACY_FILE_IO_ENABLED:
        return
    if _LEGACY_FILE_IO_ENABLED:
        old_payload = {}
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, "r", encoding="utf-8") as f:
                    old_payload = json.load(f)
            except Exception:
                old_payload = {}

        old_users = old_payload.get("users", {}) if isinstance(old_payload, dict) else {}
        merged_users: dict[str, dict] = {}
        for chat_id, user in USERS.items():
            key = str(chat_id)
            old_user = old_users.get(key) if isinstance(old_users, dict) else {}
            merged_users[key] = _merge_user_dict(old_user if isinstance(old_user, dict) else {}, _user_to_dict(user))

        # Preserve users that are present in file but not currently loaded in memory.
        if isinstance(old_users, dict):
            for key, old_user in old_users.items():
                if key not in merged_users and isinstance(old_user, dict):
                    merged_users[key] = old_user

        old_invoices = old_payload.get("invoices", {}) if isinstance(old_payload, dict) else {}
        merged_invoices = dict(old_invoices) if isinstance(old_invoices, dict) else {}
        merged_invoices.update(INVOICES)

        payload = {
            "active_domain": ACTIVE_DOMAIN.get("base_url"),
            "users": merged_users,
            "invoices": merged_invoices,
        }
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)


def update_user_fields(chat_id: int, **fields) -> None:
    user = get_user(chat_id)
    db_patch: dict = {}
    for key, value in fields.items():
        if not hasattr(user, key):
            continue
        setattr(user, key, value)
        if key == "tg_username":
            db_patch["tg_username"] = value
        elif key == "port_user_id":
            db_patch["port_user_id"] = value
        elif key == "port_user_name":
            db_patch["port_user_name"] = value
        elif key == "centrifugo_secret":
            db_patch["centrifugo_secret"] = value
        elif key == "zooma_top_session":
            db_patch["zooma_top_session"] = value
        elif key == "zooma_top_session_expires_at":
            db_patch["zooma_top_session_expires_at"] = value
        elif key == "csrf_token":
            db_patch["csrf_token"] = value
        elif key == "fingerprint_now":
            db_patch["fingerprint_now"] = value
        elif key == "user_agent":
            db_patch["user_agent"] = value
        elif key == "subscription_tier":
            db_patch["subscription_tier"] = value
        elif key == "subscription_until_ts":
            db_patch["subscription_until_ts"] = value
        elif key == "subscription_paused":
            db_patch["subscription_paused"] = bool(value)
        elif key == "subscription_pause_started_ts":
            db_patch["subscription_pause_started_ts"] = value
        elif key == "subscription_frozen_left_sec":
            db_patch["subscription_frozen_left_sec"] = value
        elif key == "subscription_freeze_reason":
            db_patch["subscription_freeze_reason"] = value
        elif key == "proxy_failure_notified_at_ts":
            db_patch["proxy_failure_notified_at_ts"] = value
        elif key == "subscription_warn_1d_for_ts":
            db_patch["subscription_warn_1d_for_ts"] = value
        elif key == "stale_notified_at_ts":
            db_patch["stale_notified_at_ts"] = value
        elif key == "user_proxy_url":
            db_patch["proxy_url"] = value
        elif key == "user_proxy_order_id":
            db_patch["proxy_order_id"] = value
        elif key == "user_proxy_ip":
            db_patch["proxy_ip"] = value
        elif key == "user_proxy_port_http":
            db_patch["proxy_port_http"] = value
        elif key == "user_proxy_port_socks5":
            db_patch["proxy_port_socks5"] = value
        elif key == "user_proxy_login":
            db_patch["proxy_login"] = value
        elif key == "user_proxy_password":
            db_patch["proxy_password"] = value
        elif key == "user_proxy_scheme":
            db_patch["proxy_scheme"] = value
        elif key == "last_profile_message_id":
            _queue_profile_msg_patch(chat_id, value)
        elif key == "last_ui_message_id":
            _queue_profile_msg_patch(chat_id, value)
        elif key == "promo_activation_paused":
            db_patch["promo_activation_paused"] = bool(value)
        elif key == "promo_activation_mode":
            mode = str(value or "server").strip().lower()
            if mode not in {"server", "extension"}:
                mode = "server"
            setattr(user, key, mode)
            db_patch["promo_activation_mode"] = mode
        elif key == "extension_bound_chat_id":
            db_patch["extension_bound_chat_id"] = int(value or 0) or None
        elif key == "extension_bound_account_id":
            db_patch["extension_bound_account_id"] = str(value or "") or None
        elif key == "extension_bound_at_ts":
            db_patch["extension_bound_at_ts"] = int(value or 0) or None
    if any(k in _ACCOUNT_LEGACY_TO_JSON for k in fields.keys()):
        db_patch.update(_sync_active_account_from_user(chat_id))
    if db_patch:
        _sb_upsert_patch(chat_id, db_patch)
    save_state()


def load_state() -> None:
    started = time.time()
    if _SB_ENABLED:
        deadline = started + _SB_LOAD_RETRY_MAX_SEC
        attempt = 0
        last_error: Exception | None = None
        while True:
            attempt += 1
            try:
                _load_state_from_supabase_once(started)
                return
            except Exception as e:
                _sb_reset_client()
                last_error = e
                remaining = deadline - time.time()
                if remaining <= 0:
                    break
                delay = min(_SB_LOAD_RETRY_MAX_SLEEP_SEC, _SB_LOAD_RETRY_BASE_SEC * (2 ** min(attempt - 1, 6)), remaining)
                logger.warning(
                    "DB restore retry: attempt=%s delay=%.1fs remaining=%.1fs error=%s",
                    attempt, delay, max(0.0, remaining), e,
                )
                time.sleep(delay)
        logger.warning("DB restore warning after retries: %s", last_error)
        if _SB_REQUIRE_INITIAL_LOAD:
            raise RuntimeError(
                "Supabase initial load failed; refusing to start with empty runtime state. "
                "Check Render outbound DNS/network and SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY."
            ) from last_error
    if _LEGACY_FILE_IO_ENABLED:
        if not os.path.exists(STATE_FILE):
            return
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            payload = json.load(f)

        USERS.clear()
        INVOICES.clear()
        users = payload.get("users", {})
        if isinstance(users, dict):
            for chat_id_str, user_data in users.items():
                try:
                    chat_id = int(chat_id_str)
                except Exception:
                    continue
                if isinstance(user_data, dict):
                    USERS[chat_id] = _dict_to_user(user_data)

        active_domain = payload.get("active_domain")
        if isinstance(active_domain, str) and active_domain.strip():
            ACTIVE_DOMAIN["base_url"] = active_domain.rstrip("/")
        invoices = payload.get("invoices")
        if isinstance(invoices, dict):
            for invoice_id, invoice_data in invoices.items():
                if isinstance(invoice_id, str) and isinstance(invoice_data, dict):
                    INVOICES[invoice_id] = invoice_data


def get_all_chat_ids() -> list[int]:
    return list(USERS.keys())


def set_active_domain(base_url: str) -> None:
    ACTIVE_DOMAIN["base_url"] = base_url.rstrip("/")
    save_state()


def get_active_domain() -> Optional[str]:
    return ACTIVE_DOMAIN.get("base_url")


def save_invoice(invoice_id: str, payload: dict) -> None:
    INVOICES[invoice_id] = payload
    try:
        chat_id = int(payload.get("chat_id"))
        user = get_user(chat_id)
        user.last_invoice_id = invoice_id
        _persist_invoice_snapshot(chat_id, payload)
    except Exception:
        pass
    save_state()


def delete_invoice(invoice_id: str) -> None:
    inv = INVOICES.pop(invoice_id, None)
    if isinstance(inv, dict):
        try:
            chat_id = int(inv.get("chat_id"))
            user = get_user(chat_id)
            if str(user.last_invoice_id or "") == str(invoice_id):
                user.last_invoice_id = None
                _sb_upsert_patch(
                    chat_id,
                    {
                        "last_invoice_id": None,
                        "last_invoice_status": None,
                        "last_invoice_expires_at_ts": None,
                        "last_invoice_message_id": None,
                        "last_invoice_pay_url": None,
                        "last_invoice_payload": None,
                    },
                )
        except Exception:
            pass
    save_state()


def get_invoice(invoice_id: str) -> Optional[dict]:
    return INVOICES.get(invoice_id)


def get_all_invoices() -> dict[str, dict]:
    return INVOICES


def save_pending_order(order_id: str, payload: dict) -> None:
    if not order_id:
        return
    PENDING_ORDERS[order_id] = dict(payload)
    if _SB_ENABLED:
        _ensure_sb_writer_started()
        _SB_WRITE_QUEUE.put((-1, {"__pending_upsert__": {"order_id": order_id, **payload}}))


def update_pending_order_fields(order_id: str, **fields) -> None:
    if not order_id:
        return
    cur = PENDING_ORDERS.get(order_id)
    if not isinstance(cur, dict):
        return
    changed = False
    for k, v in fields.items():
        if cur.get(k) != v:
            cur[k] = v
            changed = True
    if not changed:
        return
    if _SB_ENABLED:
        _ensure_sb_writer_started()
        _SB_WRITE_QUEUE.put((-1, {"__pending_upsert__": {"order_id": order_id, **cur}}))


def get_pending_order(order_id: str) -> Optional[dict]:
    return PENDING_ORDERS.get(order_id)


def remove_pending_order(order_id: str) -> None:
    if not order_id:
        return
    PENDING_ORDERS.pop(order_id, None)
    if _SB_ENABLED:
        _ensure_sb_writer_started()
        _SB_WRITE_QUEUE.put((-1, {"__pending_delete__": {"order_id": order_id}}))


def get_all_pending_orders() -> dict[str, dict]:
    return PENDING_ORDERS


def record_paid_metric(amount_usdt: float, paid_at_ts: Optional[int] = None, amount_rub: Optional[float] = None) -> None:
    amt = float(amount_usdt or 0.0)
    if amt <= 0:
        return
    ts = int(paid_at_ts or time.time())
    day = datetime.fromtimestamp(ts, tz=timezone.utc).date().isoformat()
    BILLING_STATS["paid_total_usdt"] = float(BILLING_STATS.get("paid_total_usdt") or 0.0) + amt
    rub = max(0.0, float(amount_rub or 0.0))
    BILLING_STATS["paid_total_rub"] = float(BILLING_STATS.get("paid_total_rub") or 0.0) + rub
    BILLING_STATS["paid_total_count"] = int(BILLING_STATS.get("paid_total_count") or 0) + 1
    cur = BILLING_DAILY.get(day) or {"paid_usdt": 0.0, "paid_rub": 0.0, "paid_count": 0, "proxy_spent_rub": 0.0, "proxy_spent_count": 0}
    cur["paid_usdt"] = float(cur.get("paid_usdt") or 0.0) + amt
    cur["paid_rub"] = float(cur.get("paid_rub") or 0.0) + rub
    cur["paid_count"] = int(cur.get("paid_count") or 0) + 1
    BILLING_DAILY[day] = cur
    if _SB_ENABLED:
        _ensure_sb_writer_started()
        _SB_WRITE_QUEUE.put((-2, {"__billing_metric__": {"day": day, "paid_usdt": amt, "paid_rub": rub, "paid_count": 1}}))


def record_proxy_spent_metric(amount_rub: float, spent_at_ts: Optional[int] = None) -> None:
    amt = max(0.0, float(amount_rub or 0.0))
    if amt <= 0:
        return
    ts = int(spent_at_ts or time.time())
    day = datetime.fromtimestamp(ts, tz=timezone.utc).date().isoformat()
    BILLING_STATS["proxy_spent_total_rub"] = float(BILLING_STATS.get("proxy_spent_total_rub") or 0.0) + amt
    BILLING_STATS["proxy_spent_total_count"] = int(BILLING_STATS.get("proxy_spent_total_count") or 0) + 1
    cur = BILLING_DAILY.get(day) or {"paid_usdt": 0.0, "paid_rub": 0.0, "paid_count": 0, "proxy_spent_rub": 0.0, "proxy_spent_count": 0}
    cur["proxy_spent_rub"] = float(cur.get("proxy_spent_rub") or 0.0) + amt
    cur["proxy_spent_count"] = int(cur.get("proxy_spent_count") or 0) + 1
    BILLING_DAILY[day] = cur
    if _SB_ENABLED:
        _ensure_sb_writer_started()
        _SB_WRITE_QUEUE.put((-2, {"__billing_metric__": {"day": day, "proxy_spent_rub": amt, "proxy_spent_count": 1}}))


def adjust_paid_metric(delta_usdt: float, paid_at_ts: Optional[int] = None, delta_rub: Optional[float] = None) -> None:
    delta = float(delta_usdt or 0.0)
    if abs(delta) <= 1e-12:
        return
    ts = int(paid_at_ts or time.time())
    day = datetime.fromtimestamp(ts, tz=timezone.utc).date().isoformat()
    BILLING_STATS["paid_total_usdt"] = float(BILLING_STATS.get("paid_total_usdt") or 0.0) + delta
    drub = float(delta_rub or 0.0)
    BILLING_STATS["paid_total_rub"] = float(BILLING_STATS.get("paid_total_rub") or 0.0) + drub
    # count changes only by event cardinality:
    # +1 when delta>0 (new success), -1 when delta<0 (success rollback)
    BILLING_STATS["paid_total_count"] = int(BILLING_STATS.get("paid_total_count") or 0) + (1 if delta > 0 else -1)
    cur = BILLING_DAILY.get(day) or {"paid_usdt": 0.0, "paid_rub": 0.0, "paid_count": 0, "proxy_spent_rub": 0.0, "proxy_spent_count": 0}
    cur["paid_usdt"] = float(cur.get("paid_usdt") or 0.0) + delta
    cur["paid_rub"] = float(cur.get("paid_rub") or 0.0) + drub
    cur["paid_count"] = int(cur.get("paid_count") or 0) + (1 if delta > 0 else -1)
    BILLING_DAILY[day] = cur
    # guard from accidental negatives due to out-of-order admin actions
    if float(BILLING_STATS.get("paid_total_usdt") or 0.0) < 0:
        BILLING_STATS["paid_total_usdt"] = 0.0
    if float(BILLING_STATS.get("paid_total_rub") or 0.0) < 0:
        BILLING_STATS["paid_total_rub"] = 0.0
    if int(BILLING_STATS.get("paid_total_count") or 0) < 0:
        BILLING_STATS["paid_total_count"] = 0
    if BILLING_DAILY[day]["paid_usdt"] < 0:
        BILLING_DAILY[day]["paid_usdt"] = 0.0
    if BILLING_DAILY[day]["paid_rub"] < 0:
        BILLING_DAILY[day]["paid_rub"] = 0.0
    if BILLING_DAILY[day]["paid_count"] < 0:
        BILLING_DAILY[day]["paid_count"] = 0
    if _SB_ENABLED:
        _ensure_sb_writer_started()
        _SB_WRITE_QUEUE.put((-2, {"__billing_metric__": {"day": day, "paid_usdt": delta, "paid_rub": drub, "paid_count": (1 if delta > 0 else -1)}}))


def get_billing_metrics(now_ts: Optional[int] = None) -> dict[str, float | int]:
    ts = int(now_ts or time.time())
    now_day = datetime.fromtimestamp(ts, tz=timezone.utc).date()
    sum_7 = 0.0
    sum_30 = 0.0
    sum_7_rub = 0.0
    sum_30_rub = 0.0
    spent_7_rub = 0.0
    spent_30_rub = 0.0
    count_7 = 0
    count_30 = 0
    for day_s, row in BILLING_DAILY.items():
        try:
            day = datetime.fromisoformat(day_s).date()
        except Exception:
            continue
        age = (now_day - day).days
        if age < 0:
            continue
        usdt = float(row.get("paid_usdt") or 0.0)
        rub = float(row.get("paid_rub") or 0.0)
        spent = float(row.get("proxy_spent_rub") or 0.0)
        cnt = int(row.get("paid_count") or 0)
        if age <= 6:
            sum_7 += usdt
            sum_7_rub += rub
            spent_7_rub += spent
            count_7 += cnt
        if age <= 29:
            sum_30 += usdt
            sum_30_rub += rub
            spent_30_rub += spent
            count_30 += cnt
    spent_total_rub = float(BILLING_STATS.get("proxy_spent_total_rub") or 0.0)
    return {
        "paid_7d_usdt": round(sum_7, 6),
        "paid_30d_usdt": round(sum_30, 6),
        "paid_total_usdt": round(float(BILLING_STATS.get("paid_total_usdt") or 0.0), 6),
        "paid_7d_rub": round(sum_7_rub, 2),
        "paid_30d_rub": round(sum_30_rub, 2),
        "paid_total_rub": round(float(BILLING_STATS.get("paid_total_rub") or 0.0), 2),
        "proxy_spent_7d_rub": round(spent_7_rub, 2),
        "proxy_spent_30d_rub": round(spent_30_rub, 2),
        "proxy_spent_total_rub": round(spent_total_rub, 2),
        "net_7d_rub": round(sum_7_rub - spent_7_rub, 2),
        "net_30d_rub": round(sum_30_rub - spent_30_rub, 2),
        "net_total_rub": round(float(BILLING_STATS.get("paid_total_rub") or 0.0) - spent_total_rub, 2),
        "paid_7d_count": int(count_7),
        "paid_30d_count": int(count_30),
        "paid_total_count": int(BILLING_STATS.get("paid_total_count") or 0),
    }


def set_subscription(chat_id: int, tier: str, until_ts: int) -> None:
    user = get_user(chat_id)
    user.subscription_tier = tier
    user.subscription_until_ts = int(until_ts)
    user.subscription_paused = False
    user.subscription_pause_started_ts = None
    user.subscription_frozen_left_sec = None
    user.subscription_warn_1d_for_ts = None
    patch = {
        "subscription_tier": user.subscription_tier,
        "subscription_until_ts": user.subscription_until_ts,
        "subscription_paused": False,
        "subscription_pause_started_ts": None,
        "subscription_frozen_left_sec": None,
        "subscription_warn_1d_for_ts": None,
    }
    patch.update(_sync_active_account_from_user(chat_id))
    _sb_upsert_patch(chat_id, patch)
    save_state()


def clear_subscription(chat_id: int) -> None:
    user = get_user(chat_id)
    user.subscription_tier = None
    user.subscription_until_ts = None
    user.subscription_paused = False
    user.subscription_pause_started_ts = None
    user.subscription_frozen_left_sec = None
    user.subscription_warn_1d_for_ts = None
    patch = {
        "subscription_tier": None,
        "subscription_until_ts": None,
        "subscription_paused": False,
        "subscription_pause_started_ts": None,
        "subscription_frozen_left_sec": None,
        "subscription_warn_1d_for_ts": None,
    }
    patch.update(_sync_active_account_from_user(chat_id))
    _sb_upsert_patch(chat_id, patch)
    save_state()


def set_user_proxy(
    chat_id: int,
    proxy_url: Optional[str],
    country: Optional[str] = None,
    city: Optional[str] = None,
    order_id: Optional[str] = None,
    ip: Optional[str] = None,
    port_http: Optional[int] = None,
    port_socks5: Optional[int] = None,
    login: Optional[str] = None,
    password: Optional[str] = None,
    scheme: Optional[str] = None,
) -> None:
    user = get_user(chat_id)
    user.user_proxy_url = (proxy_url or None)
    user.user_proxy_country = (country or None)
    user.user_proxy_city = (city or None)
    user.user_proxy_order_id = (order_id or None)
    user.user_proxy_ip = (ip or None)
    user.user_proxy_port_http = int(port_http) if port_http else None
    user.user_proxy_port_socks5 = int(port_socks5) if port_socks5 else None
    user.user_proxy_login = (login or None)
    user.user_proxy_password = (password or None)
    user.user_proxy_scheme = (scheme or None)
    patch = {
        "proxy_url": user.user_proxy_url,
        "proxy_order_id": user.user_proxy_order_id,
        "proxy_ip": user.user_proxy_ip,
        "proxy_port_http": user.user_proxy_port_http,
        "proxy_port_socks5": user.user_proxy_port_socks5,
        "proxy_login": user.user_proxy_login,
        "proxy_password": user.user_proxy_password,
        "proxy_scheme": user.user_proxy_scheme,
    }
    patch.update(_sync_active_account_from_user(chat_id))
    _sb_upsert_patch(chat_id, patch)
    save_state()


def set_account_subscription(chat_id: int, account_id: str, tier: str, until_ts: int) -> None:
    patch_user_account(
        chat_id,
        account_id,
        subscription_tier=tier,
        subscription_until_ts=int(until_ts),
        subscription_paused=False,
        subscription_pause_started_ts=None,
        subscription_frozen_left_sec=None,
        subscription_freeze_reason=None,
        proxy_failure_notified_at_ts=None,
        subscription_warn_1d_for_ts=0,
        status=_account_status_from_until(int(until_ts)),
    )


def set_account_proxy(
    chat_id: int,
    account_id: str,
    proxy_url: Optional[str],
    country: Optional[str] = None,
    city: Optional[str] = None,
    order_id: Optional[str] = None,
    ip: Optional[str] = None,
    port_http: Optional[int] = None,
    port_socks5: Optional[int] = None,
    login: Optional[str] = None,
    password: Optional[str] = None,
    scheme: Optional[str] = None,
) -> None:
    patch_user_account(
        chat_id,
        account_id,
        proxy_url=(proxy_url or ""),
        proxy_country=(country or ""),
        proxy_city=(city or ""),
        proxy_order_id=(order_id or ""),
        proxy_ip=(ip or ""),
        proxy_port_http=(int(port_http) if port_http else None),
        proxy_port_socks5=(int(port_socks5) if port_socks5 else None),
        proxy_login=(login or ""),
        proxy_password=(password or ""),
        proxy_scheme=(scheme or "socks5"),
        proxy_runtime_status="healthy",
        proxy_runtime_reason="",
        proxy_runtime_source="proxy_update",
        proxy_runtime_domain="",
        proxy_unavailable_since_ts=0,
        proxy_recovery_successes=0,
        proxy_runtime_alerted_at_ts=0,
        proxy_ping_error="",
    )


def has_active_account_subscription(chat_id: int, account_id: Optional[str], now_ts: int) -> bool:
    acc = get_user_account(chat_id, account_id)
    if not acc:
        return False
    if _boolish(acc.get("subscription_paused")):
        return False
    until_ts = int(acc.get("subscription_until_ts") or 0)
    return until_ts > int(now_ts)


def get_or_create_empty_addon_account(chat_id: int) -> dict:
    accounts = get_user_accounts(chat_id, include_empty=True)
    for acc in accounts:
        if str(acc.get("billing_type") or "") == "addon" and int(acc.get("subscription_until_ts") or 0) <= 0:
            return dict(acc)
    return create_user_account_slot(chat_id, billing_type="addon")


def has_active_subscription(chat_id: int, now_ts: int) -> bool:
    user = get_user(chat_id)
    if bool(user.subscription_paused):
        return False
    if not user.subscription_until_ts:
        return False
    return int(user.subscription_until_ts) > int(now_ts)


def pause_account_subscription(chat_id: int, account_id: str, now_ts: Optional[int] = None, reason: str = "manual") -> dict:
    ts = int(now_ts or time.time())
    acc = get_user_account(int(chat_id), account_id)
    if not acc:
        raise KeyError(f"account_not_found:{account_id}")

    prev_until = int(acc.get("subscription_until_ts") or 0)
    left = int(acc.get("subscription_frozen_left_sec") or 0) if _boolish(acc.get("subscription_paused")) else max(0, prev_until - ts)

    patched = patch_user_account(
        int(chat_id),
        account_id,
        subscription_paused=True,
        subscription_pause_started_ts=ts,
        subscription_frozen_left_sec=left,
        subscription_freeze_reason=str(reason or "manual"),
        proxy_failure_notified_at_ts=(ts if str(reason or "") == "proxy_unavailable" else None),
        connected=False,
        status="frozen",
    )
    return {
        "account_id": str(account_id),
        "left_sec": left,
        "prev_until_ts": prev_until,
        "pause_started_ts": ts,
        "account": patched,
    }


def resume_account_subscription(chat_id: int, account_id: str, now_ts: Optional[int] = None) -> dict:
    ts = int(now_ts or time.time())
    acc = get_user_account(int(chat_id), account_id)
    if not acc:
        raise KeyError(f"account_not_found:{account_id}")

    left = int(acc.get("subscription_frozen_left_sec") or 0)
    if left <= 0:
        left = max(0, int(acc.get("subscription_until_ts") or 0) - int(acc.get("subscription_pause_started_ts") or ts))
    new_until = ts + left if left > 0 else int(acc.get("subscription_until_ts") or 0)

    patched = patch_user_account(
        int(chat_id),
        account_id,
        subscription_until_ts=int(new_until),
        subscription_paused=False,
        subscription_pause_started_ts=None,
        subscription_frozen_left_sec=None,
        subscription_freeze_reason=None,
        proxy_failure_notified_at_ts=None,
        subscription_warn_1d_for_ts=0,
        status=_account_status_from_until(int(new_until)),
    )
    return {
        "account_id": str(account_id),
        "left_sec": left,
        "new_until_ts": int(new_until),
        "account": patched,
    }


def pause_subscription(chat_id: int, now_ts: Optional[int] = None) -> dict:
    user = get_user(chat_id)
    ts = int(now_ts or time.time())
    prev_until = int(user.subscription_until_ts or 0)
    left = max(0, prev_until - ts)
    user.subscription_paused = True
    user.subscription_pause_started_ts = ts
    user.subscription_frozen_left_sec = left
    _sb_upsert_patch(chat_id, {
        "subscription_paused": True,
        "subscription_pause_started_ts": ts,
        "subscription_frozen_left_sec": left,
    })
    save_state()
    return {"left_sec": left, "prev_until_ts": prev_until}


def resume_subscription(chat_id: int, now_ts: Optional[int] = None) -> dict:
    user = get_user(chat_id)
    ts = int(now_ts or time.time())
    left = int(user.subscription_frozen_left_sec or 0)
    if left > 0:
        user.subscription_until_ts = ts + left
    user.subscription_paused = False
    user.subscription_pause_started_ts = None
    user.subscription_frozen_left_sec = None
    _sb_upsert_patch(chat_id, {
        "subscription_until_ts": user.subscription_until_ts,
        "subscription_paused": False,
        "subscription_pause_started_ts": None,
        "subscription_frozen_left_sec": None,
    })
    save_state()
    return {"new_until_ts": int(user.subscription_until_ts or 0), "left_sec": left}


def get_all_tariffs() -> dict[str, dict]:
    if not TARIFFS_RUNTIME:
        _seed_default_tariffs_if_empty()
    return TARIFFS_RUNTIME


def upsert_tariff(
    *,
    key: str,
    title: Optional[str] = None,
    price_rub_base: Optional[int] = None,
    days: Optional[int] = None,
    discount_pct: Optional[float] = None,
    active: Optional[bool] = None,
    tariff_type: Optional[str] = None,
    sort_order: Optional[int] = None,
) -> dict:
    k = str(key or "").strip()
    if not k:
        raise ValueError("tariff_key_empty")
    if not TARIFFS_RUNTIME:
        _seed_default_tariffs_if_empty()
    cur = dict(TARIFFS_RUNTIME.get(k) or {
        "key": k,
        "title": k,
        "price_rub_base": 700,
        "days": 30,
        "discount_pct": 0.0,
        "active": True,
        "tariff_type": "main",
        "sort_order": 100,
    })
    if title is not None:
        cur["title"] = str(title).strip() or k
    if price_rub_base is not None:
        cur["price_rub_base"] = int(price_rub_base)
    if days is not None:
        cur["days"] = int(days)
    if discount_pct is not None:
        cur["discount_pct"] = float(discount_pct)
    if active is not None:
        cur["active"] = bool(active)
    if tariff_type is not None:
        ttype = str(tariff_type or "main").strip()
        cur["tariff_type"] = ttype if ttype in {"main", "addon"} else "main"
    cur.setdefault("tariff_type", "main")
    if sort_order is not None:
        cur["sort_order"] = int(sort_order)
    cur.setdefault("sort_order", 100)
    TARIFFS_RUNTIME[k] = cur
    _sb_upsert_tariff(cur)
    return cur


def delete_tariff(key: str) -> bool:
    k = str(key or "").strip()
    if not k:
        return False
    if k not in TARIFFS_RUNTIME:
        return False
    TARIFFS_RUNTIME.pop(k, None)
    _sb_delete_tariff(k)
    return True


def save_connected_account(
    chat_id: int,
    tg_username: Optional[str],
    port_user_id: str,
    port_user_name: str,
    centrifugo_socket: Optional[str],
    centrifugo_secret: str,
    zooma_top_session: str,
    zooma_top_session_expires_at: Optional[str],
    csrf_token: Optional[str],
    fingerprint_now: Optional[str],
    user_agent: Optional[str],
) -> None:
    user = get_user(chat_id)
    if tg_username is not None:
        user.tg_username = tg_username
    accounts = ensure_user_accounts(chat_id)
    aid = str(user.active_account_id or (accounts[0].get("account_id") if accounts else "acc_1") or "acc_1")
    current = get_user_account(chat_id, aid) or {}
    socket_value = (centrifugo_socket or "").strip() or str(current.get("centrifugo_socket") or DEFAULT_CENTRIFUGO_SOCKET)
    fields = {
        "connected": False,
        "server_session_state": {},
        "port_user_id": str(port_user_id or current.get("port_user_id") or ""),
        "port_user_name": str(port_user_name or current.get("port_user_name") or ""),
        "centrifugo_socket": socket_value,
        "centrifugo_secret": str(centrifugo_secret or current.get("centrifugo_secret") or ""),
        "zooma_top_session": str(zooma_top_session or current.get("zooma_top_session") or ""),
        "zooma_top_session_expires_at": zooma_top_session_expires_at or current.get("zooma_top_session_expires_at"),
        "csrf_token": str(csrf_token or current.get("csrf_token") or ""),
        "fingerprint_now": str(fingerprint_now or current.get("fingerprint_now") or ""),
        "user_agent": str(user_agent or current.get("user_agent") or ""),
    }
    if str(current.get("chat_ai_last_error") or "") == "server_session_stale":
        fields["chat_ai_last_error"] = ""
    patch_user_account(chat_id, aid, **fields)
    user.waiting_token = False
    _sb_upsert_patch(chat_id, {"tg_username": user.tg_username})
    save_state()
