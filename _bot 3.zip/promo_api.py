import asyncio
import contextlib
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import os
import time
import json
import logging
import uuid
import io
import zipfile
import random
import string
import secrets
from typing import Optional
from urllib.parse import parse_qs, urlparse
from urllib.parse import quote

from fastapi import FastAPI, Form, Header, HTTPException, Query, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from promo_engine import PromoEngine
from extension_ws import ExtensionWsManager, get_extension_entitlement
from extension_crypto import create_extension_challenge, extension_crypto_debug, extension_debug_id, extension_key_id, validate_public_jwk, verify_extension_challenge
from billing import BillingService
from steam_webapp import app as steam_webapp_app
from tg_webapp import app as tg_webapp_app
from yandex_webapp import app as yandex_webapp_app
from config import ADMIN_PANEL_TOKEN, ADMIN_CHAT_ID, PROXYLINE_PRICE_BUFFER_PCT, BOT_TOKEN, PUBLIC_WEB_BASE_URL, EXTENSION_WS_SECRET, EXTENSION_PROMO_TIMEOUT_SEC, CHAT_AI_GROQ_API_KEY
from config import PROXYLINE_COUNTRY_POOL, PROXYLINE_COUNTRY_RU
from config import EXPIRED_ORDER_KEEP_DAYS
from zooma import get_user_agent_pool, verify_token
from store import (
    USERS,
    get_all_pending_orders,
    has_active_subscription,
    get_billing_metrics,
    get_pending_order,
    update_pending_order_fields,
    adjust_paid_metric,
    record_proxy_spent_metric,
    get_all_tariffs,
    upsert_tariff,
    delete_tariff,
    set_subscription,
    clear_subscription,
    pause_subscription,
    resume_subscription,
    pause_account_subscription,
    resume_account_subscription,
    get_user,
    set_user_proxy,
    update_user_fields,
    get_active_domain,
    get_user_accounts,
    get_user_account,
    patch_user_account,
    bind_extension,
    register_extension_key,
    unbind_extension,
    hash_extension_installation_id,
    clear_account_casino_data,
    reset_account_casino_identity,
    normalize_chat_ai_api_keys,
    mask_chat_ai_api_key,
    normalize_chat_ai_rate_limits,
    normalize_server_session_state,
    account_server_session_is_stale,
    mark_account_server_session_stale,
    mark_account_server_session_notified,
    clear_account_server_session_state,
    set_account_proxy,
    set_account_subscription,
    has_active_account_subscription,
    register_app_state_pusher,
    get_user_promo_month_snapshot,
    persist_user_state_now,
    normalize_chat_ai_rain_miss_messages,
)

logger = logging.getLogger("promo_api")


def _is_admin_runtime_chat(chat_id: int) -> bool:
    try:
        return bool(ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID))
    except Exception:
        return False


def _account_proxy_allowed_for_runtime(chat_id: int, account_id: Optional[str] = None) -> bool:
    if _is_admin_runtime_chat(chat_id):
        return True
    if account_id:
        acc = get_user_account(int(chat_id), account_id) or {}
        if account_server_session_is_stale(acc):
            return False
        return bool(str(acc.get("proxy_url") or "").strip())
    u = get_user(int(chat_id))
    return bool(str(getattr(u, "user_proxy_url", "") or "").strip())


class PromoEnqueueBody(BaseModel):
    promo: str = Field(min_length=1, max_length=64)
    channel: str = Field(default="tg_watcher", max_length=256)
    channel_key: Optional[str] = Field(default=None, max_length=128)
    msg_id: Optional[int] = None
    post_utc: Optional[str] = None
    seen_utc: Optional[str] = None
    delay_sec: Optional[float] = None
    source: str = Field(default="tg_watcher", max_length=64)


class PromoPauseBody(BaseModel):
    paused: bool = False
    account_id: Optional[str] = Field(default=None, max_length=64)


class AdminPromoActivationModeBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = None
    account_id: Optional[str] = Field(default=None, max_length=64)
    mode: str = Field(default="server", max_length=16)


class AppPromoActivationModeBody(BaseModel):
    account_id: Optional[str] = Field(default=None, max_length=64)
    mode: str = Field(default="server", max_length=16)


class AppExtensionUnbindBody(BaseModel):
    account_id: Optional[str] = Field(default=None, max_length=64)


class AppExtensionReloadBody(BaseModel):
    account_id: Optional[str] = Field(default=None, max_length=64)


class ExtensionKeyRegisterBody(BaseModel):
    public_key_jwk: dict
    key_id: str = Field(min_length=64, max_length=64)


class ExtensionProofBody(BaseModel):
    challenge_id: str = Field(min_length=16, max_length=256)
    key_id: str = Field(min_length=64, max_length=64)
    signature: str = Field(min_length=32, max_length=1024)


class AdminStopAuthBody(BaseModel):
    provider: str = Field(default="all", max_length=16)
    sid: Optional[str] = Field(default=None, max_length=256)
    chat_id: Optional[int] = None


class AdminCreateInvoiceBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    tariff_key: str = Field(default="lite", max_length=64)
    days: Optional[int] = Field(default=30, ge=1, le=365)
    custom_price_rub: Optional[int] = Field(default=None, ge=1, le=1_000_000)

class AdminSetOrderStatusBody(BaseModel):
    order_id: str = Field(min_length=1, max_length=64)
    status: str = Field(min_length=1, max_length=16)  # pending|paid|expired|failed|cancelled
    reason: Optional[str] = Field(default=None, max_length=500)
    notify_user: bool = Field(default=True)


class AdminTariffCreateBody(BaseModel):
    key: str = Field(min_length=1, max_length=64)
    title: Optional[str] = Field(default=None, max_length=128)
    price_rub_base: int = Field(ge=1, le=1_000_000)
    days: int = Field(ge=1, le=3650)
    discount_pct: float = Field(default=0.0, ge=0.0, le=95.0)
    active: bool = Field(default=True)
    tariff_type: str = Field(default="main", max_length=16)
    sort_order: int = Field(default=100, ge=0, le=100000)


class AdminTariffUpdateBody(BaseModel):
    key: str = Field(min_length=1, max_length=64)
    title: Optional[str] = Field(default=None, max_length=128)
    price_rub_base: Optional[int] = Field(default=None, ge=1, le=1_000_000)
    days: Optional[int] = Field(default=None, ge=1, le=3650)
    discount_pct: Optional[float] = Field(default=None, ge=0.0, le=95.0)
    active: Optional[bool] = None
    tariff_type: Optional[str] = Field(default=None, max_length=16)
    sort_order: Optional[int] = Field(default=None, ge=0, le=100000)


class AdminTariffDeleteBody(BaseModel):
    key: str = Field(min_length=1, max_length=64)


class AdminProxyBuyOneBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    period_days: int = Field(default=30, ge=1, le=365)
    country_mode: str = Field(default="random", max_length=16)  # random|manual
    country: Optional[str] = Field(default=None, max_length=8)
    proxy_type: str = Field(default="dedicated_ipv4", max_length=32)  # dedicated_ipv4|shared_ipv4
    exclude_no_access_from_ru: bool = Field(default=True)
    confirm: bool = Field(default=False)


class AdminProxyBuyBatchBody(BaseModel):
    count: int = Field(default=1, ge=1, le=200)
    period_days: int = Field(default=30, ge=1, le=365)
    country_mode: str = Field(default="random", max_length=16)  # random|manual|multi
    country: Optional[str] = Field(default=None, max_length=8)
    countries: Optional[list[str]] = None
    proxy_type: str = Field(default="dedicated_ipv4", max_length=32)  # dedicated_ipv4|shared_ipv4
    exclude_no_access_from_ru: bool = Field(default=True)
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    confirm: bool = Field(default=False)


class AdminSubGrantBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    tariff_key: str = Field(default="lite", max_length=64)
    days: Optional[int] = Field(default=None, ge=1, le=3650)
    until_ts: Optional[int] = Field(default=None, ge=0)

class AdminSubReduceBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    days: Optional[int] = Field(default=None, ge=1, le=3650)
    until_ts: Optional[int] = Field(default=None, ge=0)

class AdminSubSimpleBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)

class AdminSubChangeTierBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    tariff_key: str = Field(default="lite", max_length=64)

class AdminUserProxySetBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    host: str = Field(min_length=1, max_length=255)
    login: Optional[str] = Field(default=None, max_length=255)
    password: Optional[str] = Field(default=None, max_length=255)
    port_http: Optional[int] = Field(default=None, ge=1, le=65535)
    port_socks5: Optional[int] = Field(default=None, ge=1, le=65535)
    scheme: str = Field(default="socks5", max_length=16)

class AdminUserProxyClearBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)

class AdminUserAgentSetBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: Optional[str] = Field(default=None, max_length=64)
    user_agent: str = Field(min_length=16, max_length=1024)


class AdminChatAiToggleBody(BaseModel):
    chat_id: int
    account_id: str = Field(min_length=1, max_length=64)
    enabled: bool
    use_default_key: Optional[bool] = None
    interval_min_sec: Optional[int] = Field(default=None, ge=60, le=86400)
    interval_max_sec: Optional[int] = Field(default=None, ge=60, le=86400)


class AppChatAiSettingsBody(BaseModel):
    account_id: Optional[str] = Field(default=None, max_length=64)
    enabled: Optional[bool] = None
    api_key: Optional[str] = Field(default=None, max_length=4096)
    interval_min_sec: Optional[int] = Field(default=None, ge=60, le=86400)
    interval_max_sec: Optional[int] = Field(default=None, ge=60, le=86400)
    rain_miss_messages: Optional[str] = Field(default=None, max_length=20000)


class AppAccountCasinoResetBody(BaseModel):
    account_id: str = Field(min_length=1, max_length=64)


class AdminAccountCasinoResetBody(BaseModel):
    chat_id: Optional[int] = None
    username: Optional[str] = Field(default=None, max_length=128)
    account_id: str = Field(min_length=1, max_length=64)


class AppSelectAccountBody(BaseModel):
    account_id: str = Field(min_length=1, max_length=64)


class AppManualProxyBody(BaseModel):
    account_id: str = Field(min_length=1, max_length=64)
    host: str = Field(min_length=1, max_length=255)
    port: int = Field(ge=1, le=65535)
    login: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=255)


class AppCreateInvoiceBody(BaseModel):
    tariff_key: str = Field(min_length=1, max_length=64)


class AppConnectPromptBody(BaseModel):
    account_id: str = Field(min_length=1, max_length=64)


class AppCancelInvoiceBody(BaseModel):
    invoice_id: Optional[str] = Field(default=None, max_length=64)

templates = Jinja2Templates(directory="templates")


def build_promo_app(engine: PromoEngine, billing: BillingService) -> FastAPI:
    app = FastAPI()

    admin_sessions: dict[str, dict] = {}
    admin_login_attempts: dict[str, list[float]] = {}
    extension_codes: dict[str, dict] = {}
    EXTENSION_CODE_TTL_SEC = 5 * 60
    ADMIN_LOGIN_PATH = os.getenv("ZOOMA_ADMIN_LOGIN_PATH", "/wk7kru/iwmKna").strip() or "/wk7kru/iwmKna"
    ADMIN_PANEL_PATH = os.getenv("ZOOMA_ADMIN_PANEL_PATH", "/iqpdm/pwmY81").strip() or "/iqpdm/pwmY81"
    ADMIN_API_PREFIX = os.getenv("ZOOMA_ADMIN_API_PREFIX", "/g5nqz/a7T2v9/api").strip() or "/g5nqz/a7T2v9/api"
    for _name, _value in {"ZOOMA_ADMIN_LOGIN_PATH": ADMIN_LOGIN_PATH, "ZOOMA_ADMIN_PANEL_PATH": ADMIN_PANEL_PATH, "ZOOMA_ADMIN_API_PREFIX": ADMIN_API_PREFIX}.items():
        if not _value.startswith("/"):
            _value = "/" + _value
        if _value in {"/", "/admin", "/admin/"} or _value.startswith("/admin/"):
            raise RuntimeError(f"{_name} must be a hidden non-/admin path")
        if _name == "ZOOMA_ADMIN_LOGIN_PATH":
            ADMIN_LOGIN_PATH = _value.rstrip("/")
        elif _name == "ZOOMA_ADMIN_PANEL_PATH":
            ADMIN_PANEL_PATH = _value.rstrip("/")
        else:
            ADMIN_API_PREFIX = _value.rstrip("/")
    ADMIN_SESSION_COOKIE = "zooma_admin_session"
    ADMIN_CSRF_COOKIE = "zooma_admin_csrf"

    def _is_tg_host(request: Request) -> bool:
        host = str(request.headers.get("host") or "").split(":", 1)[0].lower()
        return host.startswith("tg.")

    def _tg_url(request: Request) -> str:
        host = str(request.headers.get("host") or "").split(":", 1)[0]
        target = host if host.lower().startswith("tg.") else f"tg.{host}"
        return str(request.url.replace(netloc=target))

    def _tg_root_url(request: Request) -> str:
        host = str(request.headers.get("host") or "").split(":", 1)[0]
        target = host if host.lower().startswith("tg.") else f"tg.{host}"
        return str(request.url.replace(netloc=target, path="/", query=""))

    def _security_headers(resp: Response) -> Response:
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        resp.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        #resp.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://api.qrserver.com https://telegram.org https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap; style-src 'self' 'unsafe-inline'; img-src 'self' data: https://api.qrserver.com; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        return resp

    def _admin_session_ok(request: Request) -> bool:
        sid = request.cookies.get(ADMIN_SESSION_COOKIE, "")
        sess = admin_sessions.get(sid)
        if not sess or float(sess.get("expires", 0)) < time.time():
            admin_sessions.pop(sid, None)
            return False
        sess["last_seen"] = time.time()
        return True

    def _csrf_ok(request: Request) -> bool:
        if request.method.upper() in {"GET", "HEAD", "OPTIONS"}:
            return True
        sid = request.cookies.get(ADMIN_SESSION_COOKIE, "")
        sess = admin_sessions.get(sid) or {}
        got = request.headers.get("X-CSRF-Token") or request.cookies.get(ADMIN_CSRF_COOKIE)
        return bool(got and secrets.compare_digest(str(got), str(sess.get("csrf") or "")))

    @app.middleware("http")
    async def _app_security_and_routing(request: Request, call_next):
        path = request.url.path
        tg_host = _is_tg_host(request)
        if path == "/" and not tg_host:
            return _security_headers(RedirectResponse(_tg_root_url(request), status_code=307))
        if (path.startswith("/auth-api") or path == "/dowl" or path.startswith("/extension/")) and not tg_host:
            return _security_headers(RedirectResponse(_tg_url(request), status_code=307))
        if path == "/admin" or path.startswith("/admin/"):
            return _security_headers(RedirectResponse(_tg_root_url(request), status_code=307))
        if path == ADMIN_PANEL_PATH or path.startswith(ADMIN_API_PREFIX + "/"):
            if not _admin_session_ok(request):
                return _security_headers(RedirectResponse(ADMIN_LOGIN_PATH, status_code=302))
            if not _csrf_ok(request):
                return _security_headers(Response("CSRF blocked", status_code=403))
            if path.startswith(ADMIN_API_PREFIX + "/"):
                request.scope["path"] = "/admin/api" + path[len(ADMIN_API_PREFIX):]
                request.scope["raw_path"] = request.scope["path"].encode("ascii", "ignore")
            if "token=" not in request.scope.get("query_string", b"").decode("latin1"):
                qs = request.scope.get("query_string", b"")
                request.scope["query_string"] = qs + (b"&" if qs else b"") + b"token=" + ADMIN_PANEL_TOKEN.encode()
        response = await call_next(request)
        if response.status_code == 404:
            safe_main_prefixes = ("/app", "/auth/webapp", ADMIN_LOGIN_PATH, ADMIN_PANEL_PATH, ADMIN_API_PREFIX, "/internal", "/healthz")
            safe_tg_prefixes = ("/auth-api", "/dowl", "/extension")
            if not tg_host and not any(path == p or path.startswith(p + "/") for p in safe_main_prefixes):
                return _security_headers(RedirectResponse(_tg_root_url(request), status_code=307))
            if tg_host and not any(path == p or path.startswith(p + "/") for p in safe_tg_prefixes):
                return _security_headers(RedirectResponse(_tg_root_url(request), status_code=307))
        return _security_headers(response)

    app.mount("/auth/webapp/steam", steam_webapp_app)
    app.mount("/auth/webapp/tg", tg_webapp_app)
    app.mount("/auth/webapp/yandex", yandex_webapp_app)

    omsk_tz = timezone(timedelta(hours=6))

    def _log_now() -> str:
        return datetime.now(omsk_tz).strftime("%Y-%m-%d %H:%M:%S")

    async def _notify_admin(text: str) -> None:
        bot = getattr(engine, "_telegram_bot", None)
        if not bot or not ADMIN_CHAT_ID:
            return
        try:
            await bot.send_message(chat_id=ADMIN_CHAT_ID, text=text)
        except Exception as e:
            logger.warning("admin notify failed: %s", e)

    async def _notify_server_session_stale_once(chat_id: int, account_id: str, account: dict | None = None) -> None:
        row = dict(account or get_user_account(int(chat_id), str(account_id)) or {})
        state = normalize_server_session_state(row.get("server_session_state"))
        if int(state.get("notified_at_ts") or 0):
            return
        slot = int(row.get("slot") or 1)
        name = str(row.get("port_user_name") or "-").strip() or "-"
        casino_id = str(row.get("port_user_id") or "-").strip() or "-"
        account_line = f"Аккаунт: #{slot} · {name} | ID {casino_id}"
        bot = getattr(engine, "_telegram_bot", None)
        if bot:
            with contextlib.suppress(Exception):
                await bot.send_message(
                    chat_id=int(chat_id),
                    text="⚠️ Сессия протухла\n\nТребуется повторно подключить аккаунт казино.\n" + account_line,
                )
        username = str(getattr(get_user(int(chat_id)), "tg_username", "") or "-")
        await _notify_admin(
            f"⚠️ Сессия пользователя протухла\nchat_id: {chat_id}\nuser: {username}\n{account_line}"
        )
        mark_account_server_session_notified(int(chat_id), str(account_id))

    seen_promos: dict[str, float] = {}
    running_promos: set[str] = set()
    seen_ttl_sec = int(os.getenv("ZOOMA_INTERNAL_TG_QUEUED_PROMO_TTL_SEC", "1800"))
    extension_ws_manager = ExtensionWsManager(promo_timeout_sec=EXTENSION_PROMO_TIMEOUT_SEC)
    engine.set_extension_ws_manager(extension_ws_manager)
    app_ws_clients: dict[int, set[WebSocket]] = {}
    app_ws_snapshots: dict[WebSocket, dict] = {}

    def _require_admin(token: Optional[str]) -> None:
        if not ADMIN_PANEL_TOKEN or token != ADMIN_PANEL_TOKEN:
            raise HTTPException(status_code=403, detail="forbidden")

    def _validate_tg_init_data_or_raise(init_data: str) -> dict:
        raw = str(init_data or "").strip()
        if not raw:
            raise HTTPException(status_code=401, detail="empty_init_data")
        parsed = parse_qs(raw, keep_blank_values=True)
        got_hash = str((parsed.get("hash") or [""])[0] or "").strip()
        if not got_hash:
            raise HTTPException(status_code=401, detail="missing_hash")
        data_check_items = []
        for k in sorted(parsed.keys()):
            if k == "hash":
                continue
            v = str((parsed.get(k) or [""])[0] or "")
            data_check_items.append(f"{k}={v}")
        data_check_string = "\n".join(data_check_items)
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode("utf-8"), hashlib.sha256).digest()
        calc_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc_hash, got_hash):
            raise HTTPException(status_code=401, detail="bad_hash")
        auth_date = int(str((parsed.get("auth_date") or ["0"])[0] or "0"))
        now_ts = int(time.time())
        if auth_date <= 0 or (now_ts - auth_date) > 24 * 60 * 60:
            raise HTTPException(status_code=401, detail="init_data_expired")
        user_raw = str((parsed.get("user") or ["{}"])[0] or "{}")
        try:
            tg_user = json.loads(user_raw)
        except Exception:
            raise HTTPException(status_code=401, detail="bad_user_json")
        if not isinstance(tg_user, dict):
            raise HTTPException(status_code=401, detail="bad_user_json")
        with contextlib.suppress(Exception):
            cid = int(tg_user.get("id"))
            tg_username = str(tg_user.get("username") or "").strip()
            u = get_user(cid)
            if tg_username and tg_username != (u.tg_username or ""):
                update_user_fields(cid, tg_username=f"@{tg_username}" if not tg_username.startswith("@") else tg_username)
        return tg_user


    def _chat_ai_public_fields(acc: dict) -> dict:
        keys = normalize_chat_ai_api_keys((acc or {}).get("chat_ai_api_key"))
        masks = [mask_chat_ai_api_key(key) for key in keys]
        mode = str((acc or {}).get("promo_activation_mode") or "server").strip().lower()
        if mode not in {"server", "extension"}:
            mode = "server"
        chat_ai_last_error = str((acc or {}).get("chat_ai_last_error") or "").strip()
        # Защита пользовательского Mini App от legacy-ошибок поездов.
        # Состояние поездов хранится отдельно в train jobs.
        if chat_ai_last_error.startswith("train_join_"):
            chat_ai_last_error = ""
        extension_only_errors = {
            "extension_offline",
            "managed_tab_not_ready",
            "extension_manager_unavailable",
            "extension_timeout",
            "extension_send_error",
            "extension_not_bound",
            "extension_subscription_inactive",
            "extension_mode",
            "wrong_activation_mode",
            "activation_mode_changed",
        }
        server_only_errors = {
            "server_session_stale",
            "no_proxy",
            "proxy_unavailable",
            "proxy_site_unreachable",
            "proxy_recovering",
            "no_zooma_top_session",
            "no_csrf_token",
            "no_port_user_id",
            "active_domain_missing",
        }
        if (mode == "server" and chat_ai_last_error in extension_only_errors) or (
            mode == "extension" and chat_ai_last_error in server_only_errors
        ):
            chat_ai_last_error = ""
        recent = []
        for item in list((acc or {}).get("chat_ai_recent_messages") or [])[-3:]:
            if not isinstance(item, dict):
                continue
            recent.append({
                "sent_at_ts": int(item.get("sent_at_ts") or 0),
                "text": str(item.get("text") or "")[:500],
                "target": str(item.get("target") or "")[:255],
                "source": str(item.get("source") or "regular")[:32],
                "mode": str(item.get("mode") or "server")[:16],
            })
        pending = dict((acc or {}).get("chat_ai_pending_task") or {})
        session_state = normalize_server_session_state((acc or {}).get("server_session_state"))
        return {
            "chat_ai_enabled": bool((acc or {}).get("chat_ai_enabled")),
            "chat_ai_has_api_key": bool(keys),
            "chat_ai_api_key_masked": masks[0] if masks else "",
            "chat_ai_api_key_masks": masks,
            "chat_ai_key_count": len(keys),
            "chat_ai_key_mode": str((acc or {}).get("chat_ai_key_mode") or "user"),
            "chat_ai_interval_min_sec": int((acc or {}).get("chat_ai_interval_min_sec") or 10 * 60),
            "chat_ai_interval_max_sec": int((acc or {}).get("chat_ai_interval_max_sec") or 25 * 60),
            "chat_ai_next_run_ts": int((acc or {}).get("chat_ai_next_run_ts") or 0),
            "chat_ai_last_error": chat_ai_last_error,
            "chat_ai_last_sent_ts": int((acc or {}).get("chat_ai_last_sent_ts") or 0),
            "chat_ai_recent_messages": recent,
            "chat_ai_pending_status": str(pending.get("status") or ""),
            "chat_ai_pending_retry_at_ts": int(pending.get("retry_at_ts") or 0),
            "chat_ai_rain_miss_messages": normalize_chat_ai_rain_miss_messages((acc or {}).get("chat_ai_rain_miss_messages")),
            "chat_ai_cycle_started_ts": int((acc or {}).get("chat_ai_cycle_started_ts") or 0),
            "chat_ai_rest_until_ts": int((acc or {}).get("chat_ai_rest_until_ts") or 0),
            "chat_ai_rate_limits": normalize_chat_ai_rate_limits((acc or {}).get("chat_ai_rate_limits")),
            "server_session_stale": bool(session_state.get("stale")),
            "server_session_state": session_state,
        }

    def _build_user_app_state(chat_id: int) -> dict:
        now_ts = int(time.time())
        u = get_user(chat_id)
        promo_month = get_user_promo_month_snapshot(int(chat_id), now_ts=now_ts)
        accounts = [_account_admin_row(int(chat_id), acc, now_ts) for acc in get_user_accounts(int(chat_id), include_empty=True)]
        for a in accounts:
            aid = str(a.get("account_id") or "acc_1")
            mode = str(
                a.get("promo_activation_mode") or "server"
            ).strip().lower()
            server_ws_live = False
            with contextlib.suppress(Exception):
                server_ws_live = bool(
                    ws_manager.is_connected(
                        int(chat_id),
                        account_id=aid,
                    )
                )
            a["ws_live"] = (
                bool(a.get("extension_ws_live"))
                if mode == "extension"
                else server_ws_live
            )
            a["server_ws_live"] = (
                server_ws_live
                if mode == "server"
                else False
            )
        visible = [a for a in accounts if (
            bool(a.get("subscription_active"))
            or bool(a.get("subscription_paused"))
            or bool(a.get("connected"))
            or str(a.get("port_user_name") or "").strip()
            or str(a.get("port_user_id") or "").strip()
            or str(a.get("proxy_ip") or "").strip()
        )]
        if not visible:
            visible = []
        for a in visible:
            a["auth_status"] = _auth_status_ru(a)
        active_id = str(getattr(u, "active_account_id", "") or "acc_1")
        primary = None
        for a in visible:
            if str(a.get("account_id") or "") == active_id:
                primary = a
                break
        if primary is None and visible:
            primary = visible[0]
        if primary is None:
            primary = {}
        pending_invoice = None
        pending_best_created = 0
        for _oid, p in get_all_pending_orders().items():
            if int(p.get("chat_id") or 0) != int(chat_id):
                continue
            if str(p.get("status") or "") != "pending":
                continue
            exp = int(p.get("expires_at_ts") or 0)
            if exp <= now_ts:
                continue
            created = int(p.get("created_at_ts") or 0)
            if pending_invoice is not None and created < pending_best_created:
                continue
            pending_best_created = created
            pending_invoice = {
                "order_id": str(p.get("order_id") or ""),
                "invoice_id": str(p.get("invoice_id") or ""),
                "invoice_label": str(p.get("invoice_label") or ""),
                "pay_url": str(p.get("pay_url") or ""),
                "price_rub": int(p.get("price_rub") or 0),
                "price_usdt": float(p.get("price_usdt") or 0.0),
                "expires_at_ts": exp,
                "status": "pending",

                # Addon invoice metadata for Mini App rendering.
                # Without these fields the Mini App can show a plain invoice
                # after auto-refresh and lose "Доп. аккаунт / слот / тариф".
                "kind": str(p.get("kind") or ""),
                "is_addon": bool(p.get("is_addon")) or str(p.get("kind") or "") in {"account_add", "account_renew"},
                "account_id": str(p.get("account_id") or ""),
                "account_slot": int(p.get("account_slot") or 0),
                "account_label": str(p.get("account_label") or ""),
                "tariff_key": str(p.get("tariff_key") or ""),
                "tariff_title": str(p.get("tariff_title") or ""),
                "tariff_days": int(p.get("tariff_days") or 0),
            }
            break

        return {
            "chat_id": int(chat_id),
            "tg_username": str(u.tg_username or ""),
            "active_account_id": active_id,
            "subscription_tier": str(primary.get("subscription_tier") or u.subscription_tier or ""),
            "subscription_until_ts": int(primary.get("subscription_until_ts") or u.subscription_until_ts or 0),
            "subscription_paused": bool(primary.get("subscription_paused")),
            "subscription_frozen_left_sec": int(primary.get("subscription_frozen_left_sec") or 0),
            "proxy_set": bool(primary.get("proxy_set")),
            "proxy_ip": str(primary.get("proxy_ip") or ""),
            "proxy_scheme": str(primary.get("proxy_scheme") or ""),
            "proxy_ping_ms": primary.get("proxy_ping_ms"),
            "effective_ping_ms": primary.get("effective_ping_ms"),
            "effective_ping_source": str(primary.get("effective_ping_source") or "server"),
            "extension_ws_live": bool(primary.get("extension_ws_live")),
            "extension_ws_ping_ms": primary.get("extension_ws_ping_ms"),
            "server_ws_live": bool(primary.get("server_ws_live")),
            "promo_activated_count": int(getattr(u, "promo_activated_count", 0) or 0),
            "promo_activated_total_amount": round(float(getattr(u, "promo_activated_total_amount", 0.0) or 0.0), 2),
            "promo_month_key": str(promo_month.get("promo_month_key") or ""),
            "promo_month_label": str(promo_month.get("promo_month_label") or ""),
            "promo_month_count": int(promo_month.get("promo_month_count") or 0),
            "promo_month_total_amount": round(float(promo_month.get("promo_month_total_amount") or 0.0), 2),
            "promo_activation_paused": bool(primary.get("promo_activation_paused", getattr(u, "promo_activation_paused", False))),
            "promo_activation_mode": str(primary.get("promo_activation_mode") or getattr(u, "promo_activation_mode", "server") or "server"),
            "main_subscription_active": _has_active_main_subscription(int(chat_id)),
            "accounts": visible,
            "tariffs": [
                {
                    "key": t.key,
                    "title": t.title,
                    "days": t.days,
                    "price_rub": t.price_rub,
                    "tariff_type": t.tariff_type,
                }
                for t in billing.tariffs("main")
            ],
            "auth_urls": {
                "steam": f"{PUBLIC_WEB_BASE_URL}/auth/webapp/steam/?chat_id={int(chat_id)}",
                "yandex": f"{PUBLIC_WEB_BASE_URL}/auth/webapp/yandex/?chat_id={int(chat_id)}",
                "tg": f"{PUBLIC_WEB_BASE_URL}/auth/webapp/tg/?chat_id={int(chat_id)}",
            },
            "addon_config": _build_user_app_addon_config(chat_id),
            "pending_invoice": pending_invoice,
            "server_ts": now_ts,
        }

    def _build_user_app_addon_config(chat_id: int) -> dict:
        main_active = _has_active_main_subscription(chat_id)
        return {
            "main_active": main_active,
            "error": "" if main_active else "main_subscription_required",
            "message": "" if main_active else "Доп. аккаунты доступны только при активной подписке на основной аккаунт.",
            "tariffs_addon": [_tariff_to_app_dict(t) for t in billing.tariffs("addon")],
            "accounts": _addon_account_options(chat_id),
        }

    def _user_app_profile_section(payload: dict) -> dict:
        return {
            "chat_id": int(payload.get("chat_id") or 0),
            "tg_username": str(payload.get("tg_username") or ""),
            "subscription_tier": str(payload.get("subscription_tier") or ""),
            "subscription_until_ts": int(payload.get("subscription_until_ts") or 0),
            "subscription_paused": bool(payload.get("subscription_paused")),
            "subscription_frozen_left_sec": int(payload.get("subscription_frozen_left_sec") or 0),
            "proxy_set": bool(payload.get("proxy_set")),
            "proxy_ip": str(payload.get("proxy_ip") or ""),
            "proxy_scheme": str(payload.get("proxy_scheme") or ""),
            "proxy_ping_ms": payload.get("proxy_ping_ms"),
            "effective_ping_ms": payload.get("effective_ping_ms"),
            "effective_ping_source": str(payload.get("effective_ping_source") or "server"),
            "extension_ws_live": bool(payload.get("extension_ws_live")),
            "extension_ws_ping_ms": payload.get("extension_ws_ping_ms"),
            "server_ws_live": bool(payload.get("server_ws_live")),
            "main_subscription_active": bool(payload.get("main_subscription_active")),
            "promo_activation_paused": bool(payload.get("promo_activation_paused")),
            "promo_activation_mode": str(payload.get("promo_activation_mode") or "server"),
        }

    def _user_app_accounts_section(payload: dict) -> dict:
        return {
            "active_account_id": str(payload.get("active_account_id") or ""),
            "accounts": list(payload.get("accounts") or []),
        }

    def _user_app_promo_section(payload: dict) -> dict:
        return {
            "promo_activated_count": int(payload.get("promo_activated_count") or 0),
            "promo_activated_total_amount": round(float(payload.get("promo_activated_total_amount") or 0.0), 2),
            "promo_month_key": str(payload.get("promo_month_key") or ""),
            "promo_month_label": str(payload.get("promo_month_label") or ""),
            "promo_month_count": int(payload.get("promo_month_count") or 0),
            "promo_month_total_amount": round(float(payload.get("promo_month_total_amount") or 0.0), 2),
        }

    def _user_app_tariffs_section(payload: dict) -> dict:
        return {
            "tariffs": list(payload.get("tariffs") or []),
        }

    def _user_app_invoice_section(payload: dict) -> dict:
        return {
            "pending_invoice": payload.get("pending_invoice"),
        }

    def _user_app_addon_section(payload: dict) -> dict:
        return {
            "addon_config": payload.get("addon_config") or {},
        }

    def _same_payload(left, right) -> bool:
        return json.dumps(left, ensure_ascii=False, sort_keys=True, separators=(",", ":")) == json.dumps(
            right, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )

    def _build_user_app_events(prev_state: dict | None, next_state: dict) -> list[dict]:
        if not prev_state:
            return [{"type": "bootstrap", "data": next_state}]

        events: list[dict] = []

        prev_profile = _user_app_profile_section(prev_state)
        next_profile = _user_app_profile_section(next_state)
        if not _same_payload(prev_profile, next_profile):
            events.append({"type": "profile_patch", "data": next_profile})

        prev_accounts = _user_app_accounts_section(prev_state)
        next_accounts = _user_app_accounts_section(next_state)
        if not _same_payload(prev_accounts, next_accounts):
            prev_list = {str(a.get("account_id") or ""): a for a in list(prev_accounts.get("accounts") or [])}
            next_list = {str(a.get("account_id") or ""): a for a in list(next_accounts.get("accounts") or [])}
            if prev_accounts.get("active_account_id") == next_accounts.get("active_account_id") and set(prev_list) == set(next_list):
                for aid, row in next_list.items():
                    if not _same_payload(prev_list.get(aid), row):
                        events.append({"type": "account_patch", "data": row})
            else:
                events.append({"type": "accounts_patch", "data": next_accounts})

        prev_invoice = _user_app_invoice_section(prev_state)
        next_invoice = _user_app_invoice_section(next_state)
        if not _same_payload(prev_invoice, next_invoice):
            events.append({"type": "invoice_patch", "data": next_invoice})

        prev_promo = _user_app_promo_section(prev_state)
        next_promo = _user_app_promo_section(next_state)
        if not _same_payload(prev_promo, next_promo):
            events.append({"type": "promo_patch", "data": next_promo})

        prev_tariffs = _user_app_tariffs_section(prev_state)
        next_tariffs = _user_app_tariffs_section(next_state)
        if not _same_payload(prev_tariffs, next_tariffs):
            events.append({"type": "tariffs_patch", "data": next_tariffs})

        prev_addon = _user_app_addon_section(prev_state)
        next_addon = _user_app_addon_section(next_state)
        if not _same_payload(prev_addon, next_addon):
            events.append({"type": "addon_config_patch", "data": next_addon})

        return events

    def _tariff_to_app_dict(t) -> dict:
        return {
            "key": str(getattr(t, "key", "") or ""),
            "title": str(getattr(t, "title", "") or ""),
            "days": int(getattr(t, "days", 0) or 0),
            "price_rub": int(getattr(t, "price_rub", 0) or 0),
            "price_rub_base": int(getattr(t, "price_rub_base", 0) or 0),
            "discount_pct": float(getattr(t, "discount_pct", 0.0) or 0.0),
            "tariff_type": str(getattr(t, "tariff_type", "addon") or "addon"),
        }

    def _account_has_any_data_for_addon(acc: dict) -> bool:
        for key in (
            "port_user_id",
            "port_user_name",
            "zooma_top_session",
            "proxy_url",
            "subscription_tier",
            "centrifugo_secret",
            "csrf_token",
        ):
            if str((acc or {}).get(key) or "").strip():
                return True
        return int((acc or {}).get("subscription_until_ts") or 0) > 0

    def _has_active_main_subscription(chat_id: int) -> bool:
        now_ts = int(time.time())
        for acc in get_user_accounts(int(chat_id), include_empty=True):
            if int(acc.get("slot") or 0) == 1:
                return (not bool(acc.get("subscription_paused"))) and int(acc.get("subscription_until_ts") or 0) > now_ts
        return False


    def _addon_account_options(chat_id: int) -> list[dict]:
        now_ts = int(time.time())
        accounts = get_user_accounts(int(chat_id), include_empty=True)

        out: list[dict] = []
        occupied_slots = {1}

        for acc in accounts:
            slot = int(acc.get("slot") or 0)
            if slot <= 1:
                continue

            # Empty shells can appear after cancelled/expired pre-payment attempts.
            # Do not show them as real addon accounts and do not reserve their slots.
            if not _account_has_any_data_for_addon(acc):
                continue

            occupied_slots.add(slot)

            aid = str(acc.get("account_id") or f"acc_{slot}")
            name = str(acc.get("port_user_name") or "").strip()
            casino_id = str(acc.get("port_user_id") or "").strip()
            until_ts = int(acc.get("subscription_until_ts") or 0)
            frozen = bool(acc.get("subscription_paused"))
            active = (not frozen) and until_ts > now_ts

            if name or casino_id:
                label_main = f"#{slot} · {name or '-'} · ID {casino_id or '-'}"
            else:
                label_main = f"#{slot} · доп. аккаунт"

            label_tail = "заморожен" if frozen else ("активен" if active else "не активен")

            out.append({
                "account_id": aid,
                "slot": slot,
                "label": f"{label_main} · {label_tail}",
                "name": name,
                "casino_id": casino_id,
                "subscription_until_ts": until_ts,
                "promo_activation_mode": str(acc.get("promo_activation_mode") or getattr(get_user(int(chat_id)), "promo_activation_mode", "server") or "server"),
                "promo_activation_paused": bool(acc.get("promo_activation_paused", getattr(get_user(int(chat_id)), "promo_activation_paused", False))),
                "subscription_paused": frozen,
                "active": active,
                "empty": False,
                "action": "frozen" if frozen else ("extend" if active else "buy"),
            })

        next_slot = 2
        while next_slot in occupied_slots and next_slot <= 10:
            next_slot += 1

        if next_slot <= 10:
            out.insert(0, {
                "account_id": "new",
                "slot": next_slot,
                "label": f"Новый доп. аккаунт #{next_slot}",
                "name": "",
                "casino_id": "",
                "subscription_until_ts": 0,
                "active": False,
                "empty": True,
                "action": "buy",
            })

        out.sort(key=lambda x: (0 if x.get("account_id") == "new" else 1, int(x.get("slot") or 999)))
        return out


    def _auth_status_ru(acc: dict) -> str:
        # Mini App shows only the factual connection state. The selected mode
        # is displayed separately and decides which WS is checked upstream.
        return "подключен" if bool(acc.get("runtime_live")) else "не подключен"

    def _user_connect_keyboard(chat_id: int) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Войти через Steam", web_app=WebAppInfo(url=f"{PUBLIC_WEB_BASE_URL}/auth/webapp/steam/?chat_id={chat_id}"))],
                [InlineKeyboardButton("Войти через Telegram", web_app=WebAppInfo(url=f"{PUBLIC_WEB_BASE_URL}/auth/webapp/tg/?chat_id={chat_id}"))],
                [InlineKeyboardButton("Войти через Яндекс", web_app=WebAppInfo(url=f"{PUBLIC_WEB_BASE_URL}/auth/webapp/yandex/?chat_id={chat_id}"))],
            ]
        )

    async def _app_ws_push(chat_id: int) -> None:
        clients = list(app_ws_clients.get(int(chat_id), set()))
        if not clients:
            return
        next_state = _build_user_app_state(int(chat_id))
        dead: list[WebSocket] = []
        for ws in clients:
            try:
                prev_state = app_ws_snapshots.get(ws)
                events = _build_user_app_events(prev_state, next_state)
                for payload in events:
                    await ws.send_json(payload)
                app_ws_snapshots[ws] = deepcopy(next_state)
            except Exception:
                dead.append(ws)
        if dead:
            cur = app_ws_clients.get(int(chat_id), set())
            for ws in dead:
                with contextlib.suppress(Exception):
                    cur.discard(ws)
                    app_ws_snapshots.pop(ws, None)
            if not cur:
                app_ws_clients.pop(int(chat_id), None)

    register_app_state_pusher(_app_ws_push)
    setattr(billing, "mini_app_state_pusher", _app_ws_push)
    extension_ws_manager.set_state_pusher(_app_ws_push)

    async def _set_promo_activation_mode_runtime(chat_id: int, account_id: str, mode: str) -> dict:
        cid = int(chat_id)
        aid = str(account_id or "acc_1").strip() or "acc_1"
        target_mode = str(mode or "server").strip().lower()
        if target_mode not in {"server", "extension"}:
            raise HTTPException(status_code=400, detail="mode must be server or extension")

        mode_guard = await engine.acquire_mode_switch_guard(cid, aid)
        if mode_guard is None:
            raise HTTPException(
                status_code=409,
                detail="Сейчас выполняется активация промо. Повторите переключение после её завершения.",
            )

        try:
            current = get_user_account(cid, aid)
            if not current:
                raise HTTPException(status_code=404, detail="account_not_found")
            old_mode = str(current.get("promo_activation_mode") or "server").strip().lower()
            if old_mode not in {"server", "extension"}:
                old_mode = "server"
            old_epoch = max(0, int(current.get("runtime_mode_epoch") or 0))
            mode_epoch = old_epoch + (1 if old_mode != target_mode else 0)

            # A mode switch also ends any old manual-token prompt. Otherwise the
            # next text message can unexpectedly enter the manual auth branch.
            update_user_fields(cid, active_account_id=aid, waiting_token=False)

            patch_fields = {
                "promo_activation_mode": target_mode,
                "runtime_mode_epoch": mode_epoch,
                "connected": False,
            }
            if target_mode == "extension":
                patch_fields["server_session_state"] = {}
                if str(current.get("chat_ai_last_error") or "") == "server_session_stale":
                    patch_fields["chat_ai_last_error"] = ""
            patch_user_account(cid, aid, **patch_fields)
            try:
                await asyncio.to_thread(persist_user_state_now, cid)
            except Exception as exc:
                patch_user_account(
                    cid,
                    aid,
                    promo_activation_mode=old_mode,
                    runtime_mode_epoch=old_epoch,
                    connected=bool(current.get("connected")),
                    server_session_state=current.get("server_session_state") or {},
                )
                with contextlib.suppress(Exception):
                    await asyncio.to_thread(persist_user_state_now, cid)
                logger.error(
                    "activation mode durable save failed chat_id=%s account_id=%s mode=%s error=%s",
                    cid,
                    aid,
                    target_mode,
                    exc,
                )
                raise HTTPException(status_code=503, detail="Не удалось надёжно сохранить режим активации")

            server_ws_ok = False
            probe_status = "not_required"
            if target_mode == "extension":
                patch_user_account(
                    cid,
                    aid,
                    connected=False,
                    proxy_ping_ms=None,
                    proxy_ping_last_ts=0,
                    proxy_ping_error="",
                    proxy_runtime_status="healthy",
                    proxy_runtime_reason="",
                    proxy_runtime_source="",
                    proxy_unavailable_since_ts=0,
                    proxy_recovery_successes=0,
                    server_session_state={},
                )
                await engine.ws_manager.stop_for_user(cid, account_id=aid)
            else:
                fresh = get_user_account(cid, aid) or {}
                can_probe = (
                    has_active_account_subscription(cid, aid, int(time.time()))
                    and not bool(fresh.get("subscription_paused"))
                    and bool(get_active_domain())
                    and bool(str(fresh.get("zooma_top_session") or "").strip())
                    and bool(str(fresh.get("csrf_token") or "").strip())
                    and _account_proxy_allowed_for_runtime(cid, aid)
                )
                if can_probe:
                    detail = await engine.probe_user_session_detail(cid, account_id=aid, require_connected=False)
                    probe_status = str(detail.get("status") or "unknown")
                    if probe_status == "ok" and bool(detail.get("valid")):
                        server_ws_ok = await engine.ws_manager.reconnect_for_user(
                            cid,
                            str(get_active_domain()),
                            account_id=aid,
                            attempts=3,
                            attempt_timeout=5.0,
                        )
                    elif probe_status == "session_stale":
                        mark_account_server_session_stale(
                            cid,
                            aid,
                            reason="mode_switch_to_server",
                            http_status=int(detail.get("http_status") or 0),
                            response=str(detail.get("body") or ""),
                        )
                        await _notify_server_session_stale_once(cid, aid)
                    else:
                        logger.warning(
                            "server mode probe not passed chat_id=%s account_id=%s status=%s http=%s body=%s",
                            cid,
                            aid,
                            probe_status,
                            detail.get("http_status") or 0,
                            str(detail.get("body") or "")[:600],
                        )
                else:
                    probe_status = "requirements_missing"

            patch_user_account(cid, aid, connected=bool(target_mode == "server" and server_ws_ok))
            with contextlib.suppress(Exception):
                await asyncio.to_thread(persist_user_state_now, cid)

            if old_mode != target_mode:
                try:
                    from rain_runtime import handover_chat_ai_for_account, handover_train_jobs_for_account

                    await handover_chat_ai_for_account(
                        cid,
                        aid,
                        target_mode,
                        previous_mode=old_mode,
                        mode_epoch=mode_epoch,
                    )
                    await handover_train_jobs_for_account(cid, aid, target_mode)
                except Exception:
                    logger.exception(
                        "activation mode task handover failed chat_id=%s account_id=%s old=%s new=%s epoch=%s",
                        cid,
                        aid,
                        old_mode,
                        target_mode,
                        mode_epoch,
                    )

            await _app_ws_push(cid)
            row = _account_admin_row(cid, get_user_account(cid, aid) or {}, int(time.time()))
            row["server_probe_status"] = probe_status
            row["server_mode_ready"] = bool(server_ws_ok) if target_mode == "server" else True
            return row
        finally:
            engine.release_mode_switch_guard(mode_guard)


    def _auth_sessions_snapshot() -> list[dict]:
        def _username_for_chat(chat_id: Optional[int]) -> str:
            if chat_id is None:
                return ""
            with contextlib.suppress(Exception):
                u = USERS.get(int(chat_id))
                return (u.tg_username or "") if u else ""
            return ""

        def _account_meta_for_chat(chat_id: Optional[int]) -> dict:
            if chat_id is None:
                return {"account_id": "", "account_label": ""}
            with contextlib.suppress(Exception):
                u = USERS.get(int(chat_id))
                aid = str(getattr(u, "active_account_id", "") or "")
                acc = _select_admin_account(int(chat_id), aid)
                if acc:
                    slot = int(acc.get("slot") or 0)
                    name = str(acc.get("port_user_name") or "").strip()
                    casino_id = str(acc.get("port_user_id") or "").strip()
                    label = f"акк #{slot}" if slot else "акк"
                    if name or casino_id:
                        label += f" · {name or '-'} | {casino_id or '-'}"
                    return {
                        "account_id": str(acc.get("account_id") or aid),
                        "account_label": label,
                    }
            return {"account_id": "", "account_label": ""}

        out: list[dict] = []
        with contextlib.suppress(Exception):
            from steam_webapp import sessions as steam_sessions
            for sid, s in list(steam_sessions.items()):
                chat_id = _chat_id_from_sid(sid)
                out.append({
                    "provider": "steam",
                    "sid": sid,
                    "chat_id": chat_id,
                    "tg_username": _username_for_chat(chat_id),
                    **_account_meta_for_chat(chat_id),
                    "stage": s.get("stage", ""),
                    "ready": bool(s.get("ready")),
                    "last_seen": int(s.get("last_seen") or 0),
                })
        with contextlib.suppress(Exception):
            from tg_webapp import sessions as tg_sessions
            for sid, s in list(tg_sessions.items()):
                chat_id = _chat_id_from_sid(sid)
                out.append({
                    "provider": "tg",
                    "sid": sid,
                    "chat_id": chat_id,
                    "tg_username": _username_for_chat(chat_id),
                    **_account_meta_for_chat(chat_id),
                    "stage": s.get("stage", ""),
                    "ready": bool(s.get("ready")),
                    "last_seen": int(s.get("last_seen") or 0),
                })
        with contextlib.suppress(Exception):
            from yandex_webapp import sessions as ya_sessions
            for sid, s in list(ya_sessions.items()):
                chat_id = _chat_id_from_sid(sid)
                out.append({
                    "provider": "yandex",
                    "sid": sid,
                    "chat_id": chat_id,
                    "tg_username": _username_for_chat(chat_id),
                    **_account_meta_for_chat(chat_id),
                    "stage": s.get("stage", ""),
                    "ready": bool(s.get("ready")),
                    "last_seen": int(s.get("last_seen") or 0),
                })
        out.sort(key=lambda x: x.get("last_seen", 0), reverse=True)
        now_ts = int(time.time())
        for item in out:
            created_at = int(item.get("created_at") or item.get("last_seen") or now_ts)
            last_seen = int(item.get("last_seen") or now_ts)
            item["work_sec"] = max(0, now_ts - created_at)
            item["idle_sec"] = max(0, now_ts - last_seen)
        return out

    def _chat_id_from_sid(sid: str) -> Optional[int]:
        tail = (sid.split("_")[-1] if sid else "").strip()
        return int(tail) if tail.isdigit() else None

    def _resolve_chat_id(chat_id: Optional[int], username: Optional[str]) -> Optional[int]:
        if chat_id is not None:
            return int(chat_id)
        uname = (username or "").strip().lstrip("@").lower()
        if not uname:
            return None
        for cid, u in USERS.items():
            if (u.tg_username or "").strip().lstrip("@").lower() == uname:
                return int(cid)
        return None

    def _proxy_ip_from_account(acc: dict) -> str:
        proxy_ip = str(acc.get("proxy_ip") or "").strip()
        if not proxy_ip and str(acc.get("proxy_url") or "").strip():
            with contextlib.suppress(Exception):
                pu = urlparse(str(acc.get("proxy_url") or ""))
                proxy_ip = pu.hostname or ""
        return proxy_ip

    def _account_admin_row(chat_id: int, acc: dict, now_ts: int) -> dict:
        aid = str(acc.get("account_id") or "")
        proxy_ip = _proxy_ip_from_account(acc)
        until_ts = int(acc.get("subscription_until_ts") or 0)
        sub_paused = bool(acc.get("subscription_paused"))
        sub_active = (not sub_paused) and until_ts > now_ts
        mode = str(acc.get("promo_activation_mode") or getattr(get_user(int(chat_id)), "promo_activation_mode", "server") or "server").strip().lower()
        if mode not in {"server", "extension"}:
            mode = "server"
        server_ws_live = False
        with contextlib.suppress(Exception):
            server_ws_live = bool(ws_manager.is_connected(int(chat_id), account_id=aid))
        extension_state = extension_ws_manager.status_snapshot(int(chat_id), aid)
        extension_ws_live = bool(extension_state.get("extension_ws_live"))
        extension_bound = int(acc.get("extension_bound_chat_id") or 0) == int(chat_id)
        stored_proxy_ping_ms = (
            round(float(acc.get("proxy_ping_ms")), 1)
            if acc.get("proxy_ping_ms") is not None
            else None
        )
        proxy_ping_ms = (
            None
            if mode == "extension"
            else stored_proxy_ping_ms
        )

        if mode == "extension":
            runtime_live = extension_ws_live
            runtime_status = "подключен через расширение" if extension_ws_live else ("ожидает подключение расширения" if extension_bound else "расширение не привязано")
            effective_ping_ms = extension_state.get("extension_ws_ping_ms")
            effective_ping_source = "extension"
        else:
            session_stale = account_server_session_is_stale(acc)
            runtime_live = bool(server_ws_live and not session_stale)
            runtime_status = "сессия протухла" if session_stale else ("подключен через сервер" if server_ws_live else ("ожидает серверный WebSocket" if str(acc.get("zooma_top_session") or "").strip() else "не подключен"))
            effective_ping_ms = proxy_ping_ms
            effective_ping_source = "server"
        return {
            "account_id": aid,
            "slot": int(acc.get("slot") or 0),
            "billing_type": str(acc.get("billing_type") or "main"),
            "status": str(acc.get("status") or ""),
            "connected": bool(sub_active and runtime_live),
            "runtime_live": bool(runtime_live),
            "runtime_mode": mode,
            "runtime_status": runtime_status,
            "effective_ping_ms": effective_ping_ms,
            "effective_ping_source": effective_ping_source,
            "ws_live": bool(server_ws_live) if mode == "server" else bool(extension_ws_live),
            "server_ws_live": bool(server_ws_live) if mode == "server" else False,
            **extension_state,
            "subscription_tier": str(acc.get("subscription_tier") or ""),
            "subscription_active": sub_active,
            "subscription_paused": sub_paused,
            "subscription_pause_started_ts": int(acc.get("subscription_pause_started_ts") or 0),
            "subscription_frozen_left_sec": int(acc.get("subscription_frozen_left_sec") or 0),
            "subscription_freeze_reason": str(acc.get("subscription_freeze_reason") or ""),
            "subscription_until_ts": until_ts,
            "promo_activation_mode": mode,
            "promo_activation_paused": bool(acc.get("promo_activation_paused", getattr(get_user(int(chat_id)), "promo_activation_paused", False))),
            "extension_bound_chat_id": int(acc.get("extension_bound_chat_id") or 0) or None,
            "extension_bound_at_ts": int(acc.get("extension_bound_at_ts") or 0) or None,
            "extension_current_domain": str(acc.get("extension_current_domain") or ""),
            "extension_current_domain_ts": int(acc.get("extension_current_domain_ts") or 0) or None,
            "proxy_set": bool(str(acc.get("proxy_url") or "").strip()),
            "proxy_scheme": str(acc.get("proxy_scheme") or ""),
            "proxy_port_http": acc.get("proxy_port_http"),
            "proxy_port_socks5": acc.get("proxy_port_socks5"),
            "proxy_login": str(acc.get("proxy_login") or ""),
            "proxy_password": str(acc.get("proxy_password") or ""),
            "proxy_ip": proxy_ip,
            "proxy_country": str(acc.get("proxy_country") or ""),
            "proxy_city": str(acc.get("proxy_city") or ""),
            "proxy_order_id": str(acc.get("proxy_order_id") or ""),
            "proxy_ping_ms": proxy_ping_ms,
            "proxy_ping_last_ts": int(acc.get("proxy_ping_last_ts") or 0),
            "proxy_ping_error": str(acc.get("proxy_ping_error") or ""),
            "port_user_id": str(acc.get("port_user_id") or ""),
            "port_user_name": str(acc.get("port_user_name") or ""),
            "user_agent": str(acc.get("user_agent") or ""),
            **_chat_ai_public_fields(acc),
        }

    def _select_admin_account(chat_id: int, account_id: Optional[str]) -> Optional[dict]:
        accounts = get_user_accounts(int(chat_id), include_empty=True)
        if account_id:
            for acc in accounts:
                if str(acc.get("account_id") or "") == str(account_id):
                    return dict(acc)
            return None
        u = get_user(int(chat_id))
        active = str(getattr(u, "active_account_id", "") or "")
        if active:
            for acc in accounts:
                if str(acc.get("account_id") or "") == active:
                    return dict(acc)
        return dict(accounts[0]) if accounts else None

    def _resolve_admin_proxy_account(chat_id: int, account_id: Optional[str]) -> tuple[str, Optional[dict]]:
        aid = str(account_id or "").strip()
        if aid:
            return aid, _select_admin_account(int(chat_id), aid)
        u = get_user(int(chat_id))
        aid = str(getattr(u, "active_account_id", "") or "acc_1").strip() or "acc_1"
        return aid, _select_admin_account(int(chat_id), aid)

    def _account_notify_title(acc: dict) -> str:
        slot = int((acc or {}).get("slot") or 0)
        name = str((acc or {}).get("port_user_name") or "").strip()
        casino_id = str((acc or {}).get("port_user_id") or "").strip()
        title = f"аккаунта #{slot}" if slot else "аккаунта"
        if name or casino_id:
            title += f" ({name or '-'} | {casino_id or '-'})"
        return title


    async def _notify_user_sub_action(chat_id: int, text: str) -> None:
        if not billing.app:
            return
        with contextlib.suppress(Exception):
            await billing.app.bot.send_message(chat_id=chat_id, text=text)

    async def _handle_ws_proxy_unavailable(chat_id: int, account_id: str, error: str) -> None:
        # Use the same account-scoped runtime state machine as periodic checks.
        # This stops only the affected WS/runtime; subscription time keeps running.
        await billing.auto_freeze_proxy_unavailable(
            int(chat_id),
            str(account_id or "acc_1"),
            str(error or "proxy_unavailable"),
            source="ws_proxy_failure",
        )

    with contextlib.suppress(Exception):
        billing.ws_manager.set_proxy_failure_handler(_handle_ws_proxy_unavailable)


    def _humanize_proxy_error(reason: str) -> str:
        raw = str(reason or "").strip()
        if not raw:
            return "неизвестная ошибка"
        rl = raw.lower()
        if "not enough money" in rl or "insufficient" in rl or "balance" in rl:
            return "недостаточно средств на балансе Proxyline"
        if "api token" in rl or "proxyline_api_token" in rl:
            return "не настроен API-ключ Proxyline"
        if "http 401" in rl or "unauthorized" in rl:
            return "ошибка авторизации Proxyline API (401)"
        if "http 403" in rl or "forbidden" in rl:
            return "доступ к Proxyline API запрещен (403)"
        if "http 404" in rl:
            return "метод Proxyline API не найден (404)"
        if "http 429" in rl or "too many requests" in rl:
            return "слишком много запросов к Proxyline (429), попробуйте позже"
        if "http 5" in rl or "server error" in rl:
            return "временная ошибка сервера Proxyline, попробуйте позже"
        if "timeout" in rl:
            return "таймаут при обращении к Proxyline"
        if "bad_country" in rl:
            return "выбрана недоступная страна из пула"
        if "not enough free ip on the server" in rl:
            return "в выбранной стране сейчас нет свободных IP для этого типа прокси"
        # Unknown case: return original API text as requested.
        return raw

    def _status_ru(status: str) -> str:
        s = (status or "").strip().lower()
        if s == "pending":
            return "Ожидание"
        if s == "paid":
            return "Успех"
        if s == "expired":
            return "Истек"
        if s == "failed":
            return "Ошибка"
        if s == "cancelled":
            return "Отменен"
        return s or "-"

    def _with_proxy_buffer(rub: Optional[float]) -> Optional[float]:
        if rub is None:
            return None
        try:
            val = float(rub)
        except Exception:
            return None
        k = 1.0 + max(0.0, float(PROXYLINE_PRICE_BUFFER_PCT)) / 100.0
        return round(val * k, 2)

    @app.get("/healthz")
    async def healthz() -> dict:
        return {"ok": True}

    @app.get("/app", response_class=HTMLResponse)
    async def user_app_page(request: Request):
        return templates.TemplateResponse(request, "user_app.html")

    @app.websocket("/app/ws")
    async def user_app_ws(ws: WebSocket):
        await ws.accept()
        chat_id = None
        try:
            init_data = str(ws.query_params.get("init_data") or "")
            tg_user = _validate_tg_init_data_or_raise(init_data)
            chat_id = int(tg_user.get("id"))
            app_ws_clients.setdefault(chat_id, set()).add(ws)
            bootstrap = _build_user_app_state(chat_id)
            app_ws_snapshots[ws] = deepcopy(bootstrap)
            await ws.send_json({"type": "bootstrap", "data": bootstrap})
            while True:
                # держим сокет + обрабатываем ping от клиента
                data = await ws.receive_text()
                if str(data).strip().lower() == "ping":
                    with contextlib.suppress(Exception):
                        await ws.send_text("pong")
        except WebSocketDisconnect:
            pass
        except Exception:
            with contextlib.suppress(Exception):
                await ws.close(code=1008)
        finally:
            if chat_id is not None:
                cur = app_ws_clients.get(int(chat_id), set())
                cur.discard(ws)
                app_ws_snapshots.pop(ws, None)
                if not cur:
                    app_ws_clients.pop(int(chat_id), None)

    @app.get("/app/api/state")
    async def user_app_state(init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        return {"ok": True, "data": _build_user_app_state(chat_id)}

    @app.post("/app/api/promo-activation-pause")
    async def user_app_promo_activation_pause(body: PromoPauseBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        account_id = str(body.account_id or getattr(get_user(chat_id), "active_account_id", "") or "acc_1")
        current = get_user_account(chat_id, account_id)
        if not current:
            return {"ok": False, "error": "account_not_found"}
        previous = bool(current.get("promo_activation_paused", False))
        patch_user_account(chat_id, account_id, promo_activation_paused=bool(body.paused))
        try:
            await asyncio.to_thread(persist_user_state_now, chat_id)
        except Exception as exc:
            patch_user_account(chat_id, account_id, promo_activation_paused=previous)
            with contextlib.suppress(Exception):
                await asyncio.to_thread(persist_user_state_now, chat_id)
            logger.error("promo pause durable save failed chat_id=%s account_id=%s error=%s", chat_id, account_id, exc)
            return {"ok": False, "error": "durable_save_failed", "detail": "Не удалось надёжно сохранить паузу"}
        fresh = get_user_account(chat_id, account_id) or {}
        await _app_ws_push(chat_id)
        return {"ok": True, "data": {"account_id": account_id, "promo_activation_paused": bool(fresh.get("promo_activation_paused"))}}

    @app.post("/app/api/promo-activation-mode")
    async def user_app_promo_activation_mode(body: AppPromoActivationModeBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        account_id = str(body.account_id or getattr(get_user(chat_id), "active_account_id", "") or "acc_1")
        data = await _set_promo_activation_mode_runtime(chat_id, account_id, body.mode)
        return {"ok": True, "data": data}

    @app.post("/app/api/extension-unbind")
    async def user_app_extension_unbind(body: AppExtensionUnbindBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        account_id = str(body.account_id or getattr(get_user(chat_id), "active_account_id", "") or "acc_1")
        try:
            unbind_extension(chat_id, account_id)
            await asyncio.to_thread(persist_user_state_now, chat_id)
        except KeyError:
            return {"ok": False, "error": "account_not_found"}
        except Exception as exc:
            logger.error("user extension unbind failed chat_id=%s account_id=%s error=%s", chat_id, account_id, exc)
            return {"ok": False, "error": "durable_save_failed", "detail": "Не удалось сохранить отвязку"}
        await extension_ws_manager.disconnect(chat_id, account_id, code=4004)
        await _app_ws_push(chat_id)
        return {"ok": True, "data": {"account_id": account_id, "extension_bound": False}}

    @app.post("/app/api/extension-reload")
    async def user_app_extension_reload(body: AppExtensionReloadBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        account_id = str(body.account_id or getattr(get_user(chat_id), "active_account_id", "") or "acc_1")
        account = get_user_account(chat_id, account_id)
        if not account:
            return {"ok": False, "error": "account_not_found"}
        mode = str(account.get("promo_activation_mode") or "server").strip().lower()
        if mode != "extension":
            return {
                "ok": False,
                "error": "extension_mode_required",
                "detail": "Обновление страницы ПК доступно только в режиме расширения.",
            }
        result = await extension_ws_manager.reload_managed_tab(chat_id, account_id)
        if not result.get("ok"):
            return {
                "ok": False,
                "error": str(result.get("status") or "extension_reload_failed"),
                "detail": str(result.get("message") or "Не удалось обновить страницу ПК через расширение."),
            }
        await _app_ws_push(chat_id)
        return {"ok": True, "data": {"account_id": account_id, **dict(result)}}


    @app.post("/app/api/chat-ai/settings")
    async def user_app_chat_ai_settings(body: AppChatAiSettingsBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        account_id = str(body.account_id or getattr(get_user(chat_id), "active_account_id", "") or "acc_1").strip() or "acc_1"
        current = get_user_account(chat_id, account_id)
        if not current:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        was_enabled = bool(current.get("chat_ai_enabled"))
        patch: dict = {}
        api_key = None if body.api_key is None else " ".join(normalize_chat_ai_api_keys(body.api_key))
        if api_key:
            patch["chat_ai_api_key"] = api_key
            patch["chat_ai_rate_limits"] = {}
            patch["chat_ai_key_mode"] = "user"
        if body.rain_miss_messages is not None:
            patch["chat_ai_rain_miss_messages"] = normalize_chat_ai_rain_miss_messages(
                body.rain_miss_messages
            )
        min_sec = int(body.interval_min_sec if body.interval_min_sec is not None else current.get("chat_ai_interval_min_sec") or 10 * 60)
        max_sec = int(body.interval_max_sec if body.interval_max_sec is not None else current.get("chat_ai_interval_max_sec") or 25 * 60)
        if min_sec > max_sec:
            return {"ok": False, "error": "bad_interval", "detail": "Минимальный интервал не может быть больше максимального"}
        patch["chat_ai_interval_min_sec"] = min_sec
        patch["chat_ai_interval_max_sec"] = max_sec
        interval_changed = min_sec != int(current.get("chat_ai_interval_min_sec") or 10 * 60) or max_sec != int(current.get("chat_ai_interval_max_sec") or 25 * 60)
        if body.enabled is not None:
            if body.enabled:
                effective_key = api_key or str(current.get("chat_ai_api_key") or "").strip()
                if not effective_key:
                    return {"ok": False, "error": "chat_ai_api_key_required", "detail": "Сначала сохраните API-ключ Groq"}
                if not has_active_account_subscription(chat_id, account_id, int(time.time())):
                    return {"ok": False, "error": "subscription_inactive", "detail": "Нужна активная подписка"}
                patch["chat_ai_enabled"] = True
                patch["chat_ai_key_mode"] = "user"
                patch["chat_ai_last_error"] = ""
                patch["chat_ai_pending_task"] = {}
                patch["chat_ai_next_run_ts"] = 0
                if not was_enabled:
                    patch["chat_ai_cycle_started_ts"] = int(time.time())
                    patch["chat_ai_rest_until_ts"] = 0
            else:
                patch["chat_ai_enabled"] = False
                patch["chat_ai_next_run_ts"] = 0
                patch["chat_ai_pending_task"] = {}
                patch["chat_ai_last_error"] = ""
                patch["chat_ai_cycle_started_ts"] = 0
                patch["chat_ai_rest_until_ts"] = 0
        elif interval_changed:
            patch["chat_ai_next_run_ts"] = 0
        patched = patch_user_account(chat_id, account_id, **patch)
        try:
            await asyncio.to_thread(persist_user_state_now, chat_id)
        except Exception as exc:
            logger.error("user chat ai durable save failed chat_id=%s account_id=%s error=%s", chat_id, account_id, exc)
            return {"ok": False, "error": "durable_save_failed", "detail": "Не удалось сохранить настройки Chat AI"}
        await _app_ws_push(chat_id)
        return {"ok": True, "data": {"account_id": account_id, **_chat_ai_public_fields(patched)}}


    @app.post("/app/api/account/reset-casino-data")
    async def user_app_reset_casino_data(body: AppAccountCasinoResetBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        account_id = str(body.account_id or "").strip()
        current = get_user_account(chat_id, account_id)
        if not current:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        if str(current.get("promo_activation_mode") or "server").strip().lower() != "server":
            return {"ok": False, "error": "server_mode_required", "detail": "Сначала переключите аккаунт в режим сервера"}
        await engine.ws_manager.stop_for_user(chat_id, account_id=account_id)
        patched = reset_account_casino_identity(chat_id, account_id)
        await asyncio.to_thread(persist_user_state_now, chat_id)
        await _app_ws_push(chat_id)
        return {"ok": True, "data": _account_admin_row(chat_id, patched, int(time.time()))}

    @app.post("/app/api/account/select")
    async def user_app_account_select(body: AppSelectAccountBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        acc = get_user_account(chat_id, str(body.account_id or "").strip())
        if not acc:
            return {"ok": False, "error": "account_not_found"}
        update_user_fields(chat_id, active_account_id=str(body.account_id))
        await _app_ws_push(chat_id)
        return {"ok": True}

    @app.post("/app/api/proxy/manual")
    async def user_app_manual_proxy(body: AppManualProxyBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        aid = str(body.account_id or "").strip()
        acc = get_user_account(chat_id, aid)
        if not acc:
            return {"ok": False, "error": "account_not_found"}
        if bool(acc.get("subscription_paused")) and str(acc.get("subscription_freeze_reason") or "") != "proxy_unavailable":
            return {
                "ok": False,
                "error": "subscription_frozen",
                "detail": "Аккаунт заморожен вручную. Прокси можно менять только для авто-заморозки из-за прокси.",
            }
        proxy_url = (
            f"socks5://{quote(str(body.login), safe='')}:{quote(str(body.password), safe='')}@"
            f"{str(body.host).strip()}:{int(body.port)}"
        )
        set_account_proxy(
            chat_id=chat_id,
            account_id=aid,
            proxy_url=proxy_url,
            order_id="manual",
            ip=str(body.host).strip(),
            port_http=None,
            port_socks5=int(body.port),
            login=str(body.login).strip(),
            password=str(body.password).strip(),
            scheme="socks5",
        )
        await billing.resume_proxy_auto_frozen_if_proxy_ok(chat_id, aid, proxy_url, source="mini_app_manual_proxy")
        await _app_ws_push(chat_id)
        return {"ok": True}

    @app.get("/app/api/addon/config")
    async def user_app_addon_config(init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        return {"ok": True, "data": _build_user_app_addon_config(chat_id)}


    @app.post("/app/api/addon/invoice")
    async def user_app_addon_invoice(request: Request, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))

        body = await request.json()

        if not _has_active_main_subscription(chat_id):
            return {
                "ok": False,
                "error": "main_subscription_required",
                "detail": "Доп. аккаунты доступны только при активной подписке на основной аккаунт.",
            }

        tariff_key = str((body or {}).get("tariff_key") or "").strip()
        selected_id = str((body or {}).get("account_id") or "new").strip() or "new"

        tariff = billing.find_tariff(tariff_key, "addon")
        if not tariff:
            return {"ok": False, "error": "tariff_not_found"}

        now_ts = int(time.time())

        if selected_id == "new":
            new_opt = next((x for x in _addon_account_options(chat_id) if str(x.get("account_id")) == "new"), None)
            slot = int((new_opt or {}).get("slot") or 2)
            account_id = None
            kind = "account_add"
        else:
            account = get_user_account(chat_id, selected_id)
            if not account:
                return {"ok": False, "error": "account_not_found"}
            if bool(account.get("subscription_paused")):
                return {
                    "ok": False,
                    "error": "subscription_frozen",
                    "detail": "Этот доп. аккаунт заморожен. Сначала разморозьте подписку.",
                }

            slot = int(account.get("slot") or 0)
            if slot <= 1:
                return {"ok": False, "error": "main_account_not_allowed"}

            account_id = str(account.get("account_id") or selected_id)
            kind = "account_renew" if int(account.get("subscription_until_ts") or 0) > now_ts else "account_add"

            patch_user_account(
                chat_id,
                account_id,
                billing_type="addon",
                status="pending_payment",
            )

        if slot <= 1:
            return {"ok": False, "error": "addon_slot_not_found"}

        label = f"доп акк #{slot}"

        invoice = await billing.create_invoice(
            chat_id,
            tariff,
            kind=kind,
            account_id=account_id,
            account_slot=slot,
            account_label=label,
            is_addon=True,
        )

        await billing.send_invoice_message(chat_id, invoice)
        await _app_ws_push(chat_id)

        return {
            "ok": True,
            "data": {
                "invoice_id": str(invoice.get("invoice_id") or ""),
                "invoice_label": str(invoice.get("invoice_label") or ""),
                "pay_url": str(invoice.get("pay_url") or ""),
                "price_rub": int(invoice.get("price_rub") or 0),
                "price_usdt": float(invoice.get("price_usdt") or 0.0),
                "expires_at_ts": int(invoice.get("expires_at") or 0),

                "is_addon": True,
                "kind": kind,
                "account_id": account_id or "",
                "account_slot": slot,
                "account_label": label,
                "tariff_key": tariff_key,
                "tariff_title": str(getattr(tariff, "title", tariff_key) or tariff_key),
                "tariff_days": int(getattr(tariff, "days", 0) or 0),
            },
        }


    @app.post("/app/api/tariff/invoice")
    async def user_app_create_invoice(body: AppCreateInvoiceBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        main_acc = None
        for acc in get_user_accounts(int(chat_id), include_empty=True):
            if int((acc or {}).get("slot") or 0) == 1:
                main_acc = acc
                break
        if main_acc and bool(main_acc.get("subscription_paused")):
            return {
                "ok": False,
                "error": "subscription_frozen",
                "detail": "Основной аккаунт заморожен. Сначала разморозьте подписку.",
            }

        tariff = billing.find_tariff(str(body.tariff_key or "").strip(), "main")
        if not tariff:
            return {"ok": False, "error": "tariff_not_found"}
        invoice = await billing.create_invoice(chat_id, tariff)
        await billing.send_invoice_message(chat_id, invoice)
        await _app_ws_push(chat_id)
        return {
            "ok": True,
            "data": {
                "invoice_id": str(invoice.get("invoice_id") or ""),
                "invoice_label": str(invoice.get("invoice_label") or ""),
                "pay_url": str(invoice.get("pay_url") or ""),
                "price_rub": int(invoice.get("price_rub") or 0),
                "price_usdt": float(invoice.get("price_usdt") or 0.0),
                "expires_at_ts": int(invoice.get("expires_at") or 0),
            },
        }

    @app.post("/app/api/tariff/invoice/cancel")
    async def user_app_cancel_invoice(body: AppCancelInvoiceBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        now_ts = int(time.time())
        invoice_id_filter = str(body.invoice_id or "").strip()

        target_order_id = ""
        target = None
        best_created = 0
        for oid, p in get_all_pending_orders().items():
            if int(p.get("chat_id") or 0) != chat_id:
                continue
            if str(p.get("status") or "").strip().lower() != "pending":
                continue
            if invoice_id_filter and str(p.get("invoice_id") or "").strip() != invoice_id_filter:
                continue
            exp = int(p.get("expires_at_ts") or 0)
            if exp <= now_ts:
                continue
            created = int(p.get("created_at_ts") or 0)
            if target is not None and created < best_created:
                continue
            best_created = created
            target_order_id = str(oid)
            target = p

        if not target_order_id or not isinstance(target, dict):
            return {"ok": False, "error": "pending_invoice_not_found"}

        async with billing._lock:
            cur = get_pending_order(target_order_id)
            if not isinstance(cur, dict):
                return {"ok": False, "error": "pending_invoice_not_found"}
            if str(cur.get("status") or "").strip().lower() != "pending":
                return {"ok": False, "error": "invoice_not_pending"}

            update_pending_order_fields(
                target_order_id,
                status="cancelled",
                fail_reason="user_cancelled",
                cancelled_at_ts=now_ts,
                purge_after_ts=now_ts + int(EXPIRED_ORDER_KEEP_DAYS) * 24 * 60 * 60,
            )

            msg_id = cur.get("message_id")
            if msg_id and billing.app:
                with contextlib.suppress(Exception):
                    await billing.app.bot.delete_message(chat_id=chat_id, message_id=int(msg_id))

        await _app_ws_push(chat_id)
        return {"ok": True, "data": {"order_id": target_order_id, "status": "cancelled"}}

    def _admin_folder_sync(reason: str) -> None:
        with contextlib.suppress(Exception):
            billing.request_tg_subscription_folder_sync(f"admin_{reason}", immediate=True)


    @app.post("/app/api/account/connect-prompt")
    async def user_app_connect_prompt(body: AppConnectPromptBody, init_data: str = Query(default="")) -> dict:
        tg_user = _validate_tg_init_data_or_raise(init_data)
        chat_id = int(tg_user.get("id"))
        aid = str(body.account_id or "").strip()
        acc = get_user_account(chat_id, aid)
        if not acc:
            return {"ok": False, "error": "account_not_found"}
        if bool(acc.get("subscription_paused")):
            return {"ok": False, "error": "subscription_frozen", "detail": "Подписка аккаунта заморожена."}
        if not has_active_account_subscription(chat_id, aid, int(time.time())):
            return {"ok": False, "error": "subscription_inactive", "detail": "Нет активной подписки аккаунта."}
        update_user_fields(chat_id, active_account_id=aid, waiting_token=False)
        bot = getattr(engine, "_telegram_bot", None)
        if not bot:
            return {"ok": False, "error": "bot_unavailable"}
        await bot.send_message(
            chat_id=chat_id,
            text="Выберите способ авторизации",
            reply_markup=_user_connect_keyboard(chat_id),
        )
        await _app_ws_push(chat_id)
        return {"ok": True}

    def _admin_login_html(error: str = "") -> str:
        error_html = ""
        if error:
            error_html = f'<div class="mb-5 rounded-2xl border border-red-400/40 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-200">{error}</div>'
        return f"""
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ZOOMA Admin Login</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4">
<form method="post" action="{ADMIN_LOGIN_PATH}" class="w-full max-w-md rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur">
<div class="mb-7"><div class="text-sm uppercase tracking-[0.35em] text-sky-300">ZOOMA</div><h1 class="mt-2 text-3xl font-black">Админ-панель</h1></div>
{error_html}
<label class="block text-sm text-slate-300">Логин<input name="username" autocomplete="username" required class="mt-2 w-full rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 outline-none focus:border-sky-400"></label>
<label class="mt-4 block text-sm text-slate-300">Пароль<input name="password" type="password" autocomplete="current-password" required class="mt-2 w-full rounded-2xl border border-white/10 bg-slate-900 px-4 py-3 outline-none focus:border-sky-400"></label>
<button class="mt-6 w-full rounded-2xl bg-sky-500 px-4 py-3 font-bold hover:bg-sky-400">Войти</button>
</form></body></html>"""

    @app.get(ADMIN_LOGIN_PATH, response_class=HTMLResponse)
    async def admin_login_page(request: Request):
        if _admin_session_ok(request):
            return RedirectResponse(ADMIN_PANEL_PATH, status_code=302)
        return HTMLResponse(_admin_login_html())

    @app.post(ADMIN_LOGIN_PATH)
    async def admin_login_submit(request: Request, username: str = Form(...), password: str = Form(...)):
        ip = request.client.host if request.client else "unknown"
        now = time.time()
        bucket = [t for t in admin_login_attempts.get(ip, []) if now - t < 15 * 60]
        admin_login_attempts[ip] = bucket
        if len(bucket) >= 8:
            return HTMLResponse(_admin_login_html("Слишком много попыток. Попробуйте позже."), status_code=429)
        good_user = os.getenv("ZOOMA_ADMIN_USERNAME", "saxarok")
        good_pass = os.getenv("ZOOMA_ADMIN_PASSWORD", "394Gwj990!")
        if not (secrets.compare_digest(username, good_user) and secrets.compare_digest(password, good_pass)):
            bucket.append(now)
            await asyncio.sleep(min(3.0, 0.4 * len(bucket)))
            return HTMLResponse(_admin_login_html("Неверный логин или пароль"), status_code=401)
        sid = secrets.token_urlsafe(48)
        csrf = secrets.token_urlsafe(32)
        admin_sessions[sid] = {"created": now, "last_seen": now, "expires": now + 12 * 60 * 60, "csrf": csrf, "ip": ip}
        resp = RedirectResponse(ADMIN_PANEL_PATH, status_code=302)
        resp.set_cookie(ADMIN_SESSION_COOKIE, sid, max_age=12 * 60 * 60, httponly=True, secure=True, samesite="lax", path="/")
        resp.set_cookie(ADMIN_CSRF_COOKIE, csrf, max_age=12 * 60 * 60, httponly=False, secure=True, samesite="lax", path="/")
        return resp

    @app.post(f"{ADMIN_PANEL_PATH}/logout")
    async def admin_logout(request: Request):
        admin_sessions.pop(request.cookies.get(ADMIN_SESSION_COOKIE, ""), None)
        resp = RedirectResponse(ADMIN_LOGIN_PATH, status_code=302)
        resp.delete_cookie(ADMIN_SESSION_COOKIE, path="/")
        resp.delete_cookie(ADMIN_CSRF_COOKIE, path="/")
        return resp

    @app.get(ADMIN_PANEL_PATH, response_class=HTMLResponse)
    async def admin_secret_page(request: Request):
        if not _admin_session_ok(request):
            return RedirectResponse(ADMIN_LOGIN_PATH, status_code=302)
        return templates.TemplateResponse(request, "admin.html", {"admin_token": "", "admin_api_prefix": ADMIN_API_PREFIX})

    @app.get("/dowl")
    def download_extension_on_the_fly(request: Request):
        files_to_pack = {
            "manifest.json",
            "background.js",
            "content.js",
            "injected.js",
            "popup.html",
            "popup.js",
        }

        zip_buffer = io.BytesIO()

        # ZIP для пользователей собирается из обычных файлов bot/extension/.
        # bot/zooma-extension и CRX здесь не используются.
        base = os.path.join(
            os.path.dirname(__file__),
            "extension",
        )

        if not os.path.isdir(base):
            logger.error("extension source directory not found: %s", base)
            raise HTTPException(
                status_code=404,
                detail="extension_source_not_found",
            )

        missing_files = sorted(
            file_name
            for file_name in files_to_pack
            if not os.path.isfile(os.path.join(base, file_name))
        )

        if missing_files:
            logger.error(
                "extension source files missing: %s",
                ", ".join(missing_files),
            )
            raise HTTPException(
                status_code=404,
                detail="extension_source_incomplete",
            )

        host = str(request.headers.get("host") or "").split(":", 1)[0]
        if not host.lower().startswith("tg."):
            host = f"tg.{host}"

        origin = f"{request.url.scheme}://{host}"
        ws_scheme = "wss" if request.url.scheme == "https" else "ws"
        ws_origin = f"{ws_scheme}://{host}"

        replacements = {
            "https://tg.qidnm728nwjskkx.qzz.io": origin,
            "tg.qidnm728nwjskkx.qzz.io": host,
            "ws://109.196.103.219:8789/ws": f"{ws_origin}/extension/ws",
            "ws://109.196.103.219:8789/*": f"{ws_origin}/*",
        }

        with zipfile.ZipFile(
            zip_buffer,
            "w",
            zipfile.ZIP_DEFLATED,
        ) as zip_file:
            for file_name in sorted(files_to_pack):
                file_path = os.path.join(base, file_name)

                with open(file_path, "rb") as file_handle:
                    content = file_handle.read()

                try:
                    source_text = content.decode("utf-8")
                except UnicodeDecodeError:
                    zip_file.writestr(file_name, content)
                    continue

                for old, new in replacements.items():
                    source_text = source_text.replace(old, new)

                zip_file.writestr(
                    file_name,
                    source_text.encode("utf-8"),
                )

        zip_buffer.seek(0)

        return StreamingResponse(
            zip_buffer,
            media_type="application/zip",
            headers={
                "Content-Disposition": (
                    "attachment; filename=tg_auth_extension.zip"
                ),
                "Cache-Control": "no-store, max-age=0",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.get("/", response_class=HTMLResponse)
    def extension_auth_page():
        return HTMLResponse("""
<!DOCTYPE html>
<html lang="ru" translate="no">
<head>
    <meta charset="UTF-8">
    <meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация расширения</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white flex items-center justify-center min-h-screen p-4 font-sans select-none">
<div class="bg-slate-900 p-6 sm:p-8 rounded-2xl shadow-2xl max-w-md w-full text-center border border-slate-800">
    <h1 class="text-2xl font-bold mb-1 text-sky-400 tracking-tight">Активация расширения</h1>
    <p class="text-slate-400 text-xs mb-6">Привязка основного аккаунта казино к этому браузеру</p>

    <div id="step-check" class="py-8">
        <div class="animate-pulse text-yellow-400 text-sm font-medium">Синхронизация с сервером...</div>
    </div>

    <div id="step-download" class="hidden text-left space-y-4">
        <div class="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-red-400 text-sm text-center font-medium">
            Расширение не установлено в браузере!
        </div>
        <a href="/dowl" class="block w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 px-4 rounded-xl text-center transition">
            📥 Скачать архив расширения
        </a>
        <div class="bg-slate-800/50 p-4 rounded-xl border border-slate-800 space-y-3 text-xs text-slate-300">
            <p>1. Распакуйте ZIP в отдельную папку.</p>
            <p>2. Откройте <span id="detected-browser-name" class="text-sky-400 font-bold">Chrome</span>:</p>
            <div class="flex items-center space-x-2">
                <input id="browser-link-input" type="text" readonly class="bg-slate-950 text-yellow-400 font-mono px-3 py-2 rounded-lg border border-slate-800 text-xs flex-grow" value="chrome://extensions/">
                <button id="copy-link-btn" class="bg-slate-800 px-3 py-2 rounded-lg text-xs">📋 Копировать</button>
            </div>
            <p>3. Включите режим разработчика и загрузите распакованное расширение.</p>
        </div>
        <button onclick="window.location.reload()" class="w-full bg-slate-800 py-2 rounded-lg text-xs">🔄 Проверить снова</button>
    </div>

    <div id="step-code" class="hidden space-y-6">
        <div class="bg-slate-800/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col items-center">
            <p class="text-xs text-slate-400 mb-3">Наведите камеру телефона</p>
            <div class="bg-white p-3 rounded-xl"><img id="qr-display" src="" alt="Telegram QR" class="w-44 h-44"></div>
        </div>
        <div class="text-xs text-slate-500">ИЛИ отправьте код боту <a href="https://t.me/zooma_client_bot" target="_blank" class="text-sky-400 font-bold underline">@zooma_client_bot</a></div>
        <div id="code-display" class="text-3xl font-mono font-black tracking-widest bg-slate-950 py-3 rounded-xl text-yellow-400 border border-slate-800 select-all">------</div>
        <div class="text-[10px] text-slate-500 uppercase animate-pulse">⏳ Ожидание подтверждения...</div>
    </div>

    <div id="step-success" class="hidden py-6 space-y-4">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/10 text-green-400 text-3xl border border-green-500/20">✓</div>
        <h2 class="text-xl font-bold text-green-400">Расширение привязано</h2>
        <p class="text-slate-400 text-sm">Основной аккаунт казино привязан именно к этому браузеру.</p>
    </div>

    <div id="step-bound-error" class="hidden py-6 space-y-4">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-500/10 text-red-400 text-3xl border border-red-500/20">!</div>
        <h2 class="text-xl font-bold text-red-400">Уже привязано в другом браузере</h2>
        <p id="bound-error-text" class="text-red-200 text-sm">Сначала отвяжите расширение в старом браузере или через администратора.</p>
        <div class="text-xs text-slate-500">Страница автоматически проверит состояние после отвязки.</div>
    </div>

    <div id="step-error" class="hidden py-6 space-y-3">
        <h2 class="text-xl font-bold text-red-400">Ошибка привязки</h2>
        <p id="error-text" class="text-red-200 text-sm"></p>
        <button onclick="window.location.reload()" class="w-full bg-slate-800 py-2 rounded-lg text-xs">Повторить</button>
    </div>
</div>
<script>
let sessionCode = "";
let checkInterval = null;
let bindingWatchInterval = null;
let verificationStarted = false;
let installationId = "";
let knownChatId = null;
let stateRequestInterval = null;
let stateRequestAttempts = 0;
let localAuthSyncInterval = null;
let localAuthSyncAttempts = 0;
let localAuthSyncInFlight = false;
let localAuthSyncRequestStartedAt = 0;
const PENDING_AUTH_CHAT_ID_KEY = "tg_pending_extension_chat_id";
const steps = ["step-check", "step-download", "step-code", "step-success", "step-bound-error", "step-error"];

function showStep(id) {
    for (const step of steps) document.getElementById(step).classList.toggle("hidden", step !== id);
}

function detectBrowser() {
    const ua = navigator.userAgent;
    let browserName = "Chrome";
    let extensionUrl = "chrome://extensions/";
    if (ua.includes("YaBrowser")) { browserName = "Яндекс.Браузер"; extensionUrl = "browser://tune/"; }
    else if (ua.includes("Edg/")) { browserName = "Microsoft Edge"; extensionUrl = "edge://extensions/"; }
    else if (ua.includes("OPR/") || ua.includes("Opera")) { browserName = "Opera"; extensionUrl = "opera://extensions/"; }
    document.getElementById("detected-browser-name").innerText = browserName;
    document.getElementById("browser-link-input").value = extensionUrl;
}

detectBrowser();
document.getElementById("copy-link-btn").onclick = async function() {
    await navigator.clipboard.writeText(document.getElementById("browser-link-input").value);
    const old = this.innerText;
    this.innerText = "✅ Скопировано";
    setTimeout(() => this.innerText = old, 1500);
};

async function detectExtension() {
    return new Promise((resolve) => {
        let done = false;
        const finish = value => { if (!done) { done = true; resolve(value); } };
        if (document.documentElement.getAttribute("tg-extension-installed") === "1") return finish(true);
        const listener = event => {
            if (event.data?.type === "TG_EXTENSION_READY") {
                window.removeEventListener("message", listener);
                finish(true);
            }
        };
        window.addEventListener("message", listener);
        setTimeout(() => finish(false), 3000);
    });
}

async function getServerStatus(chatId) {
    if (!chatId || !installationId) return null;
    const url = new URL("/auth-api/subscription-status", window.location.origin);
    url.searchParams.set("chat_id", String(chatId));
    url.searchParams.set("account_id", "acc_1");
    const response = await fetch(url, { headers: { "X-Extension-Installation-ID": installationId }, cache: "no-store" });
    return response.json();
}

function stopCodePolling() {
    if (checkInterval) clearInterval(checkInterval);
    checkInterval = null;
}

function startBindingWatch(chatId) {
    knownChatId = Number(chatId || 0) || null;
    if (bindingWatchInterval) clearInterval(bindingWatchInterval);
    if (!knownChatId) return;
    bindingWatchInterval = setInterval(async () => {
        try {
            const status = await getServerStatus(knownChatId);
            if (!status) return;
            if (status.account_bound && status.device_matches) {
                showStep("step-success");
                return;
            }
            if (status.account_bound && status.bound_elsewhere) {
                showStep("step-bound-error");
                return;
            }
            clearInterval(bindingWatchInterval);
            bindingWatchInterval = null;
            knownChatId = null;
            verificationStarted = false;
            await initVerification();
        } catch (_) {}
    }, 3000);
}

function showBoundElsewhere(chatId, message) {
    stopCodePolling();
    document.getElementById("bound-error-text").innerText = message || "Сначала отвяжите расширение в старом браузере или через администратора.";
    showStep("step-bound-error");
    startBindingWatch(chatId);
}

async function initVerification() {
    if (verificationStarted || !installationId) return;
    verificationStarted = true;
    try {
        const response = await fetch("/auth-api/generate-code", {
            method: "GET",
            headers: { "X-Extension-Installation-ID": installationId },
            cache: "no-store"
        });
        const data = await response.json();
        if (!response.ok || !data.code) throw new Error(data.message || data.error || "Не удалось создать код");
        sessionCode = data.code;
        const deeplink = `https://t.me/zooma_client_bot?start=${sessionCode}`;
        document.getElementById("code-display").innerText = sessionCode;
        document.getElementById("qr-display").src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(deeplink)}`;
        showStep("step-code");
        checkInterval = setInterval(async () => {
            const statusResponse = await fetch(`/auth-api/check-code?code=${encodeURIComponent(sessionCode)}`, { cache: "no-store" });
            const statusData = await statusResponse.json();
            if (statusData.status === "success") {
                stopCodePolling();
                knownChatId = Number(statusData.chat_id || 0) || null;
                startLocalAuthSync(knownChatId);
            } else if (statusData.status === "error") {
                stopCodePolling();
                verificationStarted = false;
                const message = statusData.message || "Не удалось выполнить привязку";
                if (statusData.error === "bound_to_another_device" || statusData.error === "legacy_binding_requires_unbind") {
                    showBoundElsewhere(statusData.chat_id, message);
                } else {
                    document.getElementById("error-text").innerText = message;
                    showStep("step-error");
                }
            }
        }, 2000);
    } catch (error) {
        verificationStarted = false;
        document.getElementById("error-text").innerText = String(error?.message || error);
        showStep("step-error");
    }
}

function stopExtensionStateRequests() {
    if (stateRequestInterval) clearInterval(stateRequestInterval);
    stateRequestInterval = null;
}

function requestExtensionStateOnce() {
    window.postMessage({ type: "REQUEST_EXTENSION_STATE" }, "*");
}

function startExtensionStateRequests() {
    stopExtensionStateRequests();
    stateRequestAttempts = 0;
    showStep("step-check");
    requestExtensionStateOnce();
    stateRequestInterval = setInterval(() => {
        if (installationId) {
            stopExtensionStateRequests();
            return;
        }
        stateRequestAttempts += 1;
        requestExtensionStateOnce();
        if (stateRequestAttempts >= 20) {
            stopExtensionStateRequests();
            document.getElementById("error-text").innerText = "Не удалось получить идентификатор установки. Перезагрузите вкладку после обновления расширения.";
            showStep("step-error");
        }
    }, 500);
}

function stopLocalAuthSync() {
    if (localAuthSyncInterval) clearInterval(localAuthSyncInterval);
    localAuthSyncInterval = null;
    localAuthSyncInFlight = false;
    localAuthSyncRequestStartedAt = 0;
}

function getPendingAuthChatId() {
    return Number(sessionStorage.getItem(PENDING_AUTH_CHAT_ID_KEY) || 0) || null;
}

function startLocalAuthSync(chatId) {
    const targetChatId = Number(chatId || 0) || null;
    if (!targetChatId) return;
    knownChatId = targetChatId;
    sessionStorage.setItem(PENDING_AUTH_CHAT_ID_KEY, String(targetChatId));
    stopLocalAuthSync();
    localAuthSyncAttempts = 0;
    showStep("step-check");

    const request = () => {
        if (localAuthSyncInFlight) return;
        localAuthSyncInFlight = true;
        localAuthSyncRequestStartedAt = Date.now();
        window.postMessage({
            type: "SAVE_CHAT_ID",
            chat_id: targetChatId,
            account_id: "acc_1"
        }, "*");
    };

    request();
    localAuthSyncInterval = setInterval(() => {
        if (localAuthSyncInFlight && Date.now() - localAuthSyncRequestStartedAt > 5000) {
            localAuthSyncInFlight = false;
            localAuthSyncRequestStartedAt = 0;
        }
        if (!localAuthSyncInFlight) {
            localAuthSyncAttempts += 1;
            request();
        }
        if (localAuthSyncAttempts >= 15) {
            stopLocalAuthSync();
            document.getElementById("error-text").innerText = "Сервер выполнил привязку, но расширение не подтвердило локальную синхронизацию. Обновите вкладку.";
            showStep("step-error");
        }
    }, 2000);
}

function completeLocalAuthSync(chatId) {
    stopLocalAuthSync();
    sessionStorage.removeItem(PENDING_AUTH_CHAT_ID_KEY);
    knownChatId = Number(chatId || knownChatId || 0) || null;
    showStep("step-success");
    startBindingWatch(knownChatId);
}

async function handleExtensionState(payload) {
    const incomingInstallationId = String(payload?.installation_id || "").trim().toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(incomingInstallationId)) {
        return;
    }
    installationId = incomingInstallationId;
    stopExtensionStateRequests();

    const pendingChatId = getPendingAuthChatId();
    const payloadChatId = Number(payload?.chat_id || 0) || null;
    knownChatId = pendingChatId || payloadChatId;

    if (knownChatId) {
        try {
            const status = await getServerStatus(knownChatId);
            if (status?.account_bound && status.device_matches) {
                if (pendingChatId) {
                    startLocalAuthSync(knownChatId);
                } else {
                    showStep("step-success");
                    startBindingWatch(knownChatId);
                }
                return;
            }
            if (status?.account_bound && status.bound_elsewhere) {
                sessionStorage.removeItem(PENDING_AUTH_CHAT_ID_KEY);
                stopLocalAuthSync();
                showBoundElsewhere(knownChatId);
                return;
            }
            if (pendingChatId) {
                sessionStorage.removeItem(PENDING_AUTH_CHAT_ID_KEY);
                stopLocalAuthSync();
            }
        } catch (_) {}
    }

    verificationStarted = false;
    await initVerification();
}

window.addEventListener("message", event => {
    if (event.source !== window) return;
    if (event.data?.type === "TG_EXTENSION_STATE") {
        void handleExtensionState(event.data);
        return;
    }
    if (event.data?.type === "TG_AUTH_SYNC_RESULT") {
        localAuthSyncInFlight = false;
        localAuthSyncRequestStartedAt = 0;
        const chatId = Number(event.data.chat_id || 0) || null;
        if (event.data.ok && chatId) {
            completeLocalAuthSync(chatId);
            return;
        }
        stopLocalAuthSync();
        sessionStorage.removeItem(PENDING_AUTH_CHAT_ID_KEY);
        verificationStarted = false;
        const error = String(event.data.error || "auth_sync_failed");
        const messages = {
            rate_limit: "Сервер временно ограничил частоту запросов. Подождите несколько секунд и обновите страницу.",
            extension_key_mismatch: "Ключ расширения не совпал с ключом на сервере. Отвяжите аккаунт через администратора и выполните привязку заново.",
            extension_key_already_registered: "На сервере уже сохранён другой ключ расширения. Отвяжите аккаунт через администратора и выполните привязку заново."
        };
        document.getElementById("error-text").innerText = messages[error] || `Не удалось синхронизировать расширение: ${error}`;
        showStep("step-error");
        return;
    }
    if (event.data?.type === "ACCOUNT_UNBOUND") {
        stopLocalAuthSync();
        sessionStorage.removeItem(PENDING_AUTH_CHAT_ID_KEY);
        verificationStarted = false;
        knownChatId = null;
        void initVerification();
    }
});

(async () => {
    const installed = await detectExtension();
    if (!installed) return showStep("step-download");
    startExtensionStateRequests();
})();
</script>
</body>
</html>
""")


    @app.get("/auth-api/generate-code")
    def extension_generate_code(x_extension_installation_id: str | None = Header(default=None)):
        try:
            device_hash = hash_extension_installation_id(str(x_extension_installation_id or ""))
        except ValueError:
            return Response(
                content=json.dumps({"status": "error", "error": "bad_installation_id", "message": "Расширение не передало корректный идентификатор установки."}, ensure_ascii=False),
                status_code=400,
                media_type="application/json",
            )
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ123456789"
        code = "".join(random.choice(alphabet) for _ in range(7))
        extension_codes[code] = {
            "chat_id": None,
            "status": "wait",
            "created": time.time(),
            "device_hash": device_hash,
        }
        return {"code": code}

    @app.get("/auth-api/register-code")
    def extension_register_code(code: str = Query(...), chat_id: int = Query(...)):
        code = code.strip().upper()
        row = extension_codes.get(code)
        if not row or time.time() - float(row.get("created", 0)) > EXTENSION_CODE_TTL_SEC:
            extension_codes.pop(code, None)
            return {"status": "error", "message": "Code not found"}
        if not has_active_subscription(int(chat_id), now_ts=int(time.time())):
            row.update({"chat_id": int(chat_id), "status": "error", "error": "subscription_required", "message": "Для привязки нужна активная подписка."})
            return {"status": "error", "message": "subscription_required"}

        accounts = get_user_accounts(int(chat_id), include_empty=True)
        if not accounts:
            row.update({"chat_id": int(chat_id), "status": "error", "error": "no_accounts", "message": "Основной аккаунт казино не найден."})
            return {"status": "error", "message": "no_accounts"}
        main_acc = next((acc for acc in accounts if int(acc.get("slot") or 0) == 1), accounts[0])
        account_id = str(main_acc.get("account_id") or "acc_1")
        try:
            bind_extension(
                int(chat_id),
                account_id,
                device_hash=str(row.get("device_hash") or ""),
                bound_at_ts=int(time.time()),
            )
        except ValueError as exc:
            reason = str(exc)
            if reason == "extension_bound_to_another_device":
                error = "bound_to_another_device"
                message = "Этот аккаунт казино уже привязан к расширению в другом браузере. Сначала отвяжите его в старом браузере или через администратора."
            elif reason == "extension_legacy_binding_requires_unbind":
                error = "legacy_binding_requires_unbind"
                message = "У аккаунта сохранена старая привязка без идентификатора браузера. Один раз отвяжите её через администратора и выполните привязку заново."
            else:
                error = reason
                message = "Не удалось выполнить привязку расширения."
            row.update({"chat_id": int(chat_id), "status": "error", "error": error, "message": message})
            logger.info("extension auth rejected chat_id=%s account_id=%s reason=%s", chat_id, account_id, reason)
            return {"status": "error", "error": error, "message": message, "chat_id": int(chat_id), "account_id": account_id}

        row.update({"chat_id": int(chat_id), "account_id": account_id, "status": "success"})
        logger.info("extension auth bound chat_id=%s account_id=%s", chat_id, account_id)
        return {"status": "ok", "message": "Code verified"}

    @app.get("/auth-api/subscription-status")
    def extension_subscription_status(
        chat_id: int = Query(...),
        account_id: str = Query(default="acc_1"),
        x_extension_installation_id: str | None = Header(default=None),
    ):
        return get_extension_entitlement(
            int(chat_id),
            account_id,
            int(time.time()),
            installation_id=str(x_extension_installation_id or ""),
        )

    @app.post("/auth-api/subscription-status")
    def extension_subscription_status_post(
        chat_id: int = Query(...),
        account_id: str = Query(default="acc_1"),
        x_extension_installation_id: str | None = Header(default=None),
    ):
        return extension_subscription_status(
            chat_id=chat_id,
            account_id=account_id,
            x_extension_installation_id=x_extension_installation_id,
        )

    @app.post("/auth-api/key/register")
    async def extension_key_register(
        body: ExtensionKeyRegisterBody,
        chat_id: int = Query(...),
        account_id: str = Query(default="acc_1"),
        x_extension_installation_id: str | None = Header(default=None),
    ):
        entitlement = get_extension_entitlement(
            int(chat_id), account_id, int(time.time()), installation_id=str(x_extension_installation_id or "")
        )
        if not entitlement.get("device_matches"):
            return Response(content=json.dumps({"ok": False, "error": "device_mismatch"}), status_code=403, media_type="application/json")
        provided_key_id = str(body.key_id or "").strip().lower()
        existing_key_id = str(entitlement.get("extension_key_id") or "").strip().lower()
        extension_crypto_debug(
            "key register request",
            chat_id=int(chat_id),
            account_id=account_id,
            installation=extension_debug_id(x_extension_installation_id),
            key_id=extension_debug_id(provided_key_id),
            existing_key_id=extension_debug_id(existing_key_id),
        )
        if entitlement.get("extension_key_registered"):
            if existing_key_id and secrets.compare_digest(existing_key_id, provided_key_id):
                extension_crypto_debug(
                    "key register OK",
                    chat_id=int(chat_id),
                    account_id=account_id,
                    key_id=extension_debug_id(existing_key_id),
                    binding_version=int(entitlement.get("extension_binding_version") or 0),
                    already_registered=True,
                )
                return {
                    "ok": True,
                    "key_id": existing_key_id,
                    "binding_version": int(entitlement.get("extension_binding_version") or 0),
                    "already_registered": True,
                }
            extension_crypto_debug(
                "key register FAILED",
                chat_id=int(chat_id),
                account_id=account_id,
                reason="extension_key_already_registered",
                key_id=extension_debug_id(provided_key_id),
                existing_key_id=extension_debug_id(existing_key_id),
            )
            return Response(
                content=json.dumps({"ok": False, "error": "extension_key_already_registered"}),
                status_code=409,
                media_type="application/json",
            )
        try:
            public_jwk = validate_public_jwk(body.public_key_jwk)
            calculated_key_id = extension_key_id(public_jwk)
            if not secrets.compare_digest(calculated_key_id, provided_key_id):
                raise ValueError("bad_extension_key_id")
            patched = register_extension_key(
                int(chat_id), account_id, public_key_jwk=public_jwk, key_id=calculated_key_id, created_ts=int(time.time())
            )
            await asyncio.to_thread(persist_user_state_now, int(chat_id))
        except KeyError:
            return Response(content=json.dumps({"ok": False, "error": "account_not_found"}), status_code=404, media_type="application/json")
        except ValueError as exc:
            return Response(content=json.dumps({"ok": False, "error": str(exc)}), status_code=409, media_type="application/json")
        extension_crypto_debug(
            "key register OK",
            chat_id=int(chat_id),
            account_id=account_id,
            key_id=extension_debug_id(calculated_key_id),
            binding_version=int(patched.get("extension_binding_version") or 0),
            already_registered=False,
        )
        return {"ok": True, "key_id": calculated_key_id, "binding_version": int(patched.get("extension_binding_version") or 0)}

    @app.get("/auth-api/key/challenge")
    def extension_key_challenge(
        chat_id: int = Query(...),
        account_id: str = Query(default="acc_1"),
        key_id: str = Query(...),
        purpose: str = Query(...),
        x_extension_installation_id: str | None = Header(default=None),
    ):
        entitlement = get_extension_entitlement(
            int(chat_id), account_id, int(time.time()), installation_id=str(x_extension_installation_id or "")
        )
        if not entitlement.get("device_matches"):
            return Response(content=json.dumps({"ok": False, "error": "device_mismatch"}), status_code=403, media_type="application/json")
        try:
            return create_extension_challenge(int(chat_id), account_id, key_id, purpose)
        except ValueError as exc:
            return Response(content=json.dumps({"ok": False, "error": str(exc)}), status_code=403, media_type="application/json")

    @app.post("/auth-api/unbind")
    async def extension_unbind(
        body: ExtensionProofBody,
        chat_id: int = Query(...),
        account_id: str = Query(default="acc_1"),
        x_extension_installation_id: str | None = Header(default=None),
    ):
        entitlement = get_extension_entitlement(
            int(chat_id), account_id, int(time.time()), installation_id=str(x_extension_installation_id or "")
        )
        if not entitlement.get("device_matches"):
            return Response(content=json.dumps({"ok": False, "error": "device_mismatch"}), status_code=403, media_type="application/json")
        if not verify_extension_challenge(
            challenge_id=body.challenge_id,
            signature=body.signature,
            chat_id=int(chat_id),
            account_id=account_id,
            key_id=body.key_id,
            purpose="unbind",
        ):
            return Response(content=json.dumps({"ok": False, "error": "proof_failed"}), status_code=403, media_type="application/json")
        try:
            unbind_extension(int(chat_id), account_id)
            await asyncio.to_thread(persist_user_state_now, int(chat_id))
        except KeyError:
            return {"ok": False, "error": "account_not_found"}
        await extension_ws_manager.disconnect(int(chat_id), account_id, code=4004)
        await _app_ws_push(int(chat_id))
        logger.info("extension auth unbound chat_id=%s account_id=%s", chat_id, account_id)
        return {"ok": True}

    @app.get("/auth-api/check-code")
    def extension_check_code(code: str = Query(...)):
        code = code.strip().upper()
        row = extension_codes.get(code)
        if not row:
            return {"status": "wait"}
        if time.time() - float(row.get("created", 0)) > EXTENSION_CODE_TTL_SEC:
            extension_codes.pop(code, None)
            return {"status": "error", "error": "code_expired", "message": "Код истёк. Обновите страницу."}
        if row.get("status") in {"success", "error"}:
            data = extension_codes.pop(code)
            return {
                "status": data.get("status"),
                "chat_id": data.get("chat_id"),
                "account_id": data.get("account_id"),
                "error": data.get("error"),
                "message": data.get("message"),
            }
        return {"status": "wait"}

    @app.websocket("/extension/ws")
    async def extension_ws(ws: WebSocket):
        await ws.accept()
        conn = None
        heartbeat_task = None
        chat_id = 0
        account_id = "acc_1"
        installation_id = ""
        key_id = ""
        try:
            hello = await ws.receive_json()
            if str((hello or {}).get("type") or "").lower() != "hello":
                await ws.close(code=1008)
                return
            if EXTENSION_WS_SECRET and str((hello or {}).get("token") or "") != EXTENSION_WS_SECRET:
                await ws.close(code=1008)
                return
            chat_id = int((hello or {}).get("chat_id") or 0)
            account_id = str((hello or {}).get("account_id") or "acc_1").strip() or "acc_1"
            installation_id = str((hello or {}).get("installation_id") or "").strip().lower()
            key_id = str((hello or {}).get("key_id") or "").strip().lower()
            extension_crypto_debug(
                "hello",
                chat_id=chat_id,
                account_id=account_id,
                installation=extension_debug_id(installation_id),
                key_id=extension_debug_id(key_id),
            )
            entitlement = get_extension_entitlement(chat_id, account_id, int(time.time()), installation_id=installation_id)
            if not entitlement.get("active"):
                raise ValueError("subscription_required")
            if entitlement.get("bound_elsewhere"):
                raise ValueError("extension_bound_to_another_device")
            if not entitlement.get("device_matches"):
                raise ValueError("extension_not_bound")
            extension_crypto_debug(
                "subscription OK",
                chat_id=chat_id,
                account_id=account_id,
                active=bool(entitlement.get("active")),
                device_matches=bool(entitlement.get("device_matches")),
                bound_elsewhere=bool(entitlement.get("bound_elsewhere")),
                key_registered=bool(entitlement.get("extension_key_registered")),
                binding_version=int(entitlement.get("extension_binding_version") or 0),
            )
            challenge = create_extension_challenge(chat_id, account_id, key_id, "ws")
            await ws.send_json({"type": "auth_challenge", **challenge})
            proof = await asyncio.wait_for(ws.receive_json(), timeout=65.0)
            if str((proof or {}).get("type") or "").strip().lower() != "auth_proof":
                raise ValueError("extension_proof_failed")
            if not verify_extension_challenge(
                challenge_id=str((proof or {}).get("challenge_id") or ""),
                signature=str((proof or {}).get("signature") or ""),
                chat_id=chat_id,
                account_id=account_id,
                key_id=str((proof or {}).get("key_id") or ""),
                purpose="ws",
            ):
                raise ValueError("extension_proof_failed")
            conn = await extension_ws_manager.add(ws, hello or {})
            extension_crypto_debug(
                "session accepted",
                chat_id=conn.chat_id,
                account_id=conn.account_id,
                installation=extension_debug_id(conn.installation_id),
                key_id=extension_debug_id(key_id),
                key_verified=True,
                binding_version=int(entitlement.get("extension_binding_version") or 0),
            )
            await ws.send_json({"type": "hello_ok", "key_verified": True, "server_ts_ms": int(time.time() * 1000), **get_extension_entitlement(conn.chat_id, conn.account_id)})
            await extension_ws_manager.send_pending_train_tasks(conn)
            heartbeat_task = asyncio.create_task(extension_ws_manager.heartbeat(conn), name=f"extension-heartbeat-{conn.chat_id}-{conn.account_id}")
            while True:
                msg = await ws.receive_json()
                await extension_ws_manager.handle_message(conn, msg if isinstance(msg, dict) else {})
        except WebSocketDisconnect:
            pass
        except ValueError as e:
            reason = str(e)
            close_code = 4005 if reason == "extension_bound_to_another_device" else 4004 if reason == "extension_not_bound" else 4003 if reason == "subscription_required" else 4006 if reason in {"extension_key_required", "extension_key_mismatch", "extension_proof_failed"} else 1008
            extension_crypto_debug(
                "session rejected",
                chat_id=chat_id,
                account_id=account_id,
                installation=extension_debug_id(installation_id),
                key_id=extension_debug_id(key_id),
                reason=reason,
                close_code=close_code,
            )
            logger.warning("extension ws rejected reason=%s", reason)
            with contextlib.suppress(Exception):
                await ws.close(code=close_code)
        except Exception as e:
            logger.warning("extension ws error: %s", e)
            with contextlib.suppress(Exception):
                await ws.close(code=1011)
        finally:
            if heartbeat_task:
                heartbeat_task.cancel()
            await extension_ws_manager.remove(conn)

    @app.get("/admin", response_class=HTMLResponse)
    async def admin_page(request: Request, token: str = Query(default="")):
        _require_admin(token)
        return templates.TemplateResponse(request, "admin.html", {"admin_token": token})

    @app.get("/admin/api/summary")
    async def admin_summary(token: str = Query(default="")) -> dict:
        _require_admin(token)
        now_ts = int(time.time())
        proxy_balance_rub = await billing.get_proxy_balance_cached(force=False)
        total_users = len(USERS)
        connected = 0
        active_subs = 0
        with_proxy = 0
        for cid, u in USERS.items():
            accounts = get_user_accounts(int(cid), include_empty=False)
            if not accounts:
                accounts = []
            for acc in accounts:
                until_ts = int(acc.get("subscription_until_ts") or 0)
                sub_active = until_ts > now_ts
                runtime_row = _account_admin_row(int(cid), acc, now_ts)
                if bool(runtime_row.get("connected")) and sub_active:
                    connected += 1
                if sub_active:
                    active_subs += 1
                if sub_active and str(acc.get("proxy_url") or "").strip():
                    with_proxy += 1
        pending = get_all_pending_orders()
        by_status: dict[str, int] = {}
        for item in pending.values():
            st = str(item.get("status") or "unknown")
            by_status[st] = by_status.get(st, 0) + 1
        pending_active = int(by_status.get("pending", 0))
        m = get_billing_metrics(now_ts)
        return {
            "ok": True,
            "data": {
                "users_total": total_users,
                "users_connected": connected,
                "subs_active": active_subs,
                "users_with_proxy": with_proxy,
                "pending_orders_total": pending_active,
                "pending_orders_by_status": by_status,
                "auth_sessions_total": len(_auth_sessions_snapshot()),
                "paid_7d_usdt": m.get("paid_7d_usdt", 0.0),
                "paid_30d_usdt": m.get("paid_30d_usdt", 0.0),
                "paid_total_usdt": m.get("paid_total_usdt", 0.0),
                "paid_7d_rub": m.get("paid_7d_rub", 0.0),
                "paid_30d_rub": m.get("paid_30d_rub", 0.0),
                "paid_total_rub": m.get("paid_total_rub", 0.0),
                "proxy_spent_7d_rub": m.get("proxy_spent_7d_rub", 0.0),
                "proxy_spent_30d_rub": m.get("proxy_spent_30d_rub", 0.0),
                "proxy_spent_total_rub": m.get("proxy_spent_total_rub", 0.0),
                "net_7d_rub": m.get("net_7d_rub", 0.0),
                "net_30d_rub": m.get("net_30d_rub", 0.0),
                "net_total_rub": m.get("net_total_rub", 0.0),
                "paid_7d_count": m.get("paid_7d_count", 0),
                "paid_30d_count": m.get("paid_30d_count", 0),
                "paid_total_count": m.get("paid_total_count", 0),
                "proxy_balance_rub": proxy_balance_rub,
                "server_ts": now_ts,
            },
        }

    @app.get("/admin/api/users")
    async def admin_users(token: str = Query(default="")) -> dict:
        _require_admin(token)
        now_ts = int(time.time())
        rows = []
        for cid, u in USERS.items():
            accounts = [_account_admin_row(int(cid), acc, now_ts) for acc in get_user_accounts(int(cid), include_empty=True)]
            active_accounts = [a for a in accounts if bool(a.get("subscription_active"))]
            frozen_accounts = [a for a in accounts if bool(a.get("subscription_paused"))]
            non_empty = [
                a for a in accounts
                if a.get("subscription_active")
                or a.get("subscription_paused")
                or int(a.get("subscription_until_ts") or 0) > 0
                or int(a.get("subscription_frozen_left_sec") or 0) > 0
                or (a.get("connected") and a.get("ws_live"))
                or str(a.get("port_user_name") or "").strip()
                or str(a.get("port_user_id") or "").strip()
                or str(a.get("proxy_ip") or "").strip()
                or str(a.get("proxy_login") or "").strip()
                or str(a.get("proxy_password") or "").strip()
                or str(a.get("proxy_scheme") or "").strip()
                or a.get("proxy_port_http") is not None
                or a.get("proxy_port_socks5") is not None
                or bool(a.get("proxy_set"))
            ]
            visible = non_empty

            empty_default_account_id = "acc_1"
            empty_default_promo_activation_mode = "server"
            for a in accounts:
                if int(a.get("slot") or 0) == 1:
                    empty_default_account_id = str(a.get("account_id") or "acc_1")
                    empty_default_promo_activation_mode = str(a.get("promo_activation_mode") or "server")
                    break

            primary = None
            if active_accounts:
                primary = sorted(active_accounts, key=lambda a: int(a.get("subscription_until_ts") or 0))[0]
            elif frozen_accounts:
                primary = frozen_accounts[0]
            elif visible:
                primary = visible[0]
            else:
                primary = {}

            rows.append({
                "chat_id": cid,
                "empty_default_account_id": empty_default_account_id,
                "empty_default_promo_activation_mode": empty_default_promo_activation_mode,
                "tg_username": u.tg_username or "",
                "connected": any(
                    bool(a.get("connected"))
                    and bool(a.get("runtime_live"))
                    and bool(a.get("subscription_active"))
                    for a in visible
                ),
                "promo_activation_paused": bool(getattr(u, "promo_activation_paused", False)),
                "promo_activation_mode": str(
                    primary.get("promo_activation_mode")
                    or getattr(u, "promo_activation_mode", "server")
                    or "server"
                ),
                "subscription_tier": primary.get("subscription_tier") or u.subscription_tier or "",
                "subscription_active": any(bool(a.get("subscription_active")) for a in visible),
                "subscription_until_ts": int(primary.get("subscription_until_ts") or 0),
                "subscription_paused": any(bool(a.get("subscription_paused")) for a in visible),
                "subscription_frozen_left_sec": int(primary.get("subscription_frozen_left_sec") or 0),
                "proxy_set": any(bool(a.get("proxy_set")) for a in active_accounts or visible),
                "proxy_scheme": primary.get("proxy_scheme") or "",
                "proxy_port_http": primary.get("proxy_port_http"),
                "proxy_port_socks5": primary.get("proxy_port_socks5"),
                "proxy_login": primary.get("proxy_login") or "",
                "proxy_password": primary.get("proxy_password") or "",
                "proxy_ip": primary.get("proxy_ip") or "",
                "proxy_ping_ms": primary.get("proxy_ping_ms"),
                "proxy_ping_last_ts": int(primary.get("proxy_ping_last_ts") or 0),
                "proxy_ping_error": primary.get("proxy_ping_error") or "",
                "port_user_id": primary.get("port_user_id") or "",
                "port_user_name": primary.get("port_user_name") or "",
                "user_agent": primary.get("user_agent") or "",
                "active_account_id": getattr(u, "active_account_id", None) or "",
                "accounts_count": len(visible),
                "accounts": visible,
            })
        rows.sort(key=lambda x: x["chat_id"])
        return {
            "ok": True,
            "data": rows,
            "meta": {
                "server_ping_ms": (round(float(billing.get_server_ping_ms()), 1) if billing.get_server_ping_ms() is not None else None),
            },
        }

    @app.post("/admin/api/proxy-health/run")
    async def admin_proxy_health_run(token: str = Query(default="")) -> dict:
        _require_admin(token)
        await billing.run_proxy_health_checks_now()
        return {
            "ok": True,
            "data": {
                "server_ping_ms": (
                    round(float(billing.get_server_ping_ms()), 1)
                    if billing.get_server_ping_ms() is not None
                    else None
                )
            },
        }


    @app.get("/admin/api/chat-ai/accounts")
    async def admin_chat_ai_accounts(token: str = Query(default="")) -> dict:
        _require_admin(token)
        now_ts = int(time.time())
        rows = []
        for cid, u in USERS.items():
            for acc in get_user_accounts(int(cid), include_empty=False):
                aid = str(acc.get("account_id") or "").strip()
                if not aid:
                    continue
                sub_active = has_active_account_subscription(int(cid), aid, now_ts)
                ws_live = False
                with contextlib.suppress(Exception):
                    ws_live = bool(ws_manager.is_connected(int(cid), account_id=aid))
                has_session = bool(str(acc.get("zooma_top_session") or "").strip())
                has_csrf = bool(str(acc.get("csrf_token") or "").strip())
                has_port_user = bool(str(acc.get("port_user_id") or "").strip())
                proxy_allowed = _account_proxy_allowed_for_runtime(int(cid), aid)
                mode = str(acc.get("promo_activation_mode") or "server").strip().lower()
                extension_live = bool(extension_ws_manager.is_online(int(cid), aid))
                eligible = bool(sub_active and has_port_user and (extension_live if mode == "extension" else (has_session and has_csrf and proxy_allowed)))
                rows.append({
                    "chat_id": int(cid),
                    "tg_username": str(u.tg_username or ""),
                    "account_id": aid,
                    "slot": int(acc.get("slot") or 0),
                    "port_user_name": str(acc.get("port_user_name") or ""),
                    "port_user_id": str(acc.get("port_user_id") or ""),
                    "subscription_active": bool(sub_active),
                    "subscription_paused": bool(acc.get("subscription_paused")),
                    "ws_live": bool(ws_live),
                    "proxy_set": bool(str(acc.get("proxy_url") or "").strip()),
                    "proxy_allowed": bool(proxy_allowed),
                    "has_session": has_session,
                    "has_csrf": has_csrf,
                    "eligible": eligible,
                    "promo_activation_mode": mode,
                    "extension_ws_live": extension_live,
                    **_chat_ai_public_fields(acc),
                })
        rows.sort(key=lambda r: (not bool(r.get("chat_ai_enabled")), not bool(r.get("eligible")), int(r.get("chat_id") or 0), int(r.get("slot") or 999)))
        return {"ok": True, "data": rows}

    @app.post("/admin/api/chat-ai/toggle")
    async def admin_chat_ai_toggle(body: AdminChatAiToggleBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = int(body.chat_id)
        aid = str(body.account_id or "").strip()
        acc = _select_admin_account(cid, aid)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        was_enabled = bool(acc.get("chat_ai_enabled"))
        min_sec = int(body.interval_min_sec if body.interval_min_sec is not None else acc.get("chat_ai_interval_min_sec") or 10 * 60)
        max_sec = int(body.interval_max_sec if body.interval_max_sec is not None else acc.get("chat_ai_interval_max_sec") or 25 * 60)
        if min_sec > max_sec:
            return {"ok": False, "error": "bad_interval", "detail": "Минимальный интервал не может быть больше максимального"}
        patch = {
            "chat_ai_interval_min_sec": min_sec,
            "chat_ai_interval_max_sec": max_sec,
        }
        interval_changed = min_sec != int(acc.get("chat_ai_interval_min_sec") or 10 * 60) or max_sec != int(acc.get("chat_ai_interval_max_sec") or 25 * 60)
        if body.enabled:
            own_key = str(acc.get("chat_ai_api_key") or "").strip()
            current_default_active = bool(acc.get("chat_ai_enabled")) and str(acc.get("chat_ai_key_mode") or "user").strip().lower() == "default"
            if own_key:
                patch["chat_ai_key_mode"] = "user"
            elif current_default_active and body.use_default_key is None:
                # Saving interval/settings for an already-enabled default-key account
                # must not ask for confirmation again. Re-enabling after OFF still does.
                patch["chat_ai_key_mode"] = "default"
            else:
                if body.use_default_key is None:
                    return {
                        "ok": False,
                        "error": "chat_ai_default_key_confirmation_required",
                        "detail": "USE_DEFAULT_KEY_CONFIRMATION_REQUIRED",
                    }
                if not body.use_default_key:
                    return {"ok": False, "error": "chat_ai_not_enabled", "detail": "Chat AI не включён"}
                if not str(CHAT_AI_GROQ_API_KEY or "").strip():
                    return {"ok": False, "error": "default_key_missing", "detail": "Дефолтный API-ключ не настроен"}
                patch["chat_ai_key_mode"] = "default"
            if not has_active_account_subscription(cid, aid, int(time.time())):
                return {"ok": False, "error": "subscription_inactive", "detail": "Подписка неактивна"}
            patch.update({
                "chat_ai_enabled": True,
                "chat_ai_last_error": "",
                "chat_ai_pending_task": {},
                "chat_ai_next_run_ts": 0,
            })
            if not was_enabled:
                patch["chat_ai_cycle_started_ts"] = int(time.time())
                patch["chat_ai_rest_until_ts"] = 0
        else:
            patch.update({
                "chat_ai_enabled": False,
                "chat_ai_last_error": "",
                "chat_ai_pending_task": {},
                "chat_ai_next_run_ts": 0,
                "chat_ai_cycle_started_ts": 0,
                "chat_ai_rest_until_ts": 0,
            })
        if interval_changed:
            patch["chat_ai_next_run_ts"] = 0
        patched = patch_user_account(cid, aid, **patch)
        await asyncio.to_thread(persist_user_state_now, cid)
        await _app_ws_push(cid)
        logger.info("admin chat_ai update | chat_id=%s account_id=%s enabled=%s interval=%s-%s key_mode=%s", cid, aid, bool(body.enabled), min_sec, max_sec, patched.get("chat_ai_key_mode"))
        return {"ok": True, "data": {"chat_id": cid, "account_id": aid, **_chat_ai_public_fields(patched)}}

    @app.get("/admin/api/user-agents")
    async def admin_user_agents(token: str = Query(default="")) -> dict:
        _require_admin(token)
        return {"ok": True, "data": get_user_agent_pool()}

    @app.post("/admin/api/action/user-agent/set")
    async def admin_user_agent_set(body: AdminUserAgentSetBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None or cid not in USERS:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        ua = str(body.user_agent or "").strip()
        allowed = set(get_user_agent_pool())
        if ua not in allowed:
            return {"ok": False, "error": "bad_user_agent", "detail": "User-Agent не найден в списке"}

        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            patch_user_account(int(cid), account_id, user_agent=ua)
        else:
            update_user_fields(int(cid), user_agent=ua)
        u = get_user(int(cid))
        acc = _select_admin_account(int(cid), account_id) if account_id else None
        return {
            "ok": True,
            "data": {
                "chat_id": int(cid),
                "tg_username": u.tg_username or "",
                "account_id": account_id,
                "user_agent": (str(acc.get("user_agent") or "") if acc else (u.user_agent or "")),
            },
        }

    @app.post("/admin/api/action/session-recheck/status")
    async def admin_session_recheck_status(request: Request, token: str = Query(default="")) -> dict:
        _require_admin(token)
        body = await request.json()

        raw_chat_id = (body or {}).get("chat_id")
        chat_id = int(raw_chat_id) if raw_chat_id not in (None, "") else None
        username = str((body or {}).get("username") or "").strip()
        account_id = str((body or {}).get("account_id") or "acc_1").strip() or "acc_1"

        cid = _resolve_chat_id(chat_id, username)
        if cid is None or cid not in USERS:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}

        return {
            "ok": True,
            "data": {
                "has_session": bool(str(acc.get("zooma_top_session") or "").strip()),
                "slot": int(acc.get("slot") or 1),
                "port_user_name": str(acc.get("port_user_name") or ""),
                "port_user_id": str(acc.get("port_user_id") or ""),
            },
        }


    @app.post("/admin/api/action/session-recheck/run")
    async def admin_session_recheck_run(request: Request, token: str = Query(default="")) -> dict:
        _require_admin(token)
        body = await request.json()

        raw_chat_id = (body or {}).get("chat_id")
        chat_id = int(raw_chat_id) if raw_chat_id not in (None, "") else None
        username = str((body or {}).get("username") or "").strip()
        account_id = str((body or {}).get("account_id") or "acc_1").strip() or "acc_1"
        notify_user = bool((body or {}).get("notify_user") or False)

        cid = _resolve_chat_id(chat_id, username)
        if cid is None or cid not in USERS:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}

        if str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension":
            return {
                "ok": False,
                "error": "extension_mode",
                "detail": "Аккаунт работает через расширение. Серверная перепроверка токена отключена; используйте обновление вкладки расширения.",
            }

        saved_session = str(acc.get("zooma_top_session") or "").strip()
        if not saved_session:
            return {"ok": False, "error": "no_saved_session", "detail": "Сохранённого токена нет"}

        active_domain = get_active_domain()
        if not active_domain:
            return {"ok": False, "error": "no_active_domain", "detail": "Активный домен не определён"}

        result = await verify_token(
            saved_session,
            active_domain,
            chat_id=int(cid),
            account_id=account_id,
        )

        if not result.ok:
            return {
                "ok": False,
                "error": "verify_failed",
                "detail": result.error or "Не удалось проверить сохранённый токен",
            }

        patch_user_account(
            int(cid),
            account_id,
            port_user_id=result.port_user_id or "",
            port_user_name=result.port_user_name or "",
            centrifugo_socket=result.centrifugo_socket or "",
            centrifugo_secret=result.centrifugo_secret or "",
            zooma_top_session=result.zooma_top_session or saved_session,
            zooma_top_session_expires_at=result.zooma_top_session_expires_at,
            csrf_token=result.csrf_token or "",
            fingerprint_now=result.fingerprint_now or "",
            user_agent=result.user_agent or "",
            connected=True,
        )

        ws_ok = False
        acc_after = _select_admin_account(int(cid), account_id) or {}
        has_active_sub = int(acc_after.get("subscription_until_ts") or 0) > int(time.time())

        if has_active_sub:
            with contextlib.suppress(Exception):
                ws_ok = bool(
                    await billing.ws_manager.reconnect_for_user(
                        int(cid),
                        active_domain,
                        account_id=account_id,
                        attempts=3,
                        attempt_timeout=5.0,
                    )
                )

        if notify_user and billing.app:
            with contextlib.suppress(Exception):
                acc_now = _select_admin_account(int(cid), account_id) or {}
                slot = int(acc_now.get("slot") or 1)
                title = "Аккаунт" if slot <= 1 else f"Аккаунт #{slot}"
                name = str(result.port_user_name or acc_now.get("port_user_name") or "").strip() or "-"
                uid = str(result.port_user_id or acc_now.get("port_user_id") or "").strip() or "-"
                await billing.app.bot.send_message(
                    chat_id=int(cid),
                    text=f"✅ {title} подключен\n{name} | {uid}",
                )

        await _app_ws_push(int(cid))

        return {
            "ok": True,
            "data": {
                "chat_id": int(cid),
                "account_id": account_id,
                "port_user_id": result.port_user_id or "",
                "port_user_name": result.port_user_name or "",
                "ws_ok": ws_ok,
                "notified": notify_user,
            },
        }

    @app.post("/admin/api/action/session-recheck/get-token")
    async def admin_session_recheck_get_token(request: Request, token: str = Query(default="")) -> dict:
        _require_admin(token)
        body = await request.json()

        raw_chat_id = (body or {}).get("chat_id")
        chat_id = int(raw_chat_id) if raw_chat_id not in (None, "") else None
        username = str((body or {}).get("username") or "").strip()
        account_id = str((body or {}).get("account_id") or "acc_1").strip() or "acc_1"

        cid = _resolve_chat_id(chat_id, username)
        if cid is None or cid not in USERS:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}

        return {
            "ok": True,
            "data": {
                "zooma_top_session": str(acc.get("zooma_top_session") or ""),
            },
        }

    @app.post("/admin/api/action/session-recheck/set-token")
    async def admin_session_recheck_set_token(request: Request, token: str = Query(default="")) -> dict:
        _require_admin(token)
        body = await request.json()

        raw_chat_id = (body or {}).get("chat_id")
        chat_id = int(raw_chat_id) if raw_chat_id not in (None, "") else None
        username = str((body or {}).get("username") or "").strip()
        account_id = str((body or {}).get("account_id") or "acc_1").strip() or "acc_1"
        new_session = str((body or {}).get("zooma_top_session") or "")

        if not new_session.strip():
            return {"ok": False, "error": "empty_session", "detail": "Токен пуст"}

        cid = _resolve_chat_id(chat_id, username)
        if cid is None or cid not in USERS:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}

        patch_user_account(int(cid), account_id, zooma_top_session=new_session)
        return {"ok": True, "data": {"saved": True}}


    @app.post("/admin/api/action/extension-unbind")
    async def admin_extension_unbind(body: AdminSubSimpleBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        account_id = str(body.account_id or "").strip() or "acc_1"
        try:
            unbind_extension(int(cid), account_id)
            await asyncio.to_thread(persist_user_state_now, int(cid))
        except KeyError:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        except Exception as exc:
            logger.error("admin extension unbind durable save failed chat_id=%s account_id=%s error=%s", cid, account_id, exc)
            return {"ok": False, "error": "durable_save_failed", "detail": "Не удалось сохранить отвязку"}
        await extension_ws_manager.disconnect(int(cid), account_id, code=4004)
        await _app_ws_push(int(cid))
        logger.info("admin extension unbind | chat_id=%s account_id=%s", cid, account_id)
        return {"ok": True, "data": {"chat_id": int(cid), "account_id": account_id}}

    @app.post("/admin/api/action/promo-activation-mode")
    async def admin_promo_activation_mode(body: AdminPromoActivationModeBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        account_id = str(body.account_id or getattr(get_user(int(cid)), "active_account_id", "") or "acc_1")
        try:
            data = await _set_promo_activation_mode_runtime(int(cid), account_id, body.mode)
        except HTTPException as exc:
            return {"ok": False, "error": "mode_switch_failed", "detail": str(exc.detail)}
        return {"ok": True, "data": data}


    @app.post("/admin/api/action/account/reset-casino-data")
    async def admin_reset_casino_data(body: AdminAccountCasinoResetBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        account_id = str(body.account_id or "").strip()
        current = _select_admin_account(int(cid), account_id)
        if not current:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        if str(current.get("promo_activation_mode") or "server").strip().lower() != "server":
            return {"ok": False, "error": "server_mode_required", "detail": "Сначала переключите аккаунт в режим сервера"}
        await engine.ws_manager.stop_for_user(int(cid), account_id=account_id)
        patched = reset_account_casino_identity(int(cid), account_id)
        await asyncio.to_thread(persist_user_state_now, int(cid))
        await _app_ws_push(int(cid))
        logger.info("admin reset casino data | chat_id=%s account_id=%s", cid, account_id)
        return {"ok": True, "data": _account_admin_row(int(cid), patched, int(time.time()))}

    @app.post("/admin/api/action/user-ws/reconnect")
    async def admin_user_ws_reconnect(body: AdminSubSimpleBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None or cid not in USERS:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        u = get_user(int(cid))
        account_id = str(body.account_id or getattr(u, "active_account_id", "") or "acc_1").strip()
        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}

        mode = str(acc.get("promo_activation_mode") or "server").strip().lower()
        if mode == "extension":
            result = await extension_ws_manager.reload_managed_tab(int(cid), account_id, timeout_sec=25.0)
            if not result.get("ok"):
                return {"ok": False, "error": str(result.get("status") or "extension_reload_failed"), "detail": str(result.get("message") or "Не удалось обновить вкладку расширения")}
            return {"ok": True, "data": {"chat_id": int(cid), "account_id": account_id, "action": "extension_tab_reload", "message": str(result.get("message") or "Рабочая вкладка расширения обновлена")}}

        active_domain = get_active_domain()
        if not active_domain:
            return {"ok": False, "error": "no_active_domain", "detail": "Нет активного домена"}
        if not str(acc.get("zooma_top_session") or "").strip():
            return {"ok": False, "error": "no_session", "detail": "У аккаунта нет zooma_top_session"}
        if not str(acc.get("centrifugo_socket") or "").strip() or not str(acc.get("centrifugo_secret") or "").strip() or not str(acc.get("port_user_id") or "").strip():
            return {"ok": False, "error": "no_ws_data", "detail": "У аккаунта нет данных WebSocket"}

        logger.info("admin user ws reconnect requested | chat_id=%s username=%s account_id=%s", cid, u.tg_username or "", account_id)
        ok = await engine.ws_manager.reconnect_for_user(int(cid), active_domain, account_id=account_id, attempts=3, attempt_timeout=5.0)
        if not ok:
            label = u.tg_username or f"chat_id={cid}"
            slot = int(acc.get("slot") or 0)
            msg = f"⚠️ WebSocket не подключился за 3 попытки\nЮзер: {label}\nchat_id: {int(cid)}\nаккаунт: #{slot}"
            logger.warning("admin user ws reconnect failed | chat_id=%s username=%s account_id=%s", cid, u.tg_username or "", account_id)
            await _notify_admin(msg)
            return {"ok": False, "error": "ws_reconnect_failed", "detail": "WebSocket не подключился за 3 попытки"}

        return {"ok": True, "data": {"chat_id": int(cid), "tg_username": u.tg_username or "", "account_id": account_id, "action": "server_ws_reconnect", "message": "WebSocket переподключен"}}

    @app.get("/admin/api/billing")
    async def admin_billing(token: str = Query(default="")) -> dict:
        _require_admin(token)
        rows = []
        for oid, p in get_all_pending_orders().items():
            chat_id = p.get("chat_id")
            username = ""
            with contextlib.suppress(Exception):
                if chat_id is not None and int(chat_id) in USERS:
                    username = USERS[int(chat_id)].tg_username or ""
            invoice_label = str(p.get("invoice_label") or "").strip()
            if not invoice_label:
                pay_url = str(p.get("pay_url") or "").strip()
                if pay_url:
                    with contextlib.suppress(Exception):
                        start = (parse_qs(urlparse(pay_url).query).get("start") or [""])[0]
                        if str(start).startswith("IV"):
                            invoice_label = f"#{start}"
            if not invoice_label:
                raw_invoice_id = str(p.get("invoice_id") or "").strip()
                if raw_invoice_id:
                    invoice_label = f"#{raw_invoice_id}"
            rows.append({
                "order_id": oid,
                "chat_id": chat_id,
                "tg_username": username,
                "status": p.get("status"),
                "invoice_label": invoice_label,
                "expected_amount": p.get("expected_amount"),
                "paid_amount": p.get("paid_amount"),
                "invoice_id": p.get("invoice_id"),
                "created_at_ts": p.get("created_at_ts"),
                "expires_at_ts": p.get("expires_at_ts"),
                "purge_after_ts": p.get("purge_after_ts"),
                "fail_reason": p.get("fail_reason"),
                "kind": p.get("kind"),
                "account_id": p.get("account_id"),
                "account_slot": p.get("account_slot"),
                "account_label": p.get("account_label"),
                "is_addon": bool(p.get("is_addon")),
            })
        rows.sort(key=lambda x: int(x.get("expires_at_ts") or 0), reverse=True)
        return {"ok": True, "data": rows[:200]}

    @app.get("/admin/api/trains")
    async def admin_trains(token: str = Query(default="")) -> dict:
        _require_admin(token)
        now_ts = int(time.time())
        rows: list[dict] = []
        for chat_id, user in USERS.items():
            for acc in get_user_accounts(int(chat_id), include_empty=True):
                jobs = acc.get("train_jobs")
                if not isinstance(jobs, dict):
                    continue
                account_id = str(acc.get("account_id") or "")
                for join_id, raw_job in jobs.items():
                    if not isinstance(raw_job, dict):
                        continue
                    job = dict(raw_job)
                    finish_ts = int(float(job.get("finish_ts") or 0.0))
                    join_at_ts = int(float(job.get("join_at_ts") or 0.0))
                    join_state = str(job.get("join_state") or "scheduled")
                    detail = str(job.get("last_error") or "").strip()
                    dispatch = str(job.get("extension_dispatch_state") or "").strip()
                    rows.append({
                        "chat_id": int(chat_id),
                        "tg_username": str(getattr(user, "tg_username", "") or ""),
                        "account_id": account_id,
                        "account_slot": int(acc.get("slot") or 0),
                        "port_user_name": str(acc.get("port_user_name") or ""),
                        "port_user_id": str(acc.get("port_user_id") or ""),
                        "gid": str(job.get("gid") or ""),
                        "join_id": str(job.get("join_id") or join_id),
                        "url": str(job.get("url") or ""),
                        "conductor": str(job.get("conductor") or ""),
                        "join_mode": str(job.get("join_mode") or "server"),
                        "join_state": join_state,
                        "extension_dispatch_state": dispatch,
                        "detail": detail,
                        "join_at_ts": join_at_ts,
                        "finish_ts": finish_ts,
                        "remaining_sec": finish_ts - now_ts if finish_ts else 0,
                        "updated_at_ts": int(job.get("updated_at_ts") or 0),
                    })
        rows.sort(key=lambda row: (int(row.get("finish_ts") or 0), int(row.get("chat_id") or 0), int(row.get("account_slot") or 0)))
        return {"ok": True, "data": rows, "server_ts": now_ts}


    @app.get("/admin/api/auth-sessions")
    async def admin_auth_sessions(token: str = Query(default="")) -> dict:
        _require_admin(token)
        return {"ok": True, "data": _auth_sessions_snapshot()}

    @app.get("/admin/api/tariffs")
    async def admin_tariffs(token: str = Query(default="")) -> dict:
        _require_admin(token)
        rows = []
        for key, cfg in get_all_tariffs().items():
            rows.append({
                "key": key,
                "title": str(cfg.get("title") or key),
                "days": int(cfg.get("days") or 30),
                "price_rub_base": int(float(cfg.get("price_rub_base") or cfg.get("price_rub") or 0)),
                "discount_pct": float(cfg.get("discount_pct") or 0.0),
                "price_rub": max(1, int(round(float(cfg.get("price_rub_base") or cfg.get("price_rub") or 0) * (1 - float(cfg.get("discount_pct") or 0.0) / 100.0)))),
                "active": bool(cfg.get("active", True)),
                "tariff_type": str(cfg.get("tariff_type") or "main"),
                "sort_order": int(cfg.get("sort_order") or 100),
            })
        rows.sort(key=lambda x: (str(x.get("tariff_type") or "main"), int(x.get("price_rub") or x.get("price_rub_base") or 0), int(x.get("days") or 0), str(x.get("key") or "")))
        return {"ok": True, "data": rows}

    @app.post("/admin/api/tariffs/create")
    async def admin_tariff_create(body: AdminTariffCreateBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        key = (body.key or "").strip()
        if key in get_all_tariffs():
            return {"ok": False, "error": "tariff_exists", "detail": "Тариф с таким key уже существует"}
        row = upsert_tariff(
            key=key,
            title=body.title or key,
            price_rub_base=body.price_rub_base,
            days=body.days,
            discount_pct=body.discount_pct,
            active=body.active,
            tariff_type=body.tariff_type,
            sort_order=body.sort_order,
        )
        return {"ok": True, "data": row}

    @app.post("/admin/api/tariffs/update")
    async def admin_tariff_update(body: AdminTariffUpdateBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        key = (body.key or "").strip()
        if key not in get_all_tariffs():
            return {"ok": False, "error": "tariff_not_found", "detail": "Тариф не найден"}
        row = upsert_tariff(
            key=key,
            title=body.title,
            price_rub_base=body.price_rub_base,
            days=body.days,
            discount_pct=body.discount_pct,
            active=body.active,
            tariff_type=body.tariff_type,
            sort_order=body.sort_order,
        )
        return {"ok": True, "data": row}

    @app.post("/admin/api/tariffs/delete")
    async def admin_tariff_delete(body: AdminTariffDeleteBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        key = (body.key or "").strip()
        all_t = get_all_tariffs()
        if key not in all_t:
            return {"ok": False, "error": "tariff_not_found", "detail": "Тариф не найден"}
        active_cnt = sum(1 for _, v in all_t.items() if bool(v.get("active", True)))
        if bool(all_t[key].get("active", True)) and active_cnt <= 1:
            return {"ok": False, "error": "last_active_tariff", "detail": "Нельзя удалить последний активный тариф"}
        if not delete_tariff(key):
            return {"ok": False, "error": "delete_failed", "detail": "Не удалось удалить тариф"}
        return {"ok": True, "data": {"key": key}}

    @app.get("/admin/api/proxy/balance")
    async def admin_proxy_balance(token: str = Query(default="")) -> dict:
        _require_admin(token)
        bal = await billing.get_proxy_balance_cached(force=False)
        return {"ok": True, "data": {"balance_rub": bal, "updated_ts": int(time.time())}}

    @app.get("/admin/api/proxy/countries")
    async def admin_proxy_countries(token: str = Query(default="")) -> dict:
        _require_admin(token)
        rows = []
        for c in PROXYLINE_COUNTRY_POOL:
            cc = c.strip().lower()
            rows.append({"code": cc, "title_ru": PROXYLINE_COUNTRY_RU.get(cc, cc.upper())})
        return {"ok": True, "data": rows}

    @app.get("/admin/api/proxy/active")
    async def admin_proxy_active(token: str = Query(default="")) -> dict:
        _require_admin(token)
        rows = []
        for cid, u in USERS.items():
            for acc in get_user_accounts(int(cid), include_empty=True):
                proxy_url = str(acc.get("proxy_url") or "").strip()
                if not proxy_url:
                    continue
                p_login = ""
                p_pass = ""
                p_hostport = ""
                try:
                    pu = urlparse(proxy_url)
                    p_login = pu.username or ""
                    p_pass = pu.password or ""
                    if pu.hostname and pu.port:
                        p_hostport = f"{pu.hostname}:{pu.port}"
                except Exception:
                    p_login = ""
                    p_pass = ""
                    p_hostport = ""
                rows.append({
                    "chat_id": cid,
                    "tg_username": u.tg_username or "",
                    "account_id": str(acc.get("account_id") or ""),
                    "account_slot": int(acc.get("slot") or 0),
                    "account_name": str(acc.get("port_user_name") or ""),
                    "account_port_user_id": str(acc.get("port_user_id") or ""),
                    "proxy_country": str(acc.get("proxy_country") or ""),
                    "proxy_city": str(acc.get("proxy_city") or ""),
                    "proxy_ip": str(acc.get("proxy_ip") or ""),
                    "proxy_order_id": str(acc.get("proxy_order_id") or ""),
                    "proxy_url": proxy_url,
                    "proxy_scheme": str(acc.get("proxy_scheme") or ""),
                    "proxy_port_http": acc.get("proxy_port_http"),
                    "proxy_port_socks5": acc.get("proxy_port_socks5"),
                    "proxy_login": p_login,
                    "proxy_password": p_pass,
                    "proxy_hostport": p_hostport,
                })
        rows.sort(key=lambda x: (int(x["chat_id"]), int(x.get("account_slot") or 0)))
        return {"ok": True, "data": rows}

    @app.post("/admin/api/proxy/buy-one")
    async def admin_proxy_buy_one(body: AdminProxyBuyOneBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        op_id = uuid.uuid4().hex[:12]
        try:
            country = ""
            if body.country_mode == "manual":
                country = (body.country or "").strip().lower()
                if country not in PROXYLINE_COUNTRY_POOL:
                    return {"ok": False, "error": "bad_country", "detail": "Страна не из пула"}
            else:
                import random
                country = random.choice(PROXYLINE_COUNTRY_POOL)

            estimate = await billing.proxyline.estimate_price_rub(
                country=country,
                period=body.period_days,
                quantity=1,
                proxy_type=body.proxy_type,
                exclude_no_access_from_ru=bool(body.exclude_no_access_from_ru),
                proxy_op_id=op_id,
            )
            if estimate is not None:
                estimate = await billing._to_rub_amount(float(estimate), "")
                estimate = _with_proxy_buffer(estimate)
            if not body.confirm:
                logger.info(
                    "proxy preview one | op_id=%s mode=%s type=%s ex_ru=%s country=%s period=%s estimate_rub=%s",
                    op_id,
                    body.country_mode,
                    body.proxy_type,
                    int(bool(body.exclude_no_access_from_ru)),
                    country,
                    body.period_days,
                    estimate,
                )
                return {
                    "ok": True,
                    "preview": True,
                    "data": {
                        "country": country,
                        "country_ru": PROXYLINE_COUNTRY_RU.get(country, country.upper()),
                        "period_days": body.period_days,
                        "estimated_rub": estimate,
                    },
                }

            target_chat = _resolve_chat_id(body.chat_id, body.username)
            account_id = str(body.account_id or "").strip()
            account = None
            slot = 1

            if target_chat is not None:
                account_id, account = _resolve_admin_proxy_account(int(target_chat), account_id)
                if not account:
                    return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}

                with contextlib.suppress(Exception):
                    slot = int(account.get("slot") or 1) or 1

            tag_names = [str(target_chat), str(slot)] if target_chat is not None else ["admin_unbound"]
            result = await billing.proxyline.buy_proxy(
                country=country,
                period=body.period_days,
                tag=tag_names[0],
                tags=tag_names,
                proxy_type=body.proxy_type,
                exclude_no_access_from_ru=bool(body.exclude_no_access_from_ru),
                proxy_op_id=op_id,
            )
            if not result.ok or not result.proxy_url:
                logger.warning(
                    "proxy buy one failed | op_id=%s mode=%s type=%s ex_ru=%s country=%s period=%s reason=%s",
                    op_id,
                    body.country_mode,
                    body.proxy_type,
                    int(bool(body.exclude_no_access_from_ru)),
                    country,
                    body.period_days,
                    str(result.reason)[:300],
                )
                return {"ok": False, "error": "buy_failed", "detail": _humanize_proxy_error(result.reason)}
            if target_chat is not None:
                if account_id:
                    set_account_proxy(
                        chat_id=target_chat,
                        account_id=account_id,
                        proxy_url=result.proxy_url,
                        country=result.country,
                        city=result.city,
                        order_id=result.order_id,
                        ip=result.ip,
                        port_http=result.port_http,
                        port_socks5=result.port_socks5,
                        login=result.login,
                        password=result.password,
                        scheme=result.scheme or "socks5",
                    )
                    with contextlib.suppress(Exception):
                        await billing.resume_proxy_auto_frozen_if_proxy_ok(
                            int(target_chat),
                            str(account_id),
                            str(result.proxy_url or ""),
                            source="admin_proxy_buy",
                        )
                    logger.info(
                        "proxy buy one bind ok | op_id=%s chat_id=%s account_id=%s order_id=%s ip=%s",
                        op_id,
                        target_chat,
                        account_id,
                        result.order_id,
                        result.ip,
                    )
                    await _app_ws_push(int(target_chat))
                else:
                    set_user_proxy(
                        chat_id=target_chat,
                        proxy_url=result.proxy_url,
                        country=result.country,
                        city=result.city,
                        order_id=result.order_id,
                        ip=result.ip,
                        port_http=result.port_http,
                        port_socks5=result.port_socks5,
                        login=result.login,
                        password=result.password,
                        scheme=result.scheme or "socks5",
                    )
                    logger.info(
                        "proxy buy one legacy bind ok | op_id=%s chat_id=%s order_id=%s ip=%s",
                        op_id,
                        target_chat,
                        result.order_id,
                        result.ip,
                    )
            result_price_rub = None
            if result.price_rub is not None:
                with contextlib.suppress(Exception):
                    result_price_rub = await billing._to_rub_amount(float(result.price_rub), "")
                    result_price_rub = _with_proxy_buffer(result_price_rub)
                    if result_price_rub is not None:
                        record_proxy_spent_metric(float(result_price_rub), int(time.time()))
            await billing.get_proxy_balance_cached(force=True)
            logger.info(
                "proxy buy one ok | op_id=%s chat_id=%s account_id=%s type=%s ex_ru=%s country=%s order_id=%s ip=%s price_rub=%s",
                op_id,
                target_chat,
                account_id or "-",
                body.proxy_type,
                int(bool(body.exclude_no_access_from_ru)),
                result.country,
                result.order_id,
                result.ip,
                result_price_rub,
            )
            return {
                "ok": True,
                "data": {
                    "chat_id": target_chat,
                    "account_id": account_id or "",
                    "tg_username": USERS[target_chat].tg_username if target_chat in USERS else "",
                    "order_id": result.order_id,
                    "country": result.country,
                    "country_ru": PROXYLINE_COUNTRY_RU.get((result.country or "").lower(), (result.country or "").upper()),
                    "city": result.city,
                    "ip": result.ip,
                    "masked_ip": result.masked_ip,
                    "proxy_url": result.proxy_url,
                    "price_rub": result_price_rub,
                },
            }
        except Exception as e:
            return {"ok": False, "error": "buy_failed", "detail": _humanize_proxy_error(str(e))}

    @app.post("/admin/api/proxy/buy-batch")
    async def admin_proxy_buy_batch(body: AdminProxyBuyBatchBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        op_id = uuid.uuid4().hex[:12]
        try:
            countries: list[str] = []
            if body.country_mode == "random":
                import random
                countries = [random.choice(PROXYLINE_COUNTRY_POOL) for _ in range(body.count)]
            elif body.country_mode == "manual":
                c = (body.country or "").strip().lower()
                if c not in PROXYLINE_COUNTRY_POOL:
                    return {"ok": False, "error": "bad_country", "detail": "Страна не из пула"}
                countries = [c for _ in range(body.count)]
            else:
                raw = [str(x).strip().lower() for x in (body.countries or []) if str(x).strip()]
                raw = [x for x in raw if x in PROXYLINE_COUNTRY_POOL]
                if not raw:
                    return {"ok": False, "error": "bad_countries", "detail": "Не выбраны валидные страны"}
                i = 0
                for _ in range(body.count):
                    countries.append(raw[i % len(raw)])
                    i += 1
            country_counts: dict[str, int] = {}
            for c in countries:
                country_counts[c] = country_counts.get(c, 0) + 1

            async def _estimate_one_country(c: str, n: int) -> tuple[str, int, Optional[float]]:
                p = await billing.proxyline.estimate_price_rub(
                    country=c,
                    period=body.period_days,
                    quantity=1,
                    proxy_type=body.proxy_type,
                    exclude_no_access_from_ru=bool(body.exclude_no_access_from_ru),
                    proxy_op_id=op_id,
                )
                if p is None:
                    return c, n, None
                one_rub = float(await billing._to_rub_amount(float(p), ""))
                return c, n, one_rub

            estimate_total = 0.0
            estimate_known = True
            estimate_rows = await asyncio.gather(
                *(_estimate_one_country(c, n) for c, n in country_counts.items()),
                return_exceptions=True,
            )
            for row in estimate_rows:
                if isinstance(row, Exception):
                    estimate_known = False
                    break
                _country, count_for_country, one_rub = row
                if one_rub is None:
                    estimate_known = False
                    break
                estimate_total += float(one_rub) * int(count_for_country)

            estimate_total_buf = _with_proxy_buffer(estimate_total) if estimate_known else None
            if not body.confirm:
                logger.info(
                    "proxy preview batch | op_id=%s mode=%s type=%s ex_ru=%s count=%s period=%s estimate_total_rub=%s known=%s",
                    op_id,
                    body.country_mode,
                    body.proxy_type,
                    int(bool(body.exclude_no_access_from_ru)),
                    body.count,
                    body.period_days,
                    estimate_total_buf,
                    int(estimate_known),
                )
                return {
                    "ok": True,
                    "preview": True,
                    "data": {
                        "count": body.count,
                        "period_days": body.period_days,
                        "countries": countries,
                        "estimated_total_rub": estimate_total_buf,
                    },
                }
            target_chat = _resolve_chat_id(body.chat_id, body.username)
            tag_prefix = str(target_chat) if target_chat is not None else "admin_unbound"
            results = await billing.proxyline.buy_batch(
                countries=countries,
                period=body.period_days,
                tag_prefix=tag_prefix,
                proxy_type=body.proxy_type,
                exclude_no_access_from_ru=bool(body.exclude_no_access_from_ru),
                proxy_op_id=op_id,
            )
            success = 0
            failed = 0
            spent = 0.0
            last_ok = None
            batch_account_id = ""
            batch_account = None
            if target_chat is not None:
                batch_account_id, batch_account = _resolve_admin_proxy_account(int(target_chat), str(body.account_id or "").strip())
            for r in results:
                if r.ok:
                    success += 1
                    if r.price_rub:
                        with contextlib.suppress(Exception):
                            one_spent = float(await billing._to_rub_amount(float(r.price_rub), ""))
                            one_spent = float(_with_proxy_buffer(one_spent) or one_spent)
                            spent += one_spent
                            record_proxy_spent_metric(one_spent, int(time.time()))
                    last_ok = r
                else:
                    failed += 1
            if target_chat is not None and success > 0 and last_ok and last_ok.proxy_url:
                if batch_account:
                    set_account_proxy(
                        chat_id=int(target_chat),
                        account_id=batch_account_id,
                        proxy_url=last_ok.proxy_url,
                        country=last_ok.country,
                        city=last_ok.city,
                        order_id=last_ok.order_id,
                        ip=last_ok.ip,
                        port_http=last_ok.port_http,
                        port_socks5=last_ok.port_socks5,
                        login=last_ok.login,
                        password=last_ok.password,
                        scheme=last_ok.scheme or "socks5",
                    )
                    with contextlib.suppress(Exception):
                        await billing.resume_proxy_auto_frozen_if_proxy_ok(
                            int(target_chat),
                            batch_account_id,
                            str(last_ok.proxy_url or ""),
                            source="admin_proxy_batch",
                        )
                    logger.info(
                        "proxy buy batch bind ok | op_id=%s chat_id=%s account_id=%s order_id=%s ip=%s",
                        op_id,
                        target_chat,
                        batch_account_id,
                        last_ok.order_id,
                        last_ok.ip,
                    )
                    await _app_ws_push(int(target_chat))
                else:
                    set_user_proxy(
                        chat_id=target_chat,
                        proxy_url=last_ok.proxy_url,
                        country=last_ok.country,
                        city=last_ok.city,
                        order_id=last_ok.order_id,
                        ip=last_ok.ip,
                        port_http=last_ok.port_http,
                        port_socks5=last_ok.port_socks5,
                        login=last_ok.login,
                        password=last_ok.password,
                        scheme=last_ok.scheme or "socks5",
                    )
                    logger.info(
                        "proxy buy batch legacy bind ok | op_id=%s chat_id=%s order_id=%s ip=%s",
                        op_id,
                        target_chat,
                        last_ok.order_id,
                        last_ok.ip,
                    )
            await billing.get_proxy_balance_cached(force=True)
            logger.info(
                "proxy buy batch done | op_id=%s chat_id=%s type=%s ex_ru=%s count=%s success=%s failed=%s spent_rub=%s",
                op_id,
                target_chat,
                body.proxy_type,
                int(bool(body.exclude_no_access_from_ru)),
                body.count,
                success,
                failed,
                round(spent, 2),
            )
            if failed > 0 and billing.app:
                sample_reasons = []
                for r in results:
                    if not r.ok:
                        sample_reasons.append(_humanize_proxy_error(r.reason))
                    if len(sample_reasons) >= 3:
                        break
                with contextlib.suppress(Exception):
                    await billing.app.bot.send_message(
                        chat_id=ADMIN_CHAT_ID,
                        text=(
                            "⚠️ Proxy batch завершился с ошибками\n"
                            f"chat_id: {target_chat if target_chat is not None else '-'}\n"
                            f"type: {body.proxy_type}\n"
                            f"count: {body.count}\n"
                            f"успех: {success}, ошибки: {failed}\n"
                            f"причины: {'; '.join(sample_reasons) if sample_reasons else 'нет деталей'}"
                        ),
                    )
            return {
                "ok": True,
                "data": {
                    "count": body.count,
                    "success": success,
                    "failed": failed,
                    "spent_rub": round(spent, 2),
                    "results": [
                        {
                            "ok": r.ok,
                            "reason": _humanize_proxy_error(r.reason),
                            "order_id": r.order_id,
                            "country": r.country,
                            "country_ru": PROXYLINE_COUNTRY_RU.get((r.country or "").lower(), (r.country or "").upper()),
                            "masked_ip": r.masked_ip,
                            "price_rub": (await billing._to_rub_amount(float(r.price_rub), "") if r.price_rub is not None else None),
                        } for r in results
                    ],
                },
            }
        except Exception as e:
            return {"ok": False, "error": "buy_failed", "detail": _humanize_proxy_error(str(e))}

    @app.post("/admin/api/action/stop-auth")
    async def admin_stop_auth(body: AdminStopAuthBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        provider = (body.provider or "all").strip().lower()
        stopped = 0
        providers = [provider] if provider in {"steam", "tg", "yandex"} else ["steam", "tg", "yandex"]
        for p in providers:
            if p == "steam":
                from steam_webapp import close_session_by_sid as close_sid, close_sessions_for_chat as close_chat
            elif p == "tg":
                from tg_webapp import close_session_by_sid as close_sid, close_sessions_for_chat as close_chat
            else:
                from yandex_webapp import close_session_by_sid as close_sid, close_sessions_for_chat as close_chat
            if body.sid:
                if await close_sid(body.sid, reason="admin_stop"):
                    stopped += 1
            elif body.chat_id is not None:
                await close_chat(int(body.chat_id))
                stopped += 1
        return {"ok": True, "stopped": stopped}

    @app.post("/admin/api/action/refresh")
    async def admin_refresh(token: str = Query(default="")) -> dict:
        _require_admin(token)
        now_ts = int(time.time())
        checked = 0
        ok = 0
        tasks = []
        for cid, u in USERS.items():
            if not u.connected:
                continue
            if not has_active_subscription(cid, now_ts):
                continue
            tasks.append(engine.probe_user_session(cid))
        for result in await asyncio.gather(*tasks[:60], return_exceptions=True):
            checked += 1
            if result is True:
                ok += 1
        return {"ok": True, "data": {"checked": checked, "ok": ok, "failed": max(0, checked - ok)}}

    @app.post("/admin/api/action/create-invoice")
    async def admin_create_invoice(body: AdminCreateInvoiceBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        target_chat_id: Optional[int] = None
        if body.chat_id is not None:
            target_chat_id = int(body.chat_id)
        elif (body.username or "").strip():
            uname = (body.username or "").strip().lstrip("@").lower()
            for cid, u in USERS.items():
                if (u.tg_username or "").strip().lstrip("@").lower() == uname:
                    target_chat_id = int(cid)
                    break
        if target_chat_id is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден (chat_id/@username)"}

        tariff = billing.find_tariff((body.tariff_key or "").strip())
        if not tariff:
            return {"ok": False, "error": "tariff_not_found", "detail": "Тариф не найден"}

        days = int(body.days or 30)
        custom_price = int(body.custom_price_rub) if body.custom_price_rub is not None else None
        if days != int(tariff.days) or custom_price is not None:
            from billing import Tariff as BillingTariff
            tariff = BillingTariff(
                key=tariff.key,
                title=tariff.title,
                days=days,
                price_rub_base=(custom_price if custom_price is not None else tariff.price_rub_base),
                discount_pct=(0.0 if custom_price is not None else tariff.discount_pct),
                active=tariff.active,
                tariff_type=getattr(tariff, "tariff_type", "main"),
                sort_order=getattr(tariff, "sort_order", 100),
            )

        account_id = str(body.account_id or "").strip()
        if str(getattr(tariff, "tariff_type", "main") or "main") == "addon" or account_id:
            if account_id:
                acc = _select_admin_account(int(target_chat_id), account_id)
                if not acc:
                    return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
                slot = int(acc.get("slot") or 0)
                kind = "account_renew" if int(acc.get("subscription_until_ts") or 0) > int(time.time()) else "account_add"
                invoice = await billing.create_invoice(
                    target_chat_id,
                    tariff,
                    kind=kind,
                    account_id=account_id,
                    account_slot=slot,
                    account_label=f"доп акк #{slot}",
                    is_addon=True,
                )
            else:
                invoice = await billing.create_addon_invoice(target_chat_id, tariff)
        else:
            invoice = await billing.create_invoice(target_chat_id, tariff)
        await billing.send_invoice_message(target_chat_id, invoice)
        await _app_ws_push(int(target_chat_id))
        user = USERS.get(target_chat_id)
        return {
            "ok": True,
            "data": {
                "chat_id": target_chat_id,
                "tg_username": (user.tg_username if user else "") or "",
                "invoice_id": str(invoice.get("invoice_id") or ""),
                "invoice_label": str(invoice.get("invoice_label") or f"#{invoice.get('invoice_id') or ''}"),
                "tariff_title": tariff.title,
                "days": tariff.days,
                "price_rub": tariff.price_rub,
                "price_usdt": invoice.get("price_usdt"),
                "pay_url": str(invoice.get("pay_url") or ""),
            },
        }

    @app.post("/admin/api/action/subscription/grant")
    async def admin_sub_grant(body: AdminSubGrantBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        tariff = billing.find_tariff((body.tariff_key or "").strip())
        if not tariff:
            return {"ok": False, "error": "tariff_not_found", "detail": "Тариф не найден"}
        now_ts = int(time.time())
        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            old_until = int(acc.get("subscription_until_ts") or 0)
            base = max(now_ts, old_until)
            new_until = int(body.until_ts or 0) if body.until_ts else base + int(body.days or 30) * 24 * 60 * 60
            set_account_subscription(int(cid), account_id, f"manual:{tariff.key}", new_until)

            active_domain = get_active_domain()
            if active_domain and str(acc.get("zooma_top_session") or "").strip():
                if _account_proxy_allowed_for_runtime(int(cid), account_id):
                    with contextlib.suppress(Exception):
                        await billing.ws_manager.start_for_user(int(cid), active_domain, account_id=account_id)
                else:
                    logger.info("admin account WS start skipped no_proxy | chat_id=%s account_id=%s", cid, account_id)
            u = get_user(int(cid))
            logger.info("admin account sub grant | chat_id=%s username=%s account_id=%s old_until=%s new_until=%s days=%s tier=%s", cid, u.tg_username or "", account_id, old_until, new_until, body.days, tariff.key)
            await _notify_user_sub_action(
                int(cid),
                f"Подписка {_account_notify_title(acc)} обновлена админом.\n"
                f"Новый срок до: {datetime.fromtimestamp(new_until, tz=timezone(timedelta(hours=3))).strftime('%d.%m.%Y %H:%M')} МСК",
            )
            if int(body.days or 0) > 0:
                await billing.request_proxy_choice_after_grant(
                    chat_id=int(cid),
                    account_id=account_id,
                    period_days=int(body.days or max(1, (new_until - old_until) // 86400)),
                    had_active_remainder=old_until > now_ts,
                )
            await _app_ws_push(int(cid))
            _admin_folder_sync("grant")
            return {"ok": True, "data": {"chat_id": int(cid), "account_id": account_id, "old_until_ts": old_until, "new_until_ts": new_until, "tier": f"manual:{tariff.key}"}}

        u = get_user(cid)
        old_until = int(u.subscription_until_ts or 0)
        base = max(now_ts, old_until)
        new_until = int(body.until_ts or 0) if body.until_ts else base + int(body.days or 30) * 24 * 60 * 60
        set_subscription(cid, f"manual:{tariff.key}", new_until)
        active_domain = get_active_domain()
        if active_domain and (u.zooma_top_session or "").strip():
            if _account_proxy_allowed_for_runtime(int(cid), None):
                with contextlib.suppress(Exception):
                    await billing.ws_manager.start_for_user(cid, active_domain)
            else:
                logger.info("admin legacy WS start skipped no_proxy | chat_id=%s", cid)
        logger.info("admin sub grant | chat_id=%s username=%s old_until=%s new_until=%s days=%s tier=%s", cid, u.tg_username or "", old_until, new_until, body.days, tariff.key)
        await _notify_user_sub_action(
            cid,
            "Подписка обновлена админом.\n"
            f"Новый срок до: {datetime.fromtimestamp(new_until, tz=timezone(timedelta(hours=3))).strftime('%d.%m.%Y %H:%M')} МСК",
        )
        if int(body.days or 0) > 0:
            await billing.request_proxy_choice_after_grant(
                chat_id=int(cid),
                account_id=None,
                period_days=int(body.days or max(1, (new_until - old_until) // 86400)),
                had_active_remainder=old_until > now_ts,
            )
        await _app_ws_push(int(cid))
        _admin_folder_sync("grant")
        return {"ok": True, "data": {"chat_id": cid, "old_until_ts": old_until, "new_until_ts": new_until, "tier": f"manual:{tariff.key}"}}

    @app.post("/admin/api/action/subscription/reduce")
    async def admin_sub_reduce(body: AdminSubReduceBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        now_ts = int(time.time())
        u = get_user(cid)
        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            old_until = int(acc.get("subscription_until_ts") or 0)
            new_until = int(body.until_ts or 0) if body.until_ts is not None else old_until - int(body.days or 1) * 24 * 60 * 60
            if new_until <= now_ts:
                with contextlib.suppress(Exception):
                    await billing.ws_manager.stop_for_user(int(cid), account_id=account_id)
                clear_account_casino_data(int(cid), account_id)
                new_until = 0
            else:
                set_account_subscription(int(cid), account_id, str(acc.get("subscription_tier") or "manual:lite"), new_until)
            logger.info("admin account sub reduce | chat_id=%s username=%s account_id=%s old_until=%s new_until=%s days=%s", cid, u.tg_username or "", account_id, old_until, new_until, body.days)
            if new_until > 0:
                await _notify_user_sub_action(
                    int(cid),
                    f"Подписка {_account_notify_title(acc)} обновлена админом.\n"
                    f"Новый срок до: {datetime.fromtimestamp(new_until, tz=timezone(timedelta(hours=3))).strftime('%d.%m.%Y %H:%M')} МСК",
                )
            else:
                await _notify_user_sub_action(int(cid), f"Подписка {_account_notify_title(acc)} отключена админом.")
            await _app_ws_push(int(cid))
            _admin_folder_sync("reduce")
            return {"ok": True, "data": {"chat_id": int(cid), "account_id": account_id, "old_until_ts": old_until, "new_until_ts": new_until}}

        old_until = int(u.subscription_until_ts or 0)
        new_until = int(body.until_ts or 0) if body.until_ts is not None else old_until - int(body.days or 1) * 24 * 60 * 60
        if new_until <= now_ts:
            clear_subscription(cid)
            new_until = 0
            with contextlib.suppress(Exception):
                await billing.ws_manager.stop_for_user(cid)
        else:
            set_subscription(cid, u.subscription_tier or "manual:lite", new_until)
        logger.info("admin sub reduce | chat_id=%s username=%s old_until=%s new_until=%s days=%s", cid, u.tg_username or "", old_until, new_until, body.days)
        if new_until > 0:
            await _notify_user_sub_action(
                cid,
                "Подписка обновлена админом.\n"
                f"Новый срок до: {datetime.fromtimestamp(new_until, tz=timezone(timedelta(hours=3))).strftime('%d.%m.%Y %H:%M')} МСК",
            )
        else:
            await _notify_user_sub_action(cid, "Подписка отключена админом.")
        await _app_ws_push(int(cid))
        _admin_folder_sync("reduce")
        return {"ok": True, "data": {"chat_id": cid, "old_until_ts": old_until, "new_until_ts": new_until}}

    @app.post("/admin/api/action/subscription/pause")
    async def admin_sub_pause(body: AdminSubSimpleBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        u = get_user(cid)
        account_id = str(body.account_id or getattr(u, "active_account_id", "") or "acc_1").strip() or "acc_1"
        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        if bool(acc.get("subscription_paused")):
            return {"ok": True, "ignored": True, "reason": "already_paused"}

        info = pause_account_subscription(int(cid), account_id, int(time.time()))
        with contextlib.suppress(Exception):
            await billing.ws_manager.stop_for_user(int(cid), account_id=account_id)

        left_days = max(0, int(info.get("left_sec") or 0)) // 86400
        logger.info("admin account sub freeze | chat_id=%s username=%s account_id=%s left_sec=%s", cid, u.tg_username or "", account_id, info.get("left_sec"))
        await _notify_user_sub_action(
            int(cid),
            f"Ваша подписка {_account_notify_title(acc)} заморожена. Остаток дней: {left_days}.",
        )
        await _app_ws_push(int(cid))
        _admin_folder_sync("freeze")
        return {"ok": True, "data": {"chat_id": int(cid), **info}}


    @app.post("/admin/api/action/subscription/resume")
    async def admin_sub_resume(body: AdminSubSimpleBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}

        u = get_user(cid)
        account_id = str(body.account_id or getattr(u, "active_account_id", "") or "acc_1").strip() or "acc_1"
        acc = _select_admin_account(int(cid), account_id)
        if not acc:
            return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
        if not bool(acc.get("subscription_paused")):
            return {"ok": True, "ignored": True, "reason": "not_paused"}

        info = resume_account_subscription(int(cid), account_id, int(time.time()))
        new_until = int(info.get("new_until_ts") or 0)
        left_days = max(0, int(info.get("left_sec") or 0)) // 86400

        active_domain = get_active_domain()
        fresh_acc = _select_admin_account(int(cid), account_id) or {}
        if active_domain and str(fresh_acc.get("zooma_top_session") or "").strip() and new_until > int(time.time()):
            if _account_proxy_allowed_for_runtime(int(cid), account_id):
                with contextlib.suppress(Exception):
                    await billing.ws_manager.start_for_user(int(cid), active_domain, account_id=account_id)

        logger.info("admin account sub unfreeze | chat_id=%s username=%s account_id=%s new_until=%s left_sec=%s", cid, u.tg_username or "", account_id, new_until, info.get("left_sec"))
        await _notify_user_sub_action(
            int(cid),
            f"Ваша подписка {_account_notify_title(acc)} разморожена, остаток дней: {left_days}.",
        )
        await _app_ws_push(int(cid))
        _admin_folder_sync("unfreeze")
        return {"ok": True, "data": {"chat_id": int(cid), **info}}


    @app.post("/admin/api/action/subscription/disable")
    async def admin_sub_disable(body: AdminSubSimpleBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        u = get_user(cid)
        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            old_until = int(acc.get("subscription_until_ts") or 0)
            acc_title = _account_notify_title(acc)
            with contextlib.suppress(Exception):
                await billing.ws_manager.stop_for_user(int(cid), account_id=account_id)
            clear_account_casino_data(int(cid), account_id)
            logger.info("admin account sub disable clear | chat_id=%s username=%s account_id=%s old_until=%s", cid, u.tg_username or "", account_id, old_until)
            await _notify_user_sub_action(int(cid), f"Подписка {acc_title} отключена админом.")
            await _app_ws_push(int(cid))
            _admin_folder_sync("disable")
            return {"ok": True, "data": {"chat_id": int(cid), "account_id": account_id, "old_until_ts": old_until, "new_until_ts": 0}}

        old_until = int(u.subscription_until_ts or 0)
        active_aid = str(getattr(u, "active_account_id", "") or "acc_1")
        with contextlib.suppress(Exception):
            await billing.ws_manager.stop_for_user(cid, account_id=active_aid)
        clear_account_casino_data(int(cid), active_aid)
        logger.info("admin sub disable clear | chat_id=%s username=%s account_id=%s old_until=%s", cid, u.tg_username or "", active_aid, old_until)
        await _notify_user_sub_action(cid, "Подписка отключена админом.")
        await _app_ws_push(int(cid))
        _admin_folder_sync("disable")
        return {"ok": True, "data": {"chat_id": cid, "old_until_ts": old_until, "new_until_ts": 0}}

    @app.post("/admin/api/action/subscription/change-tier")
    async def admin_sub_change_tier(body: AdminSubChangeTierBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        tariff = billing.find_tariff((body.tariff_key or "").strip())
        if not tariff:
            return {"ok": False, "error": "tariff_not_found", "detail": "Тариф не найден"}
        u = get_user(cid)
        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            old_tier = str(acc.get("subscription_tier") or "")
            patch_user_account(int(cid), account_id, subscription_tier=f"manual:{tariff.key}")
            logger.info("admin account sub change_tier | chat_id=%s username=%s account_id=%s old_tier=%s new_tier=%s", cid, u.tg_username or "", account_id, old_tier, f"manual:{tariff.key}")
            await _notify_user_sub_action(int(cid), f"Тариф {_account_notify_title(acc)} изменен админом на {tariff.title}.")
            await _app_ws_push(int(cid))
            return {"ok": True, "data": {"chat_id": int(cid), "account_id": account_id, "old_tier": old_tier, "new_tier": f"manual:{tariff.key}"}}

        old_tier = u.subscription_tier
        update_user_fields(cid, subscription_tier=f"manual:{tariff.key}")
        logger.info("admin sub change_tier | chat_id=%s username=%s old_tier=%s new_tier=%s", cid, u.tg_username or "", old_tier, f"manual:{tariff.key}")
        await _notify_user_sub_action(cid, f"Тариф подписки изменен админом на {tariff.title}.")
        await _app_ws_push(int(cid))
        return {"ok": True, "data": {"chat_id": cid, "old_tier": old_tier, "new_tier": f"manual:{tariff.key}"}}

    @app.post("/admin/api/action/user-proxy/set")
    async def admin_user_proxy_set(body: AdminUserProxySetBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        scheme = (body.scheme or "socks5").strip().lower()
        if scheme not in {"socks5", "http"}:
            scheme = "socks5"
        port = body.port_socks5 if scheme == "socks5" else body.port_http
        if not port:
            return {"ok": False, "error": "bad_port", "detail": "Для выбранной схемы не задан порт"}
        host = body.host.strip()
        login = (body.login or "").strip()
        password = (body.password or "").strip()
        auth = ""
        if login and password:
            auth = f"{quote(login, safe='')}:{quote(password, safe='')}@"
        proxy_url = f"{scheme}://{auth}{host}:{int(port)}"
        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            set_account_proxy(
                int(cid),
                account_id,
                proxy_url=proxy_url,
                order_id="manual",
                ip=host,
                port_http=body.port_http,
                port_socks5=body.port_socks5,
                login=(login or None),
                password=(password or None),
                scheme=scheme,
            )
            fresh_acc = _select_admin_account(int(cid), account_id) or {}
            if str(fresh_acc.get("promo_activation_mode") or "server").strip().lower() != "extension":
                await billing.resume_proxy_auto_frozen_if_proxy_ok(int(cid), account_id, proxy_url, source="admin_proxy_set")
        else:
            set_user_proxy(
                cid,
                proxy_url=proxy_url,
                order_id="manual",
                ip=host,
                port_http=body.port_http,
                port_socks5=body.port_socks5,
                login=(login or None),
                password=(password or None),
                scheme=scheme,
            )
        u = get_user(cid)
        logger.info("admin user proxy set | chat_id=%s username=%s account_id=%s scheme=%s host=%s", cid, u.tg_username or "", account_id, scheme, host)
        await _app_ws_push(int(cid))
        return {"ok": True, "data": {"chat_id": cid, "account_id": account_id, "proxy_url": proxy_url, "scheme": scheme}}

    @app.post("/admin/api/action/user-proxy/clear")
    async def admin_user_proxy_clear(body: AdminUserProxyClearBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        cid = _resolve_chat_id(body.chat_id, body.username)
        if cid is None:
            return {"ok": False, "error": "user_not_found", "detail": "Пользователь не найден"}
        account_id = str(body.account_id or "").strip()
        if account_id:
            acc = _select_admin_account(int(cid), account_id)
            if not acc:
                return {"ok": False, "error": "account_not_found", "detail": "Аккаунт не найден"}
            set_account_proxy(int(cid), account_id, proxy_url=None, order_id=None, ip=None, port_http=None, port_socks5=None, login=None, password=None, scheme=None)
        else:
            set_user_proxy(cid, proxy_url=None, order_id=None, ip=None, port_http=None, port_socks5=None, login=None, password=None, scheme=None)
        u = get_user(cid)
        logger.info("admin user proxy clear | chat_id=%s username=%s account_id=%s", cid, u.tg_username or "", account_id)
        await _app_ws_push(int(cid))
        return {"ok": True, "data": {"chat_id": cid, "account_id": account_id}}

    @app.post("/admin/api/action/set-order-status")
    async def admin_set_order_status(body: AdminSetOrderStatusBody, token: str = Query(default="")) -> dict:
        _require_admin(token)
        order_id = (body.order_id or "").strip()
        status = (body.status or "").strip().lower()
        allowed = {"pending", "paid", "expired", "failed", "cancelled"}
        if status not in allowed:
            return {"ok": False, "error": "bad_status", "detail": "Допустимые статусы: pending/paid/expired/failed/cancelled"}
        async with billing._lock:
            cur = get_pending_order(order_id)
            if not isinstance(cur, dict):
                return {"ok": False, "error": "order_not_found", "detail": "Заказ не найден"}
            old_status = str(cur.get("status") or "")
            if old_status == status:
                return {"ok": True, "ignored": True, "reason": "status_unchanged", "data": {"order_id": order_id, "status": status}}
            chat_id = int(cur.get("chat_id") or 0)
            tg_username = ""
            if chat_id and chat_id in USERS:
                tg_username = USERS[chat_id].tg_username or ""
            now_ts = int(time.time())
            patch: dict = {"status": status}
            was_paid = (old_status == "paid")
            will_be_paid = (status == "paid")
            prev_paid_amount = float(cur.get("paid_amount") or cur.get("expected_amount") or 0.0)
            prev_paid_rub = float(cur.get("price_rub") or cur.get("price_rub_effective") or 0.0)
            prev_paid_at_ts = int(cur.get("paid_at_ts") or now_ts)
            if was_paid and not will_be_paid and prev_paid_amount > 0:
                adjust_paid_metric(-prev_paid_amount, prev_paid_at_ts, delta_rub=-prev_paid_rub)
            if status == "paid":
                if old_status != "paid":
                    tariff_key_for_order = str(cur.get("tariff_key") or "lite")
                    order_kind = str(cur.get("kind") or "").strip()
                    order_is_addon = bool(cur.get("is_addon"))
                    if not order_is_addon:
                        with contextlib.suppress(Exception):
                            order_tariff = billing.find_tariff(tariff_key_for_order)
                            if order_tariff and str(getattr(order_tariff, "tariff_type", "") or "") == "addon":
                                order_is_addon = True
                    if order_is_addon and not order_kind:
                        order_kind = "account_add"
                    invoice = {
                        "invoice_id": str(cur.get("invoice_id") or ""),
                        "chat_id": chat_id,
                        "tariff_key": tariff_key_for_order,
                        "tariff_days": int(cur.get("tariff_days") or 30),
                        "status": "paid",
                        "granted": True,
                        "paid_at": now_ts,
                        "message_id": cur.get("message_id"),
                        "kind": order_kind or "main_subscription",
                        "account_id": cur.get("account_id"),
                        "account_slot": cur.get("account_slot"),
                        "account_label": cur.get("account_label"),
                        "is_addon": bool(order_is_addon),
                    }
                    await billing._grant_subscription(invoice)
                    paid_amount = float(cur.get("paid_amount") or cur.get("expected_amount") or 0.0)
                    paid_rub = float(cur.get("price_rub") or cur.get("price_rub_effective") or 0.0)
                    if paid_amount > 0:
                        adjust_paid_metric(paid_amount, now_ts, delta_rub=paid_rub)
                patch["paid_at_ts"] = now_ts
                patch["paid_amount"] = float(cur.get("paid_amount") or cur.get("expected_amount") or 0.0)
                patch["fail_reason"] = None
                patch["purge_after_ts"] = now_ts + 60 * 60
            elif status in {"expired", "failed", "cancelled"}:
                if status == "failed":
                    patch["fail_reason"] = (body.reason or cur.get("fail_reason") or "manual_admin_set")[:500]
                elif status == "cancelled":
                    patch["fail_reason"] = (body.reason or cur.get("fail_reason") or "manual_cancelled")[:500]
                else:
                    patch["fail_reason"] = None
                patch["purge_after_ts"] = now_ts + int(EXPIRED_ORDER_KEEP_DAYS) * 24 * 60 * 60
            else:
                patch["fail_reason"] = None
                patch["purge_after_ts"] = None
            update_pending_order_fields(order_id, **patch)
        logger.info(
            "admin set order status | order_id=%s old=%s new=%s notify=%s reason=%s",
            order_id,
            old_status,
            status,
            int(bool(body.notify_user)),
            (body.reason or "")[:200],
        )
        if body.notify_user and chat_id and billing.app:
            invoice_label = str(cur.get("invoice_label") or "").strip()
            if not invoice_label:
                raw_invoice_id = str(cur.get("invoice_id") or "").strip()
                if raw_invoice_id:
                    invoice_label = f"#{raw_invoice_id}"
            amount = cur.get("paid_amount")
            if amount is None:
                amount = cur.get("expected_amount")
            amount_text = str(amount) if amount is not None else "-"
            text = (
                f"Статус счета {invoice_label or order_id} обновлен: {_status_ru(status)}.\n"
                f"Сумма: {amount_text} USDT.\n"
                "Если это неожиданно, напишите в поддержку @saxarok322"
            )
            with contextlib.suppress(Exception):
                await billing.app.bot.send_message(chat_id=chat_id, text=text)
        if chat_id:
            await _app_ws_push(int(chat_id))
        return {"ok": True, "data": {"order_id": order_id, "status": status}}

    @app.post("/internal/promo/enqueue")
    async def enqueue_promo(body: PromoEnqueueBody) -> dict:
        return await engine.enqueue_promo(body.promo, channel_key=body.channel_key or "", msg_id=body.msg_id)

    @app.post("/internal/billing/cryptobot/webhook")
    async def cryptobot_webhook(request: Request, x_internal_token: str | None = Header(default=None)) -> dict:
        raw_bytes = await request.body()
        raw_text = raw_bytes.decode("utf-8", errors="replace")
        logger.info("[BILLING-WEBHOOK][RAW] token=%s body=%s", x_internal_token or "", raw_text)
        try:
            payload = json.loads(raw_text) if raw_text else {}
        except Exception:
            logger.warning("[BILLING-WEBHOOK][RAW] invalid json payload")
            return {"ok": False, "error": "invalid_json"}
        return await billing.handle_webhook_payload(payload, provided_token=x_internal_token)

    return app
