import asyncio
import json
import os
import time
import uuid
import logging
import hashlib
from contextlib import suppress
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qs, urlparse, quote
from typing import Optional
import random
import httpx
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import Application

from config import (
    ADMIN_CHAT_ID,
    BILLING_CHECK_INTERVAL_SEC,
    CRYPTO_PAY_API_BASE,
    CRYPTO_PAY_API_TOKEN,
    INVOICE_COUNTDOWN_UPDATE_SEC,
    INVOICE_TTL_SEC,
    INTERNAL_WEBHOOK_TOKEN,
    REQUIRE_INTERNAL_WEBHOOK_TOKEN,
    PAYMENT_AMOUNT_ABS_TOLERANCE,
    PAYMENT_AMOUNT_REL_TOLERANCE,
    PAYLOAD_SIGN_SECRET,
    EXPIRED_ORDER_KEEP_DAYS,
    RUB_USD_RATE_URL,
    PROXYLINE_LOW_BALANCE_RUB,
    PROXYLINE_BALANCE_CACHE_TTL_SEC,
    PROXYLINE_LOW_BALANCE_ALERT_COOLDOWN_SEC,
    PROXY_HEALTH_CHECK_INTERVAL_SEC,
    PROXY_HEALTH_BATCH_SIZE,
    PROXY_HEALTH_ALERT_COOLDOWN_SEC,
)
from proxyline_service import ProxylineService
from store import (
    clear_subscription,
    get_all_chat_ids,
    get_all_pending_orders,
    get_user,
    has_active_subscription,
    delete_invoice,
    get_pending_order,
    remove_pending_order,
    save_invoice,
    save_pending_order,
    record_paid_metric,
    record_proxy_spent_metric,
    update_pending_order_fields,
    save_state,
    set_user_proxy,
    set_subscription,
    get_all_tariffs,
    update_user_fields,
    get_active_domain,
    get_user_accounts,
    get_user_account,
    get_or_create_empty_addon_account,
    patch_user_account,
    set_account_subscription,
    set_account_proxy,
    pause_account_subscription,
    resume_account_subscription,
    has_active_account_subscription,
    clear_account_casino_data,
)
from ws_manager import UserWsManager
from zooma import probe_domain_health, verify_token

logger = logging.getLogger("billing")

TG_FOLDER_SYNC_ENABLED = os.getenv("ZOOMA_TG_FOLDER_SYNC_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
TG_FOLDER_SYNC_URL = os.getenv("ZOOMA_TG_FOLDER_SYNC_URL", "http://127.0.0.1:8791/internal/folder/sync").strip()
TG_FOLDER_SYNC_SECRET = os.getenv("ZOOMA_TG_FOLDER_SYNC_SECRET", "").strip()
TG_FOLDER_SYNC_INTERVAL_SEC = max(30, int(os.getenv("ZOOMA_TG_FOLDER_SYNC_INTERVAL_SEC", "300").strip() or "300"))
TG_FOLDER_SYNC_DEBOUNCE_SEC = max(0.1, float(os.getenv("ZOOMA_TG_FOLDER_SYNC_DEBOUNCE_SEC", "0.3").strip() or "0.3"))


@dataclass
class Tariff:
    key: str
    title: str
    days: int
    price_rub_base: int
    discount_pct: float
    active: bool = True
    tariff_type: str = "main"
    sort_order: int = 100

    @property
    def price_rub(self) -> int:
        pct = max(0.0, min(95.0, float(self.discount_pct or 0.0)))
        v = int(round(float(self.price_rub_base) * (1.0 - pct / 100.0)))
        return max(1, v)


class BillingService:
    def __init__(self, ws_manager: UserWsManager):
        self.ws_manager = ws_manager
        self.app: Optional[Application] = None
        self._lock = asyncio.Lock()
        self._runner_task: Optional[asyncio.Task] = None
        self._startup_proxy_health_task: Optional[asyncio.Task] = None
        self._proxy_startup_quiet_active: bool = False
        self._proxy_startup_quiet_keys: set[str] = set()
        self.proxyline = ProxylineService()
        self._proxy_balance_rub: Optional[float] = None
        self._proxy_balance_ts: int = 0
        self._proxy_low_alert_ts: int = 0
        self._proxy_low_alert_active: bool = False
        self._proxy_health_next_ts: int = 0
        self._proxy_health_alert_ts: dict[int, int] = {}
        # Legacy maps are kept for the old diagnostic code below. New runtime
        # scheduling and alerts are keyed by chat_id + casino account_id.
        self._proxy_health_fail_state: dict[int, tuple[int, int]] = {}
        self._proxy_health_next_by_account: dict[str, float] = {}
        self._proxy_recovery_locks: dict[str, asyncio.Lock] = {}
        self._domain_health_cache: dict = {}
        self._domain_health_cache_mono: float = 0.0
        self._domain_health_lock = asyncio.Lock()
        self._server_ping_ms: Optional[float] = None
        self._server_ping_next_mono: float = 0.0
        self._server_ping_task: Optional[asyncio.Task] = None
        self._proxy_runtime_scan_next_mono: float = 0.0
        self._proxy_runtime_last_domain: str = ""
        self._proxy_health_global_alert_ts: dict[str, int] = {}
        self._proxy_choice_ttl_sec = 24 * 60 * 60
        self._proxy_choice_seen: set[str] = set()
        self._proxy_choice_inflight: dict[str, int] = {}
        self._proxy_choice_success_ts: dict[str, int] = {}
        self._proxy_choice_success_cooldown_sec = 180
        self._manual_proxy_wait_ttl_sec = 12 * 60 * 60
        self.mini_app_state_pusher = None
        self._tg_folder_sync_task: Optional[asyncio.Task] = None
        self._tg_folder_sync_pending_reason: str = ""
        self._tg_folder_sync_next_periodic_ts: int = 0

    def _new_proxy_op_id(self) -> str:
        return uuid.uuid4().hex[:12]

    async def _to_rub_amount(self, amount: float, currency: str = "") -> float:
        cur = (currency or "").strip().lower()
        if cur in {"rub", "rur", "₽", "rubles"}:
            return round(float(amount), 2)
        if cur in {"usd", "usdt", "$", "dollar", "dollars"}:
            rate = await self._rub_to_usd_rate()
            if rate > 0:
                return round(float(amount) / rate, 2)
        # Heuristic fallback: tiny values in proxy API are usually USD.
        if float(amount) <= 20:
            rate = await self._rub_to_usd_rate()
            if rate > 0:
                return round(float(amount) / rate, 2)
        return round(float(amount), 2)

    def bind_app(self, app: Application) -> None:
        self.app = app

    async def _push_mini_app_state(self, chat_id: int) -> None:
        fn = getattr(self, "mini_app_state_pusher", None)
        if not fn:
            return
        try:
            res = fn(int(chat_id))
            if asyncio.iscoroutine(res):
                await res
        except Exception:
            pass

    def _active_subscription_folder_users(self) -> list[dict]:
        now_ts = int(time.time())
        out: list[dict] = []

        for cid in get_all_chat_ids():
            try:
                chat_id = int(cid)
            except Exception:
                continue

            if ADMIN_CHAT_ID and chat_id == int(ADMIN_CHAT_ID):
                continue

            has_paid_or_frozen = False
            for acc in get_user_accounts(chat_id, include_empty=True):
                acc = acc or {}

                if bool(acc.get("subscription_paused")):
                    # Заморозка не означает конец подписки.
                    # Человек остаётся в папке, пока у замороженного слота есть остаток времени.
                    if int(acc.get("subscription_frozen_left_sec") or 0) > 0:
                        has_paid_or_frozen = True
                        break
                    continue

                if int(acc.get("subscription_until_ts") or 0) > now_ts:
                    has_paid_or_frozen = True
                    break

            if not has_paid_or_frozen:
                continue

            user = get_user(chat_id)
            username = str(getattr(user, "tg_username", "") or "").strip()
            out.append({"chat_id": chat_id, "username": username})

        out.sort(key=lambda x: int(x.get("chat_id") or 0))
        return out

    async def _sync_tg_subscription_folder_now(self, reason: str = "") -> None:
        if not TG_FOLDER_SYNC_ENABLED or not TG_FOLDER_SYNC_URL:
            return

        users = self._active_subscription_folder_users()
        headers = {"Content-Type": "application/json"}
        if TG_FOLDER_SYNC_SECRET:
            headers["X-Zooma-Folder-Token"] = TG_FOLDER_SYNC_SECRET

        payload = {
            "reason": str(reason or "sync"),
            "users": users,
            "ts": int(time.time()),
            "immediate": str(reason or "").startswith("admin_"),
        }

        try:
            from tg_watcher import request_in_memory_folder_sync
            direct = await request_in_memory_folder_sync(payload)
            if direct.get("ok"):
                logger.debug("tg folder sync queued in-memory reason=%s users=%s", reason or "-", len(users))
                return
        except Exception:
            pass

        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(connect=1.0, read=2.0, write=1.0, pool=1.0), trust_env=False) as client:
                resp = await client.post(TG_FOLDER_SYNC_URL, json=payload, headers=headers)
            if int(resp.status_code) != 200:
                logger.warning("tg folder sync failed http=%s body=%s", resp.status_code, resp.text[:180])
                return
            logger.debug("tg folder sync queued via http reason=%s users=%s", reason or "-", len(users))
        except Exception as e:
            logger.warning("tg folder sync request failed reason=%s error=%s", reason or "-", e)

    def request_tg_subscription_folder_sync(self, reason: str = "", *, immediate: bool = False) -> None:
        if not TG_FOLDER_SYNC_ENABLED:
            return

        reason = str(reason or self._tg_folder_sync_pending_reason or "sync")
        self._tg_folder_sync_pending_reason = reason

        if immediate:
            if self._tg_folder_sync_task and not self._tg_folder_sync_task.done():
                self._tg_folder_sync_task.cancel()

            async def _immediate_runner() -> None:
                reason_now = self._tg_folder_sync_pending_reason or reason or "sync"
                self._tg_folder_sync_pending_reason = ""
                await self._sync_tg_subscription_folder_now(reason_now)

            self._tg_folder_sync_task = asyncio.create_task(_immediate_runner(), name="tg-folder-sync-request-now")
            return

        if self._tg_folder_sync_task and not self._tg_folder_sync_task.done():
            return

        async def _runner() -> None:
            await asyncio.sleep(TG_FOLDER_SYNC_DEBOUNCE_SEC)
            reason_now = self._tg_folder_sync_pending_reason or "sync"
            self._tg_folder_sync_pending_reason = ""
            await self._sync_tg_subscription_folder_now(reason_now)

        self._tg_folder_sync_task = asyncio.create_task(_runner(), name="tg-folder-sync-request")

    async def _periodic_tg_folder_sync(self) -> None:
        if not TG_FOLDER_SYNC_ENABLED:
            return
        now_ts = int(time.time())
        if now_ts < self._tg_folder_sync_next_periodic_ts:
            return
        self._tg_folder_sync_next_periodic_ts = now_ts + int(TG_FOLDER_SYNC_INTERVAL_SEC)
        await self._sync_tg_subscription_folder_now("periodic")

    async def _restore_legacy_proxy_freezes(self) -> int:
        """Remove only obsolete automatic proxy freezes without extending the deadline."""
        now_ts = int(time.time())
        restored = 0
        for cid in get_all_chat_ids():
            for acc in get_user_accounts(cid, include_empty=True):
                account_id = str(acc.get("account_id") or "").strip()
                if not account_id:
                    continue
                if not bool(acc.get("subscription_paused")):
                    continue
                if str(acc.get("subscription_freeze_reason") or "") != "proxy_unavailable":
                    continue
                until_ts = int(acc.get("subscription_until_ts") or 0)
                patch_user_account(
                    int(cid),
                    account_id,
                    subscription_paused=False,
                    subscription_pause_started_ts=None,
                    subscription_frozen_left_sec=None,
                    subscription_freeze_reason=None,
                    proxy_failure_notified_at_ts=None,
                    connected=False,
                    status=("active" if until_ts > now_ts else "expired"),
                )
                restored += 1
                logger.warning(
                    "legacy proxy auto-freeze removed | chat_id=%s account_id=%s until_ts=%s",
                    int(cid), account_id, until_ts,
                )
        return restored

    async def _finalize_startup_proxy_quiet_window(
        self,
    ) -> None:
        # После единой стартовой перепроверки:
        # - healthy удаляются тихо;
        # - реальная unavailable/site_unreachable уведомляется;
        # - recovering остаётся тихим до окончательного результата.
        self._proxy_startup_quiet_active = False

        if not self._proxy_startup_quiet_keys:
            return

        active_domain = (
            get_active_domain() or ""
        ).strip().rstrip("/")

        healthy_silent = 0
        confirmed_down = 0
        pending = 0

        for key in list(self._proxy_startup_quiet_keys):
            try:
                raw_chat_id, account_id = key.split(":", 1)
                chat_id = int(raw_chat_id)
            except Exception:
                self._proxy_startup_quiet_keys.discard(key)
                continue

            row = get_user_account(chat_id, account_id) or {}
            mode = str(
                row.get("promo_activation_mode") or "server"
            ).strip().lower()

            if (
                not row
                or mode == "extension"
                or bool(row.get("subscription_paused"))
                or not has_active_account_subscription(
                    chat_id,
                    account_id,
                    int(time.time()),
                )
                or not str(row.get("proxy_url") or "").strip()
            ):
                self._proxy_startup_quiet_keys.discard(key)
                continue

            runtime_status = self._proxy_runtime_status(row)

            if runtime_status == "healthy":
                self._proxy_startup_quiet_keys.discard(key)
                healthy_silent += 1
                continue

            if runtime_status in {
                "unavailable",
                "site_unreachable",
            }:
                reason = str(
                    row.get("proxy_runtime_reason")
                    or row.get("proxy_ping_error")
                    or "startup_proxy_check_failed"
                )

                notified = await self._mark_proxy_runtime_problem(
                    chat_id,
                    account_id,
                    runtime_status,
                    reason,
                    source="proxy_health_startup_confirmed",
                    active_domain=active_domain,
                )
                if notified:
                    confirmed_down += 1
                else:
                    pending += 1
                continue

            # recovering: проверка или WS ещё завершаются.
            # Ключ остаётся в списке, чтобы последующий healthy
            # не отправил ложное уведомление о восстановлении.
            pending += 1

        logger.info(
            "Proxy startup quiet window closed | "
            "healthy_silent=%s | confirmed_down=%s | pending=%s",
            healthy_silent,
            confirmed_down,
            pending,
        )

    async def _run_startup_proxy_health_checks(self) -> None:
        delay = max(
            0.5,
            float(
                os.getenv(
                    "PROXY_RUNTIME_STARTUP_DELAY_SEC",
                    "15",
                )
                or "15"
            ),
        )
        if self._proxy_startup_quiet_active:
            logger.info(
                "Proxy startup quiet window waiting | "
                "delay=%.1fs | accounts=%s",
                delay,
                len(self._proxy_startup_quiet_keys),
            )
        await asyncio.sleep(delay)
        attempt = 0
        while True:
            try:
                # Do not consume retries while the domain resolver is still starting.
                if not (get_active_domain() or "").strip():
                    await asyncio.sleep(5.0)
                    continue
                attempt += 1
                restored = await self._restore_legacy_proxy_freezes()
                await self.run_proxy_health_checks_now()
                await self._finalize_startup_proxy_quiet_window()
                logger.info(
                    "Proxy health startup check completed | restored_legacy_freezes=%s",
                    restored,
                )
                return
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.warning(
                    "Proxy health startup check failed | attempt=%s error=%s: %s",
                    attempt, type(e).__name__, e,
                )
                if attempt >= 12:
                    logger.warning(
                        "Proxy health startup check abandoned after retries"
                    )
                    await self._finalize_startup_proxy_quiet_window()
                    return
                await asyncio.sleep(5.0)

    def start(self) -> None:
        if self._runner_task and not self._runner_task.done():
            return

        self._proxy_startup_quiet_keys.clear()

        for cid in get_all_chat_ids():
            for row in get_user_accounts(
                int(cid),
                include_empty=False,
            ):
                account_id = str(
                    row.get("account_id") or ""
                ).strip()
                if not account_id:
                    continue
                if (
                    str(
                        row.get("promo_activation_mode")
                        or "server"
                    ).strip().lower()
                    == "extension"
                ):
                    continue

                runtime_status = self._proxy_runtime_status(row)
                runtime_source = str(
                    row.get("proxy_runtime_source") or ""
                ).strip().lower()

                if (
                    runtime_status == "recovering"
                    and runtime_source == "startup_gate"
                ):
                    self._proxy_startup_quiet_keys.add(
                        self._proxy_runtime_key(
                            int(cid),
                            account_id,
                        )
                    )

        self._proxy_startup_quiet_active = bool(
            self._proxy_startup_quiet_keys
        )

        if self._proxy_startup_quiet_active:
            logger.info(
                "Proxy startup quiet window armed | "
                "accounts=%s | delay=15s",
                len(self._proxy_startup_quiet_keys),
            )

        self._runner_task = asyncio.create_task(
            self._run_loop(),
            name="billing-loop",
        )
        self._startup_proxy_health_task = asyncio.create_task(
            self._run_startup_proxy_health_checks(),
            name="proxy-health-startup",
        )

    async def stop(self) -> None:
        if self._startup_proxy_health_task and not self._startup_proxy_health_task.done():
            self._startup_proxy_health_task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self._startup_proxy_health_task
        if self._runner_task and not self._runner_task.done():
            self._runner_task.cancel()
            try:
                await self._runner_task
            except Exception:
                pass
        if self._server_ping_task and not self._server_ping_task.done():
            self._server_ping_task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self._server_ping_task

    def tariffs(self, tariff_type: str = "main") -> list[Tariff]:
        result: list[Tariff] = []
        wanted = str(tariff_type or "main").strip()
        for key, cfg in get_all_tariffs().items():
            if not bool(cfg.get("active", True)):
                continue
            ttype = str(cfg.get("tariff_type") or "main").strip()
            if wanted and ttype != wanted:
                continue
            result.append(
                Tariff(
                    key=key,
                    title=str(cfg.get("title", key)),
                    days=int(cfg.get("days", 30)),
                    price_rub_base=int(cfg.get("price_rub_base", cfg.get("price_rub", 700))),
                    discount_pct=float(cfg.get("discount_pct", 0.0)),
                    active=bool(cfg.get("active", True)),
                    tariff_type=ttype,
                    sort_order=int(cfg.get("sort_order") or 100),
                )
            )
        result.sort(key=lambda t: (int(t.price_rub), int(t.days), str(t.key)))
        return result

    def tariffs_menu_keyboard(self, tariff_type: str = "main", callback_prefix: str = "tariff_buy") -> InlineKeyboardMarkup:
        def _strike_text(s: str) -> str:
            # Unicode combining long stroke overlay for per-char strikethrough
            return "".join(ch + "\u0336" for ch in s)

        def _tariff_btn_text(t: Tariff) -> str:
            base = int(t.price_rub_base)
            eff = int(t.price_rub)
            pct = float(t.discount_pct or 0.0)
            if pct > 0 and eff < base:
                return f"{t.title} - {_strike_text(str(base))} {eff}руб (-{pct:g}%)"
            return f"{t.title} - {eff}руб"
        buttons = [
            [InlineKeyboardButton(_tariff_btn_text(t), callback_data=f"{callback_prefix}:{t.key}")]
            for t in self.tariffs(tariff_type)
        ]
        buttons.append([InlineKeyboardButton("Назад", callback_data="back")])
        return InlineKeyboardMarkup(buttons)

    def confirm_keyboard(self, tariff_key: str, callback_prefix: str = "tariff_confirm", back_callback: str = "tariff_menu") -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [[
                InlineKeyboardButton("Да", callback_data=f"{callback_prefix}:{tariff_key}"),
                InlineKeyboardButton("Нет", callback_data=back_callback),
            ]]
        )

    def find_tariff(self, tariff_key: str, tariff_type: Optional[str] = None) -> Optional[Tariff]:
        if tariff_type:
            for t in self.tariffs(tariff_type):
                if t.key == tariff_key:
                    return t
            return None
        for ttype in ("main", "addon"):
            for t in self.tariffs(ttype):
                if t.key == tariff_key:
                    return t
        return None

    async def create_invoice(
        self,
        chat_id: int,
        tariff: Tariff,
        *,
        kind: str = "main_subscription",
        account_id: Optional[str] = None,
        account_slot: Optional[int] = None,
        account_label: Optional[str] = None,
        is_addon: bool = False,
    ) -> dict:
        usd_rate = await self._rub_to_usd_rate()
        usd_amount = round(max(0.1, tariff.price_rub * usd_rate), 2)
        order_id = uuid.uuid4().hex[:12]
        sig = self._make_payload_sig(chat_id=chat_id, order_id=order_id, expected_amount=usd_amount)
        payload = json.dumps(
            {
                "chat_id": chat_id,
                "tariff_key": tariff.key,
                "order_id": order_id,
                "expected_amount": str(usd_amount),
                "sig": sig,
                "kind": kind,
                "account_id": account_id,
                "account_slot": account_slot,
                "account_label": account_label,
                "is_addon": bool(is_addon),
            },
            ensure_ascii=False,
        )
        resp = await self._crypto_api(
            "/createInvoice",
            {
                "currency_type": "crypto",
                "asset": "USDT",
                "amount": str(usd_amount),
                "description": (f"Доп аккаунт {tariff.title} на {tariff.days} дней" if is_addon else f"Подписка {tariff.title} на {tariff.days} дней"),
                "payload": payload,
                "expires_in": INVOICE_TTL_SEC,
            },
        )
        invoice = resp.get("result") or {}
        invoice_id = str(invoice.get("invoice_id") or "")
        pay_url = str(invoice.get("bot_invoice_url") or "")
        if not invoice_id or not pay_url:
            raise RuntimeError("CryptoBot createInvoice вернул пустые данные")
        invoice_label = self._extract_invoice_label_from_pay_url(pay_url) or f"#{invoice_id}"
        now_ts = int(time.time())
        invoice_data = {
            "invoice_id": invoice_id,
            "invoice_label": invoice_label,
            "order_id": order_id,
            "chat_id": chat_id,
            "tariff_key": tariff.key,
            "tariff_title": tariff.title,
            "tariff_days": tariff.days,
            "price_rub": tariff.price_rub,
            "price_rub_base": tariff.price_rub_base,
            "discount_pct": float(tariff.discount_pct),
            "price_rub_effective": tariff.price_rub,
            "price_usdt": usd_amount,
            "status": "pending",
            "created_at": now_ts,
            "expires_at": now_ts + INVOICE_TTL_SEC,
            "pay_url": pay_url,
            "message_id": None,
            "last_countdown_edit_at": 0,
            "granted": False,
            "kind": kind,
            "account_id": account_id,
            "account_slot": account_slot,
            "account_label": account_label,
            "is_addon": bool(is_addon),
            "tariff_type": tariff.tariff_type,
        }
        save_invoice(invoice_id, invoice_data)
        save_pending_order(
            order_id,
            {
                "order_id": order_id,
                "invoice_id": invoice_id,
                "invoice_label": invoice_label,
                "chat_id": chat_id,
                "expected_amount": float(usd_amount),
                "sig": sig,
                "status": "pending",
                "expires_at_ts": now_ts + INVOICE_TTL_SEC,
                "created_at_ts": now_ts,
                "tariff_key": tariff.key,
                "tariff_days": tariff.days,
                "price_rub": tariff.price_rub,
                "price_rub_base": tariff.price_rub_base,
                "discount_pct": float(tariff.discount_pct),
                "price_rub_effective": tariff.price_rub,
                "price_usdt": usd_amount,
                "pay_url": pay_url,
                "last_countdown_edit_at": 0,
                "kind": kind,
                "account_id": account_id,
                "account_slot": account_slot,
                "account_label": account_label,
                "is_addon": bool(is_addon),
                "tariff_type": tariff.tariff_type,
            },
        )
        user = get_user(chat_id)
        user.last_invoice_id = invoice_id
        save_state()
        return invoice_data

    async def create_addon_invoice(self, chat_id: int, tariff: Tariff) -> dict:
        account = get_or_create_empty_addon_account(chat_id)
        account_id = str(account.get("account_id") or "")
        slot = int(account.get("slot") or 0)
        if not account_id or slot <= 1:
            raise RuntimeError("Не удалось подготовить слот доп аккаунта")
        patch_user_account(
            chat_id,
            account_id,
            billing_type="addon",
            status="pending_payment",
        )
        return await self.create_invoice(
            chat_id,
            tariff,
            kind="account_add",
            account_id=account_id,
            account_slot=slot,
            account_label=f"доп акк #{slot}",
            is_addon=True,
        )


    async def send_invoice_message(self, chat_id: int, invoice: dict) -> None:
        if not self.app:
            return
        left = max(0, int(invoice["expires_at"] - time.time()))
        text = self._invoice_text(invoice, left)
        msg = await self.app.bot.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Оплатить", url=invoice["pay_url"])]]),
        )
        invoice["message_id"] = msg.message_id
        save_invoice(invoice["invoice_id"], invoice)
        order_id = str(invoice.get("order_id") or "").strip()
        if order_id:
            update_pending_order_fields(
                order_id,
                message_id=msg.message_id,
                pay_url=invoice.get("pay_url"),
                price_rub=invoice.get("price_rub"),
                price_usdt=invoice.get("price_usdt"),
                invoice_label=invoice.get("invoice_label"),
            )

    async def handle_webhook_payload(self, payload: dict, provided_token: str | None = None) -> dict:
        async with self._lock:
            raw_update_id = str(payload.get("update_id") or "")
            if REQUIRE_INTERNAL_WEBHOOK_TOKEN:
                if INTERNAL_WEBHOOK_TOKEN and (provided_token or "") != INTERNAL_WEBHOOK_TOKEN:
                    await self._notify_admin_webhook_log(
                        order_id="-",
                        invoice_id=None,
                        chat_id=None,
                        expected=None,
                        paid=None,
                        reason="forbidden_token",
                    )
                    return {"ok": False, "error": "forbidden"}
            update_type = str(payload.get("update_type") or "")
            if update_type != "invoice_paid":
                logger.info("billing webhook ignored: unsupported_update_type=%s", update_type)
                await self._notify_admin_webhook_log(
                    order_id="-",
                    invoice_id=None,
                    chat_id=None,
                    expected=None,
                    paid=None,
                    reason=f"unsupported_update_type:{update_type}",
                )
                return {"ok": True, "ignored": True, "reason": "unsupported_update_type"}
            invoice_obj = payload.get("payload") or {}
            invoice_id = str(invoice_obj.get("invoice_id") or "")
            payload_meta = self._extract_payload_meta(invoice_obj.get("payload"))
            if not payload_meta:
                logger.info("billing webhook ignored: invalid_payload_meta")
                await self._notify_admin_webhook_log(
                    order_id="-",
                    invoice_id=invoice_id or None,
                    chat_id=None,
                    expected=None,
                    paid=self._extract_paid_amount(invoice_obj),
                    reason="invalid_payload_meta",
                )
                return {"ok": True, "ignored": True, "reason": "invalid_payload_meta"}
            order_id = str(payload_meta.get("order_id") or "")
            paid_amount = self._extract_paid_amount(invoice_obj)
            pending = get_pending_order(order_id)
            if not pending:
                logger.info("billing webhook ignored: pending_order_not_found order_id=%s", order_id)
                await self._notify_admin_webhook_log(
                    order_id=order_id or "-",
                    invoice_id=invoice_id or None,
                    chat_id=None,
                    expected=payload_meta.get("expected_amount"),
                    paid=paid_amount,
                    reason="pending_order_not_found",
                )
                return {"ok": True, "ignored": True, "reason": "pending_order_not_found"}
            if str(pending.get("status") or "") != "pending":
                status = str(pending.get("status") or "")
                if status == "paid":
                    logger.info("billing webhook duplicate ignored: already_paid order_id=%s", order_id)
                    return {"ok": True, "ignored": True, "reason": "already_paid_duplicate"}
                logger.info("billing webhook skipped: pending_order_not_pending order_id=%s", order_id)
                await self._notify_admin_webhook_log(
                    order_id=order_id,
                    invoice_id=str(pending.get("invoice_label") or pending.get("invoice_id") or "") or None,
                    chat_id=int(pending.get("chat_id")),
                    expected=float(pending.get("expected_amount") or 0),
                    paid=paid_amount,
                    reason="order_not_pending",
                )
                return {"ok": True, "skipped": True, "reason": "order_not_pending"}
            if invoice_id and str(pending.get("invoice_id") or "") != invoice_id:
                self._mark_order_failed(
                    order_id,
                    pending,
                    reason="invoice_mismatch",
                    paid_amount=paid_amount,
                    webhook_update_id=raw_update_id,
                )
                logger.info("billing webhook skipped: invoice_mismatch order_id=%s", order_id)
                await self._push_mini_app_state(int(pending.get("chat_id") or 0))
                await self._notify_admin_webhook_log(
                    order_id=order_id,
                    invoice_id=str(pending.get("invoice_label") or invoice_id or pending.get("invoice_id") or "") or None,
                    chat_id=int(pending.get("chat_id")),
                    expected=float(pending.get("expected_amount") or 0),
                    paid=paid_amount,
                    reason="invoice_mismatch",
                )
                return {"ok": True, "skipped": True, "reason": "invoice_mismatch"}
            chat_id = int(pending.get("chat_id"))
            now_ts = int(time.time())
            if now_ts > int(pending.get("expires_at_ts", 0)):
                await self._try_delete_invoice_message(chat_id=chat_id, message_id=pending.get("message_id"))
                self._mark_order_expired(order_id, pending)
                logger.info("billing webhook skipped: ttl_expired order_id=%s", order_id)
                await self._push_mini_app_state(chat_id)
                return {"ok": True, "skipped": True, "reason": "ttl_expired"}
            if not self._validate_payload_sig(payload_meta):
                self._mark_order_failed(
                    order_id,
                    pending,
                    reason="payload_sig_invalid",
                    paid_amount=paid_amount,
                    webhook_update_id=raw_update_id,
                )
                logger.info("billing webhook skipped: payload_sig_invalid order_id=%s", order_id)
                await self._push_mini_app_state(chat_id)
                await self._notify_admin_webhook_log(
                    order_id=order_id,
                    invoice_id=str(pending.get("invoice_label") or invoice_id or pending.get("invoice_id") or "") or None,
                    chat_id=chat_id,
                    expected=float(pending.get("expected_amount") or 0),
                    paid=paid_amount,
                    reason="payload_sig_invalid",
                )
                return {"ok": True, "skipped": True, "reason": "payload_sig_invalid"}
            expected_amount = float(pending.get("expected_amount") or 0)
            if not self._is_amount_valid(expected_amount, paid_amount):
                self._mark_order_failed(
                    order_id,
                    pending,
                    reason="amount_mismatch",
                    paid_amount=paid_amount,
                    webhook_update_id=raw_update_id,
                )
                logger.info(
                    "billing webhook skipped: amount_mismatch order_id=%s expected=%s paid=%s",
                    order_id, expected_amount, paid_amount
                )
                await self._push_mini_app_state(chat_id)
                await self._notify_admin_webhook_log(
                    order_id=order_id,
                    invoice_id=str(pending.get("invoice_label") or invoice_id or pending.get("invoice_id") or "") or None,
                    chat_id=chat_id,
                    expected=expected_amount,
                    paid=paid_amount,
                    reason="amount_mismatch",
                )
                return {
                    "ok": True,
                    "skipped": True,
                    "reason": "amount_mismatch",
                    "expected": expected_amount,
                    "paid": paid_amount,
                }
            invoice = {
                "invoice_id": invoice_id or str(pending.get("invoice_id") or ""),
                "order_id": order_id,
                "chat_id": chat_id,
                "tariff_key": str(pending.get("tariff_key") or "lite"),
                "tariff_days": int(pending.get("tariff_days") or 30),
                "status": "paid",
                "granted": True,
                "paid_at": now_ts,
                "message_id": pending.get("message_id"),
                "kind": str(pending.get("kind") or "main_subscription"),
                "account_id": pending.get("account_id"),
                "account_slot": pending.get("account_slot"),
                "account_label": pending.get("account_label"),
                "is_addon": bool(pending.get("is_addon")),
            }
            await self._grant_subscription(invoice)
            self._mark_order_paid(order_id, pending)
            paid_rub = float(pending.get("price_rub") or pending.get("price_rub_effective") or 0.0)
            record_paid_metric(paid_amount, now_ts, amount_rub=paid_rub)
            logger.info("billing webhook accepted: invoice_paid order_id=%s chat_id=%s", order_id, chat_id)
            await self._push_mini_app_state(chat_id)
            await self._notify_admin_webhook_log(
                order_id=order_id,
                invoice_id=str(pending.get("invoice_label") or invoice_id or pending.get("invoice_id") or "") or None,
                chat_id=chat_id,
                expected=expected_amount,
                paid=paid_amount,
                reason="accepted",
            )
            return {"ok": True}

    async def _grant_subscription(self, invoice: dict) -> None:
        if not self.app:
            return
        chat_id = int(invoice["chat_id"])
        now_ts = int(time.time())
        kind = str(invoice.get("kind") or "main_subscription")
        account_id = str(invoice.get("account_id") or "").strip()
        is_addon = bool(invoice.get("is_addon")) or kind in {"account_add", "account_renew"}

        tariff_key = str(invoice.get("tariff_key") or "").strip()
        if not is_addon and tariff_key:
            with suppress(Exception):
                t = self.find_tariff(tariff_key)
                if t and str(getattr(t, "tariff_type", "") or "") == "addon":
                    is_addon = True
                    if kind == "main_subscription":
                        kind = "account_add"

        if is_addon and not account_id:
            # Safety net for old/admin-created addon invoices that missed account metadata.
            account = get_or_create_empty_addon_account(chat_id)
            account_id = str(account.get("account_id") or "")
            slot = int(account.get("slot") or 0)
            if account_id:
                invoice["account_id"] = account_id
                invoice["account_slot"] = slot
                invoice["account_label"] = f"доп акк #{slot}"
                invoice["is_addon"] = True
                invoice["kind"] = kind if kind in {"account_add", "account_renew"} else "account_add"
                patch_user_account(chat_id, account_id, billing_type="addon", status="pending_payment")

        if is_addon:
            if not account_id:
                raise RuntimeError("addon invoice without account_id")
            acc = get_user_account(chat_id, account_id) or {}
            prev_until_ts = int(acc.get("subscription_until_ts") or 0)
            had_active_remainder = prev_until_ts > now_ts
            base_ts = max(now_ts, prev_until_ts)
            until_ts = base_ts + int(invoice.get("tariff_days", 30)) * 24 * 60 * 60
            set_account_subscription(chat_id, account_id, str(invoice.get("tariff_key", "addon")), until_ts)
            invoice["status"] = "paid"
            invoice["paid_at"] = now_ts
            invoice["granted"] = True
            save_invoice(invoice["invoice_id"], invoice)
            if invoice.get("message_id"):
                with suppress(Exception):
                    await self.app.bot.delete_message(chat_id=chat_id, message_id=int(invoice["message_id"]))

            slot = int(invoice.get("account_slot") or acc.get("slot") or 0)
            billing_type = str(acc.get("billing_type") or ("addon" if slot > 1 else "main")).strip()
            account_kind_ru = "доп аккаунт" if billing_type == "addon" else "основной аккаунт"
            account_title = f"аккаунт #{slot}" if slot else "аккаунт"
            msk_tz = timezone(timedelta(hours=3))
            until_msk = datetime.fromtimestamp(until_ts, tz=msk_tz).strftime("%d.%m.%Y %H:%M")
            if had_active_remainder:
                prev_msk = datetime.fromtimestamp(prev_until_ts, tz=msk_tz).strftime("%d.%m.%Y %H:%M")
                notify_text = (
                    "✅ Оплата прошла\n\n"
                    f"Тип подписки: <b>{account_kind_ru}</b>\n"
                    f"Подписка {account_title} продлена на {int(invoice.get('tariff_days', 30) or 30)} дней\n"
                    f"{prev_msk} —> <b>{until_msk}</b> МСК"
                )
            else:
                notify_text = (
                    "✅ Оплата прошла\n\n"
                    f"Тип подписки: <b>{account_kind_ru}</b>\n"
                    f"Подписка {account_title} до {until_msk} МСК"
                )
            await self.app.bot.send_message(
                chat_id=chat_id,
                text=notify_text,
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("Привязать / перелогиниться", callback_data=f"relogin:{account_id}")]]
                ),
            )
            await self._send_proxy_choice_after_payment(
                chat_id=chat_id,
                order_id=str(invoice.get("order_id") or ""),
                account_id=account_id,
                period_days=int(invoice.get("tariff_days", 30) or 30),
                had_active_remainder=had_active_remainder,
            )
            self.request_tg_subscription_folder_sync("grant_addon")
            return

        user = get_user(chat_id)
        prev_until_ts = int(user.subscription_until_ts or 0)
        had_active_remainder = prev_until_ts > now_ts
        base_ts = max(now_ts, prev_until_ts)
        until_ts = base_ts + int(invoice.get("tariff_days", 30)) * 24 * 60 * 60
        set_subscription(chat_id, str(invoice.get("tariff_key", "lite")), until_ts)
        invoice["status"] = "paid"
        invoice["paid_at"] = now_ts
        invoice["granted"] = True
        save_invoice(invoice["invoice_id"], invoice)
        if invoice.get("message_id"):
            try:
                await self.app.bot.delete_message(chat_id=chat_id, message_id=int(invoice["message_id"]))
            except Exception:
                pass
        msk_tz = timezone(timedelta(hours=3))
        until_msk = datetime.fromtimestamp(until_ts, tz=msk_tz).strftime("%d.%m.%Y %H:%M")
        if had_active_remainder:
            prev_msk = datetime.fromtimestamp(prev_until_ts, tz=msk_tz).strftime("%d.%m.%Y %H:%M")
            days = int(invoice.get("tariff_days", 30) or 30)
            notify_text = (
                "✅ Оплата прошла\n\n"
                f"Подписка продлена на {days} дней\n"
                f"{prev_msk} —> <b>{until_msk}</b> МСК"
            )
        else:
            notify_text = f"✅ Оплата прошла\n\nПодписка активна до {until_msk} МСК"
        await self.app.bot.send_message(
            chat_id=chat_id,
            text=notify_text,
            parse_mode=ParseMode.HTML,
        )
        await self._send_proxy_choice_after_payment(
            chat_id=chat_id,
            order_id=str(invoice.get("order_id") or ""),
            account_id=None,
            period_days=int(invoice.get("tariff_days", 30) or 30),
            had_active_remainder=had_active_remainder,
        )
        self.request_tg_subscription_folder_sync("grant_main")

    async def request_proxy_choice_after_grant(
        self,
        *,
        chat_id: int,
        account_id: Optional[str],
        period_days: int,
        had_active_remainder: bool,
    ) -> None:
        await self._send_proxy_choice_after_payment(
            chat_id=chat_id,
            order_id="-",
            account_id=account_id,
            period_days=period_days,
            had_active_remainder=had_active_remainder,
        )

    async def _send_proxy_choice_after_payment(
        self,
        *,
        chat_id: int,
        order_id: str,
        account_id: Optional[str],
        period_days: int,
        had_active_remainder: bool,
    ) -> None:
        if not self.app:
            return
        now_ts = int(time.time())
        choice_id = uuid.uuid4().hex[:10]
        target_order_id = str(order_id or "").strip()
        aid = str(account_id or "").strip() or "acc_1"
        renew_hint = "1" if bool(had_active_remainder) else "0"
        days = max(1, int(period_days or 30))
        text = (
            "Подписка активирована.\n\n"
            "Выбери как работать с прокси для этого аккаунта:"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("Купить прокси через бота", callback_data=f"proxy_choice:buy:{choice_id}:{aid}:{days}:{renew_hint}:{target_order_id or '-'}")],
            [InlineKeyboardButton("Укажу свой прокси вручную", callback_data=f"proxy_choice:manual:{choice_id}:{aid}:{days}:{renew_hint}:{target_order_id or '-'}")],
        ])
        await self.app.bot.send_message(chat_id=chat_id, text=text, reply_markup=kb)

    def _normalize_proxy_choice_account_id(self, account_id: Optional[str]) -> str:
        aid = str(account_id or "").strip()
        if not aid or aid == "-":
            return "acc_1"
        return aid

    def _manual_proxy_help_text(self) -> str:
        return (
            "Формат ручного прокси (SOCKS5 или HTTP):\n"
            "1) socks5://login:pass@host:port\n"
            "2) socks5h://login:pass@host:port\n"
            "3) http://login:pass@host:port\n"
            "4) host:port:login:pass (по умолчанию SOCKS5)"
        )

    def _manual_proxy_wait_prompt_text(self) -> str:
        ttl_hours = int(self._manual_proxy_wait_ttl_sec // 3600)
        return (
            f"Ок, отправьте сюда ваш SOCKS5 или HTTP прокси (ожидание {ttl_hours} ч).\n\n"
            + self._manual_proxy_help_text()
        )

    def _manual_proxy_wait_prompt_keyboard(
        self, *, choice_id: str, account_id: str, period_days: int, renew_hint: bool, order_id: str
    ) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [[
                InlineKeyboardButton(
                    "Отмена",
                    callback_data=(
                        f"proxy_choice_manual_cancel:{choice_id}:{account_id}:"
                        f"{max(1, int(period_days or 30))}:{1 if bool(renew_hint) else 0}:{order_id or '-'}"
                    ),
                )
            ]]
        )

    def _mask_ip_tail(self, ip: str) -> str:
        val = str(ip or "").strip()
        parts = val.split(".")
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.#.#"
        return val or "-"

    def _clear_manual_proxy_wait_states(self, chat_id: int, *, except_account_id: Optional[str] = None) -> None:
        keep = str(except_account_id or "").strip()
        for acc in get_user_accounts(chat_id, include_empty=True):
            aid = str(acc.get("account_id") or "").strip()
            if not aid:
                continue
            if keep and aid == keep:
                continue
            if not bool(acc.get("proxy_manual_waiting")) and int(acc.get("proxy_manual_wait_until_ts") or 0) <= 0:
                continue
            with suppress(Exception):
                patch_user_account(
                    chat_id,
                    aid,
                    proxy_manual_waiting=False,
                    proxy_manual_wait_until_ts=0,
                    proxy_manual_wait_set_ts=0,
                    proxy_manual_wait_order_id="",
                    proxy_manual_wait_choice_id="",
                    proxy_manual_wait_period_days=0,
                    proxy_manual_wait_renew_hint=0,
                    proxy_manual_wait_prompt_message_id=0,
                )

    def _set_manual_proxy_wait_state(
        self,
        *,
        chat_id: int,
        account_id: str,
        choice_id: str,
        order_id: str,
        period_days: int,
        renew_hint: bool,
    ) -> None:
        now_ts = int(time.time())
        self._clear_manual_proxy_wait_states(chat_id, except_account_id=account_id)
        patch_user_account(
            chat_id,
            account_id,
            proxy_manual_waiting=True,
            proxy_manual_wait_until_ts=now_ts + int(self._manual_proxy_wait_ttl_sec),
            proxy_manual_wait_set_ts=now_ts,
            proxy_manual_wait_order_id=str(order_id or ""),
            proxy_manual_wait_choice_id=str(choice_id or ""),
            proxy_manual_wait_period_days=max(1, int(period_days or 30)),
            proxy_manual_wait_renew_hint=1 if bool(renew_hint) else 0,
            proxy_manual_wait_prompt_message_id=0,
        )

    def has_active_manual_proxy_wait(self, chat_id: int) -> bool:
        aid, acc, expired = self._get_manual_proxy_wait_target(chat_id)
        return bool(aid and acc and not expired)

    def get_manual_proxy_wait_context(self, chat_id: int) -> tuple[Optional[str], Optional[dict], bool]:
        aid, acc, expired = self._get_manual_proxy_wait_target(chat_id)
        return aid, acc, expired

    def is_likely_manual_proxy_input(self, raw: str) -> bool:
        val = str(raw or "").strip()
        if not val:
            return False
        low = val.lower()
        if low.startswith(("socks5://", "socks5h://", "http://")):
            return True
        if "://" in val:
            return False
        return len(val.split(":")) == 4

    def get_manual_proxy_wait_prompt_message_id(self, chat_id: int) -> Optional[int]:
        aid, acc, _expired = self._get_manual_proxy_wait_target(chat_id)
        if not aid or not acc:
            return None
        mid = int(acc.get("proxy_manual_wait_prompt_message_id") or 0)
        return mid or None

    def set_manual_proxy_wait_prompt_message_id(self, chat_id: int, message_id: Optional[int]) -> None:
        aid, acc, _expired = self._get_manual_proxy_wait_target(chat_id)
        if not aid or not acc:
            return
        patch_user_account(chat_id, aid, proxy_manual_wait_prompt_message_id=int(message_id or 0))

    def get_manual_proxy_wait_prompt(
        self, *, chat_id: int, choice_id: str, account_id: Optional[str], period_days: int, renew_hint: bool, order_id: Optional[str]
    ) -> tuple[str, InlineKeyboardMarkup]:
        aid = self._normalize_proxy_choice_account_id(account_id)
        return (
            self._manual_proxy_wait_prompt_text(),
            self._manual_proxy_wait_prompt_keyboard(
                choice_id=str(choice_id or ""),
                account_id=aid,
                period_days=max(1, int(period_days or 30)),
                renew_hint=bool(renew_hint),
                order_id=str(order_id or "-"),
            ),
        )

    def cancel_manual_proxy_wait(self, chat_id: int) -> bool:
        if not self.has_active_manual_proxy_wait(chat_id):
            return False
        self._clear_manual_proxy_wait_states(chat_id)
        return True

    def _get_manual_proxy_wait_target(self, chat_id: int) -> tuple[Optional[str], Optional[dict], bool]:
        now_ts = int(time.time())
        best: tuple[int, int, str, dict] | None = None
        for acc in get_user_accounts(chat_id, include_empty=True):
            if not bool(acc.get("proxy_manual_waiting")):
                continue
            aid = str(acc.get("account_id") or "").strip()
            if not aid:
                continue
            wait_until = int(acc.get("proxy_manual_wait_until_ts") or 0)
            wait_set = int(acc.get("proxy_manual_wait_set_ts") or acc.get("updated_at_ts") or 0)
            key = (wait_set, wait_until, aid, acc)
            if best is None or key[0] > best[0]:
                best = key
        if best is None:
            return None, None, False
        _, wait_until, aid, acc = best
        return aid, dict(acc), (wait_until > 0 and now_ts > wait_until)

    def _parse_manual_proxy_input(self, raw: str) -> tuple[str, dict]:
        val = str(raw or "").strip()
        if not val:
            raise RuntimeError("Пустой ввод. Введите SOCKS5 или HTTP прокси.")

        host = ""
        port = 0
        login = ""
        password = ""
        scheme = "socks5"
        low = val.lower()

        if low.startswith(("socks5://", "socks5h://", "http://")):
            parsed = urlparse(val)
            scheme = str(parsed.scheme or "").lower()
            if scheme not in {"socks5", "socks5h", "http"}:
                raise RuntimeError("Поддерживаются SOCKS5, SOCKS5H и HTTP прокси.")
            host = str(parsed.hostname or "").strip()
            with suppress(Exception):
                port = int(parsed.port or 0)
            login = str(parsed.username or "").strip()
            password = str(parsed.password or "").strip()
        else:
            if "://" in val:
                raise RuntimeError("Поддерживаются SOCKS5, SOCKS5H и HTTP прокси.")
            parts = val.split(":", 3)
            if len(parts) != 4:
                raise RuntimeError("Неверный формат прокси.")
            host = str(parts[0] or "").strip()
            with suppress(Exception):
                port = int(str(parts[1] or "").strip())
            login = str(parts[2] or "").strip()
            password = str(parts[3] or "").strip()

        if not host or port <= 0 or port > 65535:
            raise RuntimeError("Укажите корректные host и port.")
        if not login or not password:
            raise RuntimeError("Для этого прокси нужны login и password.")

        proxy = f"{scheme}://{quote(login, safe='')}:{quote(password, safe='')}@{host}:{int(port)}"
        return proxy, {
            "host": host,
            "port": int(port),
            "login": login,
            "password": password,
            "scheme": scheme,
        }

    async def _probe_url_via_proxy(self, target: str, proxy_url: str, *, parse_ip: bool = False) -> dict:
        t0 = time.perf_counter()
        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(12.0),
                proxy=proxy_url,
                follow_redirects=True,
                trust_env=False,
                headers={"User-Agent": "Mozilla/5.0 (compatible; ZOOMA-ProxyCheck/1.0)"},
            ) as client:
                resp = await client.get(str(target or "").strip())
            if int(resp.status_code) >= 500:
                raise RuntimeError(f"HTTP {resp.status_code}")
            ms = (time.perf_counter() - t0) * 1000.0
            ip = None
            if parse_ip:
                with suppress(Exception):
                    body = resp.json()
                    if isinstance(body, dict):
                        ip = str(body.get("ip") or "").strip() or None
            return {
                "ok": True,
                "status": int(resp.status_code),
                "ms": float(ms),
                "reason": "",
                "ip": ip,
            }
        except Exception as e:
            return {
                "ok": False,
                "status": 0,
                "ms": None,
                "reason": self._short_ping_error(e),
                "ip": None,
            }

    async def resume_proxy_auto_frozen_if_proxy_ok(
        self,
        chat_id: int,
        account_id: Optional[str],
        proxy_url: str,
        *,
        source: str = "proxy_update",
    ) -> bool:
        aid = self._normalize_proxy_choice_account_id(account_id)
        return await self.recover_proxy_account_now(int(chat_id), aid, source=source)
        acc = get_user_account(int(chat_id), aid) or {}
        if not bool(acc.get("subscription_paused")):
            return False
        if str(acc.get("subscription_freeze_reason") or "") != "proxy_unavailable":
            return False

        active_domain = (get_active_domain() or "").strip()
        if not active_domain:
            return False

        domain_check = await self._probe_url_via_proxy(active_domain, proxy_url, parse_ip=False)
        if not domain_check.get("ok"):
            patch_user_account(int(chat_id), aid, proxy_ping_error=str(domain_check.get("reason") or "proxy_check_failed"))
            return False

        ipify_check = await self._probe_url_via_proxy("https://api.ipify.org?format=json", proxy_url, parse_ip=True)
        if not ipify_check.get("ok"):
            patch_user_account(int(chat_id), aid, proxy_ping_error=str(ipify_check.get("reason") or "proxy_ip_check_failed"))
            return False

        avg_values = [x for x in [domain_check.get("ms"), ipify_check.get("ms")] if isinstance(x, (int, float))]
        avg_ms = round(sum(avg_values) / len(avg_values), 1) if avg_values else None
        patch_user_account(
            int(chat_id),
            aid,
            proxy_ping_ms=avg_ms,
            proxy_ping_last_ts=int(time.time()),
            proxy_ping_error="",
        )

        info = resume_account_subscription(int(chat_id), aid, int(time.time()))
        left_days = max(0, int(info.get("left_sec") or 0)) // 86400

        if self.app:
            with suppress(Exception):
                await self.app.bot.send_message(
                    chat_id=int(chat_id),
                    text=f"✅ Новый прокси проверен. Подписка разморожена, остаток дней: {left_days}.",
                )
            with suppress(Exception):
                u = get_user(int(chat_id))
                await self.app.bot.send_message(
                    chat_id=ADMIN_CHAT_ID,
                    text=(
                        "✅ Аккаунт автоматически разморожен после обновления прокси\n"
                        f"chat_id: {int(chat_id)}\n"
                        f"юзернейм: {u.tg_username or '-'}\n"
                        f"account_id: {aid}\n"
                        f"source: {source}\n"
                        f"ping: {avg_ms if avg_ms is not None else '-'} мс"
                    ),
                )

        await self._push_mini_app_state(int(chat_id))
        self.request_tg_subscription_folder_sync("proxy_auto_unfreeze", immediate=True)

        if active_domain and has_active_account_subscription(int(chat_id), aid, int(time.time())):
            fresh = get_user_account(int(chat_id), aid) or {}
            if str(fresh.get("zooma_top_session") or "").strip():
                with suppress(Exception):
                    await self.ws_manager.start_for_user(int(chat_id), active_domain, account_id=aid)

        logger.info(
            "proxy auto-unfreeze ok | chat_id=%s account_id=%s source=%s left_sec=%s ping_ms=%s",
            chat_id,
            aid,
            source,
            info.get("left_sec"),
            avg_ms,
        )
        return True


    async def consume_manual_proxy_input(self, chat_id: int, raw_text: str) -> tuple[bool, str]:
        aid, acc, expired = self._get_manual_proxy_wait_target(chat_id)
        if not aid or not acc:
            return False, ""

        if expired:
            self._clear_manual_proxy_wait_states(chat_id)
            return True, (
                "Время ввода прокси истекло. Выберите способ снова.\n\n"
                + self._manual_proxy_help_text()
            )

        try:
            normalized_proxy, parsed = self._parse_manual_proxy_input(raw_text)
        except Exception as e:
            return True, f"❌ {e}\n\n{self._manual_proxy_help_text()}"

        active_domain = (get_active_domain() or "").strip()
        if not active_domain:
            return True, "Не удалось проверить прокси: активный домен казино не определен."

        domain_check = await self._probe_url_via_proxy(active_domain, normalized_proxy, parse_ip=False)
        if not domain_check.get("ok"):
            return True, (
                "❌ Прокси не прошел проверку до сайта казино.\n"
                f"Причина: {domain_check.get('reason') or 'unknown_error'}"
            )

        ipify_check = await self._probe_url_via_proxy("https://api.ipify.org?format=json", normalized_proxy, parse_ip=True)
        if not ipify_check.get("ok"):
            return True, (
                "❌ Прокси не прошел проверку внешнего IP (ipify).\n"
                f"Причина: {ipify_check.get('reason') or 'unknown_error'}"
            )

        proxy_ip = str(ipify_check.get("ip") or "").strip()
        if not proxy_ip:
            return True, "❌ Не удалось определить IP через прокси (ipify)."

        avg_ms_values = [x for x in [domain_check.get("ms"), ipify_check.get("ms")] if isinstance(x, (int, float))]
        avg_ms = int(round(sum(avg_ms_values) / len(avg_ms_values))) if avg_ms_values else 0

        proxy_scheme = str(parsed.get("scheme") or "socks5").lower()
        set_account_proxy(
            chat_id=chat_id,
            account_id=aid,
            proxy_url=normalized_proxy,
            order_id="manual",
            ip=proxy_ip,
            port_http=(int(parsed["port"]) if proxy_scheme == "http" else None),
            port_socks5=(int(parsed["port"]) if proxy_scheme in {"socks5", "socks5h"} else None),
            login=str(parsed["login"]),
            password=str(parsed["password"]),
            scheme=proxy_scheme,
        )
        self._clear_manual_proxy_wait_states(chat_id)
        await self.recover_proxy_account_now(chat_id, aid, source="manual_proxy_update")
        return True, (
            f"✅ Ручной {proxy_scheme.upper()} прокси сохранен.\n"
            f"IP: {self._mask_ip_tail(proxy_ip)}\n"
            f"Задержка: {avg_ms} мс\n"
            "Можно продолжать авторизацию."
        )

    def clear_manual_proxy_for_account(self, chat_id: int, account_id: Optional[str]) -> tuple[bool, str]:
        aid = self._normalize_proxy_choice_account_id(account_id)
        acc = get_user_account(chat_id, aid) or {}
        if not acc:
            return False, "Аккаунт не найден."
        set_account_proxy(
            chat_id=chat_id,
            account_id=aid,
            proxy_url=None,
            order_id=None,
            ip=None,
            port_http=None,
            port_socks5=None,
            login=None,
            password=None,
            scheme=None,
        )
        self._clear_manual_proxy_wait_states(chat_id)
        return True, "Ручной прокси очищен. Продолжаю покупку/продление через бота..."

    async def handle_proxy_choice_callback(
        self,
        *,
        chat_id: int,
        action: str,
        choice_id: str,
        account_id: Optional[str],
        period_days: int,
        renew_hint: bool,
        order_id: Optional[str],
    ) -> tuple[bool, str, Optional[InlineKeyboardMarkup]]:
        action = str(action or "").strip().lower()
        if action not in {"buy", "manual"}:
            return False, "Неизвестное действие", None

        aid = self._normalize_proxy_choice_account_id(account_id)
        ord_id = str(order_id or "").strip()
        scope_key = f"{int(chat_id)}:{aid}:{ord_id or '-'}"

        now_ts = int(time.time())
        if ord_id and ord_id != "-":
            pending = get_pending_order(ord_id)
            if not isinstance(pending, dict):
                if not has_active_account_subscription(chat_id, aid, now_ts):
                    return False, "Счет не найден или уже очищен", None
                logger.info(
                    "proxy choice pending missing, fallback by active subscription | chat_id=%s account_id=%s order_id=%s",
                    chat_id,
                    aid,
                    ord_id,
                )
            else:
                if int(pending.get("chat_id") or 0) != int(chat_id):
                    return False, "Счет принадлежит другому пользователю", None
                created_ts = int(pending.get("created_at_ts") or 0)
                if created_ts and (int(time.time()) - created_ts) > int(self._proxy_choice_ttl_sec):
                    return False, "Время выбора прокси истекло", None

        if action == "manual":
            decision_key = f"{chat_id}:{choice_id}:{action}"
            if decision_key in self._proxy_choice_seen:
                text, kb = self.get_manual_proxy_wait_prompt(
                    chat_id=chat_id,
                    choice_id=choice_id,
                    account_id=aid,
                    period_days=period_days,
                    renew_hint=renew_hint,
                    order_id=ord_id or "-",
                )
                return True, text, kb
            self._proxy_choice_seen.add(decision_key)
            self._set_manual_proxy_wait_state(
                chat_id=chat_id,
                account_id=aid,
                choice_id=choice_id,
                order_id=(ord_id or "-"),
                period_days=max(1, int(period_days or 30)),
                renew_hint=bool(renew_hint),
            )
            text, kb = self.get_manual_proxy_wait_prompt(
                chat_id=chat_id,
                choice_id=choice_id,
                account_id=aid,
                period_days=period_days,
                renew_hint=renew_hint,
                order_id=ord_id or "-",
            )
            return True, text, kb

        acc = get_user_account(chat_id, aid) or {}
        proxy_url_current = str(acc.get("proxy_url") or "").strip()
        proxy_order_id_current = str(acc.get("proxy_order_id") or "").strip()
        if proxy_url_current and not self._is_proxyline_order_id(proxy_order_id_current):
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("Очистить свой прокси", callback_data=f"proxy_choice_clear_manual:{choice_id}:{aid}:{max(1, int(period_days or 30))}:{1 if bool(renew_hint) else 0}:{ord_id or '-'}")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="back")],
            ])
            return (
                False,
                "У аккаунта уже задан ручной прокси.\n"
                "Чтобы купить/продлить прокси через бота, сначала очистите ручной прокси.",
                kb,
            )

        in_flight_at = int(self._proxy_choice_inflight.get(scope_key) or 0)
        if in_flight_at and (now_ts - in_flight_at) < 300:
            return True, "Покупка/продление прокси уже выполняется, подожди немного.", None
        last_ok_ts = int(self._proxy_choice_success_ts.get(scope_key) or 0)
        if last_ok_ts and (now_ts - last_ok_ts) < int(self._proxy_choice_success_cooldown_sec):
            return True, "Прокси уже куплен/продлен по этому счету.", None
        self._proxy_choice_inflight[scope_key] = now_ts

        op_id = self._new_proxy_op_id()
        logger.info(
            "proxy choice start | op_id=%s chat_id=%s action=%s account_id=%s period_days=%s renew_hint=%s order_id=%s",
            op_id, chat_id, action, aid, period_days, int(bool(renew_hint)), ord_id or "-"
        )
        # renew_hint is only a hint that user had active remainder;
        # real renew is possible only when we have a managed Proxyline order id.
        is_extension = self._is_proxyline_order_id(acc.get("proxy_order_id"))
        try:
            ok = await self._purchase_proxy_flow(
                chat_id=chat_id,
                period_days=max(1, int(period_days or 30)),
                is_extension=is_extension,
                account_id=aid,
                proxy_op_id=op_id,
            )
            if ok:
                self._proxy_choice_success_ts[scope_key] = int(time.time())
                return True, "Запускаю покупку/продление прокси.", None
            return False, "Не удалось купить/продлить прокси. Попробуй еще раз.", None
        finally:
            self._proxy_choice_inflight.pop(scope_key, None)

    def _proxyline_tags_for_account(self, chat_id: int, account_id: Optional[str] = None, account: Optional[dict] = None) -> list[str]:
        tags = [str(int(chat_id))]
        slot = 1
        if account_id:
            acc = account or get_user_account(int(chat_id), account_id) or {}
            with suppress(Exception):
                slot = int(acc.get("slot") or 0) or slot
            if not slot:
                with suppress(Exception):
                    if str(account_id).startswith("acc_"):
                        slot = int(str(account_id).split("_", 1)[1])
        tags.append(str(slot or 1))
        # Do not put port_user_id/casino id here: it is absent before auth and user asked not to tag it.
        return tags[:5]

    def _is_proxyline_order_id(self, value: object) -> bool:
        oid = str(value or "").strip()
        return bool(oid and oid.lower() != "manual")

    def _resolve_proxy_account_binding(
        self,
        chat_id: int,
        account_id: Optional[str] = None,
        account: Optional[dict] = None,
    ) -> tuple[Optional[str], Optional[dict]]:
        aid = str(account_id or "").strip()
        acc = dict(account) if isinstance(account, dict) else None

        if aid and acc is None:
            raw = get_user_account(int(chat_id), aid)
            if raw:
                acc = dict(raw)

        if acc and not aid:
            aid = str(acc.get("account_id") or "").strip()

        if not aid:
            user = get_user(int(chat_id))
            accounts = get_user_accounts(int(chat_id), include_empty=True)
            if accounts:
                aid = str(getattr(user, "active_account_id", "") or accounts[0].get("account_id") or "acc_1").strip() or "acc_1"
                if acc is None:
                    for item in accounts:
                        if str(item.get("account_id") or "") == aid:
                            acc = dict(item)
                            break
                    if acc is None:
                        acc = dict(accounts[0])
                        aid = str(acc.get("account_id") or aid or "acc_1").strip() or "acc_1"

        return (aid or None), acc

    def _proxy_payload_from_result(
        self,
        result,
        *,
        account: Optional[dict] = None,
        user=None,
    ) -> dict:
        src = account or {}
        return {
            "proxy_url": str(result.proxy_url or src.get("proxy_url") or getattr(user, "user_proxy_url", "") or "").strip() or None,
            "country": str(result.country or src.get("proxy_country") or getattr(user, "user_proxy_country", "") or "").strip() or None,
            "city": str(result.city or src.get("proxy_city") or getattr(user, "user_proxy_city", "") or "").strip() or None,
            "order_id": str(result.order_id or src.get("proxy_order_id") or getattr(user, "user_proxy_order_id", "") or "").strip() or None,
            "ip": str(result.ip or src.get("proxy_ip") or getattr(user, "user_proxy_ip", "") or "").strip() or None,
            "port_http": result.port_http if result.port_http is not None else (src.get("proxy_port_http") if account else getattr(user, "user_proxy_port_http", None)),
            "port_socks5": result.port_socks5 if result.port_socks5 is not None else (src.get("proxy_port_socks5") if account else getattr(user, "user_proxy_port_socks5", None)),
            "login": str(result.login or src.get("proxy_login") or getattr(user, "user_proxy_login", "") or "").strip() or None,
            "password": str(result.password or src.get("proxy_password") or getattr(user, "user_proxy_password", "") or "").strip() or None,
            "scheme": str(result.scheme or src.get("proxy_scheme") or getattr(user, "user_proxy_scheme", "") or "socks5").strip() or "socks5",
        }

    async def ensure_proxy_for_subscription(
        self,
        chat_id: int,
        *,
        period_days: int,
        account_id: Optional[str] = None,
    ) -> None:
        user = get_user(int(chat_id))
        account_id, account = self._resolve_proxy_account_binding(int(chat_id), account_id)

        if account_id and not account:
            logger.warning("proxy grant flow skipped: account not found | chat_id=%s account_id=%s", chat_id, account_id)
            return

        if account_id:
            proxy_url = str((account or {}).get("proxy_url") or "").strip()
            proxy_order_id = str((account or {}).get("proxy_order_id") or "").strip()
        else:
            proxy_url = str(user.user_proxy_url or "").strip()
            proxy_order_id = str(user.user_proxy_order_id or "").strip()

        if proxy_url and not self._is_proxyline_order_id(proxy_order_id):
            logger.info(
                "proxy grant flow skipped unmanaged/manual proxy | chat_id=%s account_id=%s proxy_order_id=%s",
                chat_id,
                account_id or "-",
                proxy_order_id or "-",
            )
            return

        is_extension = self._is_proxyline_order_id(proxy_order_id)
        await self._purchase_proxy_flow(
            int(chat_id),
            period_days=max(1, int(period_days or 30)),
            is_extension=is_extension,
            account_id=account_id,
        )

    async def _purchase_proxy_flow(self, chat_id: int, period_days: int, is_extension: bool, account_id: Optional[str] = None, proxy_op_id: Optional[str] = None) -> bool:
        if not self.app:
            return False
        op_id = str(proxy_op_id or self._new_proxy_op_id())
        user = get_user(chat_id)
        account_id, account = self._resolve_proxy_account_binding(chat_id, account_id)
        action_ru = "продлением" if is_extension else "покупкой"

        account_slot = int((account or {}).get("slot") or 0)
        account_name = str((account or {}).get("port_user_name") or "").strip()
        account_port_id = str((account or {}).get("port_user_id") or "").strip()

        account_prefix = ""
        if account_id:
            acc_title = f"аккаунт #{account_slot}" if account_slot else f"аккаунт {account_id}"
            acc_extra = ""
            if account_name or account_port_id:
                acc_extra = f" ({account_name or '-'} | {account_port_id or '-'})"
            account_prefix = f"{acc_title}{acc_extra}\n"

        proxy_order_id = str((account or {}).get("proxy_order_id") if account else user.user_proxy_order_id or "").strip()
        proxy_url = str((account or {}).get("proxy_url") if account else user.user_proxy_url or "").strip()
        if is_extension and proxy_url and not self._is_proxyline_order_id(proxy_order_id):
            logger.info(
                "proxy flow skip unmanaged/manual proxy | chat_id=%s account_id=%s proxy_order_id=%s",
                chat_id,
                account_id or "-",
                proxy_order_id or "-",
            )
            return True

        status_msg = await self.app.bot.send_message(
            chat_id=chat_id,
            text=account_prefix + ("продлеваем прокси, это займет меньше 1 минуты" if is_extension else "покупаем прокси, это займет меньше 1 минуты"),
        )
        try:
            result = None
            if is_extension:
                # Try to keep same proxy for active subscription extension.
                proxy_id = await self.proxyline.resolve_proxy_id(
                    order_id=(account.get("proxy_order_id") if account else user.user_proxy_order_id),
                    proxy_url=(account.get("proxy_url") if account else user.user_proxy_url),
                    ip=(account.get("proxy_ip") if account else user.user_proxy_ip),
                    port_socks5=(account.get("proxy_port_socks5") if account else user.user_proxy_port_socks5),
                    login=(account.get("proxy_login") if account else user.user_proxy_login),
                    proxy_op_id=op_id,
                )
                if proxy_id is None:
                    raise RuntimeError("Не удалось определить id текущего прокси для продления")
                result = await self.proxyline.renew_proxy(proxy_id=int(proxy_id), period=max(1, int(period_days or 30)), proxy_op_id=op_id)
            else:
                result = await self.proxyline.buy_user_proxy(chat_id, period=max(1, int(period_days or 30)), tags=self._proxyline_tags_for_account(chat_id, account_id, account), proxy_op_id=op_id)
            logger.info(
                "proxy flow result | op_id=%s chat_id=%s account_id=%s mode=%s ok=%s order_id=%s country=%s reason=%s",
                op_id,
                chat_id,
                account_id or "-",
                ("renew" if is_extension else "buy"),
                int(bool(result.ok)),
                result.order_id or "-",
                result.country or "-",
                result.reason,
            )
            if not result or not result.ok or not result.proxy_url:
                raise RuntimeError((result.reason if result else "") or "неизвестная ошибка операции с прокси")
            with suppress(Exception):
                await self.proxyline.ensure_tags_for_order(
                    order_id=result.order_id,
                    tags=self._proxyline_tags_for_account(chat_id, account_id, account),
                    proxy_op_id=op_id,
                )

            proxy_payload = self._proxy_payload_from_result(result, account=account, user=user)
            if account_id:
                set_account_proxy(
                    chat_id=chat_id,
                    account_id=account_id,
                    proxy_url=proxy_payload["proxy_url"],
                    country=proxy_payload["country"],
                    city=proxy_payload["city"],
                    order_id=proxy_payload["order_id"],
                    ip=proxy_payload["ip"],
                    port_http=proxy_payload["port_http"],
                    port_socks5=proxy_payload["port_socks5"],
                    login=proxy_payload["login"],
                    password=proxy_payload["password"],
                    scheme=proxy_payload["scheme"],
                )
                logger.info(
                    "proxy flow bind ok | op_id=%s chat_id=%s account_id=%s mode=%s order_id=%s ip=%s",
                    op_id,
                    chat_id,
                    account_id,
                    ("renew" if is_extension else "buy"),
                    proxy_payload["order_id"] or "-",
                    proxy_payload["ip"] or "-",
                )
            else:
                set_user_proxy(
                    chat_id=chat_id,
                    proxy_url=proxy_payload["proxy_url"],
                    country=proxy_payload["country"],
                    city=proxy_payload["city"],
                    order_id=proxy_payload["order_id"],
                    ip=proxy_payload["ip"],
                    port_http=proxy_payload["port_http"],
                    port_socks5=proxy_payload["port_socks5"],
                    login=proxy_payload["login"],
                    password=proxy_payload["password"],
                    scheme=proxy_payload["scheme"],
                )
                logger.info(
                    "proxy flow legacy bind ok | op_id=%s chat_id=%s mode=%s order_id=%s ip=%s",
                    op_id,
                    chat_id,
                    ("renew" if is_extension else "buy"),
                    proxy_payload["order_id"] or "-",
                    proxy_payload["ip"] or "-",
                )
            if account_id:
                await self.resume_proxy_auto_frozen_if_proxy_ok(
                    chat_id,
                    account_id,
                    str(proxy_payload["proxy_url"] or ""),
                    source=("proxyline_renew" if is_extension else "proxyline_buy"),
                )

            if result.price_rub is not None:
                with suppress(Exception):
                    spent_rub = await self._to_rub_amount(float(result.price_rub), "")
                    record_proxy_spent_metric(spent_rub, int(time.time()))
            ip_text = result.masked_ip or proxy_payload["ip"] or "не определен"
            city_text = proxy_payload["city"] or "не определен"
            await self.app.bot.edit_message_text(
                chat_id=chat_id,
                message_id=status_msg.message_id,
                text=(f"прокси продлен\nваш айпи {ip_text}\nГород {city_text}" if is_extension else f"прокси куплен\nваш айпи {ip_text}\nГород {city_text}"),
            )
            await self.get_proxy_balance_cached(force=True)
            return True
        except Exception as e:
            logger.error("proxy flow failed | op_id=%s chat_id=%s account_id=%s mode=%s err=%s", op_id, chat_id, account_id or "-", ("renew" if is_extension else "buy"), e)
            await self.app.bot.edit_message_text(
                chat_id=chat_id,
                message_id=status_msg.message_id,
                text=(
                    f"возникла проблема с {action_ru} прокси\n"
                    "админ оповещен\n"
                    "так же можете написать в тех поддержку @saxarok322"
                ),
            )
            await self._notify_admin_proxy_error(
                chat_id=chat_id,
                username=user.tg_username,
                reason=str(e),
                is_renew=is_extension,
                account_id=account_id,
                account=account,
            )
            return False

    async def _notify_admin_proxy_error(
        self,
        chat_id: int,
        username: Optional[str],
        reason: str,
        is_renew: bool = False,
        account_id: Optional[str] = None,
        account: Optional[dict] = None,
    ) -> None:
        if not self.app:
            return
        username_text = username or "без username"
        reason_text = self._humanize_proxy_error(reason)
        what = "продлении" if is_renew else "покупке"

        account_line = ""
        if account_id:
            acc = account or get_user_account(chat_id, account_id) or {}
            slot = int(acc.get("slot") or 0)
            name = str(acc.get("port_user_name") or "").strip()
            casino_id = str(acc.get("port_user_id") or "").strip()
            billing_type = str(acc.get("billing_type") or "").strip()

            title = f"#{slot}" if slot else str(account_id)
            details = ""
            if name or casino_id:
                details = f" · {name or '-'} | {casino_id or '-'}"
            if billing_type:
                details += f" · {billing_type}"

            account_line = f"аккаунт: {title}{details}\naccount_id: {account_id}\n"

        text = (
            f"🚨 возникла проблема при {what} прокси\n\n"
            f"чат ид: {chat_id}\n"
            f"юзернейм: {username_text}\n"
            f"{account_line}"
            f"причина: {reason_text}"
        )
        try:
            await self.app.bot.send_message(chat_id=ADMIN_CHAT_ID, text=text)
        except Exception:
            pass

    def _humanize_proxy_error(self, reason: str) -> str:
        r = (reason or "").strip()
        rl = r.lower()
        if "not enough free ip on the server" in rl:
            return "в выбранной стране сейчас нет свободных IP для этого типа прокси"
        if "api token" in rl or "proxyline_api_token" in rl:
            return "не настроен токен Proxyline API"
        if "403" in rl or "forbidden" in rl:
            return "доступ к Proxyline API запрещен (проверь токен/доступ)"
        if "402" in rl or "balance" in rl:
            return "недостаточно средств на балансе Proxyline"
        if "timeout" in rl:
            return "таймаут при обращении к Proxyline/гео-сервису"
        return r[:500] if r else "неизвестная ошибка"

    async def _run_loop(self) -> None:
        while True:
            try:
                await self._expire_subscriptions()
                await self._process_pending_invoices()
                await self.get_proxy_balance_cached(force=False)
                await self._run_proxy_health_checks()
                await self._periodic_tg_folder_sync()
                await asyncio.sleep(BILLING_CHECK_INTERVAL_SEC)
            except asyncio.CancelledError:
                return
            except Exception:
                await asyncio.sleep(5)

    def _proxy_health_samples(self) -> int:
        return max(1, int(os.getenv("PROXY_HEALTH_SAMPLES", "5").strip()))

    def _proxy_health_timeout(self) -> float:
        return max(1.0, float(os.getenv("PROXY_HEALTH_SAMPLE_TIMEOUT_SEC", "6").strip()))

    def _proxy_health_delay(self) -> float:
        return max(0.0, float(os.getenv("PROXY_HEALTH_SAMPLE_DELAY_SEC", "0.15").strip()))

    def _proxy_health_reserve_url(self) -> str:
        return os.getenv("PROXY_HEALTH_RESERVE_URL", "https://api.ipify.org?format=json").strip()

    def _proxy_health_status(self, ok_count: int, samples: int) -> str:
        # For 5 samples: 4-5 ok => ok, 2-3 ok => unstable, 0-1 ok => fail.
        if ok_count >= max(1, samples - 1):
            return "ok"
        if ok_count >= max(1, samples // 2):
            return "unstable"
        return "fail"

    def _account_in_extension_mode(self, chat_id: int, account_id: str) -> bool:
        try:
            acc = get_user_account(int(chat_id), str(account_id)) or {}
            return str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension"
        except Exception:
            return False

    def _short_ping_error(self, err: Exception | str) -> str:
        raw = str(err or "").strip()
        low = raw.lower()
        if not raw:
            return "unknown_error"
        if "407" in low or "proxy authentication" in low:
            return "proxy_auth_failed"
        if "403" in low or "forbidden" in low:
            return "http_403_forbidden"
        if "timeout" in low or "timed out" in low:
            return "timeout"
        if "name resolution" in low or "name or service" in low or "temporary failure" in low:
            return "dns_error"
        if "ssl" in low or "certificate" in low:
            return "ssl_error"
        if "connection" in low or "connecterror" in low or "connection refused" in low:
            return "connect_error"
        if raw.startswith("HTTP "):
            return raw
        return raw[:120]

    def _format_ping_check(self, label: str, check: Optional[dict]) -> str:
        if not check:
            return f"{label}: not_checked"
        samples = int(check.get("samples") or self._proxy_health_samples())
        avg = f", avg={float(check['avg_ms']):.1f} ms" if check.get("avg_ms") is not None else ""
        reason = f", reason={check.get('reason')}" if check.get("reason") else ""
        return f"{label}: {check.get('status')}, ok={check.get('ok_count')}/{samples}{avg}{reason}"

    def _proxy_health_user_label(self, chat_id: int, username: str = "") -> str:
        uname = (username or "").strip().lstrip("@")
        if not uname:
            with suppress(Exception):
                uname = str(get_user(chat_id).tg_username or "").strip().lstrip("@")
        return f"@{uname}" if uname else f"chat_id={chat_id}"

    async def _measure_route_ping(self, target: str, proxy_url: Optional[str] = None) -> dict:
        target = (target or "").strip()
        samples = self._proxy_health_samples()
        if not target:
            return {
                "target": "-",
                "status": "fail",
                "avg_ms": None,
                "ok_count": 0,
                "fail_count": samples,
                "samples": samples,
                "reason": "empty_target",
            }

        ok_values: list[float] = []
        errors: list[str] = []
        headers = {"User-Agent": "Mozilla/5.0 (compatible; ZOOMA-HealthCheck/1.0)"}

        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(self._proxy_health_timeout()),
                proxy=proxy_url,
                follow_redirects=True,
                trust_env=False,
                headers=headers,
            ) as client:
                for idx in range(samples):
                    t0 = time.perf_counter()
                    try:
                        resp = await client.get(target)
                        if int(resp.status_code) >= 500:
                            raise RuntimeError(f"HTTP {resp.status_code}")
                        ok_values.append((time.perf_counter() - t0) * 1000.0)
                    except Exception as e:
                        errors.append(self._short_ping_error(e))
                    if idx + 1 < samples and self._proxy_health_delay() > 0:
                        await asyncio.sleep(self._proxy_health_delay())
        except Exception as e:
            errors.append(self._short_ping_error(e))

        ok_count = len(ok_values)
        fail_count = max(0, samples - ok_count)
        status = self._proxy_health_status(ok_count, samples)
        return {
            "target": target,
            "status": status,
            "avg_ms": (sum(ok_values) / len(ok_values)) if ok_values else None,
            "ok_count": ok_count,
            "fail_count": fail_count,
            "samples": samples,
            "reason": "" if status == "ok" else (errors[-1] if errors else "failed_samples"),
        }

    async def _measure_user_health(
        self,
        active_domain: str,
        chat_id: int,
        account_id: str,
        username: str,
        proxy_url: str,
        was_proxy_frozen: bool = False,
    ) -> tuple[int, str, str, dict, Optional[dict], bool]:
        casino = await self._measure_route_ping(active_domain, proxy_url=proxy_url)
        reserve = None
        if casino.get("status") != "ok" and self._proxy_health_reserve_url():
            reserve = await self._measure_route_ping(self._proxy_health_reserve_url(), proxy_url=proxy_url)
        return chat_id, account_id, username, casino, reserve, bool(was_proxy_frozen)

    def _build_proxy_ping_error(self, casino: dict, reserve: Optional[dict]) -> str:
        samples = int(casino.get("samples") or self._proxy_health_samples())
        base = (
            f"casino {casino.get('status')}: {casino.get('reason') or 'unknown_error'} "
            f"({casino.get('ok_count')}/{samples} ok)"
        )
        if not reserve:
            return base
        reserve_samples = int(reserve.get("samples") or self._proxy_health_samples())
        if reserve.get("status") == "ok":
            return f"{base}; reserve OK {float(reserve.get('avg_ms') or 0.0):.1f} ms"
        return (
            f"{base}; reserve {reserve.get('status')}: {reserve.get('reason') or 'unknown_error'} "
            f"({reserve.get('ok_count')}/{reserve_samples} ok)"
        )

    def _should_send_proxy_health_user_alert(self, chat_id: int) -> bool:
        now_ts = int(time.time())
        fail_window = max(180, int(PROXY_HEALTH_CHECK_INTERVAL_SEC) + 60)
        last_ts, streak = self._proxy_health_fail_state.get(chat_id, (0, 0))
        if last_ts and (now_ts - last_ts) <= fail_window:
            streak += 1
        else:
            streak = 1
        self._proxy_health_fail_state[chat_id] = (now_ts, streak)

        if streak < 2:
            return False

        last_alert = int(self._proxy_health_alert_ts.get(chat_id) or 0)
        if (now_ts - last_alert) < int(PROXY_HEALTH_ALERT_COOLDOWN_SEC):
            return False

        self._proxy_health_alert_ts[chat_id] = now_ts
        return True

    async def _send_proxy_health_admin_message(self, text: str) -> None:
        if not self.app:
            return
        with suppress(Exception):
            await self.app.bot.send_message(chat_id=ADMIN_CHAT_ID, text=text)

    async def _send_proxy_health_global_alert(self, key: str, text: str) -> None:
        now_ts = int(time.time())
        last = int(self._proxy_health_global_alert_ts.get(key) or 0)
        if (now_ts - last) < int(PROXY_HEALTH_ALERT_COOLDOWN_SEC):
            return
        self._proxy_health_global_alert_ts[key] = now_ts
        await self._send_proxy_health_admin_message(text)

    def _proxy_health_is_hard_proxy_down(self, casino: dict, reserve: Optional[dict]) -> bool:
        if not reserve:
            return False
        if casino.get("status") == "ok" or reserve.get("status") == "ok":
            return False
        hard_reasons = {"connect_error", "proxy_auth_failed", "dns_error"}
        return str(casino.get("reason") or "") in hard_reasons and str(reserve.get("reason") or "") in hard_reasons

    def _account_title_for_notice(self, acc: dict, account_id: str) -> str:
        slot = int((acc or {}).get("slot") or 0)
        name = str((acc or {}).get("port_user_name") or "").strip()
        casino_id = str((acc or {}).get("port_user_id") or "").strip()
        title = f"аккаунт #{slot}" if slot else f"аккаунт {account_id}"
        if name or casino_id:
            title += f" ({name or '-'} | {casino_id or '-'})"
        return title

    async def auto_freeze_proxy_unavailable(
        self,
        chat_id: int,
        account_id: str,
        reason: str,
        *,
        source: str = "proxy_health",
    ) -> bool:
        # Compatibility name: callers may still use the historical method, but
        # proxy failures now pause only the technical runtime, never subscription time.
        aid = self._normalize_proxy_choice_account_id(account_id)
        return await self._mark_proxy_runtime_problem(
            int(chat_id),
            aid,
            "unavailable",
            str(reason or "proxy_unavailable"),
            source=source,
            active_domain=(get_active_domain() or "").strip().rstrip("/"),
        )


    async def _resume_proxy_auto_frozen_from_health(
        self,
        chat_id: int,
        account_id: str,
        casino: dict,
        *,
        source: str = "proxy_health_recovery",
    ) -> bool:
        aid = self._normalize_proxy_choice_account_id(account_id)
        acc = get_user_account(int(chat_id), aid) or {}
        if not acc:
            return False
        if not bool(acc.get("subscription_paused")):
            return False
        if str(acc.get("subscription_freeze_reason") or "") != "proxy_unavailable":
            # Ручную заморозку не размораживаем никогда.
            return False
        if casino.get("status") != "ok":
            return False

        info = resume_account_subscription(int(chat_id), aid, int(time.time()))
        user = get_user(int(chat_id))

        avg_ms = casino.get("avg_ms")
        with suppress(Exception):
            patch_user_account(
                int(chat_id),
                aid,
                proxy_ping_last_ts=int(time.time()),
                proxy_ping_ms=avg_ms,
                proxy_ping_error="",
            )

        left_days = max(0, int(info.get("left_sec") or 0)) // 86400
        title = self._account_title_for_notice(acc, aid)

        if self.app:
            with suppress(Exception):
                await self.app.bot.send_message(
                    chat_id=int(chat_id),
                    text=(
                        "✅ Прокси снова доступен.\n\n"
                        f"Подписка {title} автоматически разморожена.\n"
                        f"Остаток дней: {left_days}."
                    ),
                )
            with suppress(Exception):
                await self.app.bot.send_message(
                    chat_id=ADMIN_CHAT_ID,
                    text=(
                        "✅ Аккаунт автоматически разморожен: прокси ожил\n\n"
                        f"chat_id: {int(chat_id)}\n"
                        f"юзернейм: {user.tg_username or '-'}\n"
                        f"account_id: {aid}\n"
                        f"аккаунт: {title}\n"
                        f"source: {source}\n"
                        f"ping: {float(avg_ms):.1f} мс" if avg_ms is not None else
                        "✅ Аккаунт автоматически разморожен: прокси ожил\n\n"
                        f"chat_id: {int(chat_id)}\n"
                        f"юзернейм: {user.tg_username or '-'}\n"
                        f"account_id: {aid}\n"
                        f"аккаунт: {title}\n"
                        f"source: {source}\n"
                        "ping: -"
                    ),
                )

        await self._push_mini_app_state(int(chat_id))
        self.request_tg_subscription_folder_sync("proxy_auto_unfreeze", immediate=True)

        active_domain = (get_active_domain() or "").strip().rstrip("/")
        fresh = get_user_account(int(chat_id), aid) or {}
        if active_domain and str(fresh.get("zooma_top_session") or "").strip():
            with suppress(Exception):
                await self.ws_manager.start_for_user(int(chat_id), active_domain, account_id=aid)

        logger.warning(
            "proxy auto-unfreeze by health | chat_id=%s username=%s account_id=%s ping_ms=%s left_sec=%s",
            int(chat_id),
            user.tg_username or "-",
            aid,
            avg_ms,
            info.get("left_sec"),
        )
        return True

    def _proxy_runtime_key(self, chat_id: int, account_id: str) -> str:
        return f"{int(chat_id)}:{str(account_id or 'acc_1')}"

    def _proxy_runtime_status(self, acc: dict) -> str:
        status = str((acc or {}).get("proxy_runtime_status") or "healthy").strip().lower()
        return status if status in {"healthy", "unavailable", "site_unreachable", "recovering"} else "healthy"

    def _proxy_regular_interval(self) -> float:
        return max(30.0, float(os.getenv("PROXY_RUNTIME_CHECK_INTERVAL_SEC", "60") or "60"))

    def _proxy_down_interval(self) -> float:
        return max(30.0, float(os.getenv("PROXY_RUNTIME_DOWN_INTERVAL_SEC", "60") or "60"))

    def _proxy_first_retry_interval(self) -> float:
        return max(5.0, float(os.getenv("PROXY_RUNTIME_FIRST_RETRY_SEC", "30") or "30"))

    def _proxy_recovery_confirm_delay(self) -> float:
        return max(1.0, float(os.getenv("PROXY_RUNTIME_RECOVERY_CONFIRM_SEC", "5") or "5"))

    def _proxy_failure_confirm_delay(self) -> float:
        return max(0.5, float(os.getenv("PROXY_RUNTIME_FAILURE_CONFIRM_SEC", "2") or "2"))

    def _proxy_probe_timeout(self) -> float:
        return max(2.0, float(os.getenv("PROXY_RUNTIME_PROBE_TIMEOUT_SEC", "6") or "6"))

    def _server_ping_interval(self) -> float:
        default_sec = max(60, int(PROXY_HEALTH_CHECK_INTERVAL_SEC or 60))
        return max(30.0, float(os.getenv("SERVER_PING_CHECK_INTERVAL_SEC", str(default_sec)) or default_sec))

    def _schedule_proxy_runtime_check(self, key: str, delay_sec: float) -> None:
        self._proxy_health_next_by_account[str(key)] = asyncio.get_running_loop().time() + max(0.0, float(delay_sec))

    async def _refresh_server_ping(self, active_domain: str) -> None:
        check = await self._measure_route_ping(active_domain, proxy_url=None)
        avg_ms = check.get("avg_ms")
        self._server_ping_ms = float(avg_ms) if avg_ms is not None else None
        if ADMIN_CHAT_ID:
            await self._push_mini_app_state(int(ADMIN_CHAT_ID))

    def _schedule_server_ping_refresh(self, active_domain: str, *, force: bool = False) -> None:
        target = str(active_domain or "").strip().rstrip("/")
        if not target:
            self._server_ping_ms = None
            return
        if self._server_ping_task and not self._server_ping_task.done():
            return
        loop = asyncio.get_running_loop()
        now_mono = loop.time()
        if not force and now_mono < float(self._server_ping_next_mono or 0.0):
            return
        self._server_ping_next_mono = now_mono + self._server_ping_interval()

        async def _runner() -> None:
            try:
                await self._refresh_server_ping(target)
            except asyncio.CancelledError:
                raise
            except Exception:
                self._server_ping_ms = None

        self._server_ping_task = asyncio.create_task(_runner(), name="server-direct-ping")

    async def _probe_proxy_target(
        self,
        target: str,
        proxy_url: str,
        *,
        reserve: bool = False,
        warm_ping: bool = False,
    ) -> dict:
        started = time.perf_counter()
        try:
            timeout = self._proxy_probe_timeout()
            target_url = str(target or "").strip()

            def _validate_status(code: int) -> None:
                # Any application-level 4xx response (401/403/404/429, etc.)
                # proves that the proxy reached the site. HTTP 407 is different:
                # it is a proxy-authentication failure and must stay unhealthy.
                if code == 407 or code >= 500:
                    raise RuntimeError(f"HTTP {code}")

            async with httpx.AsyncClient(
                timeout=httpx.Timeout(timeout, connect=min(4.0, timeout)),
                proxy=proxy_url,
                follow_redirects=True,
                trust_env=False,
                headers={"User-Agent": "Mozilla/5.0 (compatible; ZOOMA-ProxyRuntime/1.0)"},
            ) as client:
                response = await client.get(target_url)
                first_ms = (time.perf_counter() - started) * 1000.0
                status_code = int(response.status_code or 0)
                _validate_status(status_code)

                # The first request includes proxy connect, DNS and TLS setup. For the
                # displayed ping, use one extra keep-alive request so the number stays
                # comparable with the old multi-sample health check. The first request
                # remains the actual availability check.
                displayed_ms = first_ms
                if warm_ping:
                    warm_started = time.perf_counter()
                    try:
                        warm_response = await client.get(target_url)
                        _validate_status(int(warm_response.status_code or 0))
                        displayed_ms = (time.perf_counter() - warm_started) * 1000.0
                    except asyncio.CancelledError:
                        raise
                    except Exception:
                        pass

            return {
                "ok": True,
                "status_code": status_code,
                "ms": displayed_ms,
                "cold_ms": first_ms,
                "reason": "",
            }
        except asyncio.CancelledError:
            raise
        except Exception as e:
            return {
                "ok": False,
                "status_code": 0,
                "ms": None,
                "cold_ms": None,
                "reason": self._short_ping_error(e),
            }

    async def _direct_domain_health(self, active_domain: str) -> dict:
        now_mono = asyncio.get_running_loop().time()
        cached = dict(self._domain_health_cache or {})
        if (
            cached.get("domain") == active_domain
            and (now_mono - float(self._domain_health_cache_mono or 0.0)) <= 10.0
        ):
            return cached
        async with self._domain_health_lock:
            now_mono = asyncio.get_running_loop().time()
            cached = dict(self._domain_health_cache or {})
            if (
                cached.get("domain") == active_domain
                and (now_mono - float(self._domain_health_cache_mono or 0.0)) <= 10.0
            ):
                return cached
            result = await probe_domain_health(active_domain, timeout=self._proxy_probe_timeout())
            self._domain_health_cache = dict(result)
            self._domain_health_cache_mono = now_mono
            return dict(result)

    def _direct_domain_is_globally_unhealthy(self, result: dict) -> bool:
        if not bool((result or {}).get("transport_ok")):
            return True
        status_code = int((result or {}).get("status_code") or 0)
        return status_code >= 500 or str((result or {}).get("reason") or "") == "bad_gateway"

    async def _mark_proxy_runtime_problem(
        self,
        chat_id: int,
        account_id: str,
        runtime_status: str,
        reason: str,
        *,
        source: str,
        active_domain: str,
    ) -> bool:
        acc = get_user_account(int(chat_id), account_id) or {}
        startup_key = self._proxy_runtime_key(
            int(chat_id),
            account_id,
        )
        startup_silent = (
            startup_key in self._proxy_startup_quiet_keys
        )
        startup_quiet = (
            self._proxy_startup_quiet_active
            and startup_silent
        )
        startup_confirmed_problem = (
            startup_silent
            and not self._proxy_startup_quiet_active
            and runtime_status in {
                "unavailable",
                "site_unreachable",
            }
        )

        mode = str(
            acc.get("promo_activation_mode") or "server"
        ).strip().lower()

        if mode == "extension":
            return False

        if not acc or bool(acc.get("subscription_paused")):
            return False
        if not has_active_account_subscription(int(chat_id), account_id, int(time.time())):
            return False

        previous = self._proxy_runtime_status(acc)
        already_problem = previous in {"unavailable", "site_unreachable", "recovering"}
        now_ts = int(time.time())
        since_ts = int(acc.get("proxy_unavailable_since_ts") or 0) or now_ts
        patch_user_account(
            int(chat_id),
            account_id,
            connected=False,
            proxy_runtime_status=runtime_status,
            proxy_runtime_reason=str(reason or "")[:500],
            proxy_runtime_source=str(source or "proxy_health")[:120],
            proxy_runtime_domain=str(active_domain or "")[:500],
            proxy_unavailable_since_ts=since_ts,
            proxy_recovery_successes=0,
            proxy_ping_last_ts=now_ts,
            proxy_ping_error=str(reason or "")[:500],
            proxy_runtime_alerted_at_ts=(int(acc.get("proxy_runtime_alerted_at_ts") or 0) or now_ts),
        )
        with suppress(Exception):
            await self.ws_manager.stop_for_user(int(chat_id), account_id=account_id)

        if (
            already_problem or startup_quiet
        ) and not startup_confirmed_problem:
            return False

        if startup_confirmed_problem:
            self._proxy_startup_quiet_keys.discard(
                startup_key
            )

        user = get_user(int(chat_id))
        title = self._account_title_for_notice(acc, account_id)
        if runtime_status == "site_unreachable":
            user_text = (
                f"⚠️ Работа {title} временно приостановлена до восстановления подключения. "
                "Срок подписки продолжает идти.\n\n"
                f"Проблема с работой прокси: прокси не может подключиться к сайту {active_domain}, "
                "но сам прокси работает."
            )
        else:
            user_text = (
                f"⚠️ Прокси {title} временно недоступен. Работа аккаунта приостановлена "
                "до восстановления подключения. Срок подписки продолжает идти.\n\n"
                "Проблема с работой прокси."
            )
        if self.app:
            with suppress(Exception):
                await self.app.bot.send_message(chat_id=int(chat_id), text=user_text)
            with suppress(Exception):
                await self.app.bot.send_message(
                    chat_id=ADMIN_CHAT_ID,
                    text=(
                        "⚠️ Проблема с прокси, работа аккаунта временно приостановлена\n\n"
                        f"chat_id: {int(chat_id)}\n"
                        f"юзернейм: {user.tg_username or '-'}\n"
                        f"account_id: {account_id}\n"
                        f"аккаунт: {title}\n"
                        f"status: {runtime_status}\n"
                        f"domain: {active_domain or '-'}\n"
                        f"source: {source}\n"
                        f"ошибка: {reason}"
                    ),
                )
        await self._push_mini_app_state(int(chat_id))
        logger.warning(
            "proxy runtime paused | chat_id=%s account_id=%s status=%s source=%s reason=%s",
            chat_id, account_id, runtime_status, source, reason,
        )
        return True

    async def _finish_proxy_recovery(
        self,
        chat_id: int,
        account_id: str,
        active_domain: str,
        first_check: dict,
        *,
        previous_status: str,
        source: str,
    ) -> bool:
        current = get_user_account(chat_id, account_id) or {}
        startup_key = self._proxy_runtime_key(
            chat_id,
            account_id,
        )
        startup_silent = (
            startup_key in self._proxy_startup_quiet_keys
        )
        previous_source = str(
            current.get("proxy_runtime_source") or ""
        ).strip().lower()
        current_mode = str(
            current.get("promo_activation_mode") or "server"
        ).strip().lower()

        if current_mode == "extension":
            return False

        patch_user_account(
            chat_id,
            account_id,
            connected=False,
            proxy_runtime_status="recovering",
            proxy_runtime_source=source,
            proxy_runtime_domain=active_domain,
            proxy_recovery_successes=1,
        )
        await asyncio.sleep(self._proxy_recovery_confirm_delay())
        if (get_active_domain() or "").strip().rstrip("/") != active_domain:
            return False

        fresh = get_user_account(chat_id, account_id) or {}
        fresh_mode = str(
            fresh.get("promo_activation_mode") or "server"
        ).strip().lower()

        # Режим мог переключиться во время задержки подтверждения.
        if fresh_mode == "extension":
            return False

        proxy_url = str(fresh.get("proxy_url") or "").strip()
        if self._account_in_extension_mode(chat_id, account_id):
            return False
        second_check = await self._probe_proxy_target(active_domain, proxy_url)
        if self._account_in_extension_mode(chat_id, account_id):
            return False
        if not second_check.get("ok"):
            patch_user_account(
                chat_id,
                account_id,
                proxy_runtime_status=(previous_status if previous_status in {"unavailable", "site_unreachable"} else "unavailable"),
                proxy_runtime_reason=str(second_check.get("reason") or "recovery_confirmation_failed"),
                proxy_recovery_successes=0,
                connected=False,
            )
            return False

        token = str(fresh.get("zooma_top_session") or "").strip()
        if not token:
            patch_user_account(
                chat_id,
                account_id,
                proxy_runtime_status="healthy",
                proxy_runtime_reason="",
                proxy_runtime_source=source,
                proxy_unavailable_since_ts=0,
                proxy_recovery_successes=0,
                proxy_ping_error="",
                proxy_ping_last_ts=int(time.time()),
                proxy_ping_ms=second_check.get("ms"),
            )
            return True

        if self._account_in_extension_mode(chat_id, account_id):
            return False
        result = await verify_token(token=token, base_url=active_domain, chat_id=chat_id, account_id=account_id)
        if self._account_in_extension_mode(chat_id, account_id):
            return False
        if not result.ok:
            reason_text = str(result.error or "verify_failed")
            low = reason_text.lower()
            is_proxy_error = any(x in low for x in ("proxy", "connection refused", "connect call failed", "connecterror", "errno 111"))
            patch_user_account(
                chat_id,
                account_id,
                proxy_runtime_status=(previous_status if is_proxy_error and previous_status in {"unavailable", "site_unreachable"} else "healthy"),
                proxy_runtime_reason=(reason_text if is_proxy_error else ""),
                proxy_recovery_successes=0,
                proxy_ping_error=(reason_text if is_proxy_error else ""),
                connected=False,
            )
            return False

        patch_user_account(
            chat_id,
            account_id,
            connected=False,
            port_user_id=result.port_user_id or "",
            port_user_name=result.port_user_name or "",
            centrifugo_socket=result.centrifugo_socket or "",
            centrifugo_secret=result.centrifugo_secret or "",
            zooma_top_session=result.zooma_top_session or token,
            zooma_top_session_expires_at=result.zooma_top_session_expires_at,
            csrf_token=result.csrf_token,
            fingerprint_now=result.fingerprint_now,
            user_agent=result.user_agent or fresh.get("user_agent"),
        )
        if self._account_in_extension_mode(chat_id, account_id):
            return False
        ws_ok = await self.ws_manager.reconnect_for_user(
            chat_id,
            active_domain,
            account_id=account_id,
            attempts=3,
            attempt_timeout=5.0,
            stable_sec=1.2,
        )
        if not ws_ok:
            patch_user_account(
                chat_id,
                account_id,
                connected=False,
                proxy_runtime_status=(previous_status if previous_status in {"unavailable", "site_unreachable"} else "recovering"),
                proxy_runtime_reason="ws_reconnect_failed",
                proxy_recovery_successes=0,
            )
            return False

        patch_user_account(
            chat_id,
            account_id,
            connected=True,
            proxy_runtime_status="healthy",
            proxy_runtime_reason="",
            proxy_runtime_source=source,
            proxy_runtime_domain=active_domain,
            proxy_unavailable_since_ts=0,
            proxy_recovery_successes=0,
            proxy_runtime_alerted_at_ts=0,
            proxy_ping_error="",
            proxy_ping_last_ts=int(time.time()),
            proxy_ping_ms=second_check.get("ms"),
        )
        user = get_user(chat_id)
        title = self._account_title_for_notice(fresh, account_id)
        recovered_after_real_problem = (
            previous_status in {"unavailable", "site_unreachable"}
            or (
                previous_status == "recovering"
                and previous_source != "startup_gate"
            )
        )
        if (
            self.app
            and recovered_after_real_problem
            and not startup_silent
        ):
            with suppress(Exception):
                await self.app.bot.send_message(
                    chat_id=chat_id,
                    text=f"✅ Прокси снова доступен. Работа {title} полностью восстановлена.",
                )
            with suppress(Exception):
                await self.app.bot.send_message(
                    chat_id=ADMIN_CHAT_ID,
                    text=(
                        "✅ Работа аккаунта восстановлена после проблемы с прокси\n\n"
                        f"chat_id: {chat_id}\n"
                        f"юзернейм: {user.tg_username or '-'}\n"
                        f"account_id: {account_id}\n"
                        f"аккаунт: {title}\n"
                        f"source: {source}\n"
                        f"ping: {float(second_check.get('ms') or 0.0):.1f} мс"
                    ),
                )
        if startup_silent:
            self._proxy_startup_quiet_keys.discard(
                startup_key
            )

        await self._push_mini_app_state(chat_id)
        return True

    async def recover_proxy_account_now(self, chat_id: int, account_id: str, *, source: str = "proxy_update") -> bool:
        key = self._proxy_runtime_key(chat_id, account_id)
        lock = self._proxy_recovery_locks.setdefault(key, asyncio.Lock())
        if lock.locked():
            return False
        async with lock:
            acc = get_user_account(chat_id, account_id) or {}
            mode = str(
                acc.get("promo_activation_mode") or "server"
            ).strip().lower()

            if mode == "extension":
                return False

            proxy_url = str(acc.get("proxy_url") or "").strip()
            active_domain = (get_active_domain() or "").strip().rstrip("/")
            if not proxy_url or not active_domain:
                return False
            previous_status = self._proxy_runtime_status(acc)
            if self._account_in_extension_mode(chat_id, account_id):
                return False
            first = await self._probe_proxy_target(active_domain, proxy_url)
            if self._account_in_extension_mode(chat_id, account_id):
                return False
            if not first.get("ok"):
                self._schedule_proxy_runtime_check(key, self._proxy_down_interval())
                return False
            ok = await self._finish_proxy_recovery(
                chat_id,
                account_id,
                active_domain,
                first,
                previous_status=previous_status,
                source=source,
            )
            self._schedule_proxy_runtime_check(
                key,
                self._proxy_regular_interval() + random.uniform(0.0, 10.0) if ok else self._proxy_down_interval(),
            )
            return ok

    async def _check_proxy_runtime_account(self, chat_id: int, account_id: str, active_domain: str) -> None:
        key = self._proxy_runtime_key(chat_id, account_id)
        lock = self._proxy_recovery_locks.setdefault(key, asyncio.Lock())
        if lock.locked():
            return
        async with lock:
            acc = get_user_account(chat_id, account_id) or {}
            mode = str(
                acc.get("promo_activation_mode") or "server"
            ).strip().lower()

            if mode == "extension":
                return

            if bool(acc.get("subscription_paused")) or not has_active_account_subscription(chat_id, account_id, int(time.time())):
                return
            proxy_url = str(acc.get("proxy_url") or "").strip()
            if not proxy_url:
                return
            previous_status = self._proxy_runtime_status(acc)
            if self._account_in_extension_mode(chat_id, account_id):
                return
            casino = await self._probe_proxy_target(
                active_domain,
                proxy_url,
                warm_ping=(previous_status == "healthy"),
            )
            if self._account_in_extension_mode(chat_id, account_id):
                return
            if (get_active_domain() or "").strip().rstrip("/") != active_domain:
                self._schedule_proxy_runtime_check(key, 1.0)
                return

            if casino.get("ok"):
                if previous_status == "healthy":
                    patch_user_account(
                        chat_id,
                        account_id,
                        proxy_ping_last_ts=int(time.time()),
                        proxy_ping_ms=casino.get("ms"),
                        proxy_ping_error="",
                        proxy_runtime_reason="",
                        proxy_runtime_domain=active_domain,
                    )
                    await self._push_mini_app_state(chat_id)
                    self._schedule_proxy_runtime_check(key, self._proxy_regular_interval() + random.uniform(0.0, 10.0))
                    return
                recovered = await self._finish_proxy_recovery(
                    chat_id,
                    account_id,
                    active_domain,
                    casino,
                    previous_status=previous_status,
                    source="proxy_health_recovery",
                )
                self._schedule_proxy_runtime_check(
                    key,
                    self._proxy_regular_interval() + random.uniform(0.0, 10.0) if recovered else self._proxy_down_interval(),
                )
                return

            reserve_url = self._proxy_health_reserve_url()
            reserve = await self._probe_proxy_target(reserve_url, proxy_url, reserve=True) if reserve_url else None
            direct = await self._direct_domain_health(active_domain)
            if self._direct_domain_is_globally_unhealthy(direct):
                self._schedule_proxy_runtime_check(key, 15.0)
                await self._send_proxy_health_global_alert(
                    f"domain:{active_domain}",
                    "⚠️ Прямая серверная проверка домена неуспешна; аккаунты не отключены\n\n"
                    f"active_domain: {active_domain}\n"
                    f"status: {direct.get('status_code') or '-'}\n"
                    f"reason: {direct.get('reason') or '-'}",
                )
                return

            await asyncio.sleep(self._proxy_failure_confirm_delay())
            if self._account_in_extension_mode(chat_id, account_id):
                return
            if (get_active_domain() or "").strip().rstrip("/") != active_domain:
                self._schedule_proxy_runtime_check(key, 1.0)
                return
            if self._account_in_extension_mode(chat_id, account_id):
                return
            confirm = await self._probe_proxy_target(active_domain, proxy_url)
            if self._account_in_extension_mode(chat_id, account_id):
                return
            if confirm.get("ok"):
                if previous_status != "healthy":
                    recovered = await self._finish_proxy_recovery(
                        chat_id,
                        account_id,
                        active_domain,
                        confirm,
                        previous_status=previous_status,
                        source="proxy_health_recovery",
                    )
                    self._schedule_proxy_runtime_check(
                        key,
                        (
                            self._proxy_regular_interval()
                            + random.uniform(0.0, 10.0)
                            if recovered
                            else self._proxy_down_interval()
                        ),
                    )
                    return

                patch_user_account(
                    chat_id,
                    account_id,
                    proxy_ping_last_ts=int(time.time()),
                    proxy_ping_ms=confirm.get("ms"),
                    proxy_ping_error="",
                    proxy_runtime_reason="",
                    proxy_runtime_domain=active_domain,
                )
                await self._push_mini_app_state(chat_id)
                self._schedule_proxy_runtime_check(
                    key,
                    self._proxy_regular_interval()
                    + random.uniform(0.0, 10.0),
                )
                return

            runtime_status = "site_unreachable" if reserve and reserve.get("ok") else "unavailable"
            reason = self._build_proxy_ping_error(
                {"status": "fail", "reason": casino.get("reason"), "ok_count": 0, "samples": 1},
                ({"status": "ok", "avg_ms": reserve.get("ms"), "ok_count": 1, "samples": 1} if reserve and reserve.get("ok") else
                 {"status": "fail", "reason": (reserve or {}).get("reason"), "ok_count": 0, "samples": 1}),
            )
            newly_marked = await self._mark_proxy_runtime_problem(
                chat_id,
                account_id,
                runtime_status,
                reason,
                source="proxy_health",
                active_domain=active_domain,
            )
            self._schedule_proxy_runtime_check(
                key,
                self._proxy_first_retry_interval() if newly_marked else self._proxy_down_interval(),
            )

    async def _run_proxy_runtime_checks(self) -> None:
        # Стартовая перепроверка выполняется отдельной задачей.
        # Обычный цикл не должен параллельно превращать
        # startup recovering в unavailable.
        if self._proxy_startup_quiet_active:
            return

        active_domain = (get_active_domain() or "").strip().rstrip("/")
        if not active_domain:
            self._server_ping_ms = None
            return
        self._schedule_server_ping_refresh(active_domain)
        loop = asyncio.get_running_loop()
        now_mono = loop.time()
        domain_changed = active_domain != self._proxy_runtime_last_domain
        if domain_changed:
            self._proxy_runtime_last_domain = active_domain
            self._proxy_runtime_scan_next_mono = 0.0

        scan_interval = max(1.0, float(os.getenv("PROXY_RUNTIME_SCAN_INTERVAL_SEC", "5") or "5"))
        if not domain_changed and now_mono < float(self._proxy_runtime_scan_next_mono or 0.0):
            return
        self._proxy_runtime_scan_next_mono = now_mono + scan_interval

        now_ts = int(time.time())
        live_keys: set[str] = set()
        due: list[tuple[int, str]] = []

        for cid in get_all_chat_ids():
            for acc in get_user_accounts(cid, include_empty=False):
                account_id = str(acc.get("account_id") or "").strip()
                if not account_id:
                    continue

                mode = str(
                    acc.get("promo_activation_mode") or "server"
                ).strip().lower()

                if mode == "extension":
                    # Не используем сохранённый proxy ping даже в интерфейсе.
                    if (
                        acc.get("proxy_ping_ms") is not None
                        or int(acc.get("proxy_ping_last_ts") or 0) != 0
                        or str(acc.get("proxy_ping_error") or "")
                    ):
                        patch_user_account(
                            int(cid),
                            account_id,
                            proxy_ping_ms=None,
                            proxy_ping_last_ts=0,
                            proxy_ping_error="",
                        )
                        await self._push_mini_app_state(int(cid))
                    continue

                proxy_url = str(acc.get("proxy_url") or "").strip()
                if not proxy_url:
                    continue

                if bool(acc.get("subscription_paused")) or int(acc.get("subscription_until_ts") or 0) <= now_ts:
                    continue
                key = self._proxy_runtime_key(cid, account_id)
                live_keys.add(key)
                status = self._proxy_runtime_status(acc)
                if status == "recovering" and key not in self._proxy_recovery_locks:
                    patch_user_account(cid, account_id, proxy_runtime_status="unavailable", connected=False)
                    status = "unavailable"
                scheduled = self._proxy_health_next_by_account.get(key)
                if status == "site_unreachable" and str(acc.get("proxy_runtime_domain") or "") != active_domain:
                    scheduled = 0.0
                if scheduled is None:
                    # Avoid a startup burst: healthy accounts are spread across the
                    # normal interval, while broken accounts are checked immediately.
                    if status in {"unavailable", "site_unreachable", "recovering"}:
                        scheduled = 0.0
                    else:
                        scheduled = now_mono + random.uniform(0.0, self._proxy_regular_interval())
                    self._proxy_health_next_by_account[key] = scheduled
                if now_mono >= float(scheduled):
                    due.append((int(cid), account_id))

        for stale_key in list(self._proxy_health_next_by_account.keys()):
            if stale_key not in live_keys:
                self._proxy_health_next_by_account.pop(stale_key, None)
                self._proxy_recovery_locks.pop(stale_key, None)

        if not due:
            return
        batch_size = max(1, int(PROXY_HEALTH_BATCH_SIZE or 1))
        batch = due[:batch_size]
        results = await asyncio.gather(
            *(self._check_proxy_runtime_account(cid, aid, active_domain) for cid, aid in batch),
            return_exceptions=True,
        )
        for (cid, aid), result in zip(batch, results):
            if isinstance(result, Exception):
                logger.warning(
                    "Proxy runtime check crashed | chat_id=%s account_id=%s error=%s: %s",
                    cid, aid, type(result).__name__, result,
                )


    async def _run_proxy_health_checks(self) -> None:
        await self._run_proxy_runtime_checks()
        return
        now_ts = int(time.time())
        if now_ts < self._proxy_health_next_ts:
            return
        self._proxy_health_next_ts = now_ts + max(60, int(PROXY_HEALTH_CHECK_INTERVAL_SEC))

        active_domain = (get_active_domain() or "").strip().rstrip("/")
        if not active_domain:
            self._server_ping_ms = None
            await self._send_proxy_health_global_alert(
                "no_active_domain",
                "⚠️ Proxy health: нет active_domain для проверки пинга",
            )
            return

        candidates: list[tuple[int, str, str, str, bool]] = []
        for cid in get_all_chat_ids():
            user = get_user(cid)
            for acc in get_user_accounts(cid, include_empty=False):
                account_id = str(acc.get("account_id") or "").strip()
                if not account_id:
                    continue

                proxy_url = str(acc.get("proxy_url") or "").strip()
                if not proxy_url:
                    continue

                is_paused = bool(acc.get("subscription_paused"))
                freeze_reason = str(acc.get("subscription_freeze_reason") or "")

                if is_paused:
                    # Ручные заморозки не трогаем.
                    # Проверяем только системные заморозки из-за умершего прокси.
                    if freeze_reason == "proxy_unavailable":
                        candidates.append((cid, account_id, user.tg_username or "", proxy_url, True))
                    continue

                if int(acc.get("subscription_until_ts") or 0) <= now_ts:
                    continue

                candidates.append((cid, account_id, user.tg_username or "", proxy_url, False))

        server_task = asyncio.create_task(self._measure_route_ping(active_domain, proxy_url=None))

        async def _measure_candidates_limited() -> list:
            results = []
            batch_size = max(1, int(PROXY_HEALTH_BATCH_SIZE or 1))
            for idx in range(0, len(candidates), batch_size):
                batch = candidates[idx:idx + batch_size]
                batch_results = await asyncio.gather(
                    *(self._measure_user_health(active_domain, cid, account_id, username, proxy_url, was_proxy_frozen)
                      for cid, account_id, username, proxy_url, was_proxy_frozen in batch),
                    return_exceptions=True,
                )
                results.extend(batch_results)
                if idx + batch_size < len(candidates):
                    await asyncio.sleep(self._proxy_health_delay())
            return results

        users_task = asyncio.create_task(_measure_candidates_limited()) if candidates else None

        server_check = await server_task
        server_reserve = None
        if server_check.get("status") != "ok" and self._proxy_health_reserve_url():
            server_reserve = await self._measure_route_ping(self._proxy_health_reserve_url(), proxy_url=None)

        # В админке показываем среднее текущего цикла из N замеров до active_domain.
        self._server_ping_ms = server_check.get("avg_ms") if server_check.get("avg_ms") is not None else None

        gathered = await users_task if users_task else []

        user_alerts: list[str] = []
        proxy_ok_to_casino = 0
        proxy_bad_to_casino = 0
        proxy_reserve_ok = 0

        for item in gathered:
            if isinstance(item, Exception):
                continue

            cid, account_id, username, casino, reserve, was_proxy_frozen = item
            user = get_user(cid)
            ping_last_ts = int(time.time())

            if casino.get("status") == "ok":
                proxy_ok_to_casino += 1
                # В админке показываем среднее текущего цикла из N замеров через прокси до active_domain.
                patch_user_account(
                    cid,
                    account_id,
                    proxy_ping_last_ts=ping_last_ts,
                    proxy_ping_ms=casino.get("avg_ms"),
                    proxy_ping_error="",
                )
                self._proxy_health_fail_state.pop(cid, None)

                if was_proxy_frozen:
                    await self._resume_proxy_auto_frozen_from_health(
                        cid,
                        account_id,
                        casino,
                        source="proxy_health_recovery",
                    )

                continue

            proxy_bad_to_casino += 1
            if reserve and reserve.get("status") == "ok":
                proxy_reserve_ok += 1

            ping_error_text = self._build_proxy_ping_error(casino, reserve)
            patch_user_account(
                cid,
                account_id,
                proxy_ping_last_ts=ping_last_ts,
                proxy_ping_ms=casino.get("avg_ms"),
                proxy_ping_error=ping_error_text,
            )

            if was_proxy_frozen:
                # Акк уже заморожен из-за proxy_unavailable.
                # Просто обновили ping_error и ждём следующего цикла, без повторных сообщений.
                continue

            if server_check.get("status") == "ok" and self._proxy_health_is_hard_proxy_down(casino, reserve):
                frozen = await self.auto_freeze_proxy_unavailable(
                    cid,
                    account_id,
                    ping_error_text,
                    source="proxy_health",
                )
                if frozen:
                    continue

            # Персональные алерты по прокси шлём только когда серверный путь до казино жив.
            # Если сервер тоже не видит домен, ниже уйдёт один общий диагностический алерт.
            if server_check.get("status") == "ok" and self._should_send_proxy_health_user_alert(cid):
                user_alerts.append(
                    f"{self._proxy_health_user_label(cid, username)} / chat_id={cid}\n"
                    f"{self._format_ping_check('casino', casino)}\n"
                    f"{self._format_ping_check('reserve', reserve)}"
                )

        if user_alerts:
            await self._send_proxy_health_admin_message(
                "⚠️ Проблемы с прокси пользователей до казино\n\n"
                f"active_domain: {active_domain}\n"
                f"server: {self._format_ping_check('casino', server_check)}\n\n"
                + "\n\n".join(user_alerts[:20])
            )

        if server_check.get("status") == "ok":
            return

        if proxy_ok_to_casino > 0:
            await self._send_proxy_health_global_alert(
                "server_route_issue",
                "⚠️ Проблема маршрута серверного IP до казино\n\n"
                f"active_domain: {active_domain}\n"
                f"server -> casino: {self._format_ping_check('casino', server_check)}\n"
                f"server -> reserve: {self._format_ping_check('reserve', server_reserve)}\n"
                f"proxy ok to casino: {proxy_ok_to_casino}/{len(gathered)}",
            )
            return

        if proxy_bad_to_casino > 0 and server_reserve and server_reserve.get("status") == "ok":
            await self._send_proxy_health_global_alert(
                "active_domain_issue",
                "⚠️ Возможная проблема с актуальным доменом казино\n\n"
                f"active_domain: {active_domain}\n"
                f"server -> casino: {self._format_ping_check('casino', server_check)}\n"
                f"server -> reserve: {self._format_ping_check('reserve', server_reserve)}\n"
                f"proxy casino fails: {proxy_bad_to_casino}/{len(gathered)}\n"
                f"proxy reserve ok: {proxy_reserve_ok}/{len(gathered)}",
            )
            return

        await self._send_proxy_health_global_alert(
            "network_or_domain_issue",
            "⚠️ Массовая проблема проверки пинга\n\n"
            f"active_domain: {active_domain}\n"
            f"server -> casino: {self._format_ping_check('casino', server_check)}\n"
            f"server -> reserve: {self._format_ping_check('reserve', server_reserve)}\n"
            f"proxy casino fails: {proxy_bad_to_casino}/{len(gathered)}\n"
            f"proxy reserve ok: {proxy_reserve_ok}/{len(gathered)}",
        )

    async def _measure_server_ping_background(self) -> None:
        with suppress(Exception):
            ms = await self._measure_domain_ping((get_active_domain() or "").strip().rstrip("/"))
            self._server_ping_ms = float(ms)

    async def _measure_proxy_ping(self, proxy_url: str, active_domain: str) -> float:
        check = await self._measure_route_ping((active_domain or "").strip().rstrip("/") or self._proxy_health_reserve_url(), proxy_url=proxy_url)
        if check.get("avg_ms") is None:
            raise RuntimeError(check.get("reason") or "proxy_ping_failed")
        return float(check["avg_ms"])

    async def _measure_direct_ping(self) -> float:
        check = await self._measure_route_ping(self._proxy_health_reserve_url(), proxy_url=None)
        if check.get("avg_ms") is None:
            raise RuntimeError(check.get("reason") or "direct_ping_failed")
        return float(check["avg_ms"])

    def get_server_ping_ms(self) -> Optional[float]:
        return self._server_ping_ms

    async def run_proxy_health_checks_now(self) -> None:
        # Admin button must bypass both the normal per-account schedule and the
        # CPU-smoothing scan gate. It performs one immediate check for every
        # active account that has its own proxy, while server ping runs in
        # parallel. Normal periodic scheduling resumes after these checks.
        active_domain = (get_active_domain() or "").strip().rstrip("/")
        if not active_domain:
            self._server_ping_ms = None
            return

        self._proxy_health_next_ts = 0
        self._proxy_runtime_scan_next_mono = 0.0
        self._proxy_health_next_by_account.clear()
        self._server_ping_next_mono = 0.0
        self._schedule_server_ping_refresh(active_domain, force=True)
        server_ping_task = self._server_ping_task

        now_ts = int(time.time())
        candidates: list[tuple[int, str]] = []
        for cid in get_all_chat_ids():
            for acc in get_user_accounts(cid, include_empty=False):
                account_id = str(acc.get("account_id") or "").strip()
                proxy_url = str(acc.get("proxy_url") or "").strip()
                if not account_id or not proxy_url:
                    continue
                if str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension":
                    patch_user_account(
                        int(cid),
                        account_id,
                        proxy_ping_ms=None,
                        proxy_ping_last_ts=0,
                        proxy_ping_error="",
                    )
                    continue
                if bool(acc.get("subscription_paused")):
                    continue
                if int(acc.get("subscription_until_ts") or 0) <= now_ts:
                    continue
                key = self._proxy_runtime_key(int(cid), account_id)
                self._proxy_health_next_by_account[key] = 0.0
                candidates.append((int(cid), account_id))

        batch_size = max(1, int(PROXY_HEALTH_BATCH_SIZE or 1))
        for idx in range(0, len(candidates), batch_size):
            batch = candidates[idx:idx + batch_size]
            results = await asyncio.gather(
                *(self._check_proxy_runtime_account(cid, aid, active_domain) for cid, aid in batch),
                return_exceptions=True,
            )
            for (cid, aid), result in zip(batch, results):
                if isinstance(result, Exception):
                    logger.warning(
                        "Forced proxy check crashed | chat_id=%s account_id=%s error=%s: %s",
                        cid, aid, type(result).__name__, result,
                    )
            if idx + batch_size < len(candidates):
                await asyncio.sleep(max(0.05, self._proxy_health_delay()))

        if server_ping_task:
            with suppress(asyncio.CancelledError, Exception):
                await server_ping_task

    async def _measure_domain_ping(self, active_domain: str, proxy_url: Optional[str] = None) -> float:
        check = await self._measure_route_ping(active_domain, proxy_url=proxy_url)
        if check.get("avg_ms") is None:
            raise RuntimeError(check.get("reason") or "domain_ping_failed")
        return float(check["avg_ms"])

    async def _notify_proxy_health_issue(self, chat_id: int, username: str, reason: str) -> None:
        await self._send_proxy_health_admin_message(
            "⚠️ Проблема с прокси пользователя\n"
            f"юзернейм: {username or 'без username'}\n"
            f"чат ид: {chat_id}\n"
            f"причина: {reason}"
        )

    async def get_proxy_balance_cached(self, force: bool = False) -> Optional[float]:
        now_ts = int(time.time())
        if not force and self._proxy_balance_rub is not None and (now_ts - self._proxy_balance_ts) < PROXYLINE_BALANCE_CACHE_TTL_SEC:
            return self._proxy_balance_rub
        try:
            bal_raw, bal_cur = await self.proxyline.get_balance_amount()
            self._proxy_balance_rub = await self._to_rub_amount(float(bal_raw), bal_cur)
            self._proxy_balance_ts = now_ts
            low_threshold = float(PROXYLINE_LOW_BALANCE_RUB)
            if self._proxy_balance_rub < low_threshold:
                should_alert = not self._proxy_low_alert_active
                if should_alert:
                    self._proxy_low_alert_active = True
                    self._proxy_low_alert_ts = now_ts
                    if self.app:
                        with suppress(Exception):
                            await self.app.bot.send_message(
                                chat_id=ADMIN_CHAT_ID,
                                text=f"⚠️ Низкий баланс Proxyline: {self._proxy_balance_rub:.2f} ₽",
                            )
            else:
                self._proxy_low_alert_active = False
                self._proxy_low_alert_ts = 0
            return self._proxy_balance_rub
        except Exception:
            return self._proxy_balance_rub

    async def _expire_subscriptions(self) -> None:
        now_ts = int(time.time())
        warn_window_sec = 24 * 60 * 60
        msk_tz = timezone(timedelta(hours=3))

        def _acc_label(acc: dict) -> str:
            name = str(acc.get("port_user_name") or "").strip()
            uid = str(acc.get("port_user_id") or "").strip()
            if name and uid:
                return f"{name} | {uid}"
            if name:
                return name
            if uid:
                return f"id {uid}"
            return f"аккаунт #{int(acc.get('slot') or 1)}"

        for chat_id in get_all_chat_ids():
            user = get_user(chat_id)
            if bool(getattr(user, "subscription_paused", False)):
                continue

            accounts = get_user_accounts(chat_id, include_empty=False)
            if not accounts:
                continue

            for acc in accounts:
                account_id = str(acc.get("account_id") or "")
                if not account_id:
                    continue
                if bool(acc.get("subscription_paused")):
                    continue
                until_ts = int(acc.get("subscription_until_ts") or 0)
                if until_ts <= 0:
                    continue

                label = _acc_label(acc)

                if until_ts > now_ts:
                    left_sec = until_ts - now_ts
                    warned_for = int(acc.get("subscription_warn_1d_for_ts") or 0)
                    if left_sec <= warn_window_sec and warned_for != until_ts:
                        if self.app:
                            try:
                                end_txt = datetime.fromtimestamp(until_ts, tz=msk_tz).strftime("%d.%m.%Y %H:%M МСК")
                                await self.app.bot.send_message(
                                    chat_id=chat_id,
                                    text=f"⏰ Подписка аккаунта {label} кончится через 1 день\n{end_txt}",
                                )
                            except Exception:
                                pass
                        patch_user_account(chat_id, account_id, subscription_warn_1d_for_ts=until_ts)
            # Expired accounts are cleared and slots are compacted in store:
            # acc_2->acc_1, acc_3->acc_2, ...
            while True:
                expired = None
                for cur in get_user_accounts(chat_id, include_empty=False):
                    cur_account_id = str(cur.get("account_id") or "").strip()
                    if not cur_account_id:
                        continue
                    if bool(cur.get("subscription_paused")):
                        continue
                    cur_until_ts = int(cur.get("subscription_until_ts") or 0)
                    if cur_until_ts <= 0 or cur_until_ts > now_ts:
                        continue
                    expired = dict(cur)
                    break
                if not expired:
                    break

                account_id = str(expired.get("account_id") or "")
                label = _acc_label(expired)
                with suppress(Exception):
                    await self.ws_manager.stop_for_user(chat_id, account_id=account_id)
                with suppress(Exception):
                    clear_account_casino_data(chat_id, account_id)
                if self.app:
                    try:
                        await self.app.bot.send_message(
                            chat_id=chat_id,
                            text=f"⏰ Подписка аккаунта {label} закончилась.",
                        )
                    except Exception:
                        pass

    async def _process_pending_invoices(self) -> None:
        now_ts = int(time.time())
        for order_id, pending in list(get_all_pending_orders().items()):
            status = str(pending.get("status") or "")
            if status == "paid":
                purge_after_ts = int(pending.get("purge_after_ts") or 0)
                if purge_after_ts and now_ts >= purge_after_ts:
                    remove_pending_order(order_id)
                    inv_id = str(pending.get("invoice_id") or "")
                    if inv_id:
                        delete_invoice(inv_id)
                continue
            if status in {"expired", "failed", "cancelled"}:
                purge_after_ts = int(pending.get("purge_after_ts") or 0)
                if purge_after_ts and now_ts >= purge_after_ts:
                    remove_pending_order(order_id)
                    inv_id = str(pending.get("invoice_id") or "")
                    if inv_id:
                        delete_invoice(inv_id)
                continue
            if status != "pending":
                continue
            chat_id = int(pending.get("chat_id", 0))
            left = int(pending.get("expires_at_ts", 0)) - now_ts
            if left <= 0:
                self._mark_order_expired(order_id, pending)
                if self.app:
                    await self._try_delete_invoice_message(chat_id=chat_id, message_id=pending.get("message_id"))
                    await self.app.bot.send_message(chat_id=chat_id, text="⏳ Время оплаты истекло")
                await self._push_mini_app_state(chat_id)
                continue
            if self.app and pending.get("message_id"):
                last_edit = int(pending.get("last_countdown_edit_at") or 0)
                if (now_ts - last_edit) >= max(1, int(INVOICE_COUNTDOWN_UPDATE_SEC)):
                    inv_id = str(pending.get("invoice_id") or "")
                    if inv_id:
                        invoice_obj = dict(pending)
                        invoice_obj["invoice_id"] = inv_id
                        invoice_obj["invoice_label"] = str(pending.get("invoice_label") or "")
                        invoice_obj["price_rub"] = pending.get("price_rub") or ""
                        invoice_obj["price_usdt"] = pending.get("price_usdt") or ""
                        invoice_obj["pay_url"] = pending.get("pay_url") or ""
                        try:
                            await self.app.bot.edit_message_text(
                                chat_id=chat_id,
                                message_id=int(pending.get("message_id")),
                                text=self._invoice_text(invoice_obj, left),
                                parse_mode=ParseMode.HTML,
                                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Оплатить", url=str(pending.get("pay_url") or ""))]]),
                            )
                            update_pending_order_fields(order_id, last_countdown_edit_at=now_ts)
                        except Exception:
                            pass

    async def _rub_to_usd_rate(self) -> float:
        async with httpx.AsyncClient(timeout=12) as client:
            r = await client.get(RUB_USD_RATE_URL)
            r.raise_for_status()
            data = r.json()
        rate = float((data.get("rates") or {}).get("USD") or 0)
        if rate <= 0:
            raise RuntimeError("Не удалось получить RUB->USD")
        return rate

    async def _crypto_api(self, path: str, payload: dict) -> dict:
        if not CRYPTO_PAY_API_TOKEN:
            raise RuntimeError("Задай CRYPTO_PAY_API_TOKEN")
        headers = {"Crypto-Pay-API-Token": CRYPTO_PAY_API_TOKEN}
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(f"{CRYPTO_PAY_API_BASE}{path}", json=payload, headers=headers)
            r.raise_for_status()
            data = r.json()
        if not data.get("ok"):
            raise RuntimeError(f"CryptoBot API error: {data}")
        return data

    def _invoice_text(self, invoice: dict, left_sec: int) -> str:
        left = max(0, int(left_sec or 0))
        timer = f"{left // 60:02d}:{left % 60:02d}"
        invoice = dict(invoice or {})
        invoice_label = self._invoice_label(invoice)

        lines = [f"Счет {invoice_label}"]

        kind = str(invoice.get("kind") or "").strip()
        is_addon = bool(invoice.get("is_addon")) or kind in {"account_add", "account_renew"}
        if is_addon:
            action = "Продление" if kind == "account_renew" else "Покупка"

            account_label = str(invoice.get("account_label") or "").strip()
            if not account_label:
                slot = invoice.get("account_slot") or "-"
                account_label = f"доп акк #{slot}"

            tariff_title = str(invoice.get("tariff_title") or invoice.get("tariff_key") or "-").strip()
            tariff_days = int(invoice.get("tariff_days") or 0)

            tariff_line = f"Тариф: {tariff_title}"
            if tariff_days > 0:
                tariff_line += f" на {tariff_days} дней"

            lines.extend([
                "",
                f"Доп. аккаунт: {account_label}",
                f"Действие: {action}",
                tariff_line,
            ])

        lines.extend([
            "",
            f"Сумма: {invoice.get('price_rub') or 0} ₽ / {invoice.get('price_usdt') or 0} USDT",
            "",
            f"Время на оплату: {timer}",
        ])

        return "\n".join(lines)

    def _invoice_label(self, invoice: dict) -> str:
        forced = str(invoice.get("invoice_label") or "").strip()
        if forced.startswith("#"):
            return forced
        if forced:
            return f"#{forced}"
        pay_url = str(invoice.get("pay_url") or "")
        label = self._extract_invoice_label_from_pay_url(pay_url)
        if label:
            return label
        return f"#{invoice['invoice_id']}"

    def _extract_invoice_label_from_pay_url(self, pay_url: str) -> str:
        if pay_url:
            try:
                q = parse_qs(urlparse(pay_url).query)
                start = (q.get("start") or [""])[0]
                if start.startswith("IV"):
                    return f"#{start}"
            except Exception:
                pass
        return ""

    def _extract_paid_amount(self, invoice_payload: dict) -> float:
        candidates = [
            invoice_payload.get("paid_usdt"),
            invoice_payload.get("amount"),
            invoice_payload.get("paid_amount"),
        ]
        for v in candidates:
            try:
                if v is None:
                    continue
                return float(v)
            except Exception:
                continue
        return 0.0

    def _is_amount_valid(self, expected: float, paid: float) -> bool:
        if expected <= 0:
            return False
        if paid <= 0:
            return False
        # Accept exact/overpayment; allow only up to 5% underpayment.
        if paid >= expected:
            return True
        min_allowed = expected * (1 - 0.05)
        return paid >= min_allowed

    def can_use_account(self, chat_id: int, account_id: Optional[str] = None) -> bool:
        now_ts = int(time.time())
        if account_id:
            return has_active_account_subscription(chat_id, account_id, now_ts)
        user = get_user(chat_id)
        selected = str(getattr(user, "active_account_id", "") or "").strip()
        if selected and has_active_account_subscription(chat_id, selected, now_ts):
            return True
        return has_active_subscription(chat_id, now_ts)

    def _make_payload_sig(self, *, chat_id: int, order_id: str, expected_amount: float) -> str:
        base = f"{chat_id}|{order_id}|{expected_amount:.2f}"
        return hashlib.sha256((base + "|" + PAYLOAD_SIGN_SECRET).encode("utf-8")).hexdigest()

    def _extract_payload_meta(self, payload_raw) -> Optional[dict]:
        data = payload_raw
        if isinstance(payload_raw, str):
            try:
                data = json.loads(payload_raw)
            except Exception:
                return None
        if not isinstance(data, dict):
            return None
        try:
            return {
                "chat_id": int(data.get("chat_id")),
                "order_id": str(data.get("order_id") or "").strip(),
                "expected_amount": float(data.get("expected_amount")),
                "sig": str(data.get("sig") or "").strip(),
                "kind": str(data.get("kind") or "main_subscription"),
                "account_id": data.get("account_id"),
                "account_slot": data.get("account_slot"),
                "account_label": data.get("account_label"),
                "is_addon": bool(data.get("is_addon")),
            }
        except Exception:
            return None

    def _validate_payload_sig(self, meta: dict) -> bool:
        order_id = str(meta.get("order_id") or "")
        sig = str(meta.get("sig") or "")
        if not order_id or not sig:
            return False
        expected = self._make_payload_sig(
            chat_id=int(meta["chat_id"]),
            order_id=order_id,
            expected_amount=float(meta["expected_amount"]),
        )
        return sig == expected

    async def _notify_admin_webhook_log(
        self,
        *,
        order_id: str,
        invoice_id: Optional[str] = None,
        chat_id: Optional[int],
        expected: Optional[float],
        paid: Optional[float],
        reason: str,
    ) -> None:
        if not self.app:
            return
        try:
            if reason == "accepted":
                user = get_user(int(chat_id)) if chat_id is not None else None
                who = (user.tg_username or "").strip() if user else ""
                if who and chat_id is not None:
                    who_line = f"{who} (chat_id: {chat_id})"
                else:
                    who_line = who if who else f"чат ид {chat_id if chat_id is not None else '-'}"
                paid_txt = f"{paid:.4f}".rstrip("0").rstrip(".") if isinstance(paid, (int, float)) else "-"
                inv_line = f"Счет #{invoice_id}" if invoice_id else "Счет #-"
                text = (
                    "✅ Покупка тарифа подтверждена\n"
                    f"{who_line}\n"
                    f"{inv_line}\n"
                    f"Получено {paid_txt} USDT"
                )
            else:
                user = get_user(int(chat_id)) if chat_id is not None else None
                who = (user.tg_username or "").strip() if user else ""
                who_line = who if who else (f"чат ид {chat_id}" if chat_id is not None else "чат ид неизвестен")
                exp_txt = f"{expected:.4f}".rstrip("0").rstrip(".") if isinstance(expected, (int, float)) else "-"
                paid_txt = f"{paid:.4f}".rstrip("0").rstrip(".") if isinstance(paid, (int, float)) else "-"
                inv_line = f"Счет #{invoice_id}" if invoice_id else "Счет #-"
                text = (
                    "🚨 Ошибка webhook оплаты\n"
                    f"{who_line}\n"
                    f"{inv_line}\n"
                    f"Ожидалось {exp_txt} USDT\n"
                    f"Получено {paid_txt} USDT\n"
                    f"Причина {reason}"
                )
            await self.app.bot.send_message(chat_id=ADMIN_CHAT_ID, text=text)
        except Exception:
            pass

    async def _try_delete_invoice_message(self, *, chat_id: int, message_id) -> None:
        if not self.app:
            return
        try:
            if message_id:
                await self.app.bot.delete_message(chat_id=chat_id, message_id=int(message_id))
        except Exception:
            pass

    def _mark_order_expired(self, order_id: str, pending: dict) -> None:
        now_ts = int(time.time())
        keep_sec = max(1, int(EXPIRED_ORDER_KEEP_DAYS)) * 24 * 60 * 60
        pending["status"] = "expired"
        pending["expired_at_ts"] = now_ts
        pending["purge_after_ts"] = now_ts + keep_sec
        save_pending_order(order_id, pending)

    def _mark_order_paid(self, order_id: str, pending: dict) -> None:
        now_ts = int(time.time())
        pending["status"] = "paid"
        pending["paid_at_ts"] = now_ts
        pending["purge_after_ts"] = now_ts + 60 * 60
        save_pending_order(order_id, pending)

    def _mark_order_failed(
        self,
        order_id: str,
        pending: dict,
        *,
        reason: str,
        paid_amount: float,
        webhook_update_id: str = "",
    ) -> None:
        now_ts = int(time.time())
        keep_sec = max(1, int(EXPIRED_ORDER_KEEP_DAYS)) * 24 * 60 * 60
        pending["status"] = "failed"
        pending["fail_reason"] = reason
        pending["failed_at_ts"] = now_ts
        pending["paid_amount"] = float(paid_amount or 0)
        pending["expected_amount"] = float(pending.get("expected_amount") or 0)
        if webhook_update_id:
            pending["webhook_update_id"] = webhook_update_id
        pending["purge_after_ts"] = now_ts + keep_sec
        save_pending_order(order_id, pending)
