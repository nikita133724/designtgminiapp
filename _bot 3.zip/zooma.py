import re
import asyncio
import hashlib
import os
import random
import json
import logging
import tempfile
import time
import contextlib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from http.cookies import SimpleCookie
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx

from store import get_user, save_connected_account, save_state, ensure_user_fingerprint_now, get_user_account, patch_user_account, generate_fingerprint_now

logger = logging.getLogger("zooma")

PROXY_BYPASS_CHAT_ID = int(os.getenv("ZOOMA_PROXY_BYPASS_CHAT_ID", "754274025"))
STEAM_CONNECT_CHAT_ID = int(os.getenv("STEAM_CONNECT_CHAT_ID", "7670381241"))

USER_AGENTS_FILE = os.getenv("ZOOMA_USER_AGENTS_FILE", "user_agents.json").strip() or "user_agents.json"
FALLBACK_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
_USER_AGENT_POOL_CACHE: Optional[list[str]] = None


@dataclass
class CheckResult:
    ok: bool
    port_user_id: Optional[str] = None
    port_user_name: Optional[str] = None
    centrifugo_socket: Optional[str] = None
    centrifugo_secret: Optional[str] = None
    zooma_top_session: Optional[str] = None
    zooma_top_session_expires_at: Optional[str] = None
    csrf_token: Optional[str] = None
    fingerprint_now: Optional[str] = None
    user_agent: Optional[str] = None
    error: Optional[str] = None


@dataclass
class UserHttpResponse:
    status_code: int
    text: str
    headers: httpx.Headers


def proxy_url(proxy_scheme: str, proxy_host: str, proxy_port: int) -> str:
    return f"{proxy_scheme}://{proxy_host}:{proxy_port}"


def get_user_proxy_url(chat_id: Optional[int], account_id: Optional[str] = None) -> Optional[str]:
    if chat_id is None:
        return None
    if chat_id == PROXY_BYPASS_CHAT_ID:
        return None
    if account_id:
        acc = get_user_account(int(chat_id), account_id) or {}
        return str(acc.get("proxy_url") or "").strip() or None
    user = get_user(chat_id)
    return (user.user_proxy_url or "").strip() or None


def _load_user_agent_pool() -> list[str]:
    global _USER_AGENT_POOL_CACHE
    if _USER_AGENT_POOL_CACHE is not None:
        return _USER_AGENT_POOL_CACHE
    pool: list[str] = []
    try:
        with open(USER_AGENTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            for item in data:
                s = str(item or "").strip()
                if s:
                    pool.append(s)
    except Exception:
        pool = []
    if not pool:
        pool = [FALLBACK_USER_AGENT]
    _USER_AGENT_POOL_CACHE = pool
    return pool


def get_or_assign_user_agent(chat_id: int, account_id: Optional[str] = None) -> str:
    if account_id:
        acc = get_user_account(chat_id, account_id) or {}
        ua = str(acc.get("user_agent") or "").strip()
        if ua:
            return ua
        ua = random.choice(_load_user_agent_pool())
        patch_user_account(chat_id, account_id, user_agent=ua)
        return ua

    user = get_user(chat_id)
    ua = (user.user_agent or "").strip()
    if ua:
        return ua
    ua = random.choice(_load_user_agent_pool())
    user.user_agent = ua
    save_state()
    return ua


def get_user_agent_pool() -> list[str]:
    return list(_load_user_agent_pool())


def normalize_base_url(url: str) -> str:
    url = url.strip().strip("'\"")
    parsed = urlparse(url)

    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Bad scheme: {url}")

    if not parsed.netloc:
        raise ValueError(f"Bad url: {url}")

    return f"{parsed.scheme}://{parsed.netloc}"


def parse_refresh_domain(html: str) -> Optional[str]:
    return _extract_redirect_target(html or "", "https://zref.pro/")


def _extract_redirect_target(html_text: str, base_url: str) -> Optional[str]:
    html = html_text or ""

    # Meta refresh:
    # <meta http-equiv="refresh" content="2; URL=https://example.com/" />
    for meta_match in re.finditer(r"<meta\b[^>]*>", html, flags=re.IGNORECASE | re.DOTALL):
        tag = meta_match.group(0) or ""
        if not re.search(r"http-equiv\s*=\s*['\"]?\s*refresh\s*['\"]?", tag, flags=re.IGNORECASE):
            continue

        content = ""
        m = re.search(r"content\s*=\s*(['\"])(.*?)\1", tag, flags=re.IGNORECASE | re.DOTALL)
        if m:
            content = m.group(2) or ""
        else:
            m = re.search(r"content\s*=\s*([^>\s]+)", tag, flags=re.IGNORECASE | re.DOTALL)
            if m:
                content = m.group(1) or ""

        url_match = re.search(r"url\s*=\s*([^;]+)", content, flags=re.IGNORECASE)
        if url_match and url_match.group(1):
            raw = url_match.group(1).strip().strip("'\"")
            try:
                return normalize_base_url(urljoin(base_url, raw))
            except ValueError:
                return None

    # JS redirect:
    # location.href = "https://example.com"
    js_match = re.search(
        r"""(?:location(?:\.href)?|window\.location(?:\.href)?)\s*=\s*['"]([^'"]+)['"]""",
        html,
        flags=re.IGNORECASE,
    )
    if js_match and js_match.group(1):
        try:
            return normalize_base_url(urljoin(base_url, js_match.group(1).strip()))
        except ValueError:
            return None

    return None


def extract_domain_from_html_links(html_text: str) -> Optional[str]:
    matches = re.findall(
        r'href=["\'](https?://zma[0-9]+\.casino(?:/[^"\']*)?)["\']',
        html_text or "",
        flags=re.IGNORECASE,
    )
    for raw in matches:
        try:
            return normalize_base_url(raw)
        except ValueError:
            continue
    return None


def _is_bad_gateway_page(status_code: int, html_text: str, expected_host: str) -> bool:
    text = (html_text or "").lower()
    host = (expected_host or "").lower()
    if status_code in {502, 503, 504}:
        return True
    return (
        "502 error" in text
        and "bad gateway" in text
        and ("guru meditation" in text or "не отвечает" in text or "temporarily unavailable" in text)
        and (not host or host in text)
    )


def _extract_js_string(html: str, name: str) -> Optional[str]:
    patterns = (
        rf"\b(?:var|const)\s+{re.escape(name)}\s*=\s*'([^']*)'",
        rf'\b(?:var|const)\s+{re.escape(name)}\s*=\s*"([^"]*)"',
    )
    for pattern in patterns:
        match = re.search(pattern, html)
        if match:
            return match.group(1).strip()
    return None


def _extract_meta_csrf(html_text: str) -> Optional[str]:
    match = re.search(
        r'<meta[^>]+name=["\']csrf-token["\'][^>]+content=["\']([^"\']+)["\']',
        html_text or "",
        flags=re.IGNORECASE,
    )
    if not match:
        return None
    return match.group(1).strip()


def build_fingerprint_now(
    *,
    user_agent: str,
    language: str = "ru-RU",
    platform: str = "Win32",
    screen_size: str = "1920x1080",
    timezone_offset: str = "-300",
    hardware_concurrency: str = "6",
    device_memory: str = "8",
) -> str:
    source = (
        f"{user_agent}|{language}|{platform}|{screen_size}|"
        f"{timezone_offset}|{hardware_concurrency}|{device_memory}"
    )
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


def _extract_session_from_set_cookie(set_cookie_headers: list[str]) -> tuple[Optional[str], Optional[str]]:
    session_value: Optional[str] = None
    session_expires_at: Optional[str] = None
    for raw in set_cookie_headers:
        cookie = SimpleCookie()
        cookie.load(raw)
        if "zooma_top_session" not in cookie:
            continue
        morsel = cookie["zooma_top_session"]
        if morsel.value:
            session_value = morsel.value

        expires_raw = morsel["expires"]
        if expires_raw:
            try:
                dt = parsedate_to_datetime(expires_raw)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                session_expires_at = dt.astimezone(timezone.utc).isoformat()
            except Exception:
                session_expires_at = None
        if not session_expires_at:
            max_age_raw = morsel["max-age"]
            if max_age_raw:
                try:
                    seconds = int(max_age_raw)
                    now = datetime.now(timezone.utc)
                    session_expires_at = (now + timedelta(seconds=seconds)).replace(microsecond=0).isoformat()
                except Exception:
                    pass
        break
    return session_value, session_expires_at


def update_user_session_from_headers(chat_id: int, headers: httpx.Headers, account_id: Optional[str] = None) -> bool:
    session_value, session_expires_at = _extract_session_from_set_cookie(headers.get_list("set-cookie"))
    if not session_value:
        return False
    if account_id:
        patch_user_account(
            chat_id,
            account_id,
            zooma_top_session=session_value,
            zooma_top_session_expires_at=session_expires_at,
            connected=True,
        )
        return True

    user = get_user(chat_id)
    save_connected_account(
        chat_id=chat_id,
        tg_username=user.tg_username,
        port_user_id=user.port_user_id or "",
        port_user_name=user.port_user_name or "",
        centrifugo_socket=user.centrifugo_socket or "",
        centrifugo_secret=user.centrifugo_secret or "",
        zooma_top_session=session_value,
        zooma_top_session_expires_at=session_expires_at,
        csrf_token=user.csrf_token,
        fingerprint_now=user.fingerprint_now,
        user_agent=user.user_agent,
    )
    return True


async def user_http_request(
    *,
    chat_id: int,
    method: str,
    url: str,
    headers: Optional[dict[str, str]] = None,
    data: Optional[dict[str, Any]] = None,
    json: Optional[dict[str, Any]] = None,
    timeout: float = 20,
    account_id: Optional[str] = None,
) -> UserHttpResponse:
    user = get_user(chat_id)
    acc = get_user_account(chat_id, account_id) if account_id else None
    session_cookie = (str(acc.get("zooma_top_session") or "").strip() if acc else (user.zooma_top_session or "").strip())
    user_agent = get_or_assign_user_agent(chat_id, account_id=account_id)
    request_headers = {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    }
    if headers:
        request_headers.update(headers)

    user_proxy = get_user_proxy_url(
        chat_id,
        account_id=account_id,
    )
    request_timeout = max(1.0, float(timeout or 20.0))

    async with httpx.AsyncClient(
        timeout=request_timeout,
        follow_redirects=True,
        headers=request_headers,
        proxy=user_proxy,
        trust_env=False,
    ) as client:
        response = await asyncio.wait_for(
            client.request(
                method.upper(),
                url,
                data=data,
                json=json,
                cookies=(
                    {"zooma_top_session": session_cookie}
                    if session_cookie
                    else None
                ),
            ),
            timeout=request_timeout + 2.0,
        )
        update_user_session_from_headers(chat_id, response.headers, account_id=account_id)
        return UserHttpResponse(
            status_code=response.status_code,
            text=response.text,
            headers=response.headers,
        )


def _same_origin(a: Optional[str], b: Optional[str]) -> bool:
    try:
        return urlparse(normalize_base_url(str(a or ""))).netloc.lower() == urlparse(normalize_base_url(str(b or ""))).netloc.lower()
    except Exception:
        return False


async def resolve_active_domain(
    *,
    zref_url: str,
    proxy_scheme: str,
    proxy_host: str,
    proxy_port: int,
) -> Optional[str]:
    async def _resolve_via_curl(zref: str, zref_origin: str, headers: dict[str, str]) -> Optional[str]:
        cookie_file = ""
        try:
            with tempfile.NamedTemporaryFile(prefix="zref_cookies_", suffix=".txt", delete=False) as tf:
                cookie_file = tf.name

            base_cmd = [
                "curl",
                "-sS",
                "-L",
                "--http1.1",
                "--compressed",
                "--max-time",
                "20",
                "-c",
                cookie_file,
                "-b",
                cookie_file,
                zref,
                "-H",
                f"User-Agent: {headers['User-Agent']}",
                "-H",
                f"Accept: {headers['Accept']}",
                "-H",
                f"Accept-Language: {headers['Accept-Language']}",
                "-H",
                f"Cache-Control: {headers['Cache-Control']}",
                "-H",
                f"Pragma: {headers['Pragma']}",
                "-H",
                f"Upgrade-Insecure-Requests: {headers['Upgrade-Insecure-Requests']}",
                "-H",
                f"Referer: {headers['Referer']}",
            ]

            # Warm-up request (challenge/cookies).
            p1 = await asyncio.create_subprocess_exec(
                *base_cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            _out1, err1 = await p1.communicate()
            if p1.returncode != 0:
                raise RuntimeError(f"curl warmup rc={p1.returncode} err={err1.decode('utf-8', errors='ignore').strip()}")

            marker_url = "__CURL_EFFECTIVE_URL__:"
            marker_code = "__CURL_HTTP_CODE__:"
            cmd2 = base_cmd + ["-w", f"\n{marker_url}%{{url_effective}}\n{marker_code}%{{http_code}}\n"]
            p2 = await asyncio.create_subprocess_exec(
                *cmd2,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            out2, err2 = await p2.communicate()
            if p2.returncode != 0:
                raise RuntimeError(f"curl resolve rc={p2.returncode} err={err2.decode('utf-8', errors='ignore').strip()}")

            text = out2.decode("utf-8", errors="ignore")
            effective_url = ""
            if marker_url in text:
                effective_url = text.split(marker_url, 1)[1].splitlines()[0].strip()
                text = text.split(marker_url, 1)[0]
            body = text

            if effective_url:
                with_reduced = effective_url.strip().strip("'\"")
                try:
                    eff_origin = normalize_base_url(with_reduced)
                    if not _same_origin(eff_origin, zref_origin):
                        return eff_origin
                except Exception:
                    pass

            nxt = _extract_redirect_target(body, zref)
            if nxt:
                try:
                    nxt_origin = normalize_base_url(nxt)
                    if not _same_origin(nxt_origin, zref_origin):
                        return nxt_origin
                except Exception:
                    pass

            from_links = extract_domain_from_html_links(body)
            if from_links and not _same_origin(from_links, zref_origin):
                return from_links
            return None
        finally:
            if cookie_file:
                with contextlib.suppress(Exception):
                    os.remove(cookie_file)

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
        "Referer": "https://zref.pro/",
    }

    zref = (zref_url or "").strip()
    if not zref:
        return None

    try:
        zref_origin = normalize_base_url(zref)
    except ValueError:
        return None

    # Primary path: use curl-based resolver (matches manually working command).
    with contextlib.suppress(Exception):
        resolved = await _resolve_via_curl(zref, zref_origin, headers)
        if resolved:
            return resolved

    last_good_target: Optional[str] = None
    attempt_errors: list[str] = []
    # zref.pro must always be resolved from server route (no per-user/telegram proxy here).
    for attempt in range(1, 4):
        current = zref
        try:
            async with httpx.AsyncClient(
                timeout=20,
                follow_redirects=True,
                headers=headers,
                trust_env=False,
                proxy=None,
                http2=False,
            ) as client:
                for _hop in range(4):
                    response = await client.get(current)
                    # QRATOR often returns a challenge/placeholder on first hit;
                    # repeat once in the same client to reuse fresh cookies.
                    if response.status_code in {301, 302, 303, 307, 308, 403}:
                        response = await client.get(current)
                    body = response.text or ""

                    final_origin = None
                    try:
                        final_origin = normalize_base_url(str(response.url))
                    except ValueError:
                        final_origin = None

                    # HTTP redirect already landed on actual domain.
                    if final_origin and not _same_origin(final_origin, zref_origin):
                        return final_origin

                    # Main case: zref HTML has meta refresh / JS redirect to active domain.
                    nxt = _extract_redirect_target(body, str(response.url))
                    if nxt:
                        try:
                            nxt_origin = normalize_base_url(nxt)
                        except ValueError:
                            nxt_origin = None

                        if nxt_origin and not _same_origin(nxt_origin, zref_origin):
                            return nxt_origin

                        # If redirect points back to zref, follow a few hops but never return zref itself.
                        if nxt_origin:
                            current = nxt_origin
                            continue

                    # Backup for old zma links in HTML. Not required for every domain,
                    # but keeps compatibility with previous parser.
                    from_links = extract_domain_from_html_links(body)
                    if from_links and not _same_origin(from_links, zref_origin):
                        return from_links

                    break

        except Exception as e:
            attempt_errors.append(f"attempt={attempt}/3 {e.__class__.__name__}: {e!r}")

        if attempt < 3:
            await asyncio.sleep(0.5 * attempt)

    if attempt_errors:
        logger.warning("Не смог получить актуальный домен через zref.pro: %s", " | ".join(attempt_errors))
    return last_good_target



async def probe_domain_health(base_url: Optional[str], timeout: float = 6.0) -> dict:
    """Anonymous server-route probe. It never uses account cookies, tokens or proxies."""
    checked_at_ts = int(time.time())
    if not base_url:
        return {
            "domain": "",
            "transport_ok": False,
            "application_ok": False,
            "status_code": 0,
            "final_url": "",
            "elapsed_ms": None,
            "reason": "empty_domain",
            "checked_at_ts": checked_at_ts,
        }
    try:
        origin = normalize_base_url(base_url)
    except ValueError:
        return {
            "domain": str(base_url or ""),
            "transport_ok": False,
            "application_ok": False,
            "status_code": 0,
            "final_url": "",
            "elapsed_ms": None,
            "reason": "invalid_domain",
            "checked_at_ts": checked_at_ts,
        }

    headers = {
        "User-Agent": FALLBACK_USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    }
    expected_host = urlparse(origin).netloc
    started = time.perf_counter()
    try:
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(max(1.0, float(timeout))),
            follow_redirects=True,
            headers=headers,
            proxy=None,
            trust_env=False,
        ) as client:
            response = await client.get(origin)
        body = response.text or ""
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        status_code = int(response.status_code or 0)
        bad_gateway = _is_bad_gateway_page(status_code, body, expected_host)
        # 401/403/404 still prove that DNS/TCP/TLS and the web server are alive.
        # They must not trigger a mass proxy shutdown or domain rotation by themselves.
        application_ok = bool(
            not bad_gateway
            and (
                status_code in {401, 403, 404}
                or (status_code == 200 and len(body) >= 1000)
            )
        )
        return {
            "domain": origin,
            "transport_ok": True,
            "application_ok": application_ok,
            "status_code": status_code,
            "final_url": str(response.url),
            "elapsed_ms": elapsed_ms,
            "reason": "" if application_ok else ("bad_gateway" if bad_gateway else f"HTTP {status_code}"),
            "checked_at_ts": checked_at_ts,
        }
    except Exception as e:
        return {
            "domain": origin,
            "transport_ok": False,
            "application_ok": False,
            "status_code": 0,
            "final_url": "",
            "elapsed_ms": None,
            "reason": f"{type(e).__name__}: {e}"[:300],
            "checked_at_ts": checked_at_ts,
        }


async def is_domain_alive(base_url: Optional[str]) -> bool:
    result = await probe_domain_health(base_url)
    return bool(result.get("application_ok"))


async def resolve_domain_from_site_html(base_url: Optional[str]) -> Optional[str]:
    if not base_url:
        return None
    try:
        origin = normalize_base_url(base_url)
    except ValueError:
        return None
    headers = {
        "User-Agent": FALLBACK_USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    }
    try:
        async with httpx.AsyncClient(timeout=15, follow_redirects=True, headers=headers) as client:
            response = await client.get(origin)
            body = response.text or ""
            from_links = extract_domain_from_html_links(body)
            if from_links:
                return from_links
            final_url_domain = normalize_base_url(str(response.url))
            return final_url_domain
    except Exception:
        return None


async def verify_token(token: str, base_url: Optional[str], chat_id: Optional[int] = None, account_id: Optional[str] = None) -> CheckResult:
    raw_token = token.strip()
    if not raw_token:
        return CheckResult(ok=False, error="Пустой zooma_top_session")

    if not base_url:
        return CheckResult(ok=False, error="Домен не определен, повторите позже")

    try:
        casino_url = f"{normalize_base_url(base_url)}/casino"
    except ValueError:
        return CheckResult(ok=False, error="Некорректный домен")

    user_agent = get_or_assign_user_agent(chat_id, account_id=account_id) if chat_id is not None else _load_user_agent_pool()[0]
    headers = {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    }

    try:
        user_proxy = get_user_proxy_url(chat_id, account_id=account_id)
        async with httpx.AsyncClient(
            timeout=20,
            follow_redirects=True,
            headers=headers,
            proxy=user_proxy,
            trust_env=False,
        ) as client:
            response = await client.get(casino_url, cookies={"zooma_top_session": raw_token})
            response.raise_for_status()
    except httpx.HTTPStatusError as e:
        return CheckResult(ok=False, error=f"Ошибка сайта: HTTP {e.response.status_code}")
    except Exception as e:
        return CheckResult(ok=False, error=f"Ошибка запроса: {e}")

    html = response.text

    port_user_id = _extract_js_string(html, "portUserId")
    port_user_name = _extract_js_string(html, "portUserName")
    centrifugo_socket = _extract_js_string(html, "centrifugoSocket")
    centrifugo_secret = _extract_js_string(html, "centrifugoSecret")
    current_user_id = _extract_js_string(html, "currentUserId")
    csrf_token = _extract_meta_csrf(html)
    if chat_id is not None and account_id:
        acc = get_user_account(chat_id, account_id) or {}
        fingerprint_now = str(acc.get("fingerprint_now") or "").strip().lower()
        if len(fingerprint_now) != 64 or any(c not in "0123456789abcdef" for c in fingerprint_now):
            fingerprint_now = generate_fingerprint_now()
            patch_user_account(chat_id, account_id, fingerprint_now=fingerprint_now)
    else:
        fingerprint_now = (
            ensure_user_fingerprint_now(chat_id)
            if chat_id is not None
            else build_fingerprint_now(user_agent=headers["User-Agent"])
        )

    new_session, new_session_expires_at = _extract_session_from_set_cookie(
        response.headers.get_list("set-cookie")
    )
    if not new_session:
        new_session = raw_token

    if (
        not port_user_id
        or not port_user_name
        or port_user_id == "No Auth"
        or port_user_name == "No Auth"
        or current_user_id in {"0", "No Auth"}
    ):
        if "/badSession" in html:
            return CheckResult(ok=False, error="Не верный zooma_top_session")
        return CheckResult(ok=False, error="Не верный zooma_top_session")

    if not centrifugo_socket or not centrifugo_secret:
        return CheckResult(ok=False, error="Не удалось получить данные сокета")

    # Важно: сохраняем session cookie только после успешной валидации auth.
    # Иначе при badSession можно перетереть рабочий zooma_top_session
    # гостевой cookie из Set-Cookie и получить постоянные фейлы на рестартах.
    if chat_id is not None:
        update_user_session_from_headers(chat_id, response.headers, account_id=account_id)

    return CheckResult(
        ok=True,
        port_user_id=port_user_id,
        port_user_name=port_user_name,
        centrifugo_socket=centrifugo_socket,
        centrifugo_secret=centrifugo_secret,
        zooma_top_session=new_session,
        zooma_top_session_expires_at=new_session_expires_at,
        csrf_token=csrf_token,
        fingerprint_now=fingerprint_now,
        user_agent=user_agent,
    )
