import asyncio
import html
import json
import os
import random
import re
import time
import urllib3
from datetime import datetime, timezone, timedelta
from urllib.parse import urljoin

import requests
import websockets
from bs4 import BeautifulSoup

from telegram import Bot, LinkPreviewOptions, ReplyKeyboardMarkup
from telegram.constants import ParseMode
from telegram.error import TelegramError
from telegram.request import HTTPXRequest
from telegram.ext import ApplicationBuilder, MessageHandler, filters


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# =========================
# CONFIG
# =========================

MIRROR_URL = "https://zref.pro"

# Лучше так:
# export TELEGRAM_BOT_TOKEN="сюда_токен"
TELEGRAM_BOT_TOKEN = "8595358771:AAHcM4TOsDJij8u-XZsSXCAV6iWPik9rHVk"

# Канал, куда бот постит поезда и дожди.
TELEGRAM_CHANNEL_ID = "@bonus_zooma"

# Личка/чат для управления кнопками.
CONTROL_CHAT_ID = 754274025

# Дожди по дефолту выключены.
RAIN_ENABLED = False

# Прокси ТОЛЬКО для Telegram-бота.
TG_PROXY_HOST = "127.0.0.1"
TG_PROXY_PORT = 1080
TG_PROXY_URL = f"socks5://{TG_PROXY_HOST}:{TG_PROXY_PORT}"

DOMAIN_CHECK_INTERVAL = 60
MIN_ALIVE_HTML_SIZE = 1000

CENTRIFUGE_PING_INTERVAL = 25
CENTRIFUGE_PING_TIMEOUT = 90

MIN_RETRY = 1.0
MAX_RETRY = 20.0

METHOD_CONNECT = 0
METHOD_SUBSCRIBE = 1
METHOD_PING = 7

PUSH_PUBLICATION = 0
PUSH_MESSAGE = 4

CHAT_CHANNEL = "chat"
GIVEAWAY_LOBBY_CHANNEL = "giveAway_lobby"
GIVEAWAY_NEW_EVENT = "GiveAway-New"

# Когда пришло GiveAway-New, страница /giveaways иногда обновляется не мгновенно.
GIVEAWAY_FETCH_ATTEMPTS = 3
GIVEAWAY_FETCH_DELAY = 1.2


# =========================
# GLOBAL HTTP SESSION
# Без прокси для сайта/zref/web.
# =========================

HTTP = requests.Session()
HTTP.trust_env = False


# =========================
# TELEGRAM BUTTONS
# =========================

def get_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["🌧 Вкл дождь", "❌ Выкл дождь"],
        ],
        resize_keyboard=True,
    )


async def handle_buttons(update, context):
    global RAIN_ENABLED

    if not update.message or not update.message.text:
        return

    text = update.message.text.strip()

    if text == "🌧 Вкл дождь":
        RAIN_ENABLED = True
        await update.message.reply_text(
            "Дожди включены",
            reply_markup=get_keyboard(),
        )

    elif text == "❌ Выкл дождь":
        RAIN_ENABLED = False
        await update.message.reply_text(
            "Дожди выключены",
            reply_markup=get_keyboard(),
        )


# =========================
# UTILS
# =========================

def clean_text(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def html_escape(value):
    return html.escape(str(value or ""), quote=False)


def html_link(url, text):
    safe_url = html.escape(str(url or ""), quote=True)
    safe_text = html.escape(str(text or "Без ника"), quote=False)
    return f'<a href="{safe_url}">{safe_text}</a>'


def normalize_money(value):
    text = clean_text(value)
    text = text.replace("\xa0", " ")
    text = clean_text(text)

    if not text:
        return ""

    text = (
        text
        .replace("руб.", "₽")
        .replace("руб", "₽")
        .replace("RUB", "₽")
    )

    if "₽" not in text and re.search(r"\d", text):
        text += " ₽"

    return text


def get_retry_interval(retries):
    jitter = 0.5 * random.random()
    interval = min(MAX_RETRY, MIN_RETRY * (2 ** (retries + 1)))
    return max(1.0, (1 - jitter) * interval)


def join_site_url(site_base_url, path):
    path = str(path or "").strip()

    if not path:
        return ""

    if path.startswith("http://") or path.startswith("https://"):
        return path

    if not path.startswith("/"):
        path = "/" + path

    return site_base_url.rstrip("/") + path


def short_secret(value, count=10):
    value = clean_text(value)

    if len(value) <= count:
        return value

    return value[:count] + "..."


def extract_first_regex(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.UNICODE)

        if match:
            return clean_text(match.group(1))

    return ""


def extract_int(text):
    if not text:
        return None

    match = re.search(r"\d[\d\s]*", str(text))

    if not match:
        return None

    return int(re.sub(r"\D", "", match.group(0)))


def pretty_json(value):
    return json.dumps(value, ensure_ascii=False, indent=2)


async def send_ws(ws, command):
    await ws.send(json.dumps(command, ensure_ascii=False))


class Ids:
    def __init__(self):
        self.value = 1

    def next(self):
        current = self.value
        self.value += 1
        return current


# =========================
# HTTP / DOMAIN / TOKEN
# =========================

def http_get_text(url, timeout=25, ajax=False):
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 "
            "Mobile/15E148 Safari/604.1"
        ),
        "Accept": (
            "text/plain, */*; q=0.01"
            if ajax
            else "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        ),
    }

    if ajax:
        headers["X-Requested-With"] = "XMLHttpRequest"
        headers["Referer"] = url

    response = HTTP.get(
        url,
        headers=headers,
        timeout=timeout,
        allow_redirects=True,
        verify=False,
    )

    response.raise_for_status()

    return response.text, response.url


def fetch_actual_domain():
    print("Получаю инфу по zref.pro")

    page, final_url = http_get_text(MIRROR_URL, timeout=25)

    match = re.search(
        r'<meta[^>]+http-equiv=["\']refresh["\'][^>]+content=["\'][^"\']*url\s*=\s*([^"\';\s]+)',
        page,
        re.IGNORECASE,
    )

    if not match:
        match = re.search(
            r'URL\s*=\s*(https?://[^"\'>\s]+)',
            page,
            re.IGNORECASE,
        )

    if match:
        site_url = match.group(1).strip()
        site_url = urljoin(MIRROR_URL, site_url)
        site_url = site_url.rstrip("/")

        print(f"Домен актуальный: {site_url}")

        return site_url

    if final_url and final_url.startswith("http"):
        site_url = final_url.rstrip("/")

        print(f"Домен актуальный: {site_url}")

        return site_url

    raise RuntimeError("Не удалось найти актуальный домен через zref.pro")


def fetch_centrifuge_config():
    site_base_url = fetch_actual_domain()

    print("Получаю данные вебсокет")

    page, _ = http_get_text(site_base_url + "/", timeout=25)

    ws_match = re.search(
        r"centrifugoSocket\s*=\s*['\"]([^'\"]+)['\"]",
        page,
    )

    token_match = re.search(
        r"centrifugoSecret\s*=\s*['\"]([^'\"]+)['\"]",
        page,
    )

    if not ws_match:
        raise RuntimeError("Не найден centrifugoSocket в HTML главной страницы")

    if not token_match:
        raise RuntimeError("Не найден centrifugoSecret в HTML главной страницы")

    ws_url = clean_text(ws_match.group(1))
    token = clean_text(token_match.group(1))

    print(f"Данные веб сокет: url={ws_url}, token={short_secret(token, 10)}")

    return {
        "site_base_url": site_base_url,
        "origin": site_base_url,
        "ws_url": ws_url,
        "token": token,
    }


def is_domain_alive(site_base_url):
    try:
        host = re.sub(r"^https?://", "", site_base_url.rstrip("/")).split("/")[0]
        check_url = f"http://{host}"

        response = HTTP.get(
            check_url,
            headers={
                "User-Agent": "Mozilla/5.0",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
            timeout=5,
            allow_redirects=True,
            verify=False,
        )

        size = len(response.content or b"")

        return response.ok and size > MIN_ALIVE_HTML_SIZE

    except Exception as e:
        print(f"Ошибка проверки домена: {repr(e)}")
        return False


async def domain_watch_loop(state):
    while True:
        await asyncio.sleep(DOMAIN_CHECK_INTERVAL)

        site_base_url = state.get("site_base_url")

        if not site_base_url:
            continue

        alive = await asyncio.to_thread(is_domain_alive, site_base_url)

        if alive:
            state["last_domain_check_ok"] = time.time()
            continue

        print(f"Домен умер или белый экран: {site_base_url}")

        state["domain_dead"] = True

        ws = state.get("ws")

        if ws:
            try:
                await ws.close()
            except Exception as e:
                print(f"Ошибка закрытия websocket после смерти домена: {repr(e)}")


# =========================
# TELEGRAM
# Прокси используется ТОЛЬКО здесь.
# =========================

def make_tg_request(pool_size=8):
    return HTTPXRequest(
        proxy=TG_PROXY_URL,
        connect_timeout=30,
        read_timeout=30,
        write_timeout=30,
        pool_timeout=30,
        connection_pool_size=pool_size,
    )


def make_application():
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "PASTE_TELEGRAM_BOT_TOKEN_HERE":
        raise RuntimeError("Укажи TELEGRAM_BOT_TOKEN в коде или через переменную окружения")

    request = make_tg_request(pool_size=8)
    get_updates_request = make_tg_request(pool_size=2)

    app = (
        ApplicationBuilder()
        .token(TELEGRAM_BOT_TOKEN)
        .request(request)
        .get_updates_request(get_updates_request)
        .build()
    )

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_buttons))

    return app


async def test_telegram(bot):
    try:
        me = await bot.get_me()
        print(f"Telegram бот готов: @{me.username or me.first_name}")

    except Exception as e:
        print(f"Ошибка Telegram get_me: {repr(e)}")
        raise


async def send_telegram_message(bot, text, disable_notification=False, chat_id=None):
    target_chat_id = chat_id or TELEGRAM_CHANNEL_ID

    try:
        await bot.send_message(
            chat_id=target_chat_id,
            text=text,
            parse_mode=ParseMode.HTML,
            link_preview_options=LinkPreviewOptions(is_disabled=True),
            disable_notification=disable_notification,
        )

    except TelegramError as e:
        print(f"Ошибка отправки Telegram-поста: {repr(e)}")
        print(f"Текст поста был:\n{text}")
        raise

    except Exception as e:
        print(f"Неожиданная ошибка Telegram-поста: {repr(e)}")
        print(f"Текст поста был:\n{text}")
        raise


# =========================
# CHAT / RAIN PARSER
# =========================

def get_text_by_selectors(soup, selectors):
    for selector in selectors:
        el = soup.select_one(selector)

        if el:
            text = clean_text(el.get_text(" ", strip=True))

            if text:
                return text

    return ""


def get_all_text(soup):
    return clean_text(soup.get_text(" ", strip=True))


def parse_chat_message_html(html_text):
    try:
        soup = BeautifulSoup(html_text or "", "html.parser")

        nickname = get_text_by_selectors(soup, [
            ".rightBlockChatMessageNick",
            "[onclick^='chatQuote']",
        ])

        message = get_text_by_selectors(soup, [
            ".rightBlockChatMessageText",
        ])

        message_time = get_text_by_selectors(soup, [
            ".rightBlockChatMessageTimeBlock",
        ])

        if not nickname and not message and not message_time:
            return ""

        if nickname and message:
            return f"{message_time or '--:--'} | {nickname}: {message}"

        if message:
            return f"{message_time or '--:--'} | {message}"

        return get_all_text(soup)

    except Exception as e:
        print(f"Ошибка парсинга обычного сообщения чата: {repr(e)}")
        return ""


def parse_amounts_from_html_and_text(soup, full_text):
    hint_text = get_text_by_selectors(soup, [
        ".rainDropChat__hint",
    ])

    prize_amount = get_text_by_selectors(soup, [
        ".rainDropChat__prizeAmount",
    ])

    total_amount = extract_first_regex(hint_text or full_text, [
        r"на\s+сумму\s+([\d\s.,]+)\s*₽",
        r"сумм[ауые]*\s*[:\-]?\s*([\d\s.,]+)\s*₽",
    ])

    per_user_amount = prize_amount or extract_first_regex(full_text, [
        r"каждому\s+по\s*[:\-]?\s*([\d\s.,]+)\s*₽?",
        r"каждому\s*[:\-]?\s*([\d\s.,]+)\s*₽?",
    ])

    participants = extract_first_regex(hint_text or full_text, [
        r"под\s+услови[ея]\s+попало\s+([\d\s]+)\s+человек",
        r"попало\s+([\d\s]+)\s+человек",
        r"услови[ея].*?([\d\s]+)\s+человек",
    ])

    return {
        "totalAmount": normalize_money(total_amount),
        "perUserAmount": normalize_money(per_user_amount),
        "participants": extract_int(participants),
    }


def parse_launcher(soup, full_text):
    launcher = get_text_by_selectors(soup, [
        ".rainDropChat__author",
        ".rainDropChat__nick",
        ".rainDropChat__nickname",
        ".rainDropChat__name",
        ".rightBlockChatMessageNick",
    ])

    if launcher:
        return launcher

    if "Модератор" in full_text:
        return "Модератор"

    match = re.search(
        r"([A-Za-zА-Яа-яЁё0-9_.!?\- ]{2,40})\s+Устроил",
        full_text,
        re.IGNORECASE,
    )

    if match:
        return clean_text(match.group(1))

    return "Неизвестно"


def parse_winner_links(soup, site_base_url):
    winners = []

    links = soup.select(
        ".rainDropChat__winnersList a[href^='/user/'], "
        ".rainDropChat__winnerLink[href^='/user/'], "
        ".rainDropChat a[href^='/user/']"
    )

    seen = set()

    for a in links:
        href = clean_text(a.get("href") or "")

        name = (
            clean_text(a.get("title"))
            or clean_text(a.get("aria-label"))
            or clean_text(a.get_text(" ", strip=True))
        )

        if not name:
            img = a.select_one("img")

            if img:
                name = clean_text(img.get("alt"))

        if not href or not name:
            continue

        lower = name.lower()

        if lower in {"модератор", "moderator", "staff", "admin"}:
            continue

        profile = join_site_url(site_base_url, href)
        key = (profile, name)

        if key in seen:
            continue

        seen.add(key)

        winners.append({
            "nickname": name,
            "profile": profile,
        })

    return winners


def parse_rain_html(html_text, raw_payload, site_base_url):
    try:
        if not isinstance(html_text, str):
            return None

        if "rainDropChat" not in html_text:
            return None

        soup = BeautifulSoup(html_text, "html.parser")
        root = soup.select_one(".rainDropChat")

        if not root:
            print("Ошибка парсинга дождя: rainDropChat есть в HTML, но root не найден")
            return None

        full_text = get_all_text(soup)

        rain_id = clean_text(root.get("id") or "")

        message_time = get_text_by_selectors(soup, [
            ".rainDropChat__time",
            ".rightBlockChatMessageTimeBlock",
        ])

        launcher = parse_launcher(soup, full_text)
        amounts = parse_amounts_from_html_and_text(soup, full_text)
        winners = parse_winner_links(soup, site_base_url)

        rain = {
            "event": "rain_drop_chat",
            "rainId": rain_id,
            "messageTime": message_time,
            "launcher": launcher,
            "totalAmount": amounts["totalAmount"],
            "perUserAmount": amounts["perUserAmount"],
            "participants": amounts["participants"],
            "prizesCount": len(winners),
            "winners": winners,
            "text": full_text,
            "raw": raw_payload,
        }

        problems = []

        if not rain_id:
            problems.append("rainId пустой")
        if not message_time:
            problems.append("messageTime пустой")
        if not rain["totalAmount"]:
            problems.append("totalAmount пустой")
        if not rain["perUserAmount"]:
            problems.append("perUserAmount пустой")
        if rain["participants"] is None:
            problems.append("participants пустой")
        if not winners:
            problems.append("winners пустой")

        if problems:
            print("Предупреждение парсинга дождя:", "; ".join(problems))
            print("Текст дождя:", full_text[:500])

        return rain

    except Exception as e:
        print(f"Ошибка parse_rain_html: {repr(e)}")
        print("RAW payload:", repr(raw_payload)[:1500])
        return None


def extract_html_from_publication(publication):
    try:
        data = publication.get("data", publication)

        if not isinstance(data, dict):
            return None, data

        inner = data.get("data", data)

        if not isinstance(inner, dict):
            return None, data

        html_text = inner.get("html")

        if not isinstance(html_text, str):
            return None, data

        return html_text, data

    except Exception as e:
        print(f"Ошибка extract_html_from_publication: {repr(e)}")
        return None, publication


def extract_rain_from_publication(publication, site_base_url):
    html_text, raw = extract_html_from_publication(publication)

    if not html_text:
        return None

    return parse_rain_html(html_text, raw, site_base_url)


def build_telegram_rain_message(rain):
    try:
        launcher = rain.get("launcher") or "Неизвестно"
        total_amount = rain.get("totalAmount") or "неизвестно"
        per_user_amount = rain.get("perUserAmount") or "неизвестно"
        prizes_count = rain.get("prizesCount") or 0

        participants = rain.get("participants")
        participants_text = str(participants) if participants is not None else "неизвестно"

        winners = rain.get("winners") or []

        if winners:
            winners_line = " | ".join(
                html_link(winner.get("profile"), winner.get("nickname"))
                if winner.get("profile")
                else html_escape(winner.get("nickname") or "Без ника")
                for winner in winners
            )
        else:
            winners_line = "Не удалось распарсить список победителей."

        return "\n".join([
            "<b>🌧 Дождь</b>",
            "",
            f"Кто запустил: <b>{html_escape(launcher)}</b>",
            f"Сумма дождя: <b>{html_escape(total_amount)}</b>",
            f"Каждому по: <b>{html_escape(per_user_amount)}</b>",
            f"Количество призов: <b>{html_escape(prizes_count)}</b>",
            f"Под условие попало: <b>{html_escape(participants_text)} человек</b>",
            "",
            "<b>Победители:</b>",
            winners_line,
        ])

    except Exception as e:
        print(f"Ошибка создания Telegram-поста: {repr(e)}")
        print("RAIN object:", repr(rain)[:1500])
        raise


# =========================
# GIVEAWAY / TRAINS
# =========================

def fetch_giveaways_html(site_base_url):
    url = site_base_url.rstrip("/") + "/giveaways"

    html_text, final_url = http_get_text(url, timeout=25, ajax=True)

    print(f"/giveaways OK: bytes={len(html_text.encode('utf-8'))}, final={final_url}")

    return html_text


def text_one(root, selector):
    el = root.select_one(selector)

    if not el:
        return ""

    return clean_text(el.get_text(" ", strip=True))


def attr_one(root, selector, attr):
    el = root.select_one(selector)

    if not el:
        return ""

    return clean_text(el.get(attr) or "")


def format_msk_datetime(iso_text):
    iso_text = clean_text(iso_text)

    if not iso_text:
        return "неизвестно"

    try:
        value = iso_text.replace("Z", "+00:00")
        dt = datetime.fromisoformat(value)

        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone(timedelta(hours=3)))

        msk = timezone(timedelta(hours=3))
        dt = dt.astimezone(msk)

        return f"{dt.strftime('%H:%M:%S')} мск, {dt.strftime('%d.%m.%Y')}"

    except Exception:
        match = re.search(r"T(\d{2}:\d{2}:\d{2})", iso_text)

        if match:
            return f"{match.group(1)} мск"

        return iso_text


def normalize_condition(condition):
    text = clean_text(condition)
    text = text.replace("\xa0", " ")
    text = clean_text(text)

    if not text:
        return ""

    lower = text.lower()

    if "открыт для всех" in lower or "открыто для всех" in lower:
        return "открыто для всех"

    if "только рефералам" in lower:
        return "только рефералам"

    dep_days = re.search(
        r"([\d\s]+)\s*₽\s*/\s*(\d+)\s*д",
        text,
        re.IGNORECASE,
    )

    if dep_days:
        amount = normalize_money(dep_days.group(1))
        days = int(dep_days.group(2))

        if days % 10 == 1 and days % 100 != 11:
            day_word = "день"
        elif days % 10 in {2, 3, 4} and days % 100 not in {12, 13, 14}:
            day_word = "дня"
        else:
            day_word = "дней"

        return f"депозит {amount} за {days} {day_word}"

    dep_from = re.search(
        r"деп\.?\s*от\s*([\d\s]+)\s*₽",
        text,
        re.IGNORECASE,
    )

    if dep_from:
        return f"депозит от {normalize_money(dep_from.group(1))}"

    return text[:1].lower() + text[1:]


def parse_giveaway_train(article, site_base_url):
    gid = clean_text(article.get("data-ga-gid"))
    number = gid

    href = clean_text(article.get("data-href") or article.get("href"))
    url = join_site_url(site_base_url, href)

    aria = clean_text(article.get("aria-label"))

    conductor = text_one(article, ".gaTicket__name b")

    if not conductor and "Бортпроводник:" in aria:
        conductor = clean_text(aria.split("Бортпроводник:", 1)[1])

    prize_num = text_one(article, ".gaTicket__prizeNum")
    prize = normalize_money(prize_num)

    seats_text = text_one(article, ".gaTicket__stubBig")
    seats = extract_int(seats_text)

    if seats is None:
        prize_meta = text_one(article, ".gaTicket__prizeMeta")
        seats = extract_int(prize_meta)

    finish_at = attr_one(article, ".gaTicket__cd[data-ga-finish]", "data-ga-finish")

    if not finish_at:
        finish_at = attr_one(article, ".gaLobbyTL[data-ga-finish]", "data-ga-finish")

    conditions_raw = [
        clean_text(x.get_text(" ", strip=True))
        for x in article.select(".gaTicket__condTag")
        if clean_text(x.get_text(" ", strip=True))
    ]

    conditions = [
        normalize_condition(x)
        for x in conditions_raw
        if normalize_condition(x)
    ]

    passengers = extract_int(text_one(article, ".gaTicket__footVal--num"))
    status = text_one(article, ".gaTicket__cdStatusLine")

    stub_lines = []
    for line in article.select(".gaTicket__stubLine"):
        key = text_one(line, ".gaTicket__stubKey").upper()
        value = text_one(line, ".gaTicket__stubVal")

        if key or value:
            stub_lines.append({
                "key": key,
                "value": value,
            })

    from_text = ""
    to_text = ""

    for item in stub_lines:
        if item["key"] == "FROM":
            from_text = item["value"]
        elif item["key"] == "TO":
            to_text = item["value"]

    return {
        "gid": gid,
        "number": number,
        "href": href,
        "url": url,
        "conductor": conductor,
        "prize": prize,
        "seats": seats,
        "finishAt": finish_at,
        "finishText": format_msk_datetime(finish_at),
        "conditions": conditions,
        "conditionsRaw": conditions_raw,
        "passengers": passengers,
        "status": status,
        "from": from_text,
        "to": to_text,
    }


def parse_giveaways_page(html_text, site_base_url):
    soup = BeautifulSoup(html_text or "", "html.parser")

    trains = []

    for article in soup.select("article.gaTicket[data-ga-gid]"):
        try:
            train = parse_giveaway_train(article, site_base_url)

            if train.get("gid"):
                trains.append(train)

        except Exception as e:
            print(f"Ошибка парсинга поезда: {repr(e)}")
            print("HTML article:", str(article)[:1200])

    return trains


def fetch_active_giveaway_trains(site_base_url):
    html_text = fetch_giveaways_html(site_base_url)
    trains = parse_giveaways_page(html_text, site_base_url)

    print(f"Активных поездов найдено: {len(trains)}")

    return trains


def print_one_current_train(trains):
    if not trains:
        print("Сейчас активных поездов нет")
        return

    train = trains[0]

    print("Пример текущего активного поезда:")
    print(pretty_json(train))


def build_telegram_train_message(train):
    number = clean_text(train.get("number") or train.get("gid") or "")
    conductor = train.get("conductor") or "Неизвестно"
    prize = train.get("prize") or "неизвестно"
    seats = train.get("seats")
    finish_text = train.get("finishText") or "неизвестно"
    url = train.get("url") or ""

    conditions = train.get("conditions") or []

    if conditions:
        conditions_text = ", ".join(conditions)
    else:
        conditions_text = "не указаны"

    seats_text = str(seats) if seats is not None else "неизвестно"

    title = f"<b>🚆 Train #{html_escape(number)}</b>" if number else "<b>🚆 Train</b>"

    return "\n".join([
        title,
        "",
        f"Бортпроводник: <b>{html_escape(conductor)}</b>",
        f"Призовой фонд: <b>{html_escape(prize)}</b>",
        f"Условия: <b>{html_escape(conditions_text)}</b>",
        f"Мест: <b>{html_escape(seats_text)}</b>",
        "",
        f"Отправление: <b>{html_escape(finish_text)}</b>",
        f"Ссылка: {html_escape(url)}",
    ])


def extract_giveaway_publication_event(publication):
    """
    Поддерживает разные варианты:
    1) {"type": "GiveAway-New", "data": {...}}
    2) {"type": "new", "data": {"type": "GiveAway-New", "data": {...}}}
    3) вложенный data строкой JSON
    """
    data = publication.get("data", publication) if isinstance(publication, dict) else publication

    event_type = ""
    payload = None

    def maybe_json(value):
        if isinstance(value, str):
            try:
                return json.loads(value)
            except Exception:
                return value
        return value

    data = maybe_json(data)

    if isinstance(data, dict):
        outer_type = clean_text(data.get("type") or "")
        inner = maybe_json(data.get("data"))

        if outer_type and outer_type != "new":
            event_type = outer_type
            payload = inner

        elif isinstance(inner, dict):
            inner_type = clean_text(inner.get("type") or "")

            if inner_type:
                event_type = inner_type
                payload = maybe_json(inner.get("data"))

            else:
                event_type = outer_type
                payload = inner

        else:
            event_type = outer_type
            payload = inner

    else:
        payload = data

    raw_text = ""

    try:
        raw_text = json.dumps(publication, ensure_ascii=False)
    except Exception:
        raw_text = str(publication)

    if not event_type and GIVEAWAY_NEW_EVENT in raw_text:
        event_type = GIVEAWAY_NEW_EVENT

    return {
        "eventType": event_type,
        "payload": payload,
        "raw": publication,
    }


async def setup_initial_giveaways(state, seen_train_ids):
    if state.get("giveaway_initial_loaded"):
        return

    site_base_url = state.get("site_base_url")

    if not site_base_url:
        return

    print("Получаю текущие активные поезда при старте")

    try:
        trains = await asyncio.to_thread(fetch_active_giveaway_trains, site_base_url)
    except Exception as e:
        print(f"Ошибка получения поездов при старте: {repr(e)}")
        return

    print_one_current_train(trains)

    for train in trains:
        gid = clean_text(train.get("gid"))

        if gid:
            seen_train_ids.add(gid)

    print(f"Текущие поезда помечены как уже известные: {len(seen_train_ids)}")

    state["giveaway_initial_loaded"] = True


async def fetch_and_post_new_giveaway_trains(bot, state, seen_train_ids, source):
    site_base_url = state.get("site_base_url")

    if not site_base_url:
        print("Не могу получить поезда: нет актуального домена")
        return

    for attempt in range(1, GIVEAWAY_FETCH_ATTEMPTS + 1):
        if attempt > 1:
            await asyncio.sleep(GIVEAWAY_FETCH_DELAY)

        print(f"Проверяю новые поезда после {source}, попытка {attempt}/{GIVEAWAY_FETCH_ATTEMPTS}")

        try:
            trains = await asyncio.to_thread(fetch_active_giveaway_trains, site_base_url)

        except Exception as e:
            print(f"Ошибка GET/PARSE /giveaways после {source}: {repr(e)}")
            continue

        new_trains = []

        for train in trains:
            gid = clean_text(train.get("gid"))

            if not gid:
                continue

            if gid in seen_train_ids:
                continue

            new_trains.append(train)

        if not new_trains:
            print("Новых поездов пока не найдено")
            continue

        print(f"Найдено новых поездов: {len(new_trains)}")

        for train in new_trains:
            gid = clean_text(train.get("gid"))

            if gid:
                seen_train_ids.add(gid)

            print("Новый поезд:")
            print(pretty_json(train))

            message = build_telegram_train_message(train)

            # Поезд отправляем обычным уведомлением.
            await send_telegram_message(
                bot=bot,
                text=message,
                disable_notification=False,
                chat_id=TELEGRAM_CHANNEL_ID,
            )

        return


async def handle_giveaway_lobby_publication(bot, state, seen_train_ids, publication):
    event = extract_giveaway_publication_event(publication)
    event_type = event.get("eventType") or ""

    # Не логируем GiveAway-Join и прочий шум.
    if event_type != GIVEAWAY_NEW_EVENT:
        return

    print("Найдено событие GiveAway-New")

    await fetch_and_post_new_giveaway_trains(
        bot=bot,
        state=state,
        seen_train_ids=seen_train_ids,
        source=GIVEAWAY_NEW_EVENT,
    )


# =========================
# CENTRIFUGE
# WebSocket без прокси.
# =========================

async def subscribe(ws, ids, channel, state):
    subscribe_id = ids.next()

    state.setdefault("pending_subscribes", {})[subscribe_id] = {
        "channel": channel,
        "time": time.time(),
    }

    await send_ws(ws, {
        "id": subscribe_id,
        "method": METHOD_SUBSCRIBE,
        "params": {
            "channel": channel,
        },
    })

    return subscribe_id


async def ping_loop(ws, ids, state):
    while True:
        await asyncio.sleep(CENTRIFUGE_PING_INTERVAL)

        try:
            ping_id = ids.next()

            state["pending_ping_id"] = ping_id
            state["pending_ping_time"] = time.time()
            state["last_ping_sent"] = time.time()

            await send_ws(ws, {
                "id": ping_id,
                "method": METHOD_PING,
            })

        except Exception as e:
            print(f"Ошибка отправки ping websocket: {repr(e)}")

            try:
                await ws.close()
            except Exception:
                pass

            return


async def centrifuge_watchdog_loop(state):
    while True:
        await asyncio.sleep(10)

        ws = state.get("ws")

        if not ws:
            continue

        pending_ping_time = state.get("pending_ping_time")

        if pending_ping_time:
            silent_ping = time.time() - pending_ping_time

            if silent_ping >= CENTRIFUGE_PING_TIMEOUT:
                print(
                    f"Нет ответа на Centrifuge ping {int(silent_ping)} сек, "
                    f"переподключаюсь"
                )

                try:
                    await ws.close()
                except Exception as e:
                    print(f"Ошибка закрытия WebSocket watchdog: {repr(e)}")

                continue

        pending_subscribes = state.get("pending_subscribes") or {}

        expired_subs = []

        for sub_id, sub_data in pending_subscribes.items():
            age = time.time() - sub_data.get("time", time.time())

            if age >= 30:
                expired_subs.append((sub_id, sub_data))

        for sub_id, sub_data in expired_subs:
            channel = sub_data.get("channel", "unknown")

            print(f"Нет ответа subscribe на канал {channel} за 30 сек, переподключаюсь")

            try:
                await ws.close()
            except Exception as e:
                print(f"Ошибка закрытия WebSocket после subscribe timeout: {repr(e)}")

            break


def websocket_connect_context(config):
    headers = {
        "Origin": config["origin"],
        "User-Agent": "Mozilla/5.0",
    }

    try:
        return websockets.connect(
            config["ws_url"],
            additional_headers=headers,
            ping_interval=None,
        )
    except TypeError:
        return websockets.connect(
            config["ws_url"],
            extra_headers=headers,
            ping_interval=None,
        )


def handle_command_response(packet, state):
    packet_id = packet.get("id")

    if not packet_id:
        return False

    if packet_id == state.get("pending_ping_id"):
        if packet.get("error"):
            print(f"Ошибка ответа ping Centrifuge: {packet.get('error')}")
        else:
            state["last_pong_time"] = time.time()

        state["pending_ping_id"] = None
        state["pending_ping_time"] = None

        return True

    pending_subscribes = state.get("pending_subscribes") or {}

    if packet_id in pending_subscribes:
        sub_data = pending_subscribes.pop(packet_id, {})
        channel = sub_data.get("channel", "unknown")

        if packet.get("error"):
            print(f"Ошибка subscribe на канал {channel}: {packet.get('error')}")
        else:
            print(f"Подписался на канал: {channel}")

        return True

    if packet.get("error"):
        print("Ошибка команды Centrifuge:", packet.get("error"))

    return True


async def run_once(bot, sent_rain_ids, seen_train_ids, state):
    config = fetch_centrifuge_config()

    state["site_base_url"] = config["site_base_url"]
    state["domain_dead"] = False
    state["first_chat_printed"] = False
    state["pending_ping_id"] = None
    state["pending_ping_time"] = None
    state["last_pong_time"] = None
    state["pending_subscribes"] = {}

    await setup_initial_giveaways(state, seen_train_ids)

    ids = Ids()
    ping_task = None

    try:
        async with websocket_connect_context(config) as ws:
            state["ws"] = ws

            print("Подключился к веб сокет")

            connect_id = ids.next()

            await send_ws(ws, {
                "id": connect_id,
                "method": METHOD_CONNECT,
                "params": {
                    "token": config["token"],
                },
            })

            connected = False

            async for raw_packet in ws:
                state["packets"] = state.get("packets", 0) + 1
                state["last_packet_time"] = time.time()

                if state.get("domain_dead"):
                    raise RuntimeError("DOMAIN DEAD")

                for line in str(raw_packet).split("\n"):
                    line = line.strip()

                    if not line:
                        continue

                    try:
                        packet = json.loads(line)

                    except Exception as e:
                        print(f"Ошибка JSON websocket: {repr(e)}")
                        print("RAW:", line[:1000])
                        continue

                    if packet.get("id") == connect_id:
                        if packet.get("error"):
                            raise RuntimeError(f"CONNECT ERROR: {packet['error']}")

                        connected = True

                        await subscribe(ws, ids, CHAT_CHANNEL, state)
                        await subscribe(ws, ids, GIVEAWAY_LOBBY_CHANNEL, state)

                        ping_task = asyncio.create_task(ping_loop(ws, ids, state))
                        continue

                    if packet.get("id"):
                        handle_command_response(packet, state)
                        continue

                    result = packet.get("result")

                    if not isinstance(result, dict):
                        continue

                    push_type = result.get("type", PUSH_PUBLICATION)
                    channel = result.get("channel")

                    if push_type == PUSH_PUBLICATION and channel == CHAT_CHANNEL:
                        publication = result.get("data", {})
                        html_text, _raw = extract_html_from_publication(publication)

                        if html_text:
                            state["chat_messages"] = state.get("chat_messages", 0) + 1

                            first_text = parse_chat_message_html(html_text)

                            if first_text:
                                state["last_chat_text"] = first_text[:200]

                                if not state.get("first_chat_printed"):
                                    print(f"Первое сообщение из чата: {first_text}")
                                    state["first_chat_printed"] = True

                        rain = extract_rain_from_publication(
                            publication,
                            config["site_base_url"],
                        )

                        if not rain:
                            continue

                        rain_id = (
                            rain.get("rainId")
                            or f"{rain.get('messageTime')}:{rain.get('totalAmount')}:{rain.get('text')}"
                        )

                        if rain_id in sent_rain_ids:
                            continue

                        sent_rain_ids.add(rain_id)
                        state["rains"] = state.get("rains", 0) + 1

                        print("Найден дождь")

                        if not RAIN_ENABLED:
                            print("Дождь найден, но отправка дождей выключена кнопкой")
                            continue

                        message = build_telegram_rain_message(rain)

                        await send_telegram_message(
                            bot=bot,
                            text=message,
                            disable_notification=True,
                            chat_id=TELEGRAM_CHANNEL_ID,
                        )

                    elif push_type == PUSH_PUBLICATION and channel == GIVEAWAY_LOBBY_CHANNEL:
                        publication = result.get("data", {})

                        await handle_giveaway_lobby_publication(
                            bot=bot,
                            state=state,
                            seen_train_ids=seen_train_ids,
                            publication=publication,
                        )

                    elif push_type == PUSH_MESSAGE:
                        pass

            if not connected:
                raise RuntimeError("Connection closed before Centrifuge CONNECT completed")

    finally:
        if ping_task:
            ping_task.cancel()

        state["ws"] = None


# =========================
# MAIN WITH RECONNECT
# =========================

async def main():
    app = make_application()

    await app.initialize()
    await app.start()

    if app.updater is None:
        raise RuntimeError("Application updater is None")

    await app.updater.start_polling(drop_pending_updates=True)

    bot = app.bot

    await test_telegram(bot)

    await bot.send_message(
        chat_id=CONTROL_CHAT_ID,
        text=(
            "Управление дождями:\n\n"
            "По дефолту дожди выключены.\n"
            "Поезда продолжают поститься всегда."
        ),
        reply_markup=get_keyboard(),
    )

    sent_rain_ids = set()
    seen_train_ids = set()

    retries = 0

    state = {
        "site_base_url": "",
        "domain_dead": False,
        "ws": None,
        "packets": 0,
        "chat_messages": 0,
        "rains": 0,
        "first_chat_printed": False,
        "last_chat_text": "",
        "last_packet_time": None,
        "last_ping_sent": None,
        "last_pong_time": None,
        "pending_ping_id": None,
        "pending_ping_time": None,
        "pending_subscribes": {},
        "last_domain_check_ok": None,
        "giveaway_initial_loaded": False,
    }

    domain_task = asyncio.create_task(domain_watch_loop(state))
    watchdog_task = asyncio.create_task(centrifuge_watchdog_loop(state))

    try:
        while True:
            try:
                await run_once(bot, sent_rain_ids, seen_train_ids, state)

                delay = get_retry_interval(retries)
                retries = min(retries + 1, 10)

                print(f"WebSocket закрылся, переподключение через {delay:.1f} сек")
                await asyncio.sleep(delay)

            except KeyboardInterrupt:
                print("\nОстановлено")
                return

            except RuntimeError as e:
                delay = get_retry_interval(retries)
                retries = min(retries + 1, 10)

                if "DOMAIN DEAD" in str(e):
                    print("Домен умер, получаю новый через zref.pro")
                    state["giveaway_initial_loaded"] = False
                else:
                    print(f"Runtime ошибка: {repr(e)}")

                print(f"Переподключение через {delay:.1f} сек")
                await asyncio.sleep(delay)

            except Exception as e:
                delay = get_retry_interval(retries)
                retries = min(retries + 1, 10)

                print(f"Ошибка: {repr(e)}")
                print(f"Переподключение через {delay:.1f} сек")
                await asyncio.sleep(delay)

    finally:
        domain_task.cancel()
        watchdog_task.cancel()

        try:
            await app.updater.stop()
        except Exception:
            pass

        try:
            await app.stop()
        except Exception:
            pass

        try:
            await app.shutdown()
        except Exception:
            pass


if __name__ == "__main__":
    asyncio.run(main())