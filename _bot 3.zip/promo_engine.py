import asyncio
import contextlib
import hashlib
import html
import json
import os
import random
import re
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from store import USERS, get_active_domain, get_user, get_user_accounts, get_user_account, has_active_subscription, has_active_account_subscription, record_promo_activation, notify_app_state_update, account_server_session_is_stale
from zooma import user_http_request
from ws_manager import UserWsManager
from config import ADMIN_CHAT_ID

PROMO_WS_WAIT_TIMEOUT_SEC = float(os.getenv("PROMO_WS_WAIT_TIMEOUT_SEC", "120").strip())
PROMO_CAPTCHA_TIMEOUT_SEC = float(os.getenv("PROMO_CAPTCHA_TIMEOUT_SEC", "2").strip())
PROMO_CAPTCHA_TRY_MAX = int(os.getenv("PROMO_CAPTCHA_TRY_MAX", "3").strip())
PROMO_CASINO_BALANCE_TIMEOUT_SEC = float(os.getenv("PROMO_CASINO_BALANCE_TIMEOUT_SEC", "5").strip())
PROMO_ACTIVATE_TIMEOUT_SEC = float(os.getenv("PROMO_ACTIVATE_TIMEOUT_SEC", "5").strip())
PROMO_SMALL_MINES_ENABLED = os.getenv("PROMO_SMALL_MINES_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
PROMO_SMALL_MINES_MAX_AMOUNT = float(os.getenv("PROMO_SMALL_MINES_MAX_AMOUNT", "10").strip() or "10")
PROMO_SMALL_MINES_TOTAL_BOMBS = int(os.getenv("PROMO_SMALL_MINES_TOTAL_BOMBS", "24").strip() or "24")
PROMO_SMALL_MINES_MULTIPLIER = float(os.getenv("PROMO_SMALL_MINES_MULTIPLIER", "24.25").strip() or "24.25")
PROMO_SMALL_MINES_START_DELAY_MIN_SEC = float(os.getenv("PROMO_SMALL_MINES_START_DELAY_MIN_SEC", "1").strip() or "1")
PROMO_SMALL_MINES_START_DELAY_MAX_SEC = float(os.getenv("PROMO_SMALL_MINES_START_DELAY_MAX_SEC", "4").strip() or "4")
PROMO_SMALL_MINES_ACTION_DELAY_MIN_SEC = float(os.getenv("PROMO_SMALL_MINES_ACTION_DELAY_MIN_SEC", "1").strip() or "1")
PROMO_SMALL_MINES_ACTION_DELAY_MAX_SEC = float(os.getenv("PROMO_SMALL_MINES_ACTION_DELAY_MAX_SEC", "2").strip() or "2")
PROMO_DEVICE_ALREADY_RETRY_DELAY_SEC = 0.3
PROMO_DEVICE_ALREADY_RETRY_MAX = 25
PROMO_CAPTCHA_429_RETRY_MAX = int(os.getenv("PROMO_CAPTCHA_429_RETRY_MAX", "4").strip())
PROMO_CAPTCHA_429_RETRY_MIN_DELAY_SEC = float(os.getenv("PROMO_CAPTCHA_429_RETRY_MIN_DELAY_SEC", "0.2").strip())
PROMO_CAPTCHA_429_RETRY_MAX_DELAY_SEC = float(os.getenv("PROMO_CAPTCHA_429_RETRY_MAX_DELAY_SEC", "0.3").strip())


def _is_admin_chat(chat_id: int) -> bool:
    try:
        return bool(ADMIN_CHAT_ID and int(chat_id) == int(ADMIN_CHAT_ID))
    except Exception:
        return False


def _account_in_extension_mode(chat_id: int, account_id: str | None) -> bool:
    try:
        aid = str(account_id or getattr(get_user(int(chat_id)), "active_account_id", None) or "acc_1")
        acc = get_user_account(int(chat_id), aid) or {}
        return str(acc.get("promo_activation_mode") or "server").strip().lower() == "extension"
    except Exception:
        return False


def _account_has_proxy_for_runtime(chat_id: int, acc: dict) -> bool:
    if account_server_session_is_stale(acc):
        return False
    if _is_admin_chat(chat_id):
        return True
    runtime_status = str((acc or {}).get("proxy_runtime_status") or "healthy").strip().lower()
    if runtime_status in {"unavailable", "site_unreachable", "recovering"}:
        return False
    return bool(str((acc or {}).get("proxy_url") or "").strip())


def _log_now() -> str:
    omsk_tz = timezone(timedelta(hours=6))
    return datetime.now(omsk_tz).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _format_promo_amount_for_log(amount) -> str:
    try:
        if amount is None:
            return "-"
        val = float(amount)
        if val.is_integer():
            return str(int(val))
        return f"{val:.2f}".rstrip("0").rstrip(".")
    except Exception:
        return "-"


def _is_small_promo_for_mines(amount) -> bool:
    try:
        if amount is None:
            return False
        val = float(amount)
        return val > 0 and val < float(PROMO_SMALL_MINES_MAX_AMOUNT)
    except Exception:
        return False


def _clean_html_text(text: str) -> str:
    if not text:
        return ""
    return re.sub(r"<[^>]+>", "", html.unescape(text)).strip()


def _parse_promo_status(text: str) -> tuple[str | None, str | None]:
    if not text:
        return None, None
    t = _clean_html_text(text).lower()
    promo_ctx = any(x in t for x in ("промокод", "promo", "бонус", "активац"))
    if (
        "кто-то с этого устройства уже активировал этот промокод" in t
        or "already activated this promo code from this device" in t
    ):
        return "error", _clean_html_text(text) or "Ошибка активации."
    if promo_ctx and any(x in t for x in ("успешно", "активирован", "начислен", "зачислен", "получили")):
        return "success", _clean_html_text(text)
    if "закончился" in t:
        return "expired", "Этот промокод уже закончился."
    if "использован" in t:
        return "used", "Промокод уже использован."
    if "не существует" in t or "не найден" in t:
        return "invalid", "Такого промокода не существует."
    if "ошибка" in t:
        return "error", _clean_html_text(text) or "Ошибка активации."
    if "отправлено в очередь" in t:
        return "queued", "Отправлено в очередь..."
    return "unknown", t


def _is_promo_context_text(text: str) -> bool:
    t = _clean_html_text(text).lower()
    return any(x in t for x in ("промокод", "promo", "бонус", "активац", "очеред"))


def _is_device_already_activated_error(text: str) -> bool:
    t = _clean_html_text(text).lower()
    return (
        "кто-то с этого устройства уже активировал этот промокод" in t
        or "already activated this promo code from this device" in t
    )


def _is_promo_restriction_text(text: str) -> bool:
    t = _clean_html_text(text).lower()
    return (
        "не отыграли прошлое промо" in t
        or "сумма отыгрыша" in t
        or "только для игроков с суммой пополнений" in t
        or "ваш баланс меньше 1" in t
    )


def _extract_amount_from_text(text: str) -> float | None:
    if not text:
        return None
    cleaned = text.replace("\u00a0", " ")
    matches = re.findall(r"(\d+[\d\s]*[.,]?\d*)", cleaned)
    vals: list[float] = []
    for m in matches:
        n = m.replace(" ", "").replace(",", ".")
        try:
            v = float(n)
            if v > 0:
                vals.append(v)
        except Exception:
            pass
    if not vals:
        return None
    return round(max(vals), 2)


@dataclass
class PromoResult:
    chat_id: int
    ok: bool
    status: str
    message: str
    amount: float | None = None
    account_id: str | None = None
    account_slot: int | None = None
    account_name: str | None = None
    account_port_user_id: str | None = None
    mines_status: str | None = None
    mines_bet_amount: float | None = None
    mines_multiplier: float | None = None
    mines_win_amount: float | None = None
    mines_balance_after: float | None = None


@dataclass
class _PendingPromo:
    promo: str
    chat_id: int
    account_id: str
    future: asyncio.Future
    created_at: float
    timeout_task: asyncio.Task | None = None
    balance_before: float | None = None
    domain: str | None = None
    requester_chat_id: int | None = None


class PromoEngine:
    def __init__(self, ws_manager: UserWsManager) -> None:
        self.ws_manager = ws_manager
        self._locks: dict[str, asyncio.Lock] = {}
        self._processed_by_user: dict[tuple[str, str], float] = {}
        self._processed_ttl_sec = int(os.getenv("ZOOMA_PROCESSED_PROMO_TTL_SEC", "1800"))
        self._telegram_bot: Optional[Any] = None
        self._active_promos: set[str] = set()
        self._last_captcha_status: dict[str, int] = {}
        self._pending_ws: dict[str, deque[_PendingPromo]] = {}
        self._pending_ws_locks: dict[str, asyncio.Lock] = {}
        self._ws_worker_tasks: dict[str, asyncio.Task] = {}
        self.extension_ws_manager: Any | None = None
        self._seen_promos: dict[str, float] = {}
        self._running_promos: set[str] = set()
        self._seen_ttl_sec = int(os.getenv("ZOOMA_INTERNAL_TG_QUEUED_PROMO_TTL_SEC", "1800"))

    def set_extension_ws_manager(self, manager: Any) -> None:
        self.extension_ws_manager = manager

    async def acquire_mode_switch_guard(self, chat_id: int, account_id: str) -> asyncio.Lock | None:
        """Serialize mode switches with promo activation for this exact account.

        A promo already executing must finish on its original executor. Switching
        in the middle risks activating the same promo through both server and
        extension, so the UI receives a clean 409 instead.
        """
        key_id = self._account_key(int(chat_id), str(account_id or "acc_1"))
        lock = self._locks.setdefault(key_id, asyncio.Lock())
        if lock.locked():
            return None
        await lock.acquire()
        return lock

    @staticmethod
    def release_mode_switch_guard(lock: asyncio.Lock | None) -> None:
        if lock is not None and lock.locked():
            lock.release()

    async def enqueue_promo(self, promo: str, *, channel_key: str = "", msg_id: Any = None) -> dict:
        promo = str(promo or "").strip().upper()
        if not promo:
            return {"ok": False, "error": "empty_promo"}
        now = time.time()
        for k, ts in list(self._seen_promos.items()):
            if (now - ts) > self._seen_ttl_sec:
                self._seen_promos.pop(k, None)
        dedup_key = f"{promo}:{channel_key or ''}:{msg_id or ''}"
        if dedup_key in self._seen_promos:
            return {"ok": True, "promo": promo, "skipped": True, "reason": "already_queued"}
        self._seen_promos[dedup_key] = now
        if promo not in self._running_promos:
            self._running_promos.add(promo)

            async def _run() -> None:
                try:
                    await self.activate_for_all(promo)
                finally:
                    self._running_promos.discard(promo)

            asyncio.create_task(_run(), name=f"promo:{promo}")
        return {"ok": True, "promo": promo, "queued": True}

    def _chat_label(self, chat_id: int) -> str:
        try:
            username = str(get_user(chat_id).tg_username or "").strip()
        except Exception:
            username = ""
        username = username.lstrip("@")
        if username:
            return f"@{username}"
        return f"chat_id={chat_id}"

    def _account_key(self, chat_id: int, account_id: str | None = None) -> str:
        aid = str(account_id or "acc_1")
        return f"{int(chat_id)}:{aid}"

    def _account_label(self, chat_id: int, account_id: str | None = None) -> str:
        base = self._chat_label(chat_id)
        if not account_id:
            return base
        try:
            acc = get_user_account(chat_id, account_id) or {}
            slot = int(acc.get("slot") or 0)
            name = str(acc.get("port_user_name") or "").strip()
            uid = str(acc.get("port_user_id") or "").strip()
            tail = f"acc{slot or account_id}"
            if name or uid:
                tail = f"{name or 'acc'}|{uid or account_id}"
            return f"{base}/{tail}"
        except Exception:
            return f"{base}/{account_id}"

    def _result_for_account(
        self,
        chat_id: int,
        account_id: str | None,
        ok: bool,
        status: str,
        message: str,
        amount: float | None = None,
        mines_status: str | None = None,
        mines_bet_amount: float | None = None,
        mines_multiplier: float | None = None,
        mines_win_amount: float | None = None,
        mines_balance_after: float | None = None,
    ) -> PromoResult:
        acc = get_user_account(chat_id, account_id) if account_id else None
        acc = acc or {}
        return PromoResult(
            chat_id=chat_id,
            ok=ok,
            status=status,
            message=message,
            amount=amount,
            account_id=str(account_id or acc.get("account_id") or ""),
            account_slot=int(acc.get("slot") or 0) or None,
            account_name=str(acc.get("port_user_name") or "") or None,
            account_port_user_id=str(acc.get("port_user_id") or "") or None,
            mines_status=mines_status,
            mines_bet_amount=mines_bet_amount,
            mines_multiplier=mines_multiplier,
            mines_win_amount=mines_win_amount,
            mines_balance_after=mines_balance_after,
        )

    def _result_label(self, result: PromoResult) -> str:
        name = str(result.account_name or "").strip()
        uid = str(result.account_port_user_id or "").strip()
        if name and uid:
            return f"{name} | {uid}"
        if name:
            return name
        if uid:
            return f"id {uid}"
        if result.account_slot:
            return f"Аккаунт {result.account_slot}"
        return "Аккаунт"

    def _has_mines_result(self, result: PromoResult) -> bool:
        return bool(str(result.mines_status or "").strip())

    def _money_view(self, amount: float | None) -> str | None:
        if amount is None:
            return None
        try:
            val = float(amount)
        except Exception:
            return None
        if val < 0:
            return None
        return f"{val:.2f}"

    def _mines_result_line(self, result: PromoResult) -> str | None:
        status = str(result.mines_status or "").strip().lower()
        if not status:
            return None
        if status == "won":
            win_s = self._money_view(result.mines_win_amount)
            bet_s = self._money_view(result.mines_bet_amount)
            balance_s = self._money_view(result.mines_balance_after)
            mult = result.mines_multiplier
            try:
                mult_s = f"{float(mult):.2f}x" if mult is not None else "24.25x"
            except Exception:
                mult_s = "24.25x"
            parts = [f"💣 Мины: ставка {bet_s or '-'} ₽, выигрыш {win_s or '-'} ₽ ({mult_s})"]
            if balance_s:
                parts.append(f"баланс после: {balance_s} ₽")
            return " | ".join(parts)
        if status == "lost":
            return "💣 Мины: проигрыш"
        if status in {"error", "cashout_error", "skipped"}:
            return "💣 Мины: не удалось выполнить"
        return f"💣 Мины: {html.escape(status)}"

    def set_telegram_bot(self, bot: Any) -> None:
        self._telegram_bot = bot

    def _promo_user_message(self, result: PromoResult) -> str:
        status = str(result.status or "").strip().lower()
        msg = _clean_html_text(str(result.message or "")).strip()
        low = msg.lower()
        if low == "already_processed":
            return "этот промокод уже был недавно отправлен в обработку"
        if low == "subscription_frozen_or_inactive":
            return "аккаунт пропущен: подписка заморожена или неактивна"
        if low == "promo_activation_paused":
            return "активация промо поставлена на паузу"
        if status == "extension_offline" or low == "extension_offline":
            return "расширение офлайн — браузер закрыт или соединение потеряно"
        if low == "proxy_runtime_unavailable":
            return "аккаунт временно пропущен из-за проблемы с прокси"
        if status.startswith("extension_"):
            return msg or "расширение недоступно"
        if status == "timeout":
            return f"не пришёл ответ от сайта за {int(PROMO_WS_WAIT_TIMEOUT_SEC)} секунд"
        if status == "skipped" and not msg:
            return "аккаунт пропущен"
        if status == "rejected" and msg:
            return msg
        return msg or status or "ошибка активации"

    def _ensure_ws_worker(self, chat_id: int, account_id: str) -> None:
        key_id = self._account_key(chat_id, account_id)
        task = self._ws_worker_tasks.get(key_id)
        if task and not task.done():
            return
        self._ws_worker_tasks[key_id] = asyncio.create_task(
            self._ws_status_worker(int(chat_id), str(account_id)),
            name=f"promo-ws-status-{key_id}",
        )

    async def _register_pending_ws(
        self,
        chat_id: int,
        account_id: str,
        promo: str,
        *,
        balance_before: float | None = None,
        domain: str | None = None,
        requester_chat_id: int | None = None,
    ) -> asyncio.Future:
        key_id = self._account_key(chat_id, account_id)
        lock = self._pending_ws_locks.setdefault(key_id, asyncio.Lock())
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        pending = _PendingPromo(
            promo=str(promo),
            chat_id=int(chat_id),
            account_id=str(account_id),
            future=future,
            created_at=loop.time(),
            balance_before=balance_before,
            domain=domain,
            requester_chat_id=requester_chat_id,
        )
        pending.timeout_task = asyncio.create_task(
            self._pending_ws_timeout(key_id, pending),
            name=f"promo-ws-timeout-{key_id}-{promo}",
        )
        async with lock:
            self._pending_ws.setdefault(key_id, deque()).append(pending)
            qsize = len(self._pending_ws.get(key_id) or [])
        self._ensure_ws_worker(chat_id, account_id)
        return future

    async def _pending_ws_timeout(self, key_id: str, pending: _PendingPromo) -> None:
        try:
            await asyncio.sleep(max(0.1, float(PROMO_WS_WAIT_TIMEOUT_SEC)))
            removed = False
            lock = self._pending_ws_locks.setdefault(key_id, asyncio.Lock())
            async with lock:
                q = self._pending_ws.get(key_id) or deque()
                fresh = deque()
                while q:
                    item = q.popleft()
                    if item is pending:
                        removed = True
                        continue
                    fresh.append(item)
                if fresh:
                    self._pending_ws[key_id] = fresh
                else:
                    self._pending_ws.pop(key_id, None)
            if not removed or pending.future.done():
                return

            status = "timeout"
            message = None
            amount = None
            if pending.balance_before is not None and pending.balance_before < 1.0 and pending.domain:
                balance_after = await self._get_casino_balance(pending.chat_id, pending.domain, account_id=pending.account_id)
                if balance_after is not None and balance_after > pending.balance_before:
                    amount = round(balance_after - pending.balance_before, 2)
                    status = "success"
                    message = "ok"
            result = await self._build_final_ws_result(pending, status, message, amount, source="timeout")
            if not pending.future.done():
                pending.future.set_result(result)
        except asyncio.CancelledError:
            return
        except Exception as e:
            if not pending.future.done():
                pending.future.set_result(self._result_for_account(pending.chat_id, pending.account_id, False, "error", str(e)[:300]))

    def _pending_ws_count(self, chat_id: int, account_id: str) -> int:
        key_id = self._account_key(chat_id, account_id)
        return len(self._pending_ws.get(key_id) or [])

    async def _pop_next_pending_ws(self, chat_id: int, account_id: str) -> _PendingPromo | None:
        key_id = self._account_key(chat_id, account_id)
        lock = self._pending_ws_locks.setdefault(key_id, asyncio.Lock())
        async with lock:
            q = self._pending_ws.get(key_id) or deque()
            while q:
                pending = q.popleft()
                if not pending.future.done():
                    if pending.timeout_task and not pending.timeout_task.done():
                        pending.timeout_task.cancel()
                    if q:
                        self._pending_ws[key_id] = q
                    else:
                        self._pending_ws.pop(key_id, None)
                    return pending
            self._pending_ws.pop(key_id, None)
        return None

    async def _fail_pending_ws_for_account(self, chat_id: int, account_id: str) -> None:
        key_id = self._account_key(chat_id, account_id)
        lock = self._pending_ws_locks.setdefault(key_id, asyncio.Lock())
        async with lock:
            pending_items = list(self._pending_ws.pop(key_id, deque()))
        for pending in pending_items:
            if pending.timeout_task and not pending.timeout_task.done():
                pending.timeout_task.cancel()
            if not pending.future.done():
                pending.future.set_result(
                    self._result_for_account(
                        pending.chat_id,
                        pending.account_id,
                        False,
                        "skipped",
                        "proxy_runtime_unavailable",
                    )
                )

    async def _build_final_ws_result(
        self,
        pending: _PendingPromo,
        status: str,
        message: str | None,
        amount: float | None,
        *,
        source: str,
    ) -> PromoResult:
        promo = pending.promo
        chat_id = pending.chat_id
        account_id = pending.account_id
        if status == "success":
            print(
                f"[{_log_now()}] [SUCCESS] {self._account_label(chat_id, account_id)} "
                f"✅ {promo} активирован amount={_format_promo_amount_for_log(amount)} source={source}",
                flush=True,
            )
            mines = await self._run_small_promo_mines_server(
                chat_id,
                account_id,
                promo,
                amount,
                balance_before=pending.balance_before,
            )
            try:
                record_promo_activation(chat_id, amount, promo=promo, account_id=account_id)
            except Exception as e:
                print(
                    f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} "
                    f"promo stats record failed promo={promo} amount={amount}: {type(e).__name__}: {e}",
                    flush=True,
                )
            try:
                await notify_app_state_update(chat_id)
            except Exception as e:
                print(
                    f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} "
                    f"app state notify failed promo={promo}: {type(e).__name__}: {e}",
                    flush=True,
                )
            return self._result_for_account(
                chat_id,
                account_id,
                True,
                "success",
                message or "ok",
                amount,
                mines_status=str((mines or {}).get("status") or "").strip().lower() or None,
                mines_bet_amount=(mines or {}).get("bet_amount"),
                mines_multiplier=(mines or {}).get("multiplier"),
                mines_win_amount=(mines or {}).get("win_amount"),
                mines_balance_after=(mines or {}).get("balance_after"),
            )

        clean_msg = _clean_html_text(message or "")
        if status in {"expired", "used", "invalid", "error", "rejected"}:
            if _is_promo_restriction_text(clean_msg):
                print(
                    f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} "
                    f"promo rejected ❌: {clean_msg[:220]}",
                    flush=True,
                )
            else:
                print(f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} ❌ {clean_msg or status}", flush=True)
        else:
            print(
                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                f"promo={promo} status={status} source={source}",
                flush=True,
            )
        return self._result_for_account(chat_id, account_id, False, status, clean_msg or message or "")

    def _parse_ws_promo_event(self, event: dict, chat_id: int, account_id: str) -> tuple[str | None, str | None, float | None]:
        event_type = str(event.get("type") or "")
        data = event.get("data") or {}
        data = data if isinstance(data, dict) else {}

        if event_type == "userNotify":
            text1 = str(data.get("argumentOne", "") or "").strip()
            raw_text2 = data.get("argumentTwo", "")
            text2 = "" if isinstance(raw_text2, bool) or raw_text2 is None else str(raw_text2).strip()
            status1, clean1 = _parse_promo_status(text1)
            status2, clean2 = _parse_promo_status(text2)
            if status1 == "queued" and clean1:
                print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} userNotify: {clean1}", flush=True)
            if status2 == "queued" and clean2 and clean2 != clean1:
                print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} userNotify: {clean2}", flush=True)
            if status1 == "success" or status2 == "success":
                amount = _extract_amount_from_text(text2) or _extract_amount_from_text(text1)
                return "success", "ok", amount
            for st, msg in ((status1, clean1), (status2, clean2)):
                if st in {"expired", "used", "invalid", "error"}:
                    return st or "error", msg, None

        if event_type == "updateBalance":
            try:
                old = float(data.get("argumentOne", 0) or 0)
                new = float(data.get("argumentTwo", 0) or 0)
                amount = round(new - old, 2)
            except Exception:
                amount = 0
            if amount > 0:
                return "success", "ok", amount
        return None, None, None

    async def _ws_status_worker(self, chat_id: int, account_id: str) -> None:
        key_id = self._account_key(chat_id, account_id)
        try:
            while True:
                if self._pending_ws_count(chat_id, account_id) <= 0:
                    return

                account = get_user_account(chat_id, account_id) or {}
                runtime_status = str(account.get("proxy_runtime_status") or "healthy").strip().lower()
                if runtime_status in {"unavailable", "site_unreachable", "recovering"}:
                    await self._fail_pending_ws_for_account(chat_id, account_id)
                    return

                try:
                    event = await self.ws_manager.wait_event(chat_id, timeout=1.0, account_id=account_id)
                    if not event:
                        await asyncio.sleep(0.25)
                        continue
                    status, msg, amount = self._parse_ws_promo_event(event, chat_id, account_id)
                    if not status:
                        continue
                    pending = await self._pop_next_pending_ws(chat_id, account_id)
                    if not pending:
                        print(
                            f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} "
                            f"ignored WS promo status={status}: pending queue is empty",
                            flush=True,
                        )
                        continue
                    result = await self._build_final_ws_result(pending, status, msg, amount, source="ws")
                    if not pending.future.done():
                        pending.future.set_result(result)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    print(
                        f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} "
                        f"promo WS worker crashed: {type(e).__name__}: {e}",
                        flush=True,
                    )
                    await asyncio.sleep(1.0)
        finally:
            current = self._ws_worker_tasks.get(key_id)
            if current is asyncio.current_task():
                self._ws_worker_tasks.pop(key_id, None)

    async def activate_for_all(self, promo: str, requester_chat_id: int | None = None) -> list[PromoResult]:
        now_ts = int(time.time())
        targets: list[tuple[int, str]] = []
        paused_targets: list[tuple[int, str]] = []

        for cid, _user in list(USERS.items()):
            try:
                for acc in get_user_accounts(cid, include_empty=False):
                    account_id = str(acc.get("account_id") or "").strip()
                    if not account_id:
                        continue
                    if bool(acc.get("subscription_paused")):
                        continue
                    if bool(acc.get("promo_activation_paused", getattr(_user, "promo_activation_paused", False))):
                        if has_active_account_subscription(int(cid), account_id, now_ts):
                            paused_targets.append((int(cid), account_id))
                        continue
                    if not has_active_account_subscription(int(cid), account_id, now_ts):
                        continue
                    mode = str(acc.get("promo_activation_mode") or getattr(_user, "promo_activation_mode", "server") or "server").strip().lower()
                    if mode == "extension":
                        # Keep subscribed extension accounts in the result set even while offline.
                        # activate_for_user() returns a clear extension_offline result.
                        targets.append((int(cid), account_id))
                        continue
                    if not bool(acc.get("connected")):
                        continue
                    if not str(acc.get("zooma_top_session") or "").strip():
                        continue
                    if not str(acc.get("csrf_token") or "").strip():
                        continue
                    if not str(acc.get("fingerprint_now") or "").strip():
                        continue
                    if not _account_has_proxy_for_runtime(int(cid), acc):
                        continue
                    targets.append((int(cid), account_id))
            except Exception as e:
                print(f"[{_log_now()}] [WARNING] {self._chat_label(cid)} account target scan failed: {e}", flush=True)

        labels = ", ".join(self._account_label(cid, aid) for cid, aid in targets)
        print(f"[{_log_now()}] [PROMO_DISPATCH] promo={promo} accounts={len(targets)} [{labels}]", flush=True)
        if paused_targets:
            paused_labels = ", ".join(self._account_label(cid, aid) for cid, aid in paused_targets)
            print(
                f"[{_log_now()}] [PROMO_PAUSED] promo={promo} accounts={len(paused_targets)} [{paused_labels}]",
                flush=True,
            )

        chat_account_counts: dict[int, int] = {}
        for cid, _aid in targets:
            chat_account_counts[int(cid)] = chat_account_counts.get(int(cid), 0) + 1

        async def _safe_activate(cid: int, aid: str) -> PromoResult:
            try:
                result = await self.activate_for_user(cid, promo, account_id=aid)
            except Exception as e:
                print(
                    f"[{_log_now()}] [ERROR] {self._account_label(cid, aid)} promo task crashed: {type(e).__name__}: {e}",
                    flush=True,
                )
                result = self._result_for_account(cid, aid, False, "error", "Ошибка активации.")

            try:
                await self._notify_account_result(
                    promo,
                    result,
                    multi_account=chat_account_counts.get(int(cid), 0) > 1,
                )
            except Exception as e:
                print(
                    f"[{_log_now()}] [ERROR] {self._account_label(cid, aid)} immediate notify crashed: {type(e).__name__}: {e}",
                    flush=True,
                )
            return result

        tasks = [asyncio.create_task(_safe_activate(cid, aid)) for cid, aid in targets]
        if not tasks:
            return []

        results = await asyncio.gather(*tasks)
        if requester_chat_id is not None:
            try:
                await self._notify_requester_non_success(promo, int(requester_chat_id), results)
            except Exception as e:
                print(
                    f"[{_log_now()}] [ERROR] requester promo status notify failed "
                    f"chat_id={requester_chat_id} promo={promo}: {type(e).__name__}: {e}",
                    flush=True,
                )
        return results

    async def _notify_requester_non_success(self, promo: str, requester_chat_id: int, results: list[PromoResult]) -> None:
        if not self._telegram_bot:
            return
        own = [r for r in results if int(r.chat_id) == int(requester_chat_id) and not r.ok]
        if not own:
            return
        own.sort(key=lambda r: int(r.account_slot or 999))
        lines = [f"Промо {promo}", "неуспешные статусы по вашим аккаунтам:", ""]
        for r in own:
            label = self._result_label(r)
            msg = self._promo_user_message(r)
            lines.append(f"{label}: {msg[:220]}")
        await self._telegram_bot.send_message(chat_id=requester_chat_id, text="\n".join(lines))

    async def activate_for_user(self, chat_id: int, promo: str, account_id: str | None = None) -> PromoResult:
        user = get_user(chat_id)
        if not account_id:
            account_id = str(getattr(user, "active_account_id", None) or "acc_1")
        account_id = str(account_id or "acc_1")
        key_id = self._account_key(chat_id, account_id)
        pending_future: asyncio.Future | None = None

        lock = self._locks.setdefault(key_id, asyncio.Lock())
        async with lock:
            self._active_promos.add(key_id)
            try:
                now = time.time()
                key = (key_id, promo)
                ts = self._processed_by_user.get(key)
                if ts is not None and (now - ts) <= self._processed_ttl_sec:
                    result = self._result_for_account(chat_id, account_id, False, "skipped", "already_processed")
                    print(f"[{_log_now()}] [RESULT] {self._account_label(chat_id, account_id)} promo={promo} status={result.status}", flush=True)
                    return result
                self._processed_by_user[key] = now

                account = get_user_account(chat_id, account_id) or {}
                mode = str(account.get("promo_activation_mode") or getattr(user, "promo_activation_mode", "server") or "server").strip().lower()
                if bool(account.get("promo_activation_paused", getattr(user, "promo_activation_paused", False))):
                    result = self._result_for_account(chat_id, account_id, False, "skipped", "promo_activation_paused")
                    print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} promo skipped: promo_activation_paused", flush=True)
                    return result

                if bool(account.get("subscription_paused")) or not has_active_account_subscription(int(chat_id), account_id, int(time.time())):
                    result = self._result_for_account(chat_id, account_id, False, "skipped", "subscription_frozen_or_inactive")
                    print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} promo skipped: subscription_frozen_or_inactive", flush=True)
                    return result

                if mode == "extension":
                    manager = self.extension_ws_manager
                    if manager is None:
                        return self._result_for_account(chat_id, account_id, False, "extension_unavailable", "Extension WS не запущен")
                    fingerprint = str(account.get("fingerprint_now") or "").strip()
                    if not manager.is_online(int(chat_id), account_id, fingerprint):
                        print(
                            f"[{_log_now()}] [EXT_PROMO] {self._account_label(chat_id, account_id)} "
                            f"{promo} offline ❌",
                            flush=True,
                        )
                        return self._result_for_account(
                            chat_id,
                            account_id,
                            False,
                            "extension_offline",
                            "extension_offline",
                        )
                    ext_res = await manager.send_promo_task(
                        chat_id=int(chat_id),
                        account_id=account_id,
                        username=str(getattr(user, "tg_username", "") or ""),
                        fingerprint=str(account.get("fingerprint_now") or "").strip(),
                        promo=promo,
                    )
                    status = str(ext_res.get("status") or ("success" if ext_res.get("ok") else "extension_error")).lower()
                    amount = ext_res.get("amount")
                    with contextlib.suppress(Exception):
                        if amount is not None:
                            amount = float(amount)
                    mines_status = str(ext_res.get("mines_status") or "").strip().lower() or None
                    mines_bet_amount = ext_res.get("mines_bet_amount")
                    mines_multiplier = ext_res.get("mines_multiplier")
                    mines_win_amount = ext_res.get("mines_win_amount")
                    mines_balance_after = ext_res.get("balance_after")
                    with contextlib.suppress(Exception):
                        if mines_bet_amount is not None:
                            mines_bet_amount = float(mines_bet_amount)
                    with contextlib.suppress(Exception):
                        if mines_multiplier is not None:
                            mines_multiplier = float(mines_multiplier)
                    with contextlib.suppress(Exception):
                        if mines_win_amount is not None:
                            mines_win_amount = float(mines_win_amount)
                    with contextlib.suppress(Exception):
                        if mines_balance_after is not None:
                            mines_balance_after = float(mines_balance_after)
                    message = _clean_html_text(str(ext_res.get("message") or ext_res.get("reason") or status))
                    task_id = str(ext_res.get("task_id") or "-")
                    result_source = str(ext_res.get("result_source") or "extension")
                    submit_ms = int(ext_res.get("submit_ms") or 0)
                    result_wait_ms = int(ext_res.get("result_wait_ms") or 0)
                    total_ms = int(ext_res.get("total_ms") or ext_res.get("server_wait_ms") or 0)
                    via = {
                        "casino_ws_update_balance": "balance",
                        "casino_ws_user_notify": "notify",
                        "promo_http": "http",
                        "server_timeout": "timeout",
                    }.get(result_source, result_source.replace("casino_ws_", "") or "extension")
                    low_message = message.lower().strip().rstrip(".")
                    friendly_transport = {
                        "promo_message_delivery_failed": "Не удалось передать промокод в служебную вкладку расширения.",
                        "content_script_unavailable": "Служебная вкладка расширения не готова.",
                        "managed_tab_not_ready": "Служебная вкладка расширения не готова.",
                        "extension_result_timeout": "Не получен итоговый результат активации от сайта.",
                        "result_timeout": "Не получен итоговый результат активации от сайта.",
                        "casino_ws_result_timeout": "Не получен итоговый результат активации от сайта.",
                    }
                    if low_message in friendly_transport:
                        message = friendly_transport[low_message]
                    if status in {"failed", "error"} and _is_promo_restriction_text(message):
                        status = "rejected"
                    elif "закончился" in message.lower() or "истек" in message.lower() or "истёк" in message.lower():
                        status = "expired"
                        message = message or "Этот промокод уже закончился."
                    elif "не существует" in message.lower() or "не найден" in message.lower():
                        status = "invalid"
                    elif "уже активировал" in message.lower() or "использован" in message.lower():
                        status = "used"
                    if status == "success":
                        print(
                            f"[{_log_now()}] [EXT_PROMO] {self._account_label(chat_id, account_id)} "
                            f"{promo} success ✅ amount={_format_promo_amount_for_log(amount)} "
                            f"submit_ms={submit_ms} via={via}",
                            flush=True,
                        )
                        with contextlib.suppress(Exception):
                            record_promo_activation(chat_id, amount, promo=promo, account_id=account_id)
                        with contextlib.suppress(Exception):
                            await notify_app_state_update(chat_id)
                        return self._result_for_account(
                            chat_id,
                            account_id,
                            True,
                            "success",
                            message or "ok",
                            amount,
                            mines_status=mines_status,
                            mines_bet_amount=mines_bet_amount,
                            mines_multiplier=mines_multiplier,
                            mines_win_amount=mines_win_amount,
                            mines_balance_after=mines_balance_after,
                        )
                    if status == "rejected":
                        print(
                            f"[{_log_now()}] [EXT_PROMO] {self._account_label(chat_id, account_id)} "
                            f"{promo} rejected ❌ reason={(message or status)[:220]} "
                            f"submit_ms={submit_ms} via={via}",
                            flush=True,
                        )
                    elif status in {"expired", "used", "invalid", "error"}:
                        print(
                            f"[{_log_now()}] [EXT_PROMO] {self._account_label(chat_id, account_id)} "
                            f"{promo} {status} ❌ reason={(message or status)[:220]} "
                            f"submit_ms={submit_ms} via={via}",
                            flush=True,
                        )
                    else:
                        print(
                            f"[{_log_now()}] [EXT_PROMO] {self._account_label(chat_id, account_id)} "
                            f"{promo} {status} ❌ reason={(message or status)[:220]} "
                            f"submit_ms={submit_ms} wait_ms={result_wait_ms} total_ms={total_ms} "
                            f"via={via} task={task_id}",
                            flush=True,
                        )
                    return self._result_for_account(chat_id, account_id, False, status, message or status)

                runtime_status = str(account.get("proxy_runtime_status") or "healthy").strip().lower()
                if runtime_status in {"unavailable", "site_unreachable", "recovering"}:
                    result = self._result_for_account(chat_id, account_id, False, "skipped", "proxy_runtime_unavailable")
                    print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} promo skipped: proxy runtime {runtime_status}", flush=True)
                    return result

                domain = get_active_domain()
                if not domain:
                    result = self._result_for_account(chat_id, account_id, False, "error", "Нет активного домена")
                    print(f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} {result.message}", flush=True)
                    return result

                csrf_token = str(account.get("csrf_token") or "").strip()
                fingerprint_now = str(account.get("fingerprint_now") or "").strip()
                if not csrf_token:
                    result = self._result_for_account(chat_id, account_id, False, "error", "Нет csrf_token")
                    print(f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} {result.message}", flush=True)
                    return result
                if not fingerprint_now:
                    result = self._result_for_account(chat_id, account_id, False, "error", "Нет fingerPrintNow")
                    print(f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} {result.message}", flush=True)
                    return result

                balance_before = None
                balance_before_task = asyncio.create_task(
                    self._get_casino_balance(chat_id, domain, account_id=account_id)
                )

                last_device_error = ""
                for attempt in range(0, PROMO_DEVICE_ALREADY_RETRY_MAX + 1):
                    if attempt > 0:
                        await asyncio.sleep(PROMO_DEVICE_ALREADY_RETRY_DELAY_SEC)
                        print(
                            f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} promoActivate retry "
                            f"attempt={attempt} starting",
                            flush=True,
                        )

                    captcha = None
                    captcha_max = max(1, PROMO_CAPTCHA_TRY_MAX)
                    
                    # Переменная для хранения хэша, который СРАБОТАЕТ
                    current_vpn_detect = ""

                    for captcha_try in range(captcha_max):
                        # ГЕНЕРИРУЕМ НОВЫЙ ХЭШ НА КАЖДЫЙ ЗАПРОС КАПЧИ
                        current_vpn_detect = hashlib.sha1(os.urandom(16)).hexdigest()
                        drag_ms = random.randint(350, 1350)
                        captcha_t0 = time.perf_counter()
                        try:
                            # Передаем только что сгенерированный хэш
                            captcha = await asyncio.wait_for(
                                self._captcha(chat_id, domain, csrf_token, drag_ms, account_id=account_id, vpn_detect=current_vpn_detect),
                                timeout=PROMO_CAPTCHA_TIMEOUT_SEC + 0.2,
                            )
                        except asyncio.TimeoutError:
                            captcha = None
                            self._last_captcha_status[key_id] = 0
                            print(
                                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                                f"SlideCapcha timeout {captcha_try + 1}/{captcha_max} after {PROMO_CAPTCHA_TIMEOUT_SEC:.1f}s",
                                flush=True,
                            )
                        except Exception as e:
                            captcha = None
                            self._last_captcha_status[key_id] = 0
                            print(
                                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                                f"SlideCapcha exception {captcha_try + 1}/{captcha_max}: {type(e).__name__}: {e}",
                                flush=True,
                            )

                        captcha_ms = (time.perf_counter() - captcha_t0) * 1000.0

                        # Если капча успешно получена — выходим из микро-цикла.
                        # В переменной current_vpn_detect останется именно тот хэш, на который выдали капчу!
                        if captcha:
                            break

                        if captcha_try < captcha_max - 1:
                            status = int(self._last_captcha_status.get(key_id) or 0)
                            delay = (
                                random.uniform(PROMO_CAPTCHA_429_RETRY_MIN_DELAY_SEC, PROMO_CAPTCHA_429_RETRY_MAX_DELAY_SEC)
                                if status == 429 else 0.05
                            )
                            print(
                                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                                f"SlideCapcha retry {captcha_try + 1}/{captcha_max} status={status} delay={delay:.3f}s",
                                flush=True,
                            )
                            await asyncio.sleep(delay)

                    if balance_before is None:
                        try:
                            balance_before = await balance_before_task
                        except Exception as e:
                            balance_before = None
                            print(
                                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                                f"balance_before failed: {type(e).__name__}: {e}",
                                flush=True,
                            )

                    if not captcha:
                        msg = "captcha failed"
                        if attempt == 0:
                            print(f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} SlideCapcha: пустой token", flush=True)
                            return self._result_for_account(chat_id, account_id, False, "error", msg)
                        print(
                            f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} promoActivate retry "
                            f"attempt={attempt} captcha_failed",
                            flush=True,
                        )
                        last_device_error = msg
                        continue
                    
                    delay = random.uniform(0.3, 0.8)
                    await asyncio.sleep(delay)

                    if self._pending_ws_count(chat_id, account_id) <= 0:
                        self.ws_manager.drain_events(chat_id, account_id=account_id)

                    print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} Активация промо {promo}: vpnDetect={current_vpn_detect}", flush=True)

                    activate_t0 = time.perf_counter()
                    
                    # ПЕРЕДАЕМ ТОТ ЖЕ ХЭШ, НА КОТОРЫЙ ТОЛЬКО ЧТО УСПЕШНО ВЗЯЛИ КАПЧУ
                    ok, msg = await self._promo_activate(
                        chat_id,
                        domain,
                        csrf_token,
                        promo,
                        captcha,
                        fingerprint_now,
                        account_id=account_id,
                        vpn_detect=current_vpn_detect,
                    )
                    activate_ms = (time.perf_counter() - activate_t0) * 1000.0
                    if not ok:
                        if _is_device_already_activated_error(msg) and attempt < PROMO_DEVICE_ALREADY_RETRY_MAX:
                            last_device_error = msg
                            print(
                                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} promoActivate retry "
                                f"attempt={attempt + 1} source=http msg={_clean_html_text(msg)[:160]}",
                                flush=True,
                            )
                            continue
                        clean_msg = _clean_html_text(msg)
                        if _is_promo_restriction_text(clean_msg):
                            print(
                                f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} "
                                f"promo rejected ❌: {clean_msg[:220]}",
                                flush=True,
                            )
                            return self._result_for_account(chat_id, account_id, False, "rejected", clean_msg)

                        print(
                            f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} ❌ {clean_msg} "
                            f"(promo={promo}, domain={domain}, csrf={str(csrf_token)[:8]}..., fp={str(fingerprint_now)[:8]}...)",
                            flush=True,
                        )
                        return self._result_for_account(chat_id, account_id, False, "error", clean_msg)

                    pending_future = await self._register_pending_ws(
                        chat_id,
                        account_id,
                        promo,
                        balance_before=balance_before,
                        domain=domain,
                    )
                    post_activate_delay = random.uniform(0.25, 0.5)
                    await asyncio.sleep(post_activate_delay)
                    break

                if pending_future is None:
                    err = last_device_error or "Ошибка активации."
                    print(
                        f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} ❌ {err} "
                        f"(promo={promo}, retry_limit={PROMO_DEVICE_ALREADY_RETRY_MAX})",
                        flush=True,
                    )
                    return self._result_for_account(chat_id, account_id, False, "error", err)
            finally:
                self._active_promos.discard(key_id)

        if pending_future is not None:
            return await pending_future
        return self._result_for_account(chat_id, account_id, False, "error", "Ошибка активации.")

    def _format_mines_bet_amount(self, amount: float | None) -> str:
        try:
            val = float(amount or 0)
        except Exception:
            return ""
        if val <= 0:
            return ""
        return str(int(val)) if val.is_integer() else f"{val:.2f}"

    async def _small_promo_mines_request(
        self,
        chat_id: int,
        account_id: str,
        *,
        method: str,
        url: str,
        data: dict[str, Any],
        domain: str,
    ) -> tuple[int, dict, str]:
        if _account_in_extension_mode(chat_id, account_id):
            return 0, {}, "extension_mode"
        acc = get_user_account(int(chat_id), str(account_id)) or {}
        if bool(acc.get("subscription_paused")):
            return 0, {}, "subscription_paused"
        if not has_active_account_subscription(int(chat_id), str(account_id), int(time.time())):
            return 0, {}, "subscription_inactive"
        if not _account_has_proxy_for_runtime(int(chat_id), acc):
            return 0, {}, "no_proxy"
        if not str(acc.get("zooma_top_session") or "").strip():
            return 0, {}, "no_zooma_top_session"
        resp = await user_http_request(
            chat_id=int(chat_id),
            account_id=str(account_id),
            method=method,
            url=url,
            headers={
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Accept": "*/*",
                "X-Requested-With": "XMLHttpRequest",
                "Origin": domain,
                "Referer": f"{domain}/mines",
            },
            data=data,
            timeout=7.0,
        )
        raw = resp.text or ""
        try:
            body = json.loads(raw)
        except Exception:
            body = {}
        return int(resp.status_code or 0), body if isinstance(body, dict) else {}, raw

    async def _run_small_promo_mines_server(
        self,
        chat_id: int,
        account_id: str,
        promo: str,
        amount: float | None,
        *,
        balance_before: float | None = None,
    ) -> dict[str, Any] | None:
        if not PROMO_SMALL_MINES_ENABLED or not _is_small_promo_for_mines(amount):
            return None
        if _account_in_extension_mode(chat_id, account_id):
            return None

        acc = get_user_account(int(chat_id), str(account_id)) or {}
        if bool(acc.get("subscription_paused")):
            return {"status": "skipped", "reason": "subscription_paused"}
        if not has_active_account_subscription(int(chat_id), str(account_id), int(time.time())):
            return {"status": "skipped", "reason": "subscription_inactive"}
        if not _account_has_proxy_for_runtime(int(chat_id), acc):
            return {"status": "skipped", "reason": "no_proxy"}
        if not str(acc.get("zooma_top_session") or "").strip():
            return {"status": "skipped", "reason": "no_zooma_top_session"}

        csrf_token = str(acc.get("csrf_token") or "").strip()
        if not csrf_token:
            return {"status": "skipped", "reason": "no_csrf_token"}

        domain = (get_active_domain() or "").strip().rstrip("/")
        if not domain:
            return {"status": "skipped", "reason": "active_domain_missing"}

        bet_amount = self._format_mines_bet_amount(amount)
        if not bet_amount:
            return None

        await asyncio.sleep(random.uniform(PROMO_SMALL_MINES_START_DELAY_MIN_SEC, PROMO_SMALL_MINES_START_DELAY_MAX_SEC))
        if _account_in_extension_mode(chat_id, account_id):
            return {"status": "skipped", "reason": "extension_mode"}

        try:
            http_status, body, raw = await self._small_promo_mines_request(
                chat_id,
                account_id,
                method="POST",
                url=f"{domain}/apiPost/minesStartGame",
                domain=domain,
                data={
                    "_token": csrf_token,
                    "totalBombs": str(int(PROMO_SMALL_MINES_TOTAL_BOMBS)),
                    "betAmount": bet_amount,
                    "arg2": "0",
                },
            )
            gid = str(body.get("gid") or "").strip()
            if http_status >= 400 or str(body.get("status") or "").lower() != "success" or not gid:
                return {
                    "status": "error",
                    "reason": _clean_html_text(str(body.get("text") or body.get("message") or raw or f"mines_start_http_{http_status}"))[:300],
                    "http_status": http_status,
                }

            await asyncio.sleep(random.uniform(PROMO_SMALL_MINES_ACTION_DELAY_MIN_SEC, PROMO_SMALL_MINES_ACTION_DELAY_MAX_SEC))
            if _account_in_extension_mode(chat_id, account_id):
                return {"status": "skipped", "reason": "extension_mode", "gid": gid}

            mine_id = random.randint(1, 25)
            http_status, body, raw = await self._small_promo_mines_request(
                chat_id,
                account_id,
                method="POST",
                url=f"{domain}/apiPost/minesStep",
                domain=domain,
                data={
                    "_token": csrf_token,
                    "mineId": str(mine_id),
                    "autoSelect": "",
                    "betAmount": bet_amount,
                    "arg2": "0",
                    "gid": gid,
                },
            )
            step_status = str(body.get("status") or "").lower()
            if http_status >= 400:
                return {
                    "status": "error",
                    "gid": gid,
                    "mine_id": mine_id,
                    "reason": _clean_html_text(str(body.get("text") or body.get("message") or raw or f"mines_step_http_{http_status}"))[:300],
                    "http_status": http_status,
                }
            if step_status == "bomb":
                print(
                    f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} "
                    f"small promo mines lost promo={promo} gid={gid} mine={mine_id} bet={bet_amount}",
                    flush=True,
                )
                return {
                    "status": "lost",
                    "gid": gid,
                    "mine_id": mine_id,
                    "bet_amount": float(amount or 0),
                    "win_amount": 0.0,
                    "multiplier": float(PROMO_SMALL_MINES_MULTIPLIER),
                    "reason": "bomb",
                }
            if step_status != "brilliant":
                return {
                    "status": "error",
                    "gid": gid,
                    "mine_id": mine_id,
                    "reason": _clean_html_text(str(body.get("text") or body.get("message") or step_status or "mines_step_unknown"))[:300],
                    "http_status": http_status,
                }

            await asyncio.sleep(random.uniform(PROMO_SMALL_MINES_ACTION_DELAY_MIN_SEC, PROMO_SMALL_MINES_ACTION_DELAY_MAX_SEC))
            if _account_in_extension_mode(chat_id, account_id):
                return {"status": "skipped", "reason": "extension_mode", "gid": gid, "mine_id": mine_id}

            http_status, body, raw = await self._small_promo_mines_request(
                chat_id,
                account_id,
                method="POST",
                url=f"{domain}/apiPost/minesStopGame",
                domain=domain,
                data={"_token": csrf_token, "arg2": "0", "gid": gid},
            )
            if http_status >= 400 or str(body.get("status") or "").lower() != "success":
                return {
                    "status": "cashout_error",
                    "gid": gid,
                    "mine_id": mine_id,
                    "bet_amount": float(amount or 0),
                    "multiplier": float(PROMO_SMALL_MINES_MULTIPLIER),
                    "reason": _clean_html_text(str(body.get("text") or body.get("message") or raw or f"mines_stop_http_{http_status}"))[:300],
                    "http_status": http_status,
                }

            win_amount = round(float(amount or 0) * float(PROMO_SMALL_MINES_MULTIPLIER), 2)
            balance_after = None
            with contextlib.suppress(Exception):
                balance_after = await self._get_casino_balance(chat_id, domain, account_id=account_id)
            if balance_after is None and balance_before is not None:
                with contextlib.suppress(Exception):
                    balance_after = round(float(balance_before) + win_amount, 2)
            print(
                f"[{_log_now()}] [SUCCESS] {self._account_label(chat_id, account_id)} "
                f"small promo mines won promo={promo} gid={gid} mine={mine_id} bet={bet_amount} win={win_amount}",
                flush=True,
            )
            return {
                "status": "won",
                "gid": gid,
                "mine_id": mine_id,
                "bet_amount": float(amount or 0),
                "win_amount": win_amount,
                "multiplier": float(PROMO_SMALL_MINES_MULTIPLIER),
                "balance_after": balance_after,
                "reason": "brilliant",
            }
        except Exception as e:
            return {"status": "error", "reason": f"{type(e).__name__}: {e}"[:300]}

    def is_user_promo_active(self, chat_id: int, account_id: str | None = None) -> bool:
        if account_id:
            return self._account_key(chat_id, account_id) in self._active_promos
        prefix = f"{int(chat_id)}:"
        return any(k.startswith(prefix) for k in self._active_promos)

    def _parse_money_value(self, raw: str) -> float | None:
        text = str(raw or "").replace("\u00a0", " ").replace("₽", "").strip()
        if not text:
            return None
        text = re.sub(r"[^0-9,\.\-]", "", text)
        if not text:
            return None
        if "," in text and "." in text:
            if text.rfind(",") > text.rfind("."):
                text = text.replace(".", "").replace(",", ".")
            else:
                text = text.replace(",", "")
        else:
            text = text.replace(",", ".")
        try:
            return round(float(text), 2)
        except Exception:
            return None

    def _extract_balance_from_casino_html(self, body: str) -> float | None:
        html_body = body or ""
        tags = re.findall(
            r"<span\b[^>]*js-user-balance[^>]*>.*?</span>",
            html_body,
            flags=re.IGNORECASE | re.DOTALL,
        )
        for tag in tags:
            m = re.search(r"data-value=[\"']([^\"']+)[\"']", tag, flags=re.IGNORECASE)
            if m:
                val = self._parse_money_value(m.group(1))
                if val is not None:
                    return val
            val = self._parse_money_value(_clean_html_text(tag))
            if val is not None:
                return val
        return None

    async def _get_casino_balance(self, chat_id: int, domain: str, account_id: str | None = None) -> float | None:
        if _account_in_extension_mode(chat_id, account_id):
            return None
        try:
            resp = await user_http_request(
                chat_id=chat_id,
                method="GET",
                url=f"{domain}/casino",
                headers={
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Referer": f"{domain}/casino",
                },
                timeout=PROMO_CASINO_BALANCE_TIMEOUT_SEC,
                account_id=account_id,
            )
        except Exception as e:
            print(
                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                f"casino balance request failed: {type(e).__name__}: {e}",
                flush=True,
            )
            return None

        if int(resp.status_code or 0) >= 400:
            print(
                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                f"casino balance http status={resp.status_code}",
                flush=True,
            )
            return None

        bal = self._extract_balance_from_casino_html(resp.text or "")
        if bal is None:
            print(
                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                f"casino balance not found",
                flush=True,
            )
        return bal

    async def _notify_success(self, chat_id: int, promo: str, amount_str: str) -> None:
        if not self._telegram_bot:
            print(f"[{_log_now()}] [ERROR] {self._chat_label(chat_id)} TG success notify skipped: no bot", flush=True)
            return
        text = (
            f"✅ Промокод <code>{html.escape(promo)}</code> активирован\n"
            f"💰 Сумма промо: {amount_str}"
        )
        last_err = None
        for attempt in range(1, 4):
            try:
                await self._telegram_bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML")
                return
            except Exception as e:
                last_err = e
                await asyncio.sleep(0.4 * attempt)

        print(
            f"[{_log_now()}] [ERROR] {self._chat_label(chat_id)} TG success notify failed "
            f"promo={promo} err={last_err}",
            flush=True,
        )
        if ADMIN_CHAT_ID and ADMIN_CHAT_ID != chat_id:
            try:
                await self._telegram_bot.send_message(
                    chat_id=ADMIN_CHAT_ID,
                    text=f"⚠️ Не удалось отправить юзеру уведомление об успешном промо\n"
                         f"Юзер: {self._chat_label(chat_id)}\nПромо: {promo}\nОшибка: {last_err}",
                )
            except Exception:
                pass

    async def _notify_account_result(self, promo: str, result: PromoResult, multi_account: bool = False) -> None:
        if not self._telegram_bot:
            return

        def _amount_view(amount: float | None) -> str | None:
            if amount is None:
                return None
            try:
                val = float(amount)
            except Exception:
                return None
            if val <= 0:
                return None
            return f"{val:.2f}"

        # Как раньше: юзеру пишем только если промо реально взято.
        # Ошибки/не взял/закончился остаются только в логах.
        if not result.ok:
            return
        if _is_small_promo_for_mines(result.amount) and str(result.mines_status or "").strip().lower() != "won":
            return

        amount_s = _amount_view(result.amount)
        amount_line = f"💰 Сумма промо: {amount_s}" if amount_s else "💰 Сумма промо: -"
        mines_line = self._mines_result_line(result)

        if not multi_account:
            lines = [
                f"✅ Промокод <code>{html.escape(promo)}</code> активирован",
                amount_line,
            ]
            if mines_line:
                lines.append(mines_line)
            text = (
                "\n".join(lines)
            )
        else:
            label = html.escape(self._result_label(result))
            lines = [
                f"Промокод <code>{html.escape(promo)}</code>",
                amount_line,
            ]
            if mines_line:
                lines.append(mines_line)
            lines.extend(["", f"{label} : активирован ✅"])
            text = (
                "\n".join(lines)
            )

        last_err = None
        for attempt in range(1, 4):
            try:
                await self._telegram_bot.send_message(
                    chat_id=int(result.chat_id),
                    text=text,
                    parse_mode="HTML",
                )
                return
            except Exception as e:
                last_err = e
                await asyncio.sleep(0.25 * attempt)

        print(
            f"[{_log_now()}] [ERROR] {self._chat_label(result.chat_id)} TG immediate notify failed "
            f"promo={promo} err={last_err}",
            flush=True,
        )

    async def _notify_group_results(self, promo: str, results: list[PromoResult]) -> None:
        if not self._telegram_bot or not results:
            return

        grouped: dict[int, list[PromoResult]] = {}
        for r in results:
            grouped.setdefault(int(r.chat_id), []).append(r)

        def _amount_view(amount: float | None) -> str | None:
            if amount is None:
                return None
            try:
                val = float(amount)
            except Exception:
                return None
            if val <= 0:
                return None
            return f"{val:.2f}"

        for chat_id, rows in grouped.items():
            rows = [
                r for r in rows
                if not (_is_small_promo_for_mines(r.amount) and str(r.mines_status or "").strip().lower() != "won")
            ]
            if not any(r.ok for r in rows):
                continue

            rows.sort(key=lambda r: int(r.account_slot or 999))
            amount = None
            for r in rows:
                if r.ok and r.amount is not None:
                    amount = r.amount
                    break
            if amount is None:
                for r in rows:
                    if r.amount is not None:
                        amount = r.amount
                        break

            amount_s = _amount_view(amount)
            amount_line = f"💰 Сумма промо: {amount_s}" if amount_s else "💰 Сумма промо: -"

            if len(rows) == 1:
                r = rows[0]
                if not r.ok:
                    continue
                mines_line = self._mines_result_line(r)
                lines = [
                    f"✅ Промокод <code>{html.escape(promo)}</code> активирован",
                    amount_line,
                ]
                if mines_line:
                    lines.append(mines_line)
                text = (
                    "\n".join(lines)
                )
            else:
                lines = [
                    f"Промокод <code>{html.escape(promo)}</code>",
                    amount_line,
                    "",
                ]

                for r in rows:
                    label = html.escape(self._result_label(r))
                    if r.ok:
                        lines.append(f"{label} : активирован ✅")
                        mines_line = self._mines_result_line(r)
                        if mines_line:
                            lines.append(mines_line)
                    else:
                        lines.append(f"{label} : не активирован ❌")
                    lines.append("")

                text = "\n".join(lines).rstrip()
            last_err = None
            for attempt in range(1, 4):
                try:
                    await self._telegram_bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML")
                    break
                except Exception as e:
                    last_err = e
                    await asyncio.sleep(0.4 * attempt)
            else:
                print(
                    f"[{_log_now()}] [ERROR] {self._chat_label(chat_id)} TG group notify failed "
                    f"promo={promo} err={last_err}",
                    flush=True,
                )

    async def _notify_session_stale(self, chat_id: int) -> None:
        if not self._telegram_bot:
            return
        try:
            await self._telegram_bot.send_message(chat_id=chat_id, text="сессия протухла")
        except Exception:
            pass

    async def _captcha(self, chat_id: int, domain: str, csrf_token: str, drag_ms: int, account_id: str | None = None, vpn_detect: str = "") -> str | None:
        if _account_in_extension_mode(chat_id, account_id):
            return None
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "*/*",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": domain,
            "Referer": f"{domain}/affilates",
        }
        payload = {
            "_token": csrf_token, 
            "dragMs": str(drag_ms),
            "vpnDetect": vpn_detect
        }
        try:
            resp = await user_http_request(
                chat_id=chat_id,
                method="POST",
                url=f"{domain}/apiPost/slideCapchaIssue",
                headers=headers,
                data=payload,
                timeout=PROMO_CAPTCHA_TIMEOUT_SEC,
                account_id=account_id,
            )
        except Exception as e:
            self._last_captcha_status[self._account_key(chat_id, account_id)] = 0
            print(
                f"[{_log_now()}] [WARNING] {self._account_label(chat_id, account_id)} "
                f"SlideCapcha request failed: {type(e).__name__}: {e}",
                flush=True,
            )
            return None

        self._last_captcha_status[self._account_key(chat_id, account_id)] = int(resp.status_code or 0)

        raw_text = resp.text or ""
        try:
            data = json.loads(raw_text)
        except Exception:
            data = {}

        token = ""
        if isinstance(data, dict):
            token = str(data.get("token") or data.get("capcha") or "").strip()
            if not token and isinstance(data.get("data"), dict):
                token = str(data["data"].get("token") or "").strip()

        if not token:
            ctype = ""
            try:
                ctype = str(resp.headers.get("content-type", "") or "")
            except Exception:
                ctype = ""
            print(
                f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} SlideCapcha: пустой token "
                f"status={resp.status_code} content_type={ctype[:80]} "
                f"json={str(data)[:240]} body={raw_text[:300]!r}",
                flush=True,
            )

        return token or None

    async def _promo_activate(
        self,
        chat_id: int,
        domain: str,
        csrf_token: str,
        promo: str,
        captcha: str,
        fingerprint_now: str,
        account_id: str | None = None,
        vpn_detect: str = "",
    ) -> tuple[bool, str]:
        if _account_in_extension_mode(chat_id, account_id):
            return False, "extension_mode"
        form_data = {
            "_token": csrf_token,
            "promoName2023": promo,
            "capcha": captcha,
            "fingerPrintNow": fingerprint_now,
            "vpnDetect": vpn_detect
        }
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "*/*",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": domain,
            "Referer": f"{domain}/affilates",
        }
        try:
            try:
                resp = await user_http_request(
                    chat_id=chat_id,
                    method="POST",
                    url=f"{domain}/apiPost/promoActivate",
                    headers=headers,
                    data=form_data,
                    timeout=PROMO_ACTIVATE_TIMEOUT_SEC,
                    account_id=account_id,
                )
            except Exception as e:
                print(
                    f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} "
                    f"promoActivate retry request failed: {type(e).__name__}: {e}",
                    flush=True,
                )
                return False, "Ошибка активации."
        except Exception as e:
            print(
                f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} "
                f"promoActivate request failed: {type(e).__name__}: {e}",
                flush=True,
            )
            return False, "Ошибка активации."
        
        if resp.status_code == 429:
            await asyncio.sleep(random.uniform(0.1, 0.3))
            if _account_in_extension_mode(chat_id, account_id):
                return False, "extension_mode"
            resp = await user_http_request(
                chat_id=chat_id,
                method="POST",
                url=f"{domain}/apiPost/promoActivate",
                headers=headers,
                data=form_data,
                timeout=PROMO_ACTIVATE_TIMEOUT_SEC,
                account_id=account_id,
            )
        try:
            result = json.loads(resp.text)
        except Exception:
            result = {"status": str(resp.status_code), "text": resp.text[:200]}
        if isinstance(result, dict) and result.get("status") == "error":
            err_text = _clean_html_text(str(result.get("text", ""))) or "Ошибка активации."
            if not _is_promo_restriction_text(err_text):
                print(
                    f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} promoActivate error "
                    f"status={resp.status_code} body={str(result)[:600]}",
                    flush=True,
                )
            return False, err_text
        if int(resp.status_code) >= 400:
            print(
                f"[{_log_now()}] [ERROR] {self._account_label(chat_id, account_id)} promoActivate http_fail "
                f"status={resp.status_code} body={str(resp.text)[:600]}",
                flush=True,
            )
            return False, "Ошибка активации."
        return True, "ok"

    @staticmethod
    def _session_probe_response_body(resp) -> tuple[dict, str]:
        raw = " ".join(str(getattr(resp, "text", "") or "").split())[:600]
        try:
            payload = json.loads(getattr(resp, "text", "") or "{}")
        except Exception:
            payload = {}
        return (payload if isinstance(payload, dict) else {}), raw

    async def _probe_session_detail(self, chat_id: int, domain: str, csrf_token: str, account_id: str | None = None) -> dict:
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "*/*",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": domain,
            "Referer": f"{domain}/mines",
        }
        data = {
            "_token": csrf_token,
            "totalBombs": "3",
            "betAmount": "9999999",
            "arg2": "0",
        }
        try:
            resp = await user_http_request(
                chat_id=chat_id,
                method="POST",
                url=f"{domain}/apiPost/minesStartGame",
                headers=headers,
                data=data,
                account_id=account_id,
            )
        except Exception as exc:
            return {
                "valid": False,
                "status": "request_error",
                "http_status": 0,
                "body": f"{type(exc).__name__}: {exc}"[:600],
            }
        payload, raw = self._session_probe_response_body(resp)
        http_status = int(getattr(resp, "status_code", 0) or 0)
        message = str(payload.get("message") or "").strip()
        site_status = str(payload.get("status") or "").strip()
        site_text = str(payload.get("text") or "").strip()
        if http_status == 401 and message.casefold().rstrip(".") == "unauthenticated":
            return {"valid": False, "status": "session_stale", "http_status": http_status, "body": raw}
        if http_status == 419 and "message" in payload and not message and not site_status and not site_text:
            return {"valid": False, "status": "session_stale", "http_status": http_status, "body": raw}
        if http_status == 419:
            return {"valid": False, "status": "http_419_unknown", "http_status": http_status, "body": raw}
        if http_status >= 500:
            return {"valid": False, "status": "site_transient_error", "http_status": http_status, "body": raw}
        if 200 <= http_status < 400 and payload and (message or site_status or site_text):
            return {"valid": True, "status": "ok", "http_status": http_status, "body": raw}
        if 200 <= http_status < 400:
            return {"valid": False, "status": "empty_response" if not raw or payload == {} else "unexpected_response", "http_status": http_status, "body": raw}
        return {"valid": False, "status": "http_error", "http_status": http_status, "body": raw}

    async def probe_user_session_detail(
        self,
        chat_id: int,
        account_id: str | None = None,
        *,
        require_connected: bool = True,
    ) -> dict:
        if _account_in_extension_mode(chat_id, account_id):
            return {"valid": True, "status": "extension_mode", "http_status": 0, "body": ""}
        user = get_user(chat_id)
        domain = get_active_domain()
        aid = str(account_id or getattr(user, "active_account_id", None) or "acc_1")
        acc = get_user_account(chat_id, aid) or {}
        if not domain:
            return {"valid": False, "status": "no_active_domain", "http_status": 0, "body": ""}
        if require_connected and not self.ws_manager.is_connected(chat_id, account_id=aid):
            return {"valid": False, "status": "ws_not_connected", "http_status": 0, "body": ""}
        csrf_token = str(acc.get("csrf_token") or "").strip()
        session = str(acc.get("zooma_top_session") or "").strip()
        if not session or not csrf_token:
            return {"valid": False, "status": "missing_auth", "http_status": 0, "body": ""}
        return await self._probe_session_detail(chat_id, domain, csrf_token, account_id=aid)

    async def probe_user_session(self, chat_id: int, account_id: str | None = None) -> bool:
        detail = await self.probe_user_session_detail(chat_id, account_id=account_id)
        return bool(detail.get("valid"))

    async def _wait_ws(self, chat_id: int, timeout: int = 12, account_id: str | None = None) -> tuple[str, str | None, float | None]:
        deadline = asyncio.get_running_loop().time() + timeout
        while asyncio.get_running_loop().time() < deadline:
            event = await self.ws_manager.wait_event(chat_id, timeout=0.5, account_id=account_id)
            if not event:
                continue
            event_type = str(event.get("type") or "")
            data = event.get("data") or {}
            data = data if isinstance(data, dict) else {}

            if event_type == "userNotify":
                text1 = str(data.get("argumentOne", "") or "").strip()
                raw_text2 = data.get("argumentTwo", "")
                text2 = "" if isinstance(raw_text2, bool) or raw_text2 is None else str(raw_text2).strip()
                clean1 = _clean_html_text(text1)
                clean2 = _clean_html_text(text2)
                status1, clean1 = _parse_promo_status(text1)
                status2, clean2 = _parse_promo_status(text2)
                if status1 == "queued" and clean1:
                    print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} userNotify: {clean1}", flush=True)
                if status2 == "queued" and clean2 and clean2 != clean1:
                    print(f"[{_log_now()}] [INFO] {self._account_label(chat_id, account_id)} userNotify: {clean2}", flush=True)
                if status1 == "success" or status2 == "success":
                    amount = _extract_amount_from_text(text2) or _extract_amount_from_text(text1)
                    return "success", "ok", amount
                for st, msg in ((status1, clean1), (status2, clean2)):
                    if st in {"expired", "used", "invalid", "error"}:
                        return st or "error", msg, None

            if event_type == "updateBalance":
                try:
                    old = float(data.get("argumentOne", 0) or 0)
                    new = float(data.get("argumentTwo", 0) or 0)
                    amount = round(new - old, 2)
                except Exception:
                    amount = 0
                if amount > 0:
                    return "success", "ok", amount

        return "timeout", None, None
