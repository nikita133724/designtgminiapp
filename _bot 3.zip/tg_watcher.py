from __future__ import annotations

import argparse
import asyncio
import contextlib
import html
import inspect
import json
import logging
import os
import re
import signal
import sys
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable

import httpx
from aiohttp import web
import socks
from telethon import TelegramClient, events
from telethon.errors import FloodWaitError
from telethon.tl.functions.messages import CheckChatInviteRequest, ImportChatInviteRequest, GetDialogFiltersRequest, UpdateDialogFilterRequest
from telethon.tl.types import ChatInviteAlready, DialogFilter

# Подключаем uvloop только для отдельного CLI-запуска. При импорте из main.py
# event loop уже создан python-telegram-bot, поэтому policy менять нельзя.
if os.getenv("ZOOMA_TG_WATCHER_UVLOOP", "0").strip().lower() in {"1", "true", "yes", "on"}:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        try:
            import uvloop
            asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        except ImportError:
            pass

try:
    from colorama import init, Fore, Style
except Exception:
    class _ColorFallback:
        BLACK = RED = GREEN = YELLOW = BLUE = MAGENTA = CYAN = WHITE = RESET_ALL = ""
    Fore = _ColorFallback()
    Style = _ColorFallback()
    def init(*args, **kwargs):
        return None

init(autoreset=True)

API_ID = int(os.getenv("TG_API_ID", "32239812"))
API_HASH = os.getenv("TG_API_HASH", "c3d44d0e49d0c637d7a6476eed4294a9")
TG_SESSION = os.getenv("TG_SESSION", os.path.join(os.path.dirname(os.path.abspath(__file__)), "saxarokchatzooma"))
if not os.path.isabs(TG_SESSION):
    TG_SESSION = os.path.join(os.path.dirname(os.path.abspath(__file__)), TG_SESSION)

TG_FOLDER_SYNC_ENABLED = os.getenv("ZOOMA_TG_FOLDER_SYNC_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
TG_FOLDER_SYNC_HTTP_ENABLED = os.getenv("ZOOMA_TG_FOLDER_SYNC_HTTP_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
TG_FOLDER_SYNC_HOST = os.getenv("ZOOMA_TG_FOLDER_SYNC_HOST", "127.0.0.1").strip()
TG_FOLDER_SYNC_PORT = int(os.getenv("ZOOMA_TG_FOLDER_SYNC_PORT", "8791").strip() or "8791")
TG_FOLDER_SYNC_PATH = os.getenv("ZOOMA_TG_FOLDER_SYNC_PATH", "/internal/folder/sync").strip() or "/internal/folder/sync"
TG_FOLDER_SYNC_TITLE = os.getenv("ZOOMA_TG_FOLDER_SYNC_TITLE", "скрипт зума").strip() or "скрипт зума"
TG_FOLDER_SYNC_SECRET = os.getenv("ZOOMA_TG_FOLDER_SYNC_SECRET", "").strip()
TG_FOLDER_SYNC_DEBOUNCE_SEC = float(os.getenv("ZOOMA_TG_FOLDER_SYNC_DEBOUNCE_SEC", "0.2").strip() or "0.2")
TG_FOLDER_SYNC_SKIP_IDS_RAW = os.getenv("ZOOMA_TG_FOLDER_SYNC_SKIP_CHAT_IDS", "754274025").strip()
CHANNELS = [x.strip() for x in os.getenv(
    "TG_CHANNELS",
    "DrRGNpromo,AnfibiaKazino,sjjakskskzkzkz,brat737,csgorunonly,verner1155,zooma1,aztrash2,zooma_officia,zooma_reserve,MaloyCSer2,maksone1,zooma_promocod,MilitarinAzart,l1way2,Keentsquad,3235065832,forkayt,kadillakincasino,DJABYSLOTS,zevianz,4454699746,vbudke123",
).split(",") if x.strip()]
TG_PRIVATE_INVITE_AUTO_JOIN = os.getenv("ZOOMA_TG_PRIVATE_INVITE_AUTO_JOIN", "0").strip().lower() in {"1", "true", "yes", "on"}

PROXY_HOST = os.getenv(
    "TG_WATCHER_PROXY_HOST",
    os.getenv("TG_PROXY_HOST", "127.0.0.1"),
).strip()

PROXY_PORT = int(os.getenv(
    "TG_WATCHER_PROXY_PORT",
    os.getenv("TG_PROXY_PORT", "1080"),
))

PROXY_USERNAME = os.getenv("TG_WATCHER_PROXY_USERNAME", "").strip()
PROXY_PASSWORD = os.getenv("TG_WATCHER_PROXY_PASSWORD", "").strip()

USE_PROXY = os.getenv("ZOOMA_USE_PROXY", "1").strip().lower() in {
    "1", "true", "yes", "on"
}

PROXY_SETTINGS = (
    socks.SOCKS5,
    PROXY_HOST,
    PROXY_PORT,
    True,
    PROXY_USERNAME or None,
    PROXY_PASSWORD or None,
) if USE_PROXY and PROXY_HOST and PROXY_PORT > 0 else None

PROMO_MASKED_RE = r"((?i:ZM)_[A-Za-z0-9*]+)"
PROCESSED_PROMO_TTL_SEC = int(os.getenv("ZOOMA_PROCESSED_PROMO_TTL_SEC", "1800"))
MASKED_PROMO_PENDING_TTL_SEC = int(os.getenv("ZOOMA_MASKED_PROMO_PENDING_TTL_SEC", "1800"))

TG_POLL_ENABLED = os.getenv("ZOOMA_TG_POLL_ENABLED", "1").strip().lower() in {"1", "true", "yes", "on"}
TG_POLL_INTERVAL_SEC = float(os.getenv("ZOOMA_TG_WATCHER_POLL_INTERVAL_SEC", os.getenv("ZOOMA_TG_POLL_INTERVAL_SEC", "0.50")))
TG_POLL_LIMIT = int(os.getenv("ZOOMA_TG_WATCHER_POLL_LIMIT", os.getenv("ZOOMA_TG_POLL_LIMIT", "1")))
TG_POLL_CONCURRENCY = int(os.getenv("ZOOMA_TG_WATCHER_POLL_CONCURRENCY", os.getenv("ZOOMA_TG_POLL_CONCURRENCY", "10")))
TG_POLL_PER_CHANNEL_INTERVAL_SEC = float(os.getenv("ZOOMA_TG_WATCHER_POLL_PER_CHANNEL_SEC", "8.0"))
TG_MESSAGE_DEDUP_TTL_SEC = int(os.getenv("ZOOMA_TG_MESSAGE_DEDUP_TTL_SEC", "3600"))
TG_QUEUED_PROMO_TTL_SEC = int(os.getenv("ZOOMA_TG_QUEUED_PROMO_TTL_SEC", "1800"))
TG_POLL_START_BACKFILL_SEC = float(os.getenv("ZOOMA_TG_POLL_START_BACKFILL_SEC", "15.0"))
TG_POLL_MAX_MESSAGE_AGE_SEC = float(os.getenv("ZOOMA_TG_POLL_MAX_MESSAGE_AGE_SEC", "60.0"))
TG_WATCHER_DIAG_INTERVAL_SEC = float(os.getenv("ZOOMA_TG_WATCHER_DIAG_INTERVAL_SEC", "60.0"))
TG_WATCHER_LOG_NO_PROMO = os.getenv("ZOOMA_TG_WATCHER_LOG_NO_PROMO", "0").strip().lower() in {"1", "true", "yes", "on"}
TG_WATCHER_POLL_VERBOSE = os.getenv("ZOOMA_TG_WATCHER_POLL_VERBOSE", "0").strip().lower() in {"1", "true", "yes", "on"}
TG_WATCHER_POLL_DIAG = os.getenv("ZOOMA_TG_WATCHER_POLL_DIAG", "0").strip().lower() in {"1", "true", "yes", "on"}
TG_WATCHER_DIAG_LOGS = os.getenv("ZOOMA_TG_WATCHER_DIAG_LOGS", "0").strip().lower() in {"1", "true", "yes", "on"}
TG_POLL_AUTO_GAP_START_SEC = float(os.getenv("ZOOMA_TG_WATCHER_AUTO_GAP_START_SEC", "1.0"))
TG_POLL_AUTO_GAP_MIN_SEC = float(os.getenv("ZOOMA_TG_WATCHER_AUTO_GAP_MIN_SEC", "0.25"))
TG_POLL_AUTO_GAP_MAX_SEC = float(os.getenv("ZOOMA_TG_WATCHER_AUTO_GAP_MAX_SEC", "10.0"))
TG_POLL_AUTO_FIRST_OK_REQUESTS = int(os.getenv("ZOOMA_TG_WATCHER_AUTO_FIRST_OK", "3"))
TG_POLL_AUTO_OK_REQUESTS = int(os.getenv("ZOOMA_TG_WATCHER_AUTO_OK", "5"))
TG_POLL_AUTO_DECAY = float(os.getenv("ZOOMA_TG_WATCHER_AUTO_DECAY", "0.80"))
TG_POLL_AUTO_GOLDEN_MARGIN = float(os.getenv("ZOOMA_TG_WATCHER_AUTO_GOLDEN_MARGIN", "1.05"))
TG_POLL_AUTO_FLOOD_COOLDOWN_MARGIN = float(os.getenv("ZOOMA_TG_WATCHER_AUTO_FLOOD_COOLDOWN_MARGIN", "1.15"))
TG_POLL_AUTO_CONFIRM_ROUNDS = int(os.getenv("ZOOMA_TG_WATCHER_AUTO_CONFIRM_ROUNDS", "2"))
TG_POLL_GAP_FETCH_LIMIT = int(os.getenv("ZOOMA_TG_WATCHER_GAP_FETCH_LIMIT", "5"))



EMOJI_MAP = {
    # --- Твои старые латинские буквы ---
    5226734466315067436: "A", 5330453760395191684: "B", 5330523098347218561: "C",
    5361630910816984823: "d", 5332587336939084375: "e", 5330369145244491360: "f",
    5361861335812416268: "g", 5330133162561380231: "h", 5381808177547321132: "i",
    5330383228442258084: "j", 5330026574357996347: "k", 5332396623211274002: "l",
    5332321341024508571: "m", 5359736027080565026: "n", 5361583176550457135: "o",
    5361909160273255840: "p", 5361948540828393629: "q", 5332514996804918116: "r",
    5332807088940785741: "s", 5332558333024934589: "t", 5330069773139059849: "u",
    5395613572531232916: "v", 5332308237079288987: "w", 5332575697577714724: "x",
    5332648110726323166: "y", 5330309934825351007: "z",

    # --- Твои старые цифры и знаки ---
    5393480373944459905: "0", 5382322671679708881: "1", 5381990043642502553: "2",
    5381879959335738545: "3", 5382054253403577563: "4", 5391197405553107640: "5",
    5390966190283694453: "6", 5382132232829804982: "7", 5391038994274329680: "8",
    5391234698754138414: "9", 5382261056078881010: "-", 5404702371869631372: "-",
    5393194986252542669: "+", 5393189480104468641: "*", 5407101652270325420: "/",
    
    # --- Новые цифры и знаки из второго пака ---
    5238055991517390123: "0", 5235776368905562305: "1", 5237704680372447424: "2",
    5238044171767393675: "3", 5235533321001250232: "4", 5238171599152097811: "5",
    5235500881113263583: "6", 5237875542761417785: "7", 5238067300166281132: "8",
    5237872922831367023: "9", 5255775038010829248: "-", 5253652327734192243: "+",
    5255923484965481228: "/", 5256110225848543598: "*"
}


_OMSK_TZ = timezone(timedelta(hours=6))
PENDING_MASKED_PROMOS: dict[str, list[dict[str, Any]]] = {}
processed_tg_messages: dict[str, float] = {}
queued_promos: dict[str, float] = {}
last_seen_ids: dict[str, int] = {}
last_diag_ts: dict[str, float] = {}
poll_started_utc = datetime.now(timezone.utc)
stop_event: asyncio.Event | None = None
folder_sync_pending_users: list[dict[str, Any]] = []
folder_sync_pending_reason: str = ""
folder_sync_task: asyncio.Task[Any] | None = None
folder_sync_client: TelegramClient | None = None
folder_sync_my_id: int | None = None
folder_sync_lock: asyncio.Lock | None = None
in_memory_promo_handler: Callable[[dict[str, Any]], Awaitable[dict[str, Any]] | dict[str, Any]] | None = None


def set_in_memory_promo_handler(handler: Callable[[dict[str, Any]], Awaitable[dict[str, Any]] | dict[str, Any]] | None) -> None:
    global in_memory_promo_handler
    in_memory_promo_handler = handler


def _parse_int_set(raw: str) -> set[int]:
    out: set[int] = set()
    for part in str(raw or "").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        with contextlib.suppress(Exception):
            out.add(int(part))
    return out


TG_FOLDER_SYNC_SKIP_IDS = _parse_int_set(TG_FOLDER_SYNC_SKIP_IDS_RAW)


def _dialog_filter_title(value: Any) -> str:
    title = getattr(value, "title", "")
    if hasattr(title, "text"):
        return str(getattr(title, "text") or "")
    return str(title or "")


def _make_dialog_filter(folder_id: int, title: str, peers: list[Any], existing: Any = None) -> Any:
    if isinstance(existing, DialogFilter):
        existing.include_peers = list(peers)
        existing.pinned_peers = []
        existing.exclude_peers = []
        for attr in (
            "contacts",
            "non_contacts",
            "groups",
            "broadcasts",
            "bots",
            "exclude_muted",
            "exclude_read",
            "exclude_archived",
        ):
            if hasattr(existing, attr):
                with contextlib.suppress(Exception):
                    setattr(existing, attr, False)
        return existing

    base = {
        "id": int(folder_id),
        "title": str(title),
        "pinned_peers": [],
        "include_peers": list(peers),
        "exclude_peers": [],
        "contacts": False,
        "non_contacts": False,
        "groups": False,
        "broadcasts": False,
        "bots": False,
        "exclude_muted": False,
        "exclude_read": False,
        "exclude_archived": False,
    }

    variants = [
        {**base, "emoticon": None, "color": None, "title_noanimate": False},
        {**base, "emoticon": None, "color": None},
        {**base, "emoticon": None},
        base,
    ]
    last_err = None
    for kwargs in variants:
        try:
            return DialogFilter(**kwargs)
        except TypeError as e:
            last_err = e
    raise last_err or RuntimeError("cannot_create_dialog_filter")


async def _get_or_create_folder_id(client: TelegramClient, title: str) -> tuple[int, Any | None]:
    result = await client(GetDialogFiltersRequest())

    filters = getattr(result, "filters", result)
    if filters is None:
        filters = []

    used_ids: set[int] = set()
    for f in filters:
        fid = getattr(f, "id", None)
        with contextlib.suppress(Exception):
            used_ids.add(int(fid))
        if _dialog_filter_title(f).strip().lower() == str(title).strip().lower():
            return int(getattr(f, "id")), f

    for fid in range(2, 11):
        if fid not in used_ids:
            return fid, None
    return 10, None


async def _resolve_folder_peers(client: TelegramClient, users: list[dict[str, Any]], my_id: int | None) -> tuple[list[Any], dict[str, Any]]:
    peers: list[Any] = []
    seen_keys: set[str] = set()
    stats = {
        "users": len(users or []),
        "resolved": 0,
        "unresolved": 0,
        "skipped_admin": 0,
        "skipped_self": 0,
        "unresolved_items": [],
    }

    for item in users or []:
        try:
            chat_id = int((item or {}).get("chat_id") or 0)
        except Exception:
            chat_id = 0

        username = str((item or {}).get("username") or "").strip()
        if username and not username.startswith("@"):
            username = "@" + username

        if chat_id and chat_id in TG_FOLDER_SYNC_SKIP_IDS:
            stats["skipped_admin"] += 1
            continue
        if chat_id and my_id and int(chat_id) == int(my_id):
            stats["skipped_self"] += 1
            continue

        key = username.lower() if username else str(chat_id)
        if not key or key in seen_keys:
            continue
        seen_keys.add(key)

        candidates: list[Any] = []
        if username:
            candidates.append(username)
        if chat_id:
            candidates.append(chat_id)

        resolved = None
        last_error = ""
        for cand in candidates:
            try:
                resolved = await client.get_input_entity(cand)
                break
            except Exception as e:
                last_error = f"{type(e).__name__}: {e}"

        if resolved is None:
            stats["unresolved"] += 1
            stats["unresolved_items"].append({"chat_id": chat_id, "username": username, "reason": last_error[:180]})
            continue

        peers.append(resolved)
        stats["resolved"] += 1

    return peers, stats


def _folder_peer_key(peer: Any) -> str:
    for attr in ("user_id", "chat_id", "channel_id", "id"):
        with contextlib.suppress(Exception):
            val = int(getattr(peer, attr) or 0)
            if val:
                return f"{attr}:{val}"
    return repr(peer)


async def _apply_folder_sync(client: TelegramClient, users: list[dict[str, Any]], *, reason: str = "", my_id: int | None = None) -> dict[str, Any]:
    peers, stats = await _resolve_folder_peers(client, users, my_id)
    folder_id, existing = await _get_or_create_folder_id(client, TG_FOLDER_SYNC_TITLE)

    old_keys = sorted(_folder_peer_key(p) for p in (getattr(existing, "include_peers", []) or []))
    new_keys = sorted(_folder_peer_key(p) for p in peers)
    changed = (existing is None) or (old_keys != new_keys)

    for item in stats.get("unresolved_items", [])[:10]:
        _watcher_print_special(
            _TG_FOLDER_BLUE,
            f"[TG-FOLDER] unresolved chat_id={item.get('chat_id')} username={item.get('username') or '-'} "
            f"reason={item.get('reason') or '-'}",
        )

    if not changed:
        return {"ok": True, "changed": False, "folder_id": folder_id, **stats}

    added = max(0, len(set(new_keys) - set(old_keys)))
    removed = max(0, len(set(old_keys) - set(new_keys)))

    dialog_filter = _make_dialog_filter(folder_id, TG_FOLDER_SYNC_TITLE, peers, existing=existing)
    await client(UpdateDialogFilterRequest(id=int(folder_id), filter=dialog_filter))

    _watcher_print_special(
        _TG_FOLDER_BLUE,
        f"[TG-FOLDER] changed folder=\"{TG_FOLDER_SYNC_TITLE}\" id={folder_id} "
        f"reason={reason or '-'} users={stats['users']} resolved={stats['resolved']} "
        f"added={added} removed={removed} total={len(new_keys)} "
        f"unresolved={stats['unresolved']} skipped_admin={stats['skipped_admin']} skipped_self={stats['skipped_self']}",
    )

    return {"ok": True, "changed": True, "folder_id": folder_id, "added": added, "removed": removed, **stats}


async def _folder_sync_run_now(client: TelegramClient, my_id: int | None, users: list[dict[str, Any]], reason: str) -> None:
    global folder_sync_lock

    if folder_sync_lock is None:
        folder_sync_lock = asyncio.Lock()

    async with folder_sync_lock:
        try:
            await _apply_folder_sync(client, list(users or []), reason=reason, my_id=my_id)
        except Exception as e:
            _watcher_print_special(_TG_FOLDER_BLUE, f"[TG-FOLDER] sync failed: {type(e).__name__}: {e}")


async def _folder_sync_debounced(client: TelegramClient, my_id: int | None) -> None:
    global folder_sync_pending_users, folder_sync_pending_reason, folder_sync_task, folder_sync_lock

    await asyncio.sleep(max(0.1, float(TG_FOLDER_SYNC_DEBOUNCE_SEC)))

    if folder_sync_lock is None:
        folder_sync_lock = asyncio.Lock()

    async with folder_sync_lock:
        users = list(folder_sync_pending_users or [])
        reason = str(folder_sync_pending_reason or "")
        folder_sync_pending_users = []
        folder_sync_pending_reason = ""
        try:
            await _apply_folder_sync(client, users, reason=reason, my_id=my_id)
        except Exception as e:
            _watcher_print_special(_TG_FOLDER_BLUE, f"[TG-FOLDER] sync failed: {type(e).__name__}: {e}")


async def request_in_memory_folder_sync(payload: dict[str, Any]) -> dict[str, Any]:
    """Queue a Telegram folder sync inside the current tg_watcher event loop.

    This is used when tg_watcher is embedded in main.py, so billing/admin code does
    not need to call the local HTTP endpoint and aiohttp does not emit
    127.0.0.1 access logs for every sync.
    """
    global folder_sync_pending_users, folder_sync_pending_reason, folder_sync_task

    if not TG_FOLDER_SYNC_ENABLED:
        return {"ok": False, "error": "disabled"}
    if folder_sync_client is None:
        return {"ok": False, "error": "not_ready"}

    data = payload if isinstance(payload, dict) else {}
    users = data.get("users") if isinstance(data, dict) else []
    if not isinstance(users, list):
        users = []
    reason = str(data.get("reason") or "").strip()
    immediate = bool(data.get("immediate"))

    folder_sync_pending_users = [dict(x) for x in users if isinstance(x, dict)]
    folder_sync_pending_reason = reason

    if immediate:
        if folder_sync_task is not None and not folder_sync_task.done():
            folder_sync_task.cancel()
        folder_sync_task = asyncio.create_task(
            _folder_sync_run_now(folder_sync_client, folder_sync_my_id, list(folder_sync_pending_users), reason or "immediate"),
            name="tg-folder-sync-now",
        )
    elif folder_sync_task is None or folder_sync_task.done():
        folder_sync_task = asyncio.create_task(_folder_sync_debounced(folder_sync_client, folder_sync_my_id), name="tg-folder-sync")

    return {"ok": True, "queued": True, "immediate": immediate, "users": len(folder_sync_pending_users)}


async def _folder_sync_http_handler(request: web.Request) -> web.Response:
    global folder_sync_pending_users, folder_sync_pending_reason, folder_sync_task

    if TG_FOLDER_SYNC_SECRET:
        token = str(request.headers.get("X-Zooma-Folder-Token") or "")
        if token != TG_FOLDER_SYNC_SECRET:
            return web.json_response({"ok": False, "error": "forbidden"}, status=403)

    try:
        data = await request.json()
    except Exception:
        data = {}

    users = data.get("users") if isinstance(data, dict) else []
    if not isinstance(users, list):
        users = []

    reason = str((data or {}).get("reason") or "").strip() if isinstance(data, dict) else ""
    immediate = bool((data or {}).get("immediate")) if isinstance(data, dict) else False

    folder_sync_pending_users = [dict(x) for x in users if isinstance(x, dict)]
    folder_sync_pending_reason = reason

    client = request.app["tg_client"]
    my_id = request.app.get("my_id")

    if immediate:
        if folder_sync_task is not None and not folder_sync_task.done():
            folder_sync_task.cancel()
        folder_sync_task = asyncio.create_task(
            _folder_sync_run_now(client, my_id, list(folder_sync_pending_users), reason or "immediate"),
            name="tg-folder-sync-now",
        )
    elif folder_sync_task is None or folder_sync_task.done():
        folder_sync_task = asyncio.create_task(_folder_sync_debounced(client, my_id), name="tg-folder-sync")

    return web.json_response({"ok": True, "queued": True, "immediate": immediate, "users": len(folder_sync_pending_users)})


async def _start_folder_sync_server(client: TelegramClient, my_id: int | None) -> web.AppRunner | None:
    if not TG_FOLDER_SYNC_ENABLED:
        _watcher_print_special(_TG_FOLDER_BLUE, "[TG-FOLDER] disabled")
        return None
    if not TG_FOLDER_SYNC_HTTP_ENABLED:
        _watcher_print_special(_TG_FOLDER_BLUE, f"[TG-FOLDER] in-memory sync enabled folder=\"{TG_FOLDER_SYNC_TITLE}\"")
        return None

    app = web.Application()
    app["tg_client"] = client
    app["my_id"] = my_id
    app.router.add_post(TG_FOLDER_SYNC_PATH, _folder_sync_http_handler)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, TG_FOLDER_SYNC_HOST, TG_FOLDER_SYNC_PORT)
    await site.start()

    _watcher_print_special(
        _TG_FOLDER_BLUE,
        f"[TG-FOLDER] api listening http://{TG_FOLDER_SYNC_HOST}:{TG_FOLDER_SYNC_PORT}{TG_FOLDER_SYNC_PATH} "
        f"folder=\"{TG_FOLDER_SYNC_TITLE}\"",
    )
    return runner


def _log_time_prefix() -> str:
    return datetime.now(_OMSK_TZ).strftime("%Y-%m-%d %H:%M:%S")


def _watcher_should_log(level: str, msg: str) -> bool:
    if TG_WATCHER_DIAG_LOGS:
        return True
    if level == "ERROR":
        return True
    if "[POLL-RATE] golden stable" in msg:
        return True
    if "[TG-FOLDER] changed" in msg:
        return True
    if "[TG-FOLDER] unresolved" in msg:
        return True
    return False


def _watcher_print(level: str, color: str, msg: str) -> None:
    if _watcher_should_log(level, msg):
        use_color = bool(getattr(sys.stdout, "isatty", lambda: False)())
        prefix = f"{color}[TG-WATCHER][{level}]{Style.RESET_ALL}" if use_color else f"[TG-WATCHER][{level}]"
        print(f"[{_log_time_prefix()}] {prefix} {msg}", flush=True)


def log_info(msg: str) -> None:
    _watcher_print("INFO", Fore.CYAN, msg)


def log_success(msg: str) -> None:
    _watcher_print("SUCCESS", Fore.GREEN, msg)


def log_warning(msg: str) -> None:
    _watcher_print("WARNING", Fore.YELLOW, msg)


def log_error(msg: str) -> None:
    _watcher_print("ERROR", Fore.RED, msg)


_PROMO_ORANGE = "\033[38;5;208m"
_ENQUEUE_FAIL_RED = "\033[91m"
_TG_FOLDER_BLUE = "\033[94m"


def _watcher_print_special(color: str, msg: str) -> None:
    use_color = bool(getattr(sys.stdout, "isatty", lambda: False)())
    prefix = f"{color}[TG-WATCHER]{Style.RESET_ALL}" if use_color else "[TG-WATCHER]"
    print(f"[{_log_time_prefix()}] {prefix} {msg}", flush=True)


def log_promo(msg: str) -> None:
    use_color = bool(getattr(sys.stdout, "isatty", lambda: False)())
    prefix = f"{_PROMO_ORANGE}[TG-WATCHER][PROMO]{Style.RESET_ALL}" if use_color else "[TG-WATCHER][PROMO]"
    print(f"[{_log_time_prefix()}] {prefix} {msg}", flush=True)


def _telegram_message_utc_dt(message) -> datetime | None:
    dt = getattr(message, "date", None)
    if not dt:
        return None
    try:
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _strip_hint_noise(text: str) -> str:
    s = str(text or "")
    s = re.sub(r"https?://\S+", " ", s, flags=re.I)
    s = re.sub(r"\b(?:www\.)?[a-z0-9][a-z0-9-]*(?:\.[a-z0-9][a-z0-9-]*)+(?:/[^\s]*)?", " ", s, flags=re.I)
    s = re.sub(r"\bt\.me/\S+", " ", s, flags=re.I)
    return s


def _replace_keycap_digits(text: str) -> str:
    s = str(text or "")
    repl = {
        "0️⃣": "0", "1️⃣": "1", "2️⃣": "2", "3️⃣": "3", "4️⃣": "4",
        "5️⃣": "5", "6️⃣": "6", "7️⃣": "7", "8️⃣": "8", "9️⃣": "9",
        "➕": "+", "＋": "+",
        "➖": "-", "−": "-",
        "✖️": "*", "✖": "*", "×": "*",
        "➗": "/", "÷": "/",
    }
    for k, v in repl.items():
        s = s.replace(k, v)
    return s


def _safe_eval_int_expr(expr: str) -> str | None:
    expr = re.sub(r"\s+", "", str(expr or ""))
    expr = expr.replace("×", "*").replace("÷", "/")
    if not re.fullmatch(r"\d+(?:[+\-*/]\d+)+", expr):
        return None
    try:
        value = eval(expr, {"__builtins__": {}}, {})
    except Exception:
        return None
    try:
        if isinstance(value, (int, float)) and float(value).is_integer() and int(value) >= 0:
            return str(int(value))
    except Exception:
        return None
    return None


def _unique_keep_order(values: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for v in values:
        s = str(v or "").strip()
        if not s or s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out


def _hint_candidates_from_text(raw: str) -> list[str]:
    if not raw:
        return []

    s = _replace_keycap_digits(_strip_hint_noise(raw))
    candidates: list[str] = []
    spans: list[tuple[int, int]] = []

    for m in re.finditer(r"\d+(?:\s*[+\-*/]\s*\d+)+", s):
        val = _safe_eval_int_expr(m.group(0))
        if val is not None:
            candidates.append(val)
            spans.append((m.start(), m.end()))

    if spans:
        chars = list(s)
        for a, b in spans:
            for i in range(a, b):
                chars[i] = " "
        s_no_expr = "".join(chars)
    else:
        s_no_expr = s

    num_words = {
        "ноль": "0", "один": "1", "одна": "1", "два": "2", "две": "2",
        "три": "3", "четыре": "4", "пять": "5", "шесть": "6",
        "семь": "7", "восемь": "8", "девять": "9",
        "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4",
        "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
    }

    for tok in re.findall(r"[A-Za-z0-9]+|[А-Яа-яЁё]+", s_no_expr):
        low = tok.lower()
        if low in num_words:
            candidates.append(num_words[low])
            continue
        if re.fullmatch(r"[A-Za-z0-9]+", tok):
            if tok.upper().startswith("ZM"):
                continue
            candidates.append(tok)

    return [str(x).strip() for x in candidates if str(x).strip()]


def _decode_custom_emoji_sequence(entities, min_offset: int = -1, max_offset: int | None = None) -> str:
    rows: list[tuple[int, int, str]] = []
    for ent in (entities or []):
        if getattr(ent, "__class__", type("", (), {})).__name__ != "MessageEntityCustomEmoji":
            continue
        off = int(getattr(ent, "offset", -1))
        length = int(getattr(ent, "length", 1) or 1)
        if off <= min_offset:
            continue
        if max_offset is not None and off >= max_offset:
            continue
        ch = EMOJI_MAP.get(getattr(ent, "document_id", None))
        if ch:
            rows.append((off, length, ch))

    if not rows:
        return ""

    rows.sort(key=lambda x: x[0])
    out: list[str] = []
    prev_end: int | None = None
    for off, length, ch in rows:
        if prev_end is not None and off > prev_end:
            out.append(" ")
        out.append(ch)
        prev_end = off + max(1, length)
    return "".join(out)


def _hint_candidates_from_region(text: str, entities, start_offset: int, end_offset: int | None = None) -> list[str]:
    region_text = text[start_offset:end_offset] if end_offset is not None else text[start_offset:]
    decoded = _decode_custom_emoji_sequence(entities, min_offset=start_offset - 1, max_offset=end_offset)
    return _hint_candidates_from_text(decoded) + _hint_candidates_from_text(region_text)


def _hint_candidates_after_marker(text: str, entities) -> list[str]:
    if not text:
        return []
    marker_idx = text.rfind("‼️")
    if marker_idx == -1:
        return []
    return _hint_candidates_from_region(text, entities, marker_idx + len("‼️"), None)


def _extract_numbered_hints_after_marker(message) -> dict[int, list[str]]:
    text = (getattr(message, "message", "") or "")
    marker_idx = text.rfind("‼️")
    if marker_idx == -1:
        return {}

    tail = text[marker_idx + len("‼️"):]
    matches = list(re.finditer(r"(\d+)\)\s*", tail))
    if not matches:
        return {}

    hints: dict[int, list[str]] = {}
    for i, m in enumerate(matches):
        try:
            num = int(m.group(1))
        except Exception:
            continue
        seg_start = marker_idx + len("‼️") + m.end()
        seg_end = marker_idx + len("‼️") + (matches[i + 1].start() if i + 1 < len(matches) else len(tail))
        cands = _hint_candidates_from_region(text, getattr(message, "entities", None), seg_start, seg_end)
        if cands:
            hints[num] = cands
    return hints


def _restore_masked_promo(masked_promo: str, hint: str) -> str:
    if not masked_promo or "*" not in masked_promo or not hint:
        return masked_promo
    out = []
    i = 0
    for ch in masked_promo:
        if ch == "*" and i < len(hint):
            out.append(hint[i])
            i += 1
        else:
            out.append(ch)
    return "".join(out)


def _join_candidates_for_stars(candidates: list[str], star_count: int) -> str:
    clean = [str(c or "").strip() for c in (candidates or []) if str(c or "").strip()]
    if not clean or star_count <= 0:
        return ""

    for c in clean:
        if len(c) == star_count:
            return c

    joined = ""
    for c in clean:
        if len(joined) >= star_count:
            break
        if len(joined) + len(c) <= star_count:
            joined += c

    if len(joined) == star_count:
        return joined
    return ""


def _pick_hint_for_stars(
    star_count: int,
    *,
    inline_candidates: list[str] | None = None,
    after_promo_candidates: list[str] | None = None,
    numbered_candidates: list[str] | None = None,
    marker_candidates: list[str] | None = None,
    promo_index: int = 1,
) -> str:
    groups = [
        inline_candidates or [],
        after_promo_candidates or [],
        numbered_candidates or [],
    ]

    for group in groups:
        hint = _join_candidates_for_stars(group, star_count)
        if hint:
            return hint

    marker_candidates = marker_candidates or []
    if 0 <= promo_index - 1 < len(marker_candidates):
        hint = _join_candidates_for_stars(marker_candidates[promo_index - 1:], star_count)
        if hint:
            return hint

    return _join_candidates_for_stars(marker_candidates, star_count)


def _channel_pending_key(channel_key: str | int | None) -> str:
    return str(channel_key or "unknown")


def _purge_pending_masked_promos(channel_key: str | int | None = None) -> None:
    now = time.time()
    keys = [_channel_pending_key(channel_key)] if channel_key is not None else list(PENDING_MASKED_PROMOS.keys())
    for key in keys:
        rows = PENDING_MASKED_PROMOS.get(key) or []
        fresh = [r for r in rows if now - float(r.get("ts") or 0) <= MASKED_PROMO_PENDING_TTL_SEC]
        if fresh:
            PENDING_MASKED_PROMOS[key] = fresh
        else:
            PENDING_MASKED_PROMOS.pop(key, None)


def _remember_masked_promo(channel_key: str | int | None, title: str, masked_promo: str, message_id: Any = None) -> None:
    key = _channel_pending_key(channel_key)
    _purge_pending_masked_promos(key)
    rows = PENDING_MASKED_PROMOS.setdefault(key, [])
    if any(str(r.get("masked")) == masked_promo for r in rows):
        return
    rows.append(
        {
            "masked": masked_promo,
            "stars": int(masked_promo.count("*")),
            "ts": time.time(),
            "message_id": message_id,
        }
    )
    log_warning(
        f"[MASKED] {title}: remembered {masked_promo} for {MASKED_PROMO_PENDING_TTL_SEC // 60} min "
        f"stars={masked_promo.count('*')} msg_id={message_id}"
    )


def _complete_pending_masked_promos_from_message(message, channel_key: str | int | None, title: str) -> list[str]:
    text = (getattr(message, "message", "") or "")
    if re.search(PROMO_MASKED_RE, text):
        return []

    key = _channel_pending_key(channel_key)
    _purge_pending_masked_promos(key)
    rows = list(PENDING_MASKED_PROMOS.get(key) or [])
    if not rows:
        return []

    candidates = _hint_candidates_from_region(text, getattr(message, "entities", None), 0, None)
    if not candidates:
        return []

    completed: list[str] = []
    consumed: set[int] = set()
    remaining: list[dict[str, Any]] = []

    for row in rows:
        masked = str(row.get("masked") or "")
        stars = int(row.get("stars") or masked.count("*") or 0)
        hint = ""
        hint_idx = -1
        for i, cand in enumerate(candidates):
            if i in consumed:
                continue
            if len(cand) == stars:
                hint = cand
                hint_idx = i
                break

        if not hint:
            remaining.append(row)
            continue

        restored = _restore_masked_promo(masked, hint).upper()
        if "*" in restored:
            remaining.append(row)
            continue

        consumed.add(hint_idx)
        completed.append(restored)
        log_info(f"[MASKED] {title}: restored from next post {masked} + {hint} -> {restored}")

    if remaining:
        PENDING_MASKED_PROMOS[key] = remaining
    else:
        PENDING_MASKED_PROMOS.pop(key, None)

    return completed


def _extract_promos_from_tg_message(message, channel_key: str | int | None = None, title: str = "") -> list[str]:
    text = (getattr(message, "message", "") or "")
    entities = getattr(message, "entities", None)
    out: list[str] = []

    if channel_key is not None:
        out.extend(_complete_pending_masked_promos_from_message(message, channel_key, title))

    matches = list(re.finditer(PROMO_MASKED_RE, text))
    if not matches:
        return _unique_keep_order([x.upper() for x in out])

    marker_candidates = _hint_candidates_after_marker(text, entities)
    numbered_hints = _extract_numbered_hints_after_marker(message)

    for idx, m in enumerate(matches, start=1):
        promo = m.group(1).upper()
        if "*" not in promo:
            out.append(promo)
            continue

        star_count = promo.count("*")
        line_end = text.find("\n", m.end())
        if line_end == -1:
            line_end = len(text)
        inline_candidates = _hint_candidates_from_region(text, entities, m.end(), line_end)

        next_match_start = matches[idx].start() if idx < len(matches) else None
        after_promo_candidates = _hint_candidates_from_region(text, entities, m.end(), next_match_start)

        hint = _pick_hint_for_stars(
            star_count,
            inline_candidates=inline_candidates,
            after_promo_candidates=after_promo_candidates,
            numbered_candidates=numbered_hints.get(idx, []),
            marker_candidates=marker_candidates,
            promo_index=idx,
        )

        if hint:
            restored = _restore_masked_promo(promo, hint).upper()
            if "*" not in restored:
                log_info(f"[MASKED] restored inline {promo} -> {restored} hint={hint}")
                out.append(restored)
                continue

        if channel_key is not None:
            _remember_masked_promo(channel_key, title, promo, getattr(message, "id", None))
        else:
            log_warning(f"[MASKED] unresolved {promo}")

    return _unique_keep_order([x.upper() for x in out])


def _purge_tracking() -> None:
    now = time.time()
    for key, ts in list(processed_tg_messages.items()):
        if now - ts > TG_MESSAGE_DEDUP_TTL_SEC:
            processed_tg_messages.pop(key, None)
    for promo, ts in list(queued_promos.items()):
        if now - ts > TG_QUEUED_PROMO_TTL_SEC:
            queued_promos.pop(promo, None)


def _chat_title(chat: Any) -> str:
    return str(
        getattr(chat, "title", None)
        or getattr(chat, "username", None)
        or getattr(chat, "id", None)
        or "unknown"
    )


def _chat_key(chat: Any) -> str:
    return str(getattr(chat, "id", None) or getattr(chat, "username", None) or _chat_title(chat))


def _extract_invite_hash(ref: str) -> str:
    raw = str(ref or "").strip()
    if not raw:
        return ""
    src = raw
    with contextlib.suppress(Exception):
        src = re.sub(r"^https?://", "", src, flags=re.I)
    src = src.strip().lstrip("/")
    low = src.lower()

    path = src
    if low.startswith("t.me/"):
        path = src[5:]
    elif low.startswith("telegram.me/"):
        path = src[len("telegram.me/"):]

    path = path.strip().lstrip("/")
    hash_part = ""
    if path.startswith("+"):
        hash_part = path[1:]
    elif path.lower().startswith("joinchat/"):
        hash_part = path.split("/", 1)[1] if "/" in path else ""
    elif raw.startswith("+"):
        hash_part = raw[1:]

    hash_part = str(hash_part or "").split("?", 1)[0].split("/", 1)[0].strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{10,}", hash_part):
        return hash_part
    return ""


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return False


async def _enqueue_promo(server_url: str, promo: str, title: str, channel_key: str, msg_id: Any, msg_dt: datetime | None, seen_utc: datetime, source: str, delay_sec: float | None) -> None:
    payload = {
        "promo": promo,
        "channel": title,
        "channel_key": channel_key,
        "msg_id": msg_id,
        "post_utc": msg_dt.isoformat() if msg_dt else None,
        "seen_utc": seen_utc.isoformat(),
        "delay_sec": delay_sec,
        "source": f"tg_watcher_{source}",
    }

    if in_memory_promo_handler is not None or not server_url:
        try:
            res = in_memory_promo_handler(payload) if in_memory_promo_handler is not None else {"ok": False, "error": "no_handler"}
            if inspect.isawaitable(res):
                res = await res
            if isinstance(res, dict) and res.get("ok"):
                log_info(f"[ENQUEUE-MEM] ok promo={promo} channel={title} msg_id={msg_id} data={res}")
                return
            log_warning(f"[ENQUEUE-MEM] bad_result promo={promo} data={res}")
        except Exception as e:
            log_warning(f"[ENQUEUE-MEM] promo={promo} error={type(e).__name__}: {e}")
        return

    for attempt in range(1, 31):
        try:
            timeout = httpx.Timeout(connect=1.5, read=2.5, write=1.5, pool=1.5)
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
                resp = await client.post(server_url, json=payload)
            if resp.status_code == 200:
                try:
                    data = resp.json()
                except Exception as e:
                    log_warning(f"[ENQUEUE] attempt={attempt} promo={promo} invalid_json={e} body={resp.text[:250]}")
                    data = None
                if isinstance(data, dict) and bool(data.get("ok")):
                    log_info(f"[ENQUEUE] ok promo={promo} channel={title} msg_id={msg_id} data={data}")
                    return
                log_warning(f"[ENQUEUE] attempt={attempt} promo={promo} bad_body={resp.text[:250]}")
            else:
                log_warning(f"[ENQUEUE] attempt={attempt} http={resp.status_code} promo={promo} body={resp.text[:250]}")
        except Exception as e:
            log_warning(f"[ENQUEUE] attempt={attempt} promo={promo} error={e}")

        await asyncio.sleep(0.5)

    _watcher_print_special(_ENQUEUE_FAIL_RED, f"[ENQUEUE] failed promo={promo} channel={title} msg_id={msg_id}")


async def _enqueue_promo_many(server_urls: list[str], promo: str, title: str, channel_key: str, msg_id: Any, msg_dt: datetime | None, seen_utc: datetime, source: str, delay_sec: float | None) -> None:
    if in_memory_promo_handler is not None and not server_urls:
        await _enqueue_promo("", promo, title, channel_key, msg_id, msg_dt, seen_utc, source, delay_sec)
        return
    tasks = [
        asyncio.create_task(
            _enqueue_promo(url, promo, title, channel_key, msg_id, msg_dt, seen_utc, source, delay_sec),
            name=f"enqueue-{promo}-{idx}",
        )
        for idx, url in enumerate(server_urls)
    ]
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


async def _process_tg_message(message: Any, chat: Any, source: str, server_urls: list[str]) -> None:
    if not message:
        return

    _purge_tracking()

    title = _chat_title(chat)
    channel_key = _chat_key(chat)
    msg_id = getattr(message, "id", None)
    msg_key = f"{channel_key}:{msg_id}" if msg_id is not None else f"{channel_key}:{id(message)}"

    if msg_key in processed_tg_messages:
        return

    msg_dt = _telegram_message_utc_dt(message)
    seen_utc = datetime.now(timezone.utc)

    raw_text = (getattr(message, "message", "") or "").replace("\n", "\\n")

    log_warning(
        f"[RAW-MSG] channel={title} "
        f"msg_id={msg_id} "
        f"source={source} "
        f"text={raw_text[:1000]}"
    )
    
    if source == "poll" and msg_dt:
        startup_cutoff = poll_started_utc - timedelta(seconds=max(0.0, TG_POLL_START_BACKFILL_SEC))
        age_sec = max(0.0, (seen_utc - msg_dt).total_seconds())

        if msg_dt < startup_cutoff:
            processed_tg_messages[msg_key] = time.time()
            return

        if age_sec > TG_POLL_MAX_MESSAGE_AGE_SEC:
            processed_tg_messages[msg_key] = time.time()
            return

    processed_tg_messages[msg_key] = time.time()

    try:
        if msg_id is not None:
            last_seen_ids[channel_key] = max(int(last_seen_ids.get(channel_key, 0)), int(msg_id))
    except Exception:
        pass

    promos = _extract_promos_from_tg_message(message, channel_key=channel_key, title=title)
    if not promos:
        if TG_WATCHER_LOG_NO_PROMO:
            age = max(0.0, (seen_utc - msg_dt).total_seconds()) if msg_dt else None
            log_info(f"[MSG] no-promo channel={title} msg_id={msg_id} source={source} age={age}")
        return

    delay_sec = max(0.0, (seen_utc - msg_dt).total_seconds()) if msg_dt else None
    seen_in_message: set[str] = set()

    for promo in promos:
        promo = str(promo or "").strip().upper()
        if not promo or promo in seen_in_message:
            continue
        seen_in_message.add(promo)

        queued_ts = queued_promos.get(promo)
        if queued_ts is not None and (time.time() - queued_ts) <= TG_QUEUED_PROMO_TTL_SEC:
            log_info(f"[DEDUP] promo={promo} channel={title} msg_id={msg_id} reason=already_queued")
            continue

        queued_promos[promo] = time.time()
        delay_part = f" delay={delay_sec:.3f}s" if delay_sec is not None else ""
        post_part = f" post_utc={msg_dt.isoformat()}" if msg_dt else ""
        log_promo(f"{title}: {promo}{delay_part} source={source} msg_id={msg_id}{post_part}")

        asyncio.create_task(
            _enqueue_promo_many(server_urls, promo, title, channel_key, msg_id, msg_dt, seen_utc, source, delay_sec),
            name=f"enqueue-{promo}",
        )


async def _resolve_tg_channels(client: TelegramClient) -> list[Any]:
    resolved: list[Any] = []
    
    dialogs = []
    has_numeric = any(str(x).strip().isdigit() or (str(x).strip().startswith("-") and str(x).strip()[1:].isdigit()) for x in CHANNELS)
    if has_numeric:
        try:
            log_info("[RESOLVE] сканируем активные диалоги аккаунта для точного поиска приватов...")
            dialogs = await client.get_dialogs()
        except Exception as e:
            log_warning(f"[RESOLVE] не удалось загрузить диалоги: {e}")

    for ch in CHANNELS:
        ch_clean = str(ch).strip()
        if not ch_clean:
            continue

        invite_hash = _extract_invite_hash(ch_clean)
        if invite_hash:
            try:
                t0 = time.monotonic()
                invite = await client(CheckChatInviteRequest(hash=invite_hash))
                entity = None
                if isinstance(invite, ChatInviteAlready):
                    entity = invite.chat
                elif TG_PRIVATE_INVITE_AUTO_JOIN:
                    with contextlib.suppress(Exception):
                        updates = await client(ImportChatInviteRequest(hash=invite_hash))
                        chats = list(getattr(updates, "chats", None) or [])
                        if chats:
                            entity = chats[0]
                if entity is None:
                    log_warning(
                        f"[RESOLVE] private invite unresolved {ch_clean}: "
                        f"account is not a member (or invite inaccessible)"
                    )
                    continue

                entity = await client.get_entity(entity)
                ms = int((time.monotonic() - t0) * 1000)
                resolved.append(entity)
                log_success(f"[RESOLVE] {ch_clean} -> {_chat_title(entity)} id={getattr(entity, 'id', 'unknown')} ms={ms}")
                continue
            except Exception as e:
                log_warning(f"[RESOLVE] private invite failed {ch_clean}: {e}")
                continue

        try:
            t0 = time.monotonic()
            entity = None

            if ch_clean.isdigit() or (ch_clean.startswith("-") and ch_clean[1:].isdigit()):
                target_id = int(ch_clean)
                
                for d in dialogs:
                    if d.id == target_id or str(d.id).endswith(str(abs(target_id))):
                        entity = d.entity
                        break

                if entity is None:
                    for prefix in ["-100", "-", ""]:
                        try:
                            if ch_clean.startswith("-"):
                                test_id = int(f"{prefix}{ch_clean[1:]}")
                            else:
                                test_id = int(f"{prefix}{ch_clean}")
                            entity = await client.get_entity(test_id)
                            break
                        except Exception:
                            continue
            else:
                entity = await client.get_entity(ch_clean)
                
            if entity is not None:
                ms = int((time.monotonic() - t0) * 1000)
                resolved.append(entity)
                log_success(f"[RESOLVE] {ch_clean} -> {_chat_title(entity)} id={getattr(entity, 'id', 'unknown')} ms={ms}")
            else:
                log_warning(f"[RESOLVE] не удалось найти сущность для чата: {ch_clean}")
        except Exception as e:
            log_warning(f"[RESOLVE] failed {ch_clean}: {e}")
            
    return resolved


async def _poll_one_channel(client: TelegramClient, entity: Any, sem: asyncio.Semaphore, server_urls: list[str]) -> dict[str, Any]:
    async with sem:
        title = _chat_title(entity)
        channel_key = _chat_key(entity)
        t0 = time.monotonic()

        try:
            messages = await client.get_messages(entity, limit=1)
            elapsed = time.monotonic() - t0

            latest = messages[0] if messages else None
            latest_id = getattr(latest, "id", None) if latest else None
            latest_dt = _telegram_message_utc_dt(latest) if latest else None
            latest_age = max(0.0, (datetime.now(timezone.utc) - latest_dt).total_seconds()) if latest_dt else None

            old_seen = last_seen_ids.get(channel_key)

            if latest_id is not None and channel_key not in last_seen_ids:
                try:
                    last_seen_ids[channel_key] = int(latest_id)
                except Exception:
                    pass

            changed = False
            gap_detected = False
            fetch_limit = 1

            try:
                if latest_id is not None and old_seen is not None:
                    diff = int(latest_id) - int(old_seen)
                    changed = diff > 0
                    gap_detected = diff > 1
                    if gap_detected:
                        fetch_limit = max(1, min(TG_POLL_GAP_FETCH_LIMIT, diff + 1))
            except Exception:
                changed = False
                gap_detected = False
                fetch_limit = 1

            if gap_detected and fetch_limit > 1:
                t_gap = time.monotonic()
                messages = await client.get_messages(entity, limit=fetch_limit)
                gap_elapsed = time.monotonic() - t_gap
                log_info(
                    f"[POLL] gap channel={title} old_seen={old_seen} latest_id={latest_id} "
                    f"fetch_limit={fetch_limit} elapsed={gap_elapsed:.3f}s"
                )

            is_slow = elapsed > 1.0
            if TG_WATCHER_POLL_VERBOSE or changed or is_slow:
                level = log_warning if is_slow else log_info
                reason = "verbose" if TG_WATCHER_POLL_VERBOSE else ("changed" if changed else "slow")
                level(
                    f"[POLL] {reason} channel={title} latest_id={latest_id} last_seen={old_seen} "
                    f"latest_age={latest_age if latest_age is not None else 'n/a'} fetched={len(messages or [])} "
                    f"elapsed={elapsed:.3f}s"
                )

            for msg in reversed(list(messages or [])):
                await _process_tg_message(msg, entity, "poll", server_urls)

            return {
                "ok": True,
                "flood": False,
                "changed": changed,
                "channel": title,
                "elapsed": elapsed,
            }

        except FloodWaitError as e:
            wait_sec = int(getattr(e, "seconds", 5) or 5)
            log_warning(f"[POLL] flood-wait channel={title} wait={wait_sec}s")
            return {
                "ok": False,
                "flood": True,
                "wait_sec": wait_sec,
                "channel": title,
            }

        except Exception as e:
            log_warning(f"[POLL] error channel={title}: {type(e).__name__}: {e}")
            return {
                "ok": False,
                "flood": False,
                "error": str(e),
                "channel": title,
            }


async def _tg_poll_loop(client: TelegramClient, entities: list[Any], server_urls: list[str]) -> None:
    if not TG_POLL_ENABLED:
        log_info("[POLL] disabled")
        return

    if not entities:
        log_warning("[POLL] disabled: no resolved channels")
        return

    sem = asyncio.Semaphore(1)
    channels_count = max(1, len(entities))

    def clamp_gap(v: float) -> float:
        return max(TG_POLL_AUTO_GAP_MIN_SEC, min(TG_POLL_AUTO_GAP_MAX_SEC, float(v)))

    gap = clamp_gap(TG_POLL_AUTO_GAP_START_SEC)
    last_good_gap: float | None = None
    round_ok_requests = 0
    idx = 0
    request_count = 0
    golden_gap: float | None = None
    locked_golden = False
    golden_ok_rounds = 0
    last_reported_golden_gap: float | None = None

    def maybe_log_golden_stable(value: float | None) -> None:
        nonlocal last_reported_golden_gap
        if value is None:
            return
        if last_reported_golden_gap is None or abs(float(value) - float(last_reported_golden_gap)) >= 0.001:
            last_reported_golden_gap = float(value)
            log_success(
                f"[POLL-RATE] golden stable gap={value:.3f}s "
                f"full_round={value * channels_count:.3f}s"
            )

    log_success(
        f"[POLL-RATE] round-auto start channels={channels_count} gap={gap:.3f}s "
        f"decay={TG_POLL_AUTO_DECAY:.2f} golden_margin={TG_POLL_AUTO_GOLDEN_MARGIN:.2f} "
        f"cooldown_margin={TG_POLL_AUTO_FLOOD_COOLDOWN_MARGIN:.2f} "
        f"min={TG_POLL_AUTO_GAP_MIN_SEC:.3f}s max={TG_POLL_AUTO_GAP_MAX_SEC:.3f}s"
    )

    while stop_event is None or not stop_event.is_set():
        entity = entities[idx]
        idx = (idx + 1) % channels_count

        request_count += 1
        result = await _poll_one_channel(client, entity, sem, server_urls)

        if result.get("flood"):
            flood_wait = float(result.get("wait_sec") or 5.0)
            cooldown = max(1.0, flood_wait * TG_POLL_AUTO_FLOOD_COOLDOWN_MARGIN)
            flood_gap = gap

            round_ok_requests = 0
            golden_ok_rounds = 0

            if locked_golden:
                old_gap = gap
                gap = clamp_gap(gap * 1.20)
                golden_gap = gap
                last_good_gap = gap

                log_warning(
                    f"[POLL-RATE] golden invalidated channel={result.get('channel')} "
                    f"wait={flood_wait:.1f}s cooldown={cooldown:.1f}s "
                    f"gap {old_gap:.3f}s -> {gap:.3f}s "
                    f"full_round={gap * channels_count:.3f}s"
                )

            elif last_good_gap is not None:
                golden_gap = clamp_gap(last_good_gap * TG_POLL_AUTO_GOLDEN_MARGIN)
                gap = golden_gap
                locked_golden = True

                log_warning(
                    f"[POLL-RATE] first flood channel={result.get('channel')} "
                    f"wait={flood_wait:.1f}s cooldown={cooldown:.1f}s "
                    f"flood_gap={flood_gap:.3f}s "
                    f"last_good_round_gap={last_good_gap:.3f}s "
                    f"golden={golden_gap:.3f}s "
                    f"channels={channels_count} full_round={golden_gap * channels_count:.3f}s"
                )

            else:
                old_gap = gap
                gap = clamp_gap(max(gap * 1.50, gap + 0.25))

                log_warning(
                    f"[POLL-RATE] flood before first good round channel={result.get('channel')} "
                    f"wait={flood_wait:.1f}s cooldown={cooldown:.1f}s "
                    f"gap {old_gap:.3f}s -> {gap:.3f}s "
                    f"full_round={gap * channels_count:.3f}s"
                )

            await asyncio.sleep(cooldown)
            continue

        if result.get("ok"):
            round_ok_requests += 1

            if locked_golden:
                if round_ok_requests >= channels_count:
                    golden_ok_rounds += 1
                    round_ok_requests = 0
                    maybe_log_golden_stable(golden_gap)

                await asyncio.sleep(gap)
                continue

            if round_ok_requests >= channels_count:
                last_good_gap = gap
                old_gap = gap
                next_gap = clamp_gap(gap * TG_POLL_AUTO_DECAY)
                round_ok_requests = 0

                if next_gap == old_gap:
                    golden_gap = old_gap
                    gap = golden_gap
                    locked_golden = True
                    maybe_log_golden_stable(golden_gap)
                else:
                    gap = next_gap
                    log_info(
                        f"[POLL-RATE] round ok last_good={last_good_gap:.3f}s "
                        f"probe_lower {old_gap:.3f}s -> {gap:.3f}s "
                        f"channels={channels_count} full_round={gap * channels_count:.3f}s"
                    )

        await asyncio.sleep(gap)


async def _parent_monitor(parent_pid: int) -> None:
    global stop_event
    if parent_pid <= 0:
        return

    while stop_event is None or not stop_event.is_set():
        await asyncio.sleep(1.0)
        if os.getppid() == 1 or not _pid_alive(parent_pid):
            log_warning(f"[PARENT] parent gone parent_pid={parent_pid} ppid={os.getppid()} -> stopping")
            if stop_event is not None:
                stop_event.set()
            return


async def run_tg_watcher(server_urls: list[str] | None = None, parent_pid: int = 0, zooma_tg_watcher: bool = False) -> None:
    global poll_started_utc, stop_event, folder_sync_client, folder_sync_my_id

    if server_urls is None:
        server_urls = [
            os.getenv("ZOOMA_TG_WATCHER_INTERNAL_URL", "http://127.0.0.1:8789/internal/promo/enqueue"),
            os.getenv("ZOOMA_TG_WATCHER_INTERNAL_URL_2", ""),
        ]
    uniq_server_urls: list[str] = []
    for u in server_urls:
        if u and u not in uniq_server_urls:
            uniq_server_urls.append(u)
    server_urls = uniq_server_urls

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    loop.set_debug(False)

    logging.basicConfig(level=logging.CRITICAL)
    logging.getLogger("asyncio").setLevel(logging.CRITICAL)
    logging.getLogger("telethon").setLevel(logging.CRITICAL)
    logging.getLogger("httpx").setLevel(logging.CRITICAL)
    logging.getLogger("httpcore").setLevel(logging.CRITICAL)

    for sig in (signal.SIGTERM, signal.SIGINT):
        with contextlib.suppress(Exception):
            loop.add_signal_handler(sig, stop_event.set)

    log_success(
        f"started pid={os.getpid()} parent_pid={parent_pid} server_urls={server_urls} "
        f"proxy={(str(PROXY_HOST)+':'+str(PROXY_PORT)) if PROXY_SETTINGS else 'off'} debug={os.getenv('PYTHONASYNCIODEBUG')} warnings={os.getenv('PYTHONWARNINGS')}"
    )
    log_info(f"channels={CHANNELS}")
    log_info(
        f"poll auto_gap_start={TG_POLL_AUTO_GAP_START_SEC}s limit={TG_POLL_LIMIT} "
        f"verbose={TG_WATCHER_POLL_VERBOSE} diag={TG_WATCHER_POLL_DIAG} "
        f"backfill={TG_POLL_START_BACKFILL_SEC}s max_age={TG_POLL_MAX_MESSAGE_AGE_SEC}s"
    )

    client = TelegramClient(TG_SESSION, API_ID, API_HASH, proxy=PROXY_SETTINGS)
    client.flood_sleep_threshold = 0
    poll_task: asyncio.Task[Any] | None = None
    parent_task: asyncio.Task[Any] | None = None
    folder_runner: web.AppRunner | None = None

    try:
        await client.start()
        me = await client.get_me()
        username = f"@{me.username}" if getattr(me, "username", None) else "no_username"
        log_success(f"account={username} id={getattr(me, 'id', None)}")
        folder_sync_client = client
        folder_sync_my_id = getattr(me, "id", None)
        folder_runner = await _start_folder_sync_server(client, folder_sync_my_id)

        entities = await _resolve_tg_channels(client)
        poll_started_utc = datetime.now(timezone.utc)
        log_info(f"baseline_utc={poll_started_utc.isoformat()}")

        event_chats = entities if entities else CHANNELS
        chat_meta_cache = {
            str(getattr(entity, "id", "")): {
                "id": getattr(entity, "id", None),
                "username": getattr(entity, "username", None) or str(getattr(entity, "id", None) or "unknown_channel"),
                "title": _chat_title(entity),
            }
            for entity in entities
        }

        # МГНОВЕННЫЙ ОБРАБОТЧИК ЭВЕНТОВ
        @client.on(events.NewMessage(chats=event_chats))
        async def _event_handler(event):
            log_warning(
                f"[EVENT] chat_id={event.chat_id} "
                f"msg_id={event.message.id}"
            )
            chat_entity = getattr(event, "chat", None)
            cached = chat_meta_cache.get(str(event.chat_id)) or {}
            username_val = (
                getattr(chat_entity, "username", None)
                or cached.get("username")
                or str(event.chat_id or "unknown_channel")
            )
            title_val = (
                getattr(chat_entity, "title", None)
                or cached.get("title")
                or username_val
            )

            class FastChat:
                id = event.chat_id
                username = username_val
                title = title_val

            asyncio.create_task(
                _process_tg_message(event.message, FastChat(), "event", server_urls),
                name=f"tg-event-process-{event.message.id}",
            )

        poll_task = asyncio.create_task(_tg_poll_loop(client, entities, server_urls), name="tg-watcher-poll")
        parent_task = asyncio.create_task(_parent_monitor(parent_pid), name="tg-watcher-parent-monitor")

        await stop_event.wait()

    finally:
        log_warning("stopping")
        shutdown_tasks = [task for task in (poll_task, parent_task, folder_sync_task) if task]
        for task in shutdown_tasks:
            task.cancel()
        if shutdown_tasks:
            done, pending = await asyncio.wait(shutdown_tasks, timeout=1.0)
            for task in pending:
                log_warning(f"shutdown task did not stop in time: {task.get_name()}")
            for task in done:
                with contextlib.suppress(asyncio.CancelledError):
                    exc = task.exception()
                    if exc is not None:
                        log_warning(f"shutdown task failed: {task.get_name()} {type(exc).__name__}: {exc}")
        if folder_runner:
            with contextlib.suppress(Exception):
                await folder_runner.cleanup()
        with contextlib.suppress(Exception):
            await client.disconnect()
        log_success("stopped")



async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zooma-tg-watcher", action="store_true")
    parser.add_argument("--parent-pid", type=int, default=0)
    parser.add_argument("--server-url", default=os.getenv("ZOOMA_TG_WATCHER_INTERNAL_URL", "http://127.0.0.1:8789/internal/promo/enqueue"))
    parser.add_argument("--server-url-2", default=os.getenv("ZOOMA_TG_WATCHER_INTERNAL_URL_2", ""))
    parser.add_argument("--log-file", default=os.getenv("ZOOMA_TG_WATCHER_LOG_FILE", "tg_watcher.log"))
    args = parser.parse_args()
    await run_tg_watcher([args.server_url, args.server_url_2], parent_pid=args.parent_pid, zooma_tg_watcher=bool(args.zooma_tg_watcher))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, asyncio.CancelledError):
        print(f"[{_log_time_prefix()}] [TG-WATCHER] stopped", flush=True)
        raise SystemExit(0)
