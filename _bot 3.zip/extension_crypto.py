from __future__ import annotations

import base64
import hashlib
import json
import logging
import secrets
import threading
import time
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from config import EXTENSION_CRYPTO_DEBUG
from store import get_user_account

logger = logging.getLogger("extension_crypto")

CHALLENGE_TTL_SEC = 60
_CHALLENGES: dict[str, dict[str, Any]] = {}
_CHALLENGE_LOCK = threading.Lock()


def extension_debug_id(value: Any, keep: int = 16) -> str:
    raw = str(value or "").strip()
    if not raw:
        return "-"
    return raw if len(raw) <= keep else raw[:keep] + "..."


def extension_signature_length(signature_b64: str) -> int:
    try:
        return len(_b64url_decode(signature_b64))
    except Exception:
        return 0


def extension_crypto_debug(title: str, **fields: Any) -> None:
    if not EXTENSION_CRYPTO_DEBUG:
        return
    lines = ["[EXT_CRYPTO]", f"{str(title or 'event').strip()}:"]
    for key, value in fields.items():
        lines.append(f"{key}={value}")
    logger.info("\n".join(lines))


def _proof_failed(reason: str, **fields: Any) -> bool:
    extension_crypto_debug("proof verify FAILED", reason=reason, **fields)
    return False


def _b64url_decode(value: str) -> bytes:
    raw = str(value or "").strip()
    if not raw:
        return b""
    return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))


def _b64url_encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def validate_public_jwk(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        raise ValueError("bad_extension_public_key")
    jwk = {
        "crv": str(value.get("crv") or "").strip(),
        "kty": str(value.get("kty") or "").strip(),
        "x": str(value.get("x") or "").strip(),
        "y": str(value.get("y") or "").strip(),
    }
    if jwk["kty"] != "EC" or jwk["crv"] != "P-256":
        raise ValueError("bad_extension_public_key")
    try:
        x_raw = _b64url_decode(jwk["x"])
        y_raw = _b64url_decode(jwk["y"])
    except Exception as exc:
        raise ValueError("bad_extension_public_key") from exc
    if len(x_raw) != 32 or len(y_raw) != 32:
        raise ValueError("bad_extension_public_key")
    try:
        ec.EllipticCurvePublicNumbers(
            int.from_bytes(x_raw, "big"),
            int.from_bytes(y_raw, "big"),
            ec.SECP256R1(),
        ).public_key()
    except Exception as exc:
        raise ValueError("bad_extension_public_key") from exc
    return jwk


def extension_key_id(public_jwk: Any) -> str:
    jwk = validate_public_jwk(public_jwk)
    canonical = json.dumps(jwk, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _public_key(public_jwk: Any):
    jwk = validate_public_jwk(public_jwk)
    return ec.EllipticCurvePublicNumbers(
        int.from_bytes(_b64url_decode(jwk["x"]), "big"),
        int.from_bytes(_b64url_decode(jwk["y"]), "big"),
        ec.SECP256R1(),
    ).public_key()


def verify_extension_signature(public_jwk: Any, payload: str, signature_b64: str) -> bool:
    try:
        signature = _b64url_decode(signature_b64)
        # WebCrypto ECDSA returns IEEE-P1363 r||s. cryptography verifies ASN.1 DER.
        if len(signature) == 64:
            signature = encode_dss_signature(
                int.from_bytes(signature[:32], "big"),
                int.from_bytes(signature[32:], "big"),
            )
        _public_key(public_jwk).verify(
            signature,
            str(payload or "").encode("utf-8"),
            ec.ECDSA(hashes.SHA256()),
        )
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False
    except Exception:
        return False


def _purge_expired(now_ts: int) -> None:
    for challenge_id, row in list(_CHALLENGES.items()):
        if int(row.get("expires_at_ts") or 0) < now_ts:
            _CHALLENGES.pop(challenge_id, None)


def create_extension_challenge(chat_id: int, account_id: str, key_id: str, purpose: str) -> dict[str, Any]:
    cid = int(chat_id)
    aid = str(account_id or "acc_1").strip() or "acc_1"
    kid = str(key_id or "").strip().lower()
    use = str(purpose or "").strip().lower()
    if use not in {"ws", "unbind"}:
        raise ValueError("bad_extension_challenge_purpose")
    acc = get_user_account(cid, aid) or {}
    if int(acc.get("extension_bound_chat_id") or 0) != cid:
        raise ValueError("extension_not_bound")
    stored_key_id = str(acc.get("extension_key_id") or "").strip().lower()
    public_jwk = acc.get("extension_public_key_jwk")
    if not stored_key_id or not public_jwk:
        raise ValueError("extension_key_required")
    if not secrets.compare_digest(stored_key_id, kid):
        raise ValueError("extension_key_mismatch")
    version = max(1, int(acc.get("extension_binding_version") or 0))
    now_ts = int(time.time())
    expires_at_ts = now_ts + CHALLENGE_TTL_SEC
    challenge_id = secrets.token_urlsafe(24)
    payload_obj = {
        "account_id": aid,
        "binding_version": version,
        "challenge_id": challenge_id,
        "chat_id": cid,
        "expires_at_ts": expires_at_ts,
        "key_id": stored_key_id,
        "nonce": _b64url_encode(secrets.token_bytes(32)),
        "purpose": use,
    }
    payload = json.dumps(payload_obj, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    with _CHALLENGE_LOCK:
        _purge_expired(now_ts)
        _CHALLENGES[challenge_id] = {
            **payload_obj,
            "payload": payload,
        }
    extension_crypto_debug(
        "challenge issued",
        chat_id=cid,
        account_id=aid,
        purpose=use,
        challenge_id=extension_debug_id(challenge_id),
        key_id=extension_debug_id(stored_key_id),
        binding_version=version,
        expires_at_ts=expires_at_ts,
    )
    return {
        "challenge_id": challenge_id,
        "payload": payload,
        "expires_at_ts": expires_at_ts,
        "binding_version": version,
        "key_id": stored_key_id,
    }


def verify_extension_challenge(
    *,
    challenge_id: str,
    signature: str,
    chat_id: int,
    account_id: str,
    key_id: str,
    purpose: str,
) -> bool:
    challenge_id = str(challenge_id or "").strip()
    cid = int(chat_id)
    aid = str(account_id or "acc_1").strip() or "acc_1"
    kid = str(key_id or "").strip().lower()
    use = str(purpose or "").strip().lower()
    signature_len = extension_signature_length(signature)
    extension_crypto_debug(
        "proof received",
        chat_id=cid,
        account_id=aid,
        purpose=use,
        challenge_id=extension_debug_id(challenge_id),
        key_id=extension_debug_id(kid),
        signature_len=signature_len,
    )

    now_ts = int(time.time())
    with _CHALLENGE_LOCK:
        _purge_expired(now_ts)
        row = _CHALLENGES.pop(challenge_id, None)
    common = {
        "chat_id": cid,
        "account_id": aid,
        "purpose": use,
        "challenge_id": extension_debug_id(challenge_id),
        "key_id": extension_debug_id(kid),
        "signature_len": signature_len,
    }
    if not row:
        return _proof_failed("challenge_missing_or_expired", **common)
    if int(row.get("expires_at_ts") or 0) < now_ts:
        return _proof_failed("challenge_expired", **common)
    if int(row.get("chat_id") or 0) != cid:
        return _proof_failed("chat_id_mismatch", **common)
    if str(row.get("account_id") or "") != aid:
        return _proof_failed("account_id_mismatch", **common)
    if str(row.get("key_id") or "") != kid:
        return _proof_failed("challenge_key_id_mismatch", **common)
    if str(row.get("purpose") or "") != use:
        return _proof_failed("purpose_mismatch", **common)

    binding_version = int(row.get("binding_version") or 0)
    acc = get_user_account(cid, aid) or {}
    if int(acc.get("extension_bound_chat_id") or 0) != cid:
        return _proof_failed("extension_not_bound", binding_version=binding_version, **common)
    if int(acc.get("extension_binding_version") or 0) != binding_version:
        return _proof_failed(
            "binding_version_mismatch",
            binding_version=binding_version,
            stored_binding_version=int(acc.get("extension_binding_version") or 0),
            **common,
        )
    if not secrets.compare_digest(str(acc.get("extension_key_id") or "").strip().lower(), kid):
        return _proof_failed("stored_key_id_mismatch", binding_version=binding_version, **common)
    if not verify_extension_signature(acc.get("extension_public_key_jwk"), str(row.get("payload") or ""), signature):
        return _proof_failed("bad_signature", binding_version=binding_version, **common)

    extension_crypto_debug(
        "proof verify OK",
        chat_id=cid,
        account_id=aid,
        purpose=use,
        challenge_id=extension_debug_id(challenge_id),
        key_id=extension_debug_id(kid),
        signature_len=signature_len,
        binding_version=binding_version,
    )
    return True
